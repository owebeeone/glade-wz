
## R1/R2 actual compiling original counterexamples RED
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/contracts/Cargo.toml', '-p', 'glade-crdt-recovery-codec', '--test', 'remediation1']
Exit: 101; wall: 0.771s
```text
   Compiling glade-crdt-recovery-codec v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-codec)
error[E0308]: mismatched types
  --> crdt-recovery-codec/tests/remediation1.rs:36:202
   |
36 | ...olicy:Bytes::new(vec![]),admission:Bytes::new(vec![]) } } }
   |                                       ^^^^^^^^^^^^^^^^^^ expected `Option<Bytes>`, found `Bytes`
   |
   = note: expected enum `Option<glade_crdt_recovery_codec::Bytes>`
            found struct `glade_crdt_recovery_codec::Bytes`
help: try wrapping the expression in `Some`
   |
36 | fn candidate(op:Operation)->Candidate { Candidate { instance:instance(),operation:op,evidence:EvidenceSet { certificate:Bytes::new(vec![]),permit:Bytes::new(vec![]),policy:Bytes::new(vec![]),admission:Some(Bytes::new(vec![])) } } }
   |                                                                                                                                                                                                          +++++                  +

For more information about this error, try `rustc --explain E0308`.
error: could not compile `glade-crdt-recovery-codec` (test "remediation1") due to 1 previous error

```

## R1/R2 actual assertion RED after test type correction
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/contracts/Cargo.toml', '-p', 'glade-crdt-recovery-codec', '--test', 'remediation1']
Exit: 101; wall: 1.217s
```text
   Compiling glade-crdt-recovery-codec v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-codec)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.65s
     Running tests/remediation1.rs (glade/contracts/target/debug/deps/remediation1-4606bedf9a4f1344)

running 6 tests
test root_operation_name_limit_applies_inside_opaque_canonical_bytes ... FAILED
test root_operation_depth_includes_the_embedded_interpretation_boundary ... FAILED
test concrete_container_roots_cannot_substitute_plan_for_guard ... FAILED
test root_operation_item_budget_includes_interpreted_refs_cumulatively ... FAILED
test nested_candidate_and_remote_transfer_cannot_hide_operation_name ... FAILED
test repeated_nested_operations_share_one_budget_not_one_budget_each ... FAILED

failures:

---- root_operation_name_limit_applies_inside_opaque_canonical_bytes stdout ----

thread 'root_operation_name_limit_applies_inside_opaque_canonical_bytes' (171565568) panicked at crdt-recovery-codec/tests/remediation1.rs:44:5:
assertion `left == right` failed
  left: Ok(Operation { inner: Op { share: "s", glade_id: "g", key: [1], origin: "ooooooooooooooooooooooooooooooooo", seq: 1, prev: None, lamport: 1, refs: [], shape: Crdt, payload: [1] }, canonical: Bytes { value: [170, 1, 97, 115, 2, 97, 103, 3, 65, 1, 4, 120, 33, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 5, 1, 6, 246, 7, 1, 8, 128, 9, 4, 10, 65, 1], digest: [138, 93, 239, 39, 2, 166, 169, 48, 92, 49, 241, 127, 30, 246, 68, 231, 47, 111, 11, 162, 14, 123, 119, 107, 212, 33, 59, 61, 199, 127, 220, 232] } })
 right: Err(Capacity)

---- root_operation_depth_includes_the_embedded_interpretation_boundary stdout ----

thread 'root_operation_depth_includes_the_embedded_interpretation_boundary' (171565566) panicked at crdt-recovery-codec/tests/remediation1.rs:57:5:
assertion `left == right` failed
  left: Ok(Operation { inner: Op { share: "s", glade_id: "g", key: [1], origin: "o", seq: 1, prev: None, lamport: 1, refs: [], shape: Crdt, payload: [1] }, canonical: Bytes { value: [170, 1, 97, 115, 2, 97, 103, 3, 65, 1, 4, 97, 111, 5, 1, 6, 246, 7, 1, 8, 128, 9, 4, 10, 65, 1], digest: [232, 204, 113, 117, 17, 108, 40, 3, 21, 204, 197, 240, 234, 110, 14, 202, 185, 125, 164, 236, 84, 225, 23, 162, 39, 198, 133, 246, 141, 181, 155, 60] } })
 right: Err(Capacity)

---- concrete_container_roots_cannot_substitute_plan_for_guard stdout ----

thread 'concrete_container_roots_cannot_substitute_plan_for_guard' (171565563) panicked at crdt-recovery-codec/tests/remediation1.rs:13:5:
assertion `left == right` failed
  left: Ok(GuardId { store: StoreIncarnation([1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]), instance: Instance { descriptor: [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2], incarnation: "i" }, number: 1 })
 right: Err(Invalid)
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace

---- root_operation_item_budget_includes_interpreted_refs_cumulatively stdout ----

thread 'root_operation_item_budget_includes_interpreted_refs_cumulatively' (171565567) panicked at crdt-recovery-codec/tests/remediation1.rs:51:5:
assertion `left == right` failed
  left: Ok(Operation { inner: Op { share: "s", glade_id: "g", key: [1], origin: "o", seq: 1, prev: None, lamport: 1, refs: [Head { origin: "r", seq: 0, hash: None }, Head { origin: "r", seq: 1, hash: None }, Head { origin: "r", seq: 2, hash: None }, Head { origin: "r", seq: 3, hash: None }, Head { origin: "r", seq: 4, hash: None }, Head { origin: "r", seq: 5, hash: None }, Head { origin: "r", seq: 6, hash: None }, Head { origin: "r", seq: 7, hash: None }, Head { origin: "r", seq: 8, hash: None }], shape: Crdt, payload: [1] }, canonical: Bytes { value: [170, 1, 97, 115, 2, 97, 103, 3, 65, 1, 4, 97, 111, 5, 1, 6, 246, 7, 1, 8, 137, 163, 1, 97, 114, 2, 0, 3, 246, 163, 1, 97, 114, 2, 1, 3, 246, 163, 1, 97, 114, 2, 2, 3, 246, 163, 1, 97, 114, 2, 3, 3, 246, 163, 1, 97, 114, 2, 4, 3, 246, 163, 1, 97, 114, 2, 5, 3, 246, 163, 1, 97, 114, 2, 6, 3, 246, 163, 1, 97, 114, 2, 7, 3, 246, 163, 1, 97, 114, 2, 8, 3, 246, 9, 4, 10, 65, 1], digest: [204, 163, 207, 151, 217, 149, 99, 236, 155, 138, 100, 124, 146, 242, 226, 14, 148, 25, 239, 110, 17, 88, 216, 62, 24, 192, 131, 50, 245, 43, 162, 159] } })
 right: Err(Capacity)

---- nested_candidate_and_remote_transfer_cannot_hide_operation_name stdout ----

thread 'nested_candidate_and_remote_transfer_cannot_hide_operation_name' (171565564) panicked at crdt-recovery-codec/tests/remediation1.rs:63:5:
assertion `left == right` failed
  left: Ok(Candidate { instance: Instance { descriptor: [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2], incarnation: "i" }, operation: Operation { inner: Op { share: "s", glade_id: "g", key: [1], origin: "ooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo", seq: 1, prev: None, lamport: 1, refs: [], shape: Crdt, payload: [1] }, canonical: Bytes { value: [170, 1, 97, 115, 2, 97, 103, 3, 65, 1, 4, 120, 129, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 111, 5, 1, 6, 246, 7, 1, 8, 128, 9, 4, 10, 65, 1], digest: [95, 110, 150, 116, 109, 234, 247, 76, 188, 76, 122, 156, 115, 176, 108, 249, 76, 91, 87, 65, 236, 60, 225, 254, 105, 218, 121, 126, 10, 9, 18, 48] } }, evidence: EvidenceSet { certificate: Bytes { value: [], digest: [227, 176, 196, 66, 152, 252, 28, 20, 154, 251, 244, 200, 153, 111, 185, 36, 39, 174, 65, 228, 100, 155, 147, 76, 164, 149, 153, 27, 120, 82, 184, 85] }, permit: Bytes { value: [], digest: [227, 176, 196, 66, 152, 252, 28, 20, 154, 251, 244, 200, 153, 111, 185, 36, 39, 174, 65, 228, 100, 155, 147, 76, 164, 149, 153, 27, 120, 82, 184, 85] }, policy: Bytes { value: [], digest: [227, 176, 196, 66, 152, 252, 28, 20, 154, 251, 244, 200, 153, 111, 185, 36, 39, 174, 65, 228, 100, 155, 147, 76, 164, 149, 153, 27, 120, 82, 184, 85] }, admission: None } })
 right: Err(Capacity)

---- repeated_nested_operations_share_one_budget_not_one_budget_each stdout ----

thread 'repeated_nested_operations_share_one_budget_not_one_budget_each' (171565565) panicked at crdt-recovery-codec/tests/remediation1.rs:75:5:
assertion `left == right` failed
  left: Ok([Candidate { instance: Instance { descriptor: [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2], incarnation: "i" }, operation: Operation { inner: Op { share: "s", glade_id: "g", key: [1], origin: "o", seq: 1, prev: None, lamport: 1, refs: [Head { origin: "r", seq: 0, hash: None }, Head { origin: "r", seq: 1, hash: None }, Head { origin: "r", seq: 2, hash: None }, Head { origin: "r", seq: 3, hash: None }, Head { origin: "r", seq: 4, hash: None }, Head { origin: "r", seq: 5, hash: None }, Head { origin: "r", seq: 6, hash: None }, Head { origin: "r", seq: 7, hash: None }], shape: Crdt, payload: [1] }, canonical: Bytes { value: [170, 1, 97, 115, 2, 97, 103, 3, 65, 1, 4, 97, 111, 5, 1, 6, 246, 7, 1, 8, 136, 163, 1, 97, 114, 2, 0, 3, 246, 163, 1, 97, 114, 2, 1, 3, 246, 163, 1, 97, 114, 2, 2, 3, 246, 163, 1, 97, 114, 2, 3, 3, 246, 163, 1, 97, 114, 2, 4, 3, 246, 163, 1, 97, 114, 2, 5, 3, 246, 163, 1, 97, 114, 2, 6, 3, 246, 163, 1, 97, 114, 2, 7, 3, 246, 9, 4, 10, 65, 1], digest: [238, 168, 184, 255, 189, 32, 178, 173, 114, 148, 117, 24, 217, 213, 120, 117, 215, 6, 214, 188, 31, 56, 20, 191, 126, 48, 8, 15, 139, 3, 36, 136] } }, evidence: EvidenceSet { certificate: Bytes { value: [], digest: [227, 176, 196, 66, 152, 252, 28, 20, 154, 251, 244, 200, 153, 111, 185, 36, 39, 174, 65, 228, 100, 155, 147, 76, 164, 149, 153, 27, 120, 82, 184, 85] }, permit: Bytes { value: [], digest: [227, 176, 196, 66, 152, 252, 28, 20, 154, 251, 244, 200, 153, 111, 185, 36, 39, 174, 65, 228, 100, 155, 147, 76, 164, 149, 153, 27, 120, 82, 184, 85] }, policy: Bytes { value: [], digest: [227, 176, 196, 66, 152, 252, 28, 20, 154, 251, 244, 200, 153, 111, 185, 36, 39, 174, 65, 228, 100, 155, 147, 76, 164, 149, 153, 27, 120, 82, 184, 85] }, admission: None } }, Candidate { instance: Instance { descriptor: [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2], incarnation: "i" }, operation: Operation { inner: Op { share: "s", glade_id: "g", key: [1], origin: "o", seq: 1, prev: None, lamport: 1, refs: [Head { origin: "r", seq: 0, hash: None }, Head { origin: "r", seq: 1, hash: None }, Head { origin: "r", seq: 2, hash: None }, Head { origin: "r", seq: 3, hash: None }, Head { origin: "r", seq: 4, hash: None }, Head { origin: "r", seq: 5, hash: None }, Head { origin: "r", seq: 6, hash: None }, Head { origin: "r", seq: 7, hash: None }], shape: Crdt, payload: [1] }, canonical: Bytes { value: [170, 1, 97, 115, 2, 97, 103, 3, 65, 1, 4, 97, 111, 5, 1, 6, 246, 7, 1, 8, 136, 163, 1, 97, 114, 2, 0, 3, 246, 163, 1, 97, 114, 2, 1, 3, 246, 163, 1, 97, 114, 2, 2, 3, 246, 163, 1, 97, 114, 2, 3, 3, 246, 163, 1, 97, 114, 2, 4, 3, 246, 163, 1, 97, 114, 2, 5, 3, 246, 163, 1, 97, 114, 2, 6, 3, 246, 163, 1, 97, 114, 2, 7, 3, 246, 9, 4, 10, 65, 1], digest: [238, 168, 184, 255, 189, 32, 178, 173, 114, 148, 117, 24, 217, 213, 120, 117, 215, 6, 214, 188, 31, 56, 20, 191, 126, 48, 8, 15, 139, 3, 36, 136] } }, evidence: EvidenceSet { certificate: Bytes { value: [], digest: [227, 176, 196, 66, 152, 252, 28, 20, 154, 251, 244, 200, 153, 111, 185, 36, 39, 174, 65, 228, 100, 155, 147, 76, 164, 149, 153, 27, 120, 82, 184, 85] }, permit: Bytes { value: [], digest: [227, 176, 196, 66, 152, 252, 28, 20, 154, 251, 244, 200, 153, 111, 185, 36, 39, 174, 65, 228, 100, 155, 147, 76, 164, 149, 153, 27, 120, 82, 184, 85] }, policy: Bytes { value: [], digest: [227, 176, 196, 66, 152, 252, 28, 20, 154, 251, 244, 200, 153, 111, 185, 36, 39, 174, 65, 228, 100, 155, 147, 76, 164, 149, 153, 27, 120, 82, 184, 85] }, admission: None } }])
 right: Err(Capacity)


failures:
    concrete_container_roots_cannot_substitute_plan_for_guard
    nested_candidate_and_remote_transfer_cannot_hide_operation_name
    repeated_nested_operations_share_one_budget_not_one_budget_each
    root_operation_depth_includes_the_embedded_interpretation_boundary
    root_operation_item_budget_includes_interpreted_refs_cumulatively
    root_operation_name_limit_applies_inside_opaque_canonical_bytes

test result: FAILED. 0 passed; 6 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

error: test failed, to rerun pass `-p glade-crdt-recovery-codec --test remediation1`

```

## R1 recursively concrete identities and R2 cumulative embedded limits GREEN
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/contracts/Cargo.toml', '-p', 'glade-crdt-recovery-codec', '--test', 'remediation1']
Exit: 101; wall: 2.913s
```text
   Compiling glade-crdt-recovery-codec v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-codec)
error[E0425]: cannot find type `BTreeMap` in this scope
   --> crdt-recovery-codec/src/schema/admission.rs:396:18
    |
396 |                 <BTreeMap<String, (i64, Digest)>>::preflight_value(&values[2], budget, depth + 1)?;
    |                  ^^^^^^^^ not found in this scope
    |
help: consider importing this struct
    |
  2 + use std::collections::BTreeMap;
    |

For more information about this error, try `rustc --explain E0425`.
error: could not compile `glade-crdt-recovery-codec` (lib) due to 1 previous error

```

## R4 qualification option set actual behavioral RED with valid content fixture
Command: ['python3', '-B', 'glade/contracts/crdt-recovery-codec/compat/test_gate.py', 'PinGateTests.test_python_and_shell_options_are_closed_before_qualification']
Exit: 1; wall: 0.417s
```text
F
======================================================================
FAIL: test_python_and_shell_options_are_closed_before_qualification (__main__.PinGateTests.test_python_and_shell_options_are_closed_before_qualification)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-codec/compat/test_gate.py", line 70, in test_python_and_shell_options_are_closed_before_qualification
    self.assertEqual(result.returncode, 2, command + arguments)
AssertionError: 0 != 2 : ['/Users/owebeeone/.asdf/installs/python/3.11.16/bin/python3', '/var/folders/02/bn9c9g2x5qj8bb42zb857p7c0000gn/T/tmpmibg9eti/codec/compat/gate.py', '/var/folders/02/bn9c9g2x5qj8bb42zb857p7c0000gn/T/tmpmibg9eti/codec', '--unknown']

----------------------------------------------------------------------
Ran 1 test in 0.345s

FAILED (failures=1)

```

## R6 capture help/default/output actual behavioral RED
Command: ['python3', '-B', '-m', 'unittest', 'tests.test_architecture.ProductionCrdtCaptureTests.test_capture_help_names_repository_default_paths_and_output_entry']
Exit: 1; wall: 0.830s
```text
F
======================================================================
FAIL: test_capture_help_names_repository_default_paths_and_output_entry (tests.test_architecture.ProductionCrdtCaptureTests.test_capture_help_names_repository_default_paths_and_output_entry)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Volumes/projects/limbo/gyld-wz/gyld/tests/test_architecture.py", line 5088, in test_capture_help_names_repository_default_paths_and_output_entry
    self.assertIn(phrase, help_text)
    ~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: 'Gyld application fixture checkout' not found in 'usage: python3.14 -m unittest [-h] [--repository REPOSITORY] --output OUTPUT\n\nIC3 allocation overlay; no runtime satisfaction or mutable sibling dependency.\n\noptions:\n  -h, --help            show this help message and exit\n  --repository REPOSITORY\n  --output OUTPUT\n'

----------------------------------------------------------------------
Ran 1 test in 0.647s

FAILED (failures=1)

```

## R1/R2 corrected compiling budget and identity controls
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/contracts/Cargo.toml', '-p', 'glade-crdt-recovery-codec', '--test', 'remediation1']
Exit: 0; wall: 2.670s
```text
   Compiling glade-crdt-recovery-codec v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-codec)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 2.14s
     Running tests/remediation1.rs (glade/contracts/target/debug/deps/remediation1-4606bedf9a4f1344)

running 6 tests
test root_operation_depth_includes_the_embedded_interpretation_boundary ... ok
test root_operation_name_limit_applies_inside_opaque_canonical_bytes ... ok
test root_operation_item_budget_includes_interpreted_refs_cumulatively ... ok
test nested_candidate_and_remote_transfer_cannot_hide_operation_name ... ok
test repeated_nested_operations_share_one_budget_not_one_budget_each ... ok
test concrete_container_roots_cannot_substitute_plan_for_guard ... ok

test result: ok. 6 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s


```

## R3 discarded assembly-provider witness actual wiring-mutant behavioral RED
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '-p', 'glade-node', '--test', 'ic3_boundary', 'consumer_detects_recovery_selection_mutant_instead_of_discarding_host', '--', '--exact']
Exit: 101; wall: 4.256s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
warning: unused import: `glade_crdt_evidence_api::*`
 --> tests/ic3_boundary.rs:4:5
  |
4 | use glade_crdt_evidence_api::*;
  |     ^^^^^^^^^^^^^^^^^^^^^^^^^^
  |
  = note: `#[warn(unused_imports)]` (part of `#[warn(unused)]`) on by default

warning: function `open_request` is never used
  --> tests/ic3_boundary.rs:96:4
   |
96 | fn open_request()->ReplicaOpen {
   |    ^^^^^^^^^^^^
   |
   = note: `#[warn(dead_code)]` (part of `#[warn(unused)]`) on by default

warning: `glade-node` (test "ic3_boundary") generated 2 warnings (run `cargo fix --test "ic3_boundary" -p glade-node` to apply 1 suggestion)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 3.43s
     Running tests/ic3_boundary.rs (glade/node/target/debug/deps/ic3_boundary-7f00c7b33e4a34f2)

running 1 test
test consumer_detects_recovery_selection_mutant_instead_of_discarding_host ... FAILED

failures:

---- consumer_detects_recovery_selection_mutant_instead_of_discarding_host stdout ----

thread 'consumer_detects_recovery_selection_mutant_instead_of_discarding_host' (171638725) panicked at tests/ic3_boundary.rs:119:5:
assertion `left == right` failed
  left: Err(Unavailable)
 right: Ok(())
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace


failures:
    consumer_detects_recovery_selection_mutant_instead_of_discarding_host

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 4 filtered out; finished in 0.00s

error: test failed, to rerun pass `-p glade-node --test ic3_boundary`

```

## R3 actual returned host/evidence consumers and selection mutant GREEN
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '-p', 'glade-node', '--test', 'ic3_boundary']
Exit: 0; wall: 2.176s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 1.45s
     Running tests/ic3_boundary.rs (glade/node/target/debug/deps/ic3_boundary-7f00c7b33e4a34f2)

running 6 tests
test production_composition_recovers_a_genuinely_persistent_validated_image ... ignored, IC3B real host restart success deliberately remains RED before typed acceptance
test standalone_refuser_has_no_fabricated_validated_image ... ok
test standalone_refuser_never_issues_a_consume_permit ... ok
test standalone_refuser_rejects_caller_created_permit_before_callback ... ok
test consumer_detects_recovery_selection_mutant_instead_of_discarding_host ... ok
test actual_assembled_evidence_verify_seal_and_observe_refuse ... ok

test result: ok. 5 passed; 0 failed; 1 ignored; 0 measured; 0 filtered out; finished in 0.00s


```

## R4 closed option set GREEN nonrecursive fixture
Command: ['python3', '-B', 'glade/contracts/crdt-recovery-codec/compat/test_gate.py', 'PinGateTests.test_python_and_shell_options_are_closed_before_qualification']
Exit: 0; wall: 0.165s
```text
.
----------------------------------------------------------------------
Ran 1 test in 0.111s

OK

```

## R3 future success follows actual assembled open and stays RED pending B
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '-p', 'glade-node', '--test', 'ic3_boundary', 'production_composition_recovers_a_genuinely_persistent_validated_image', '--', '--exact', '--ignored']
Exit: 101; wall: 0.182s
```text
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.15s
     Running tests/ic3_boundary.rs (glade/node/target/debug/deps/ic3_boundary-7f00c7b33e4a34f2)

running 1 test
test production_composition_recovers_a_genuinely_persistent_validated_image ... FAILED

failures:

---- production_composition_recovers_a_genuinely_persistent_validated_image stdout ----

thread 'production_composition_recovers_a_genuinely_persistent_validated_image' (171657630) panicked at tests/ic3_boundary.rs:54:10:
IC3B assembled open must supply its session: Unavailable
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace


failures:
    production_composition_recovers_a_genuinely_persistent_validated_image

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 5 filtered out; finished in 0.00s

error: test failed, to rerun pass `-p glade-node --test ic3_boundary`

```

## R6 capture help/default/output workflow GREEN
Command: ['python3', '-B', '-m', 'unittest', 'tests.test_architecture.ProductionCrdtCaptureTests.test_capture_help_names_repository_default_paths_and_output_entry']
Exit: 1; wall: 0.762s
```text
F
======================================================================
FAIL: test_capture_help_names_repository_default_paths_and_output_entry (tests.test_architecture.ProductionCrdtCaptureTests.test_capture_help_names_repository_default_paths_and_output_entry)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Volumes/projects/limbo/gyld-wz/gyld/tests/test_architecture.py", line 5094, in test_capture_help_names_repository_default_paths_and_output_entry
    self.assertIn(phrase, help_text)
    ~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: 'relative to the current working directory' not found in 'usage: python3.14 -m unittest [-h] [--repository REPOSITORY] --output OUTPUT\n\nIC3 allocation overlay; no runtime satisfaction or mutable sibling dependency.\n\noptions:\n  -h, --help            show this help message and exit\n  --repository REPOSITORY\n                        Gyld application fixture checkout (default: the\n                        application checkout containing this script); a\n                        relative path is relative to the current working\n                        directory\n  --output OUTPUT       required new directory for generated snapshot.json;\n                        relative paths are relative to the current working\n                        directory; existing directories refuse\n'

----------------------------------------------------------------------
Ran 1 test in 0.602s

FAILED (failures=1)

```

## R6 help workflow GREEN normalized argparse wrapping
Command: ['python3', '-B', '-m', 'unittest', 'tests.test_architecture.ProductionCrdtCaptureTests.test_capture_help_names_repository_default_paths_and_output_entry']
Exit: 0; wall: 0.669s
```text
.
----------------------------------------------------------------------
Ran 1 test in 0.555s

OK

```

## R2 binary batch embedded operations aggregate-item RED
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/contracts/Cargo.toml', '-p', 'glade-crdt-recovery-codec', '--test', 'batch_decode', 'batch_operations_share_the_existing_aggregate_item_budget', '--', '--exact']
Exit: 101; wall: 0.882s
```text
   Compiling glade-crdt-recovery-codec v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-codec)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.36s
     Running tests/batch_decode.rs (glade/contracts/target/debug/deps/batch_decode-c338073ef4bd3146)

running 1 test
test batch_operations_share_the_existing_aggregate_item_budget ... FAILED

failures:

---- batch_operations_share_the_existing_aggregate_item_budget stdout ----

thread 'batch_operations_share_the_existing_aggregate_item_budget' (171732562) panicked at crdt-recovery-codec/tests/batch_decode.rs:134:5:
embedded operation syntax must consume aggregate item budget
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace


failures:
    batch_operations_share_the_existing_aggregate_item_budget

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 2 filtered out; finished in 0.00s

error: test failed, to rerun pass `-p glade-crdt-recovery-codec --test batch_decode`

```

## R1/R2 all codec original and remediation controls GREEN
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/contracts/Cargo.toml', '-p', 'glade-crdt-recovery-codec', '--all-targets']
Exit: 0; wall: 8.213s
```text
   Compiling glade-crdt-recovery-codec v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-codec)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 2.11s
     Running unittests src/lib.rs (glade/contracts/target/debug/deps/glade_crdt_recovery_codec-249926a6c91406e4)

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/batch_decode.rs (glade/contracts/target/debug/deps/batch_decode-c338073ef4bd3146)

running 3 tests
test unchanged_private_encoder_has_a_complete_bounded_decoder ... ok
test batch_operations_share_the_existing_aggregate_item_budget ... ok
test interned_blob_references_cannot_amplify_owned_decoding_past_budget ... ok

test result: ok. 3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/image.rs (glade/contracts/target/debug/deps/image-ff97efb1b877942d)

running 4 tests
test interrupted_intent_preserves_issuance_and_guard_floors_without_next_image ... ok
test full_image_retains_all_kernel_callbacks_attempts_guards_issuance_and_loss ... ok
test image_hash_and_external_selection_do_not_require_a_hash_fixed_point ... ok
test corrupt_truncated_trailing_unknown_versions_and_capacity_fail_closed ... ok

test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.82s

     Running tests/remediation1.rs (glade/contracts/target/debug/deps/remediation1-4606bedf9a4f1344)

running 6 tests
test root_operation_depth_includes_the_embedded_interpretation_boundary ... ok
test root_operation_name_limit_applies_inside_opaque_canonical_bytes ... ok
test root_operation_item_budget_includes_interpreted_refs_cumulatively ... ok
test nested_candidate_and_remote_transfer_cannot_hide_operation_name ... ok
test repeated_nested_operations_share_one_budget_not_one_budget_each ... ok
test concrete_container_roots_cannot_substitute_plan_for_guard ... ok

test result: ok. 6 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/roundtrip.rs (glade/contracts/target/debug/deps/roundtrip-afbf6185948b82a4)

running 6 tests
test accepted_signature_domains_are_full_and_zero_terminated ... ok
test remote_profile_is_exact_canonical_integer_key_map_without_recovery_magic ... ok
test type_domain_cannot_substitute_plan_identity_for_receive_guard ... ok
test inventory_empty_is_exact_observation_not_a_completeness_claim ... ok
test proof_body_requires_exact_purpose_version_signature_shape_and_type ... ok
test identity_roundtrip_preserves_full_namespaces_and_unsigned_floor ... ok

test result: ok. 6 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/source_boundaries.rs (glade/contracts/target/debug/deps/source_boundaries-b49e6bf7138dd73f)

running 3 tests
test checks_disabled_branch_instead_of_skipping_cfg ... ok
test disabled_associated_foreign_and_field_declarations_are_checked ... ok
test tranche_sources_have_explicit_conditional_boundaries ... ok

test result: ok. 3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.08s

     Running tests/vectors.rs (glade/contracts/target/debug/deps/vectors-e6054aa97de7077a)

running 4 tests
test closed_maps_reject_unknown_duplicate_reordered_or_wrong_context_fields ... ok
test bounded_malformed_canonical_vectors_fail_closed ... ok
test malformed_signature_length_and_wrong_exact_domain_refuse_signed_envelope_shape ... ok
test all_remote_profile_categories_derive_exact_bytes_and_digests_from_semantic_inputs ... ok

test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s


```

## Independent Python semantic representation controls
Command: ['python3', '-B', 'glade/contracts/crdt-recovery-codec/compat/python.py', 'glade/contracts/crdt-recovery-codec']
Exit: 0; wall: 0.040s
```text
Python independent profile vectors: 21 positive + negative controls PASS

```

## Independent TypeScript semantic representation controls
Command: ['node', '--experimental-transform-types', 'glade/contracts/crdt-recovery-codec/compat/typescript.ts', 'glade/contracts/crdt-recovery-codec']
Exit: 0; wall: 0.117s
```text
(node:85828) ExperimentalWarning: Transform Types is an experimental feature and might change at any time
(Use `node --trace-warnings ...` to show where the warning was created)
TypeScript independent profile vectors: 21 positive + 18 negative controls PASS

```

## Glade process globals retained policy
Command: ['python3', 'glade/scripts/checks/check_process_globals.py']
Exit: 0; wall: 0.609s
```text
process-global state guard: 107 files, 3 allowlisted items (0 debt, 3 permanent); nothing new

```

## Affected node architecture adopter
Command: ['cargo', 'run', '--quiet', '--locked', '--offline', '--manifest-path', 'glade-discover/tools/architecture-check/Cargo.toml', '--', 'glade/node']
Exit: 0; wall: 0.735s
```text
Architecture boundaries: PASS (workspace libraries, declared dependencies, traits and conformance targets)

```

## Remediation scoped contracts adopter gate
Command: ['sh', 'glade/contracts/check.sh', 'crdt-production']
Exit: 0; wall: 9.383s
```text
Architecture boundaries: PASS (workspace libraries, declared dependencies, traits and conformance targets)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.04s
     Running unittests src/lib.rs (glade/contracts/target/debug/deps/glade_crdt_admission_core-932f6277b6041d9c)

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/encoder_complete.rs (glade/contracts/target/debug/deps/encoder_complete-0c61aeec9660768e)

running 10 tests
test candidate::all_candidate_evidence_and_inner_op_bytes ... ok
test fork::fork_pairs_have_complete_candidate_identity_and_evidence ... ok
test plan::namespaces_issuance_owner_and_storage_promise_are_part_of_bytes ... ok
test plan::complete_plan_header_and_optional_local_cut ... ok
test descriptor::all_descriptor_parsed_fields_and_bounds ... ok
test stage::all_staged_candidate_seal_and_receipt_fields ... ok
test facts::all_staged_facts_and_certificate_fields ... ok
test verify::full_verification_query_continuations ... ok
test seal_scope::full_seal_descriptor_and_evidence ... ok
test seal::full_sealing_query_continuations ... ok

test result: ok. 10 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

     Running tests/fixture_composition.rs (glade/contracts/target/debug/deps/fixture_composition-65d2eb16df52c7d1)

running 7 tests
test historical_prior_cut_fixture_registers_multiline_inspect_through_full_helper ... ok
test mandatory_text_replica_journeys_do_not_construct_fresh_host_per_drive_call ... ok
test lookup_fixture_owns_full_request_and_bounded_history_not_only_secondary_index ... ok
test trusted_seed_retains_reservations_outcomes_and_rejects_inconsistent_history ... ok
test configured_provider_matches_core_cut_and_changes_independently ... ok
test seeded_terminal_requires_original_custody_and_accounting ... ok
test seeded_custody_is_explicit_and_consecutive_port_publications_keep_history ... ok

test result: ok. 7 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/kernel_edges.rs (glade/contracts/target/debug/deps/kernel_edges-0e6067bcb16c3e14)

running 21 tests
test admission::retained_candidates_and_verifications_share_pending_capacity ... ok
test admission::restored_fork_cut_derives_one_coherent_quarantine_and_eligible_set ... ok
test encoder::storage_batch_limit_refuses_before_any_prepare_or_invocation ... ok
test admission::pending_origins_reserve_the_origin_limit_before_verification ... ok
test admission::oversized_proof_cannot_allocate_a_verification_continuation ... ok
test admission::outstanding_verification_prevents_complete_local_and_is_bounded ... ok
test frontier::already_retained_exact_frontier_hash_preserves_complete_local ... ok
test frontier::frontier_union_cannot_exceed_pending_items_or_clear_previous_observation ... ok
test frontier::empty_peer_frontier_offers_all_local_history ... ok
test encoder::full_encoded_continuation_footprint_consumes_edit_quota ... ok
test storage::lost_prepare_ack_can_recover_original_plan_while_original_invocation_is_live ... ok
test storage::prepared_reply_cannot_replace_original_attempt_mapping ... ok
test frontier::different_arriving_hash_cannot_complete_an_announced_missing_slot ... ok
test admission::committed_local_custody_retains_the_actual_seal_named_by_original_receipt ... ok
test encoder::unretained_historical_batch_due_to_encoder_limit_is_sticky_incomplete ... ok
test storage::prepare_request_from_retained_old_owner_has_no_current_callback_authority ... ok
test admission::no_prior_admission_local_intent_keeps_real_seal_for_historical_replay ... ok
test admission::signed_historical_rival_outside_permit_sequence_is_security_not_conviction ... ok
test admission::signed_invalid_payload_is_security_custody_without_conviction ... ok
test frontier::announced_missing_frontier_survives_unrelated_publication ... ok
test encoder::encoder_is_deterministic_and_binds_descriptor_facts_and_seal_continuations ... ok

test result: ok. 21 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/records_host_contract.rs (glade/contracts/target/debug/deps/records_host_contract-377bbaa390d43bf2)

running 22 tests
test icd006_stale_verification_after_policy_change_cannot_seal_or_commit ... ok
test icd003_legacy_and_strong_descriptors_do_not_activate_independent_admission ... ok
test icd007_zero_base_prev_refs_and_exact_safe_numbers ... ok
test icd004_same_display_names_do_not_share_instance_rights_or_callbacks ... ok
test icd006_offline_window_and_clock_uncertainty_refuse_new_intent ... ok
test icd005_evidence_reply_binds_mode_bytes_scope_and_candidate ... ok
test icd007_reused_canonical_origin_and_numeric_overflow_refuse ... ok
test icd006_delayed_prior_cut_committed_callback_retains_historical_admission ... ok
test icd010_old_receipt_retry_does_not_reauthorize_or_reappend ... ok
test icd006_historical_authorization_is_separate_from_current_revocation ... ok
test icd007_new_epoch_uses_new_origin_and_old_retries_stay_old ... ok
test icd010_lookup_recovery_binds_request_and_restores_original_receipt ... ok
test icd002_partitioned_admission_commits_without_a_holder ... ok
test icd010_commit_callbacks_bind_batch_revision_and_have_three_distinct_outcomes ... ok
test icd010_unknown_commit_retains_reservation_and_foreign_callback_cannot_accept ... ok
test icd013_recovery_exhaustion_is_explicit_and_cannot_spend_edit_budget ... ok
test prior_cut_inspect40_distinguishes_issued_authority_from_identical_unissued_reply ... ok
test icd013_edit_capacity_preserves_recovery_reserves ... ok
test icd008_successor_requests_predecessor_without_advancing_head ... ok
test icd009_qualified_dependent_custody_survives_quarantined_support_but_local_intent_refuses ... ok
test icd009_two_qualified_rivals_quarantine_both_and_dependents_in_either_order ... ok
test icd006_revoked_expired_unadmitted_rival_preserves_ad_and_receipts ... ok

test result: ok. 22 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

     Running tests/recovery_contract.rs (glade/contracts/target/debug/deps/recovery_contract-8cab13edcccedff2)

running 6 tests
test lookup_invocation_counter_exhaustion_refuses_without_wrap_or_reservation_loss ... ok
test trusted_restoration_invalidates_live_lookup_and_preserves_identity_high_water ... ok
test retention_committed_lookup_binds_batch_storage_revision_and_empty_receipts ... ok
test repeated_unknown_lookup_retires_invocation_and_old_replies_preserve_new_lookup ... ok
test genuine_e0_fork_then_fresh_e1_local_recovery_keeps_ab_and_old_receipts_both_orders ... ok
test every_atomic_kind_recovers_committed_absent_and_unknown_without_fake_admission ... ok

test result: ok. 6 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.02s

     Running tests/remediation1.rs (glade/contracts/target/debug/deps/remediation1-be8535f3fccf7f31)

running 16 tests
test frontier::frontier_bytes_include_existing_candidate_charge_and_parked_verification ... ok
test frontier::frontier_retained_slot_aggregate_bytes_exact_boundary_and_one_over ... ok
test pending::frontier_cannot_steal_slots_reserved_by_an_unpublished_candidate_plan ... ok
test exhaustion::local_intent_counter_refusal_alone_does_not_taint_known_history ... ok
test frontier::frontier_names_empty_exact_limit_over_limit_and_huge_are_bounded ... ok
test pending::multiple_candidates_and_frontier_slots_share_deduplicated_prospective_cap ... ok
test exhaustion::historical_query_exhaustion_remains_sticky_through_resume_restore ... ok
test pending::predecessor_and_ref_to_the_same_missing_slot_emit_one_request ... ok
test pending::prospective_two_missing_slots_refuse_before_emission_or_candidate_staging ... ok
test integrity::already_qualified_fork_cannot_stage_new_work_after_stop ... ok
test pending::exact_slot_limit_and_overlap_union_commit_without_duplicate_reservations ... ok
test exhaustion::historical_plan_exhaustion_remains_sticky_through_resume_restore ... ok
test terminal::late_pending_and_refused_never_reopen_an_authentic_terminal ... ok
test integrity::integrity_stop_preserves_owned_started_attempt_and_genuine_late_commit ... ok
test integrity::parked_verification_and_seal_cannot_create_new_work_after_authenticated_stop ... ok
test terminal::held_started_and_terminal_inspect_both_orders_all_four_kinds_and_outcomes ... ok

test result: ok. 16 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

     Running tests/remediation2.rs (glade/contracts/target/debug/deps/remediation2-c6ddfa10c99b9612)

running 3 tests
test fresh_historical_offer_during_held_started_a_is_explicitly_incomplete ... ok
test two_issued_queries_verified_historical_b_during_held_started_a_is_explicitly_incomplete ... ok
test local_intent_only_busy_refusal_does_not_taint_known_history ... ok

test result: ok. 3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

     Running tests/representation.rs (glade/contracts/target/debug/deps/representation-b4c77cef7d79e0fa)

running 2 tests
test operation_bytes_and_digest_are_derived_and_owned ... ok
test pure_step_is_deterministic_preserves_caller_input_and_read_only_state ... ok

test result: ok. 2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/source_boundaries.rs (glade/contracts/target/debug/deps/source_boundaries-cfcb6000711a5cc4)

running 4 tests
test ic3_data_boundary_is_independent_of_the_pure_algorithm ... ok
test checks_disabled_branch_instead_of_skipping_cfg ... ok
test disabled_associated_foreign_and_field_declarations_are_checked ... ok
test tranche_sources_have_explicit_conditional_boundaries ... ok

test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.11s

     Running tests/storage_attempt_contract.rs (glade/contracts/target/debug/deps/storage_attempt_contract-a98f1e5df7b04b9e)

running 15 tests
test sta009_restored_attempt_and_invocation_floors_preserve_pending ... ok
test sta008_critical_pending_does_not_release_semantic_reservation ... ok
test sta006_current_prestart_observation_emits_fence_without_erasing_plan ... ok
test identical_unissued_lookup_reply_cannot_acquire_callback_authority ... ok
test sta001_callback_complete_binding_and_finite_invocation_namespace ... ok
test sta005_unissued_foreign_or_changed_retired_callback_cannot_create_integrity_stop ... ok
test sta005_contradictory_terminal_stops_instance_after_once_only_installation ... ok
test issued_lookup_retains_full_request_on_consumption ... ok
test sta010_overflow_is_sticky_distinct_from_charges_and_partial_repair ... ok
test sta003_pending_lookup_retains_started_write_until_late_commit_all_kinds ... ok
test sta007_all_kinds_install_original_terminal_without_double_charge ... ok
test sta002_kernel_prepare_keeps_exact_plan_after_lost_ack ... ok
test sta004_noncommit_retains_tombstone_and_rescheduling_uses_fresh_plan ... ok
test sta011_driver_uses_caller_owned_session_across_continuations ... ok
test sta011_existing_twenty_seven_and_text_consumers_keep_actual_port_path ... ok

test result: ok. 15 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running unittests src/lib.rs (glade/contracts/target/debug/deps/glade_crdt_admission_data-829261682f5780f4)

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/representation.rs (glade/contracts/target/debug/deps/representation-a11dd961075c09ca)

running 1 test
test canonical_operation_owns_bytes_and_recomputes_digest ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/source_boundaries.rs (glade/contracts/target/debug/deps/source_boundaries-15d7213681b61363)

running 3 tests
test checks_disabled_branch_instead_of_skipping_cfg ... ok
test disabled_associated_foreign_and_field_declarations_are_checked ... ok
test tranche_sources_have_explicit_conditional_boundaries ... ok

test result: ok. 3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

     Running unittests src/lib.rs (glade/contracts/target/debug/deps/glade_crdt_evidence_api-0ab689c801ef5981)

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/public_contract.rs (glade/contracts/target/debug/deps/public_contract-a450847ecdbb9cfb)

running 2 tests
test concrete_provider_must_supply_all_three_trusted_operations ... ok
test required_evidence_methods_have_no_default_provider ... ok

test result: ok. 2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/source_boundaries.rs (glade/contracts/target/debug/deps/source_boundaries-d9ef5b5c6b238cc5)

running 3 tests
test checks_disabled_branch_instead_of_skipping_cfg ... ok
test disabled_associated_foreign_and_field_declarations_are_checked ... ok
test tranche_sources_have_explicit_conditional_boundaries ... ok

test result: ok. 3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

     Running unittests src/lib.rs (glade/contracts/target/debug/deps/glade_crdt_recovery_api-86172c5c56e8b27f)

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/public_contract.rs (glade/contracts/target/debug/deps/public_contract-5bc6e82aa5aa7537)

running 7 tests
test issued_guard_identity_is_not_reissued_by_same_session ... ok
test another_authority_refuses_before_constructing_or_consuming_future ... ok
test cancelled_started_async_receive_does_not_imply_drain_or_abandon ... ok
test issuer_capacity_is_finite_and_retirement_does_not_reissue_history ... ok
test abandoned_capability_cannot_start_work_again ... ok
test live_never_started_owned_guard_can_abandon_only_once ... ok
test owned_receive_drains_before_settlement_and_close ... ok

test result: ok. 7 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/source_boundaries.rs (glade/contracts/target/debug/deps/source_boundaries-d87c63d050de1dbe)

running 4 tests
test checks_disabled_branch_instead_of_skipping_cfg ... ok
test disabled_associated_foreign_and_field_declarations_are_checked ... ok
test actual_node_independent_subtree_and_disabled_branches_are_checked ... ok
test tranche_sources_have_explicit_conditional_boundaries ... ok

test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

     Running unittests src/lib.rs (glade/contracts/target/debug/deps/glade_crdt_recovery_codec-249926a6c91406e4)

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/batch_decode.rs (glade/contracts/target/debug/deps/batch_decode-c338073ef4bd3146)

running 3 tests
test unchanged_private_encoder_has_a_complete_bounded_decoder ... ok
test batch_operations_share_the_existing_aggregate_item_budget ... ok
test interned_blob_references_cannot_amplify_owned_decoding_past_budget ... ok

test result: ok. 3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/image.rs (glade/contracts/target/debug/deps/image-ff97efb1b877942d)

running 4 tests
test interrupted_intent_preserves_issuance_and_guard_floors_without_next_image ... ok
test full_image_retains_all_kernel_callbacks_attempts_guards_issuance_and_loss ... ok
test image_hash_and_external_selection_do_not_require_a_hash_fixed_point ... ok
test corrupt_truncated_trailing_unknown_versions_and_capacity_fail_closed ... ok

test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.13s

     Running tests/remediation1.rs (glade/contracts/target/debug/deps/remediation1-4606bedf9a4f1344)

running 6 tests
test root_operation_name_limit_applies_inside_opaque_canonical_bytes ... ok
test root_operation_depth_includes_the_embedded_interpretation_boundary ... ok
test root_operation_item_budget_includes_interpreted_refs_cumulatively ... ok
test nested_candidate_and_remote_transfer_cannot_hide_operation_name ... ok
test repeated_nested_operations_share_one_budget_not_one_budget_each ... ok
test concrete_container_roots_cannot_substitute_plan_for_guard ... ok

test result: ok. 6 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/roundtrip.rs (glade/contracts/target/debug/deps/roundtrip-afbf6185948b82a4)

running 6 tests
test accepted_signature_domains_are_full_and_zero_terminated ... ok
test type_domain_cannot_substitute_plan_identity_for_receive_guard ... ok
test remote_profile_is_exact_canonical_integer_key_map_without_recovery_magic ... ok
test inventory_empty_is_exact_observation_not_a_completeness_claim ... ok
test proof_body_requires_exact_purpose_version_signature_shape_and_type ... ok
test identity_roundtrip_preserves_full_namespaces_and_unsigned_floor ... ok

test result: ok. 6 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/source_boundaries.rs (glade/contracts/target/debug/deps/source_boundaries-b49e6bf7138dd73f)

running 3 tests
test checks_disabled_branch_instead_of_skipping_cfg ... ok
test disabled_associated_foreign_and_field_declarations_are_checked ... ok
test tranche_sources_have_explicit_conditional_boundaries ... ok

test result: ok. 3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.05s

     Running tests/vectors.rs (glade/contracts/target/debug/deps/vectors-e6054aa97de7077a)

running 4 tests
test closed_maps_reject_unknown_duplicate_reordered_or_wrong_context_fields ... ok
test malformed_signature_length_and_wrong_exact_domain_refuse_signed_envelope_shape ... ok
test bounded_malformed_canonical_vectors_fail_closed ... ok
test all_remote_profile_categories_derive_exact_bytes_and_digests_from_semantic_inputs ... ok

test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running unittests src/lib.rs (glade/contracts/target/debug/deps/glade_crdt_storage_attempt_api-183ed550d5084400)

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/conformance_mutants.rs (glade/contracts/target/debug/deps/conformance_mutants-62cbd41425c44fca)

running 1 test
test shared_public_port_probe_accepts_fixture_and_rejects_six_semantic_mutants ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/public_contract.rs (glade/contracts/target/debug/deps/public_contract-5dd65e92533e6d9b)

running 28 tests
test finite_attempt_invocation_and_name_bounds_refuse_without_wrap ... ok
test historical_accepted_batch_keeps_original_receipt_without_local_prestart ... ok
test host_serialized_observation_cannot_be_replaced_by_caller_current_claim ... ok
test restoration_rejects_corrupt_cardinality_floor_and_history_limit ... ok
test lost_prepare_ack_and_queued_late_prepare_recover_exactly_one_attempt ... ok
test restored_noncommit_must_retain_its_bindings_unchanged_revision ... ok
test authentic_two_commit_recovery_rejects_distinct_duplicate_revision ... ok
test restored_capacity_and_binding_phase_consistency_are_validated ... ok
test restored_started_and_committed_cuts_must_fit_their_immutable_windows ... ok
test full_retained_commit_history_rejects_missing_head_gaps_and_unbacked_current_revision ... ok
test restoration_rejects_identity_and_unresolved_overlap_but_keeps_history_and_y ... ok
test sta001_exact_binding_exhaustion_and_invocation_identity ... ok
test sequential_commits_repeated_noncommit_and_independent_revision_spaces_restore ... ok
test sta003_absent_terminal_is_pending_for_all_kinds ... ok
test sta002_exact_plan_dedup_no_overlap_and_independent_instances ... ok
test sta008_critical_reserve_exhaustion_cannot_manufacture_negative_finality ... ok
test sta004_fence_excludes_late_begin_and_reprepare_uses_new_identity ... ok
test sta005_commit_wins_fence_race_and_receipts_are_original ... ok
test sta007_retention_receipts_cannot_be_synthetic ... ok
test sta006_prestart_checks_entire_window_and_historical_has_no_current_admit_check ... ok
test sta009_exclusive_recovery_and_close_keep_issuance_floors ... ok
test started_absent_lookup_late_publication_and_fence_use_same_predicate ... ok
test reopen_validates_retained_consumption_before_changing_owner_or_floors ... ok
test started_cut_is_not_rechecked_after_revocation_or_delayed_begin_ack ... ok
test trusted_observation_injection_has_finite_instance_and_name_bounds ... ok
test validated_restore_retains_all_attempts_and_invocation_namespace_without_auto_commit ... ok
test sparse_invocation_restore_preserves_actual_remaining_capacity ... ok
test fresh_revision_mismatch_refuses_before_reserved_or_queued_for_every_kind ... ok

test result: ok. 28 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/source_boundaries.rs (glade/contracts/target/debug/deps/source_boundaries-625bf4e5641d0a44)

running 5 tests
test checks_disabled_branch_instead_of_skipping_cfg ... ok
test disabled_associated_foreign_and_field_declarations_are_checked ... ok
test rejects_missing_identity_callback_ownership_and_terminality_fields ... ok
test actual_port_preserves_required_boundary_shape ... ok
test tranche_sources_have_explicit_conditional_boundaries ... ok

test result: ok. 5 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.04s

   Doc-tests glade_crdt_admission_core

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

   Doc-tests glade_crdt_admission_data

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

   Doc-tests glade_crdt_evidence_api

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

   Doc-tests glade_crdt_recovery_api

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

   Doc-tests glade_crdt_recovery_codec

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

   Doc-tests glade_crdt_storage_attempt_api

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

    Checking glade-crdt-recovery-codec v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-codec)
    Finished `dev` profile [unoptimized + debuginfo] target(s) in 1.41s

```

## R3 actual assembly and retained standalone controls
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_boundary']
Exit: 0; wall: 1.901s
```text
    Blocking waiting for file lock on package cache
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 1.16s
     Running tests/ic3_boundary.rs (glade/node/target/debug/deps/ic3_boundary-7f00c7b33e4a34f2)

running 6 tests
test production_composition_recovers_a_genuinely_persistent_validated_image ... ignored, IC3B assembled open and validated recovery success remain RED; physical restart is deferred
test standalone_refuser_has_no_fabricated_validated_image ... ok
test standalone_refuser_never_issues_a_consume_permit ... ok
test standalone_refuser_rejects_caller_created_permit_before_callback ... ok
test consumer_detects_recovery_selection_mutant_instead_of_discarding_host ... ok
test actual_assembled_evidence_verify_seal_and_observe_refuse ... ok

test result: ok. 5 passed; 0 failed; 1 ignored; 0 measured; 0 filtered out; finished in 0.00s


```

## Gyld architecture policy gate
Command: ['python3', '-B', 'scripts/check_architecture.py']
Exit: 0; wall: 0.140s
```text
architecture check passed

```

## Gyld affected Python lint
Command: ['uvx', '--quiet', 'ruff@0.13.0', 'check', 'scripts/capture_glade_crdt_production.py', 'tests/test_architecture.py']
Exit: 0; wall: 0.168s
```text
All checks passed!

```

## Gyld affected Python formatting
Command: ['uvx', '--quiet', 'ruff@0.13.0', 'format', '--check', 'scripts/capture_glade_crdt_production.py', 'tests/test_architecture.py']
Exit: 0; wall: 0.171s
```text
2 files already formatted

```

## Gyld owner five-second affected architecture selection
Command: ['python3', '-B', 'scripts/test_fast.py', 'architecture', '--affected']
Exit: 0; wall: 3.093s
```text
test_every_lens_is_listed_and_full_is_named_as_not_emitted (tests.test_architecture.ArchitectureLineageDocumentTests.test_every_lens_is_listed_and_full_is_named_as_not_emitted) ... ok
test_the_index_lists_both_lineages_once (tests.test_architecture.ArchitectureLineageDocumentTests.test_the_index_lists_both_lineages_once) ... ok
test_the_record_names_the_snapshot_and_carries_no_overlay (tests.test_architecture.ArchitectureLineageDocumentTests.test_the_record_names_the_snapshot_and_carries_no_overlay) ... ok
test_a_tool_test_may_own_an_io_module_without_a_package_dependency_policy (tests.test_architecture.ArchitectureTests.test_a_tool_test_may_own_an_io_module_without_a_package_dependency_policy) ... ok
test_affected_selection_includes_transitive_consumers_not_unrelated_packages (tests.test_architecture.ArchitectureTests.test_affected_selection_includes_transitive_consumers_not_unrelated_packages) ... ok
test_declared_fixture_loader_has_only_narrow_filesystem_allowance (tests.test_architecture.ArchitectureTests.test_declared_fixture_loader_has_only_narrow_filesystem_allowance) ... ok
test_dynamic_imports_are_rejected (tests.test_architecture.ArchitectureTests.test_dynamic_imports_are_rejected) ... ok
test_fast_and_io_module_selection_are_separate (tests.test_architecture.ArchitectureTests.test_fast_and_io_module_selection_are_separate) ... ok
test_fast_runner_selects_only_existing_named_modules (tests.test_architecture.ArchitectureTests.test_fast_runner_selects_only_existing_named_modules) ... ok
test_fixture_helpers_cannot_mask_cross_owner_dependencies (tests.test_architecture.ArchitectureTests.test_fixture_helpers_cannot_mask_cross_owner_dependencies) ... ok
test_io_selectors_are_the_declared_owners_and_tool_tests (tests.test_architecture.ArchitectureTests.test_io_selectors_are_the_declared_owners_and_tool_tests) ... ok
test_io_suite_is_explicit_and_inherits_owner_dependency_policy (tests.test_architecture.ArchitectureTests.test_io_suite_is_explicit_and_inherits_owner_dependency_policy) ... ok
test_ports_reject_concrete_dependencies_and_empty_contracts (tests.test_architecture.ArchitectureTests.test_ports_reject_concrete_dependencies_and_empty_contracts) ... ok
test_pure_packages_reject_direct_io_process_and_network (tests.test_architecture.ArchitectureTests.test_pure_packages_reject_direct_io_process_and_network) ... ok
test_relative_aliased_and_conditional_imports_cannot_bypass_policy (tests.test_architecture.ArchitectureTests.test_relative_aliased_and_conditional_imports_cannot_bypass_policy) ... ok
test_repository_conforms_to_declared_architecture (tests.test_architecture.ArchitectureTests.test_repository_conforms_to_declared_architecture) ... ok
test_root_package_must_remain_inert (tests.test_architecture.ArchitectureTests.test_root_package_must_remain_inert) ... ok
test_runtime_dependencies_are_empty_but_build_and_lint_tools_are_separate (tests.test_architecture.ArchitectureTests.test_runtime_dependencies_are_empty_but_build_and_lint_tools_are_separate) ... ok
test_self_model_dependency_view_is_explicitly_partial_and_exact (tests.test_architecture.ArchitectureTests.test_self_model_dependency_view_is_explicitly_partial_and_exact) ... ok
test_self_model_matches_all_packages_and_distinguishes_permission (tests.test_architecture.ArchitectureTests.test_self_model_matches_all_packages_and_distinguishes_permission) ... ok
test_self_model_refuses_source_and_policy_drift (tests.test_architecture.ArchitectureTests.test_self_model_refuses_source_and_policy_drift) ... ok
test_self_model_retains_interfaces_and_selected_providers (tests.test_architecture.ArchitectureTests.test_self_model_retains_interfaces_and_selected_providers) ... ok
test_test_imports_and_support_cannot_bypass_production_boundaries (tests.test_architecture.ArchitectureTests.test_test_imports_and_support_cannot_bypass_production_boundaries) ... ok
test_test_modules_follow_package_names (tests.test_architecture.ArchitectureTests.test_test_modules_follow_package_names) ... ok
test_unknown_nested_helpers_and_io_owners_are_rejected (tests.test_architecture.ArchitectureTests.test_unknown_nested_helpers_and_io_owners_are_rejected) ... ok
test_unknown_source_package_is_rejected (tests.test_architecture.ArchitectureTests.test_unknown_source_package_is_rejected) ... ok
test_a_live_branch_with_an_open_prerequisite_is_blocked_and_not_dormant (tests.test_architecture.BranchLivenessTests.test_a_live_branch_with_an_open_prerequisite_is_blocked_and_not_dormant)
The other half of the rule, on an edge this declaration no longer draws. ... ok
test_the_base_declaration_selects_nothing_so_every_branch_stays_dormant (tests.test_architecture.BranchLivenessTests.test_the_base_declaration_selects_nothing_so_every_branch_stays_dormant)
The v1 host's answer does not move, because a base declaration has no ruling. ... ok
test_the_other_selection_opens_its_own_branch_and_leaves_this_ones_dormant (tests.test_architecture.BranchLivenessTests.test_the_other_selection_opens_its_own_branch_and_leaves_this_ones_dormant)
`topology` implies one question since revision 5, and opening it is the rule. ... ok
test_the_readme_says_when_a_branch_opens_and_where_the_rule_lives (tests.test_architecture.BranchLivenessTests.test_the_readme_says_when_a_branch_opens_and_where_the_rule_lives) ... ok
test_the_reason_names_the_alternative_and_the_ruling_that_selected_it (tests.test_architecture.BranchLivenessTests.test_the_reason_names_the_alternative_and_the_ruling_that_selected_it)
`answerable_because.induced_by` says who opened the question, and on what. ... ok
test_the_selected_alternative_opens_the_question_it_implies (tests.test_architecture.BranchLivenessTests.test_the_selected_alternative_opens_the_question_it_implies)
`node_trust` implies `metadata_exposure`, which requires nothing and no gate. ... ok
test_a_docstring_that_does_not_explain_its_decision_is_marked_not_rewritten (tests.test_architecture.DecisionIndexTests.test_a_docstring_that_does_not_explain_its_decision_is_marked_not_rewritten) ... ok
test_a_row_carries_the_identifier_its_matrix_row_and_the_docstring (tests.test_architecture.DecisionIndexTests.test_a_row_carries_the_identifier_its_matrix_row_and_the_docstring) ... ok
test_alternatives_carry_their_own_meaning_the_lean_and_what_they_make_live (tests.test_architecture.DecisionIndexTests.test_alternatives_carry_their_own_meaning_the_lean_and_what_they_make_live) ... ok
test_an_unknown_colour_is_refused_rather_than_left_without_a_word (tests.test_architecture.DecisionIndexTests.test_an_unknown_colour_is_refused_rather_than_left_without_a_word) ... ok
test_answerable_now_matches_the_capture_hosts_own_answer (tests.test_architecture.DecisionIndexTests.test_answerable_now_matches_the_capture_hosts_own_answer) ... ok
test_every_question_is_listed_once_sorted_by_tier_then_name (tests.test_architecture.DecisionIndexTests.test_every_question_is_listed_once_sorted_by_tier_then_name) ... ok
test_metadata_exposure_offers_the_four_rung_ladder_and_marks_none (tests.test_architecture.DecisionIndexTests.test_metadata_exposure_offers_the_four_rung_ladder_and_marks_none) ... ok
test_relay_posture_is_an_ordinary_question_rather_than_a_branch_of_topology (tests.test_architecture.DecisionIndexTests.test_relay_posture_is_an_ordinary_question_rather_than_a_branch_of_topology) ... ok
test_requires_is_reported_both_ways_and_gates_carry_their_meaning (tests.test_architecture.DecisionIndexTests.test_requires_is_reported_both_ways_and_gates_carry_their_meaning) ... ok
test_the_legend_gives_every_colour_the_capture_host_draws_a_word (tests.test_architecture.DecisionIndexTests.test_the_legend_gives_every_colour_the_capture_host_draws_a_word) ... ok
test_the_markdown_says_how_to_read_the_graph_and_repeats_no_invention (tests.test_architecture.DecisionIndexTests.test_the_markdown_says_how_to_read_the_graph_and_repeats_no_invention) ... ok
test_the_readme_documents_the_index_host (tests.test_architecture.DecisionIndexTests.test_the_readme_documents_the_index_host) ... ok
test_ucan_is_argued_from_its_own_encoding_rather_than_from_jwt (tests.test_architecture.DecisionIndexTests.test_ucan_is_argued_from_its_own_encoding_rather_than_from_jwt) ... ok
test_version_pin_asks_for_a_manifest_floor_because_no_lockfile_is_tracked (tests.test_architecture.DecisionIndexTests.test_version_pin_asks_for_a_manifest_floor_because_no_lockfile_is_tracked) ... ok
test_a_clean_stream_reports_no_finding_and_two_captures_agree (tests.test_architecture.DecisionStreamCaptureTests.test_a_clean_stream_reports_no_finding_and_two_captures_agree) ... ok
test_a_reopen_retires_the_parents_ruling_and_the_child_answers_again (tests.test_architecture.DecisionStreamCaptureTests.test_a_reopen_retires_the_parents_ruling_and_the_child_answers_again) ... ok
test_a_ruling_carries_its_principal_its_stamp_and_the_slots_it_names (tests.test_architecture.DecisionStreamCaptureTests.test_a_ruling_carries_its_principal_its_stamp_and_the_slots_it_names) ... ok
test_an_occurred_record_meets_the_gate_it_names (tests.test_architecture.DecisionStreamCaptureTests.test_an_occurred_record_meets_the_gate_it_names) ... ok
test_effective_status_is_the_declared_status_plus_the_live_rulings (tests.test_architecture.DecisionStreamCaptureTests.test_effective_status_is_the_declared_status_plus_the_live_rulings) ... ok
test_every_validation_rule_reports_its_own_code_on_its_own_mistake (tests.test_architecture.DecisionStreamCaptureTests.test_every_validation_rule_reports_its_own_code_on_its_own_mistake) ... ok
test_structural_mistakes_are_still_raised_by_the_capture (tests.test_architecture.DecisionStreamCaptureTests.test_structural_mistakes_are_still_raised_by_the_capture) ... ok
test_the_overlay_adds_records_and_leaves_every_base_slot_in_place (tests.test_architecture.DecisionStreamCaptureTests.test_the_overlay_adds_records_and_leaves_every_base_slot_in_place) ... ok
test_a_run_that_skipped_the_reports_says_where_the_identical_ones_are (tests.test_architecture.EvaluatorRunRecordTests.test_a_run_that_skipped_the_reports_says_where_the_identical_ones_are) ... ok
test_every_file_the_run_wrote_is_named_and_every_one_it_skipped_is_null (tests.test_architecture.EvaluatorRunRecordTests.test_every_file_the_run_wrote_is_named_and_every_one_it_skipped_is_null) ... ok
test_the_readme_documents_the_run_record_and_every_field (tests.test_architecture.EvaluatorRunRecordTests.test_the_readme_documents_the_run_record_and_every_field) ... ok
test_the_record_is_the_same_document_every_run (tests.test_architecture.EvaluatorRunRecordTests.test_the_record_is_the_same_document_every_run) ... ok
test_the_record_names_each_proposal_its_frame_and_its_candidate (tests.test_architecture.EvaluatorRunRecordTests.test_the_record_names_each_proposal_its_frame_and_its_candidate) ... ok
test_the_record_says_what_the_lens_draws_and_what_it_leaves_out (tests.test_architecture.EvaluatorRunRecordTests.test_the_record_says_what_the_lens_draws_and_what_it_leaves_out) ... ok
test_multi_selection_and_io_keep_their_existing_limits (tests.test_architecture.FastExecutionBudgetTests.test_multi_selection_and_io_keep_their_existing_limits) ... ok
test_single_selection_uses_owner_five_seconds_excluding_startup (tests.test_architecture.FastExecutionBudgetTests.test_single_selection_uses_owner_five_seconds_excluding_startup) ... ok
test_a_fork_and_a_link_of_one_stream_both_say_what_it_said (tests.test_architecture.GeneratedStreamTests.test_a_fork_and_a_link_of_one_stream_both_say_what_it_said) ... ok
test_a_fork_and_a_link_off_the_base_both_capture (tests.test_architecture.GeneratedStreamTests.test_a_fork_and_a_link_off_the_base_both_capture)
A stream can be taken from `base`, which is where an owner with no stream starts. ... ok
test_a_fork_of_a_reopened_chain_restates_only_what_still_stands (tests.test_architecture.GeneratedStreamTests.test_a_fork_of_a_reopened_chain_restates_only_what_still_stands) ... ok
test_a_fork_restates_the_standing_records_over_the_base_and_imports_no_overlay (tests.test_architecture.GeneratedStreamTests.test_a_fork_restates_the_standing_records_over_the_base_and_imports_no_overlay) ... ok
test_a_generated_overlay_is_handed_exactly_the_modules_it_imports (tests.test_architecture.GeneratedStreamTests.test_a_generated_overlay_is_handed_exactly_the_modules_it_imports)
The closure rule, over every parent a stream can be taken from. ... ok
test_a_link_imports_its_parent_and_subclasses_its_root (tests.test_architecture.GeneratedStreamTests.test_a_link_imports_its_parent_and_subclasses_its_root) ... ok
test_an_id_names_the_module_the_root_and_the_file_the_fixtures_carry (tests.test_architecture.GeneratedStreamTests.test_an_id_names_the_module_the_root_and_the_file_the_fixtures_carry) ... ok
test_the_committed_fork_is_what_the_generator_writes_and_writes_again (tests.test_architecture.GeneratedStreamTests.test_the_committed_fork_is_what_the_generator_writes_and_writes_again) ... ok
test_the_first_ruling_added_to_a_generated_overlay_captures (tests.test_architecture.GeneratedStreamTests.test_the_first_ruling_added_to_a_generated_overlay_captures)
An owner answers a question by editing the generated module, and nothing else. ... ok
test_a_baseline_that_is_not_the_capture_of_the_problem_inputs_is_refused (tests.test_architecture.GladeArchitectureDeclarationTests.test_a_baseline_that_is_not_the_capture_of_the_problem_inputs_is_refused) ... ok
test_all_responsibilities_allocated_and_requirement_meanings_retained (tests.test_architecture.GladeArchitectureDeclarationTests.test_all_responsibilities_allocated_and_requirement_meanings_retained) ... ok
test_async_cleanup_ownership_is_separate_from_cache_scope (tests.test_architecture.GladeArchitectureDeclarationTests.test_async_cleanup_ownership_is_separate_from_cache_scope) ... ok
test_deferred_reference_typo_is_rejected (tests.test_architecture.GladeArchitectureDeclarationTests.test_deferred_reference_typo_is_rejected) ... ok
test_dependency_state_and_runtime_edges_are_distinct (tests.test_architecture.GladeArchitectureDeclarationTests.test_dependency_state_and_runtime_edges_are_distinct) ... ok
test_injection_bindings_qualify_same_port_and_shared_clock (tests.test_architecture.GladeArchitectureDeclarationTests.test_injection_bindings_qualify_same_port_and_shared_clock) ... ok
test_missing_allocation_and_cycle_are_rejected (tests.test_architecture.GladeArchitectureDeclarationTests.test_missing_allocation_and_cycle_are_rejected) ... ok
test_profile_provider_is_not_the_live_directory_facade (tests.test_architecture.GladeArchitectureDeclarationTests.test_profile_provider_is_not_the_live_directory_facade) ... ok
test_selected_injector_is_an_assembly_only_dependency (tests.test_architecture.GladeArchitectureDeclarationTests.test_selected_injector_is_an_assembly_only_dependency) ... ok
test_unresolved_binding_provider_is_rejected (tests.test_architecture.GladeArchitectureDeclarationTests.test_unresolved_binding_provider_is_rejected) ... ok
test_allocation_lens_places_every_responsibility_in_its_area (tests.test_architecture.GladeArchitectureViewTests.test_allocation_lens_places_every_responsibility_in_its_area) ... ok
test_binding_and_composition_lenses_separate_recipes_from_the_injector (tests.test_architecture.GladeArchitectureViewTests.test_binding_and_composition_lenses_separate_recipes_from_the_injector) ... ok
test_each_lens_draws_exactly_its_relations_edges_and_states_omissions (tests.test_architecture.GladeArchitectureViewTests.test_each_lens_draws_exactly_its_relations_edges_and_states_omissions) ... ok
test_lens_set_covers_every_declared_architecture_relation (tests.test_architecture.GladeArchitectureViewTests.test_lens_set_covers_every_declared_architecture_relation) ... ok
test_requirement_and_journey_lenses_label_functions_with_their_allocation (tests.test_architecture.GladeArchitectureViewTests.test_requirement_and_journey_lenses_label_functions_with_their_allocation) ... ok
test_every_question_is_classified_and_leans_name_one_preferred_alternative (tests.test_architecture.GladeDecisionCaptureTests.test_every_question_is_classified_and_leans_name_one_preferred_alternative) ... ok
test_lean_questions_carry_exactly_one_preferred_alternative (tests.test_architecture.GladeDecisionCaptureTests.test_lean_questions_carry_exactly_one_preferred_alternative) ... ok
test_lens_draws_every_edge_and_states_what_it_is_not (tests.test_architecture.GladeDecisionCaptureTests.test_lens_draws_every_edge_and_states_what_it_is_not) ... ok
test_requires_is_acyclic_with_the_named_roots_and_cycles_are_rejected (tests.test_architecture.GladeDecisionCaptureTests.test_requires_is_acyclic_with_the_named_roots_and_cycles_are_rejected) ... ok
test_every_legend_entry_carries_the_declaration_s_own_docstring (tests.test_architecture.GladeLensPlanTests.test_every_legend_entry_carries_the_declaration_s_own_docstring)
`doc` is READ from the captured catalogue, never written by the renderer. ... ok
test_every_lens_declares_what_it_draws_and_what_it_omits (tests.test_architecture.GladeLensPlanTests.test_every_lens_declares_what_it_draws_and_what_it_omits) ... ok
test_every_node_and_edge_id_resolves_to_a_snapshot_record (tests.test_architecture.GladeLensPlanTests.test_every_node_and_edge_id_resolves_to_a_snapshot_record) ... ok
test_every_plan_declares_the_node_typography_its_dot_writes (tests.test_architecture.GladeLensPlanTests.test_every_plan_declares_the_node_typography_its_dot_writes) ... ok
test_lens_counts_equal_the_snapshot_counts_for_its_relations (tests.test_architecture.GladeLensPlanTests.test_lens_counts_equal_the_snapshot_counts_for_its_relations) ... ok
test_one_assertion_with_several_refs_indexes_every_drawn_edge (tests.test_architecture.GladeLensPlanTests.test_one_assertion_with_several_refs_indexes_every_drawn_edge) ... ok
test_the_decision_legend_quotes_the_statuses_and_relations_verbatim (tests.test_architecture.GladeLensPlanTests.test_the_decision_legend_quotes_the_statuses_and_relations_verbatim)
The four statuses, the Trigger kind and the three relations, as declared. ... ok
test_the_legend_describes_what_the_dot_actually_draws (tests.test_architecture.GladeLensPlanTests.test_the_legend_describes_what_the_dot_actually_draws) ... ok
test_two_runs_produce_byte_identical_lens_plans (tests.test_architecture.GladeLensPlanTests.test_two_runs_produce_byte_identical_lens_plans) ... ok
test_frozen_sources_are_checked_and_repeatable (tests.test_architecture.GladeProblemCaptureTests.test_frozen_sources_are_checked_and_repeatable) ... ok
test_inventory_is_present_without_invented_implementation_allocations (tests.test_architecture.GladeProblemCaptureTests.test_inventory_is_present_without_invented_implementation_allocations) ... ok
test_missing_inventory_concern_is_rejected (tests.test_architecture.GladeProblemCaptureTests.test_missing_inventory_concern_is_rejected) ... ok
test_overview_accounts_for_every_responsibility_but_does_not_claim_full_graph (tests.test_architecture.GladeProblemCaptureTests.test_overview_accounts_for_every_responsibility_but_does_not_claim_full_graph) ... ok
test_source_id_in_comment_does_not_count_as_captured_concern (tests.test_architecture.GladeProblemCaptureTests.test_source_id_in_comment_does_not_count_as_captured_concern) ... ok
test_every_responsibility_is_allocated_to_exactly_one_participant (tests.test_architecture.GrythUiCaptureTests.test_every_responsibility_is_allocated_to_exactly_one_participant) ... ok
test_missing_allocation_is_refused (tests.test_architecture.GrythUiCaptureTests.test_missing_allocation_is_refused) ... ok
test_frames_gates_and_alternatives_are_named (tests.test_architecture.GrythUiEvaluationTests.test_frames_gates_and_alternatives_are_named) ... ok
test_cached_baseline_rejects_changed_sources_and_ledger (tests.test_architecture.IndependentCrdtCaptureTests.test_cached_baseline_rejects_changed_sources_and_ledger) ... ok
test_combined_capture_preserves_base_and_exact_new_requirements (tests.test_architecture.IndependentCrdtCaptureTests.test_combined_capture_preserves_base_and_exact_new_requirements) ... ok
test_loader_uses_only_app_owned_frozen_sources (tests.test_architecture.IndependentCrdtCaptureTests.test_loader_uses_only_app_owned_frozen_sources) ... ok
test_mutated_source_pin_and_removed_requirement_refused (tests.test_architecture.IndependentCrdtCaptureTests.test_mutated_source_pin_and_removed_requirement_refused) ... ok
test_a_class_or_a_member_the_notebook_already_has_is_refused_by_name (tests.test_architecture.NotebookMergeTests.test_a_class_or_a_member_the_notebook_already_has_is_refused_by_name) ... ok
test_a_fork_generated_notebook_keeps_every_record_it_restated (tests.test_architecture.NotebookMergeTests.test_a_fork_generated_notebook_keeps_every_record_it_restated)
A fork's module is the busy case: many classes, a parenthesised import block. ... ok
test_a_link_generated_notebook_takes_its_first_ruling (tests.test_architecture.NotebookMergeTests.test_a_link_generated_notebook_takes_its_first_ruling)
The notebook a `link` writes: the root body is one docstring and `use` is unknown. ... ok
test_a_long_union_is_written_as_the_parenthesised_form_this_host_writes (tests.test_architecture.NotebookMergeTests.test_a_long_union_is_written_as_the_parenthesised_form_this_host_writes) ... ok
test_a_merge_adds_a_module_the_notebook_never_named (tests.test_architecture.NotebookMergeTests.test_a_merge_adds_a_module_the_notebook_never_named) ... ok
test_a_notebook_that_already_holds_rulings_takes_another (tests.test_architecture.NotebookMergeTests.test_a_notebook_that_already_holds_rulings_takes_another)
The shipped sample, READ: two rulings and a question already, and a third added. ... ok
test_every_refusal_is_a_code_and_a_sentence_the_owner_can_act_on (tests.test_architecture.NotebookMergeTests.test_every_refusal_is_a_code_and_a_sentence_the_owner_can_act_on) ... ok
test_the_host_prints_the_merged_module_and_writes_no_file (tests.test_architecture.NotebookMergeTests.test_the_host_prints_the_merged_module_and_writes_no_file)
The CLI: one JSON document on stdout, and the notebook on disk untouched. ... ok
test_capture_help_names_repository_default_paths_and_output_entry (tests.test_architecture.ProductionCrdtCaptureTests.test_capture_help_names_repository_default_paths_and_output_entry) ... ok
test_missing_or_changed_source_and_ownership_refuse (tests.test_architecture.ProductionCrdtCaptureTests.test_missing_or_changed_source_and_ownership_refuse) ... ok
test_overlay_loads_without_sibling_checkout (tests.test_architecture.ProductionCrdtCaptureTests.test_overlay_loads_without_sibling_checkout) ... ok
test_production_overlay_has_exact_inherited_and_new_allocations (tests.test_architecture.ProductionCrdtCaptureTests.test_production_overlay_has_exact_inherited_and_new_allocations) ... ok
test_a_passage_is_the_row_the_paragraph_or_the_section (tests.test_architecture.SourceIndexTests.test_a_passage_is_the_row_the_paragraph_or_the_section) ... ok
test_a_root_that_is_not_a_directory_is_data_and_not_a_raise (tests.test_architecture.SourceIndexTests.test_a_root_that_is_not_a_directory_is_data_and_not_a_raise) ... ok
test_a_section_longer_than_the_cap_is_capped_and_says_so (tests.test_architecture.SourceIndexTests.test_a_section_longer_than_the_cap_is_capped_and_says_so) ... ok
test_a_tag_no_resolver_claims_is_unresolved_with_the_family_it_looked_like (tests.test_architecture.SourceIndexTests.test_a_tag_no_resolver_claims_is_unresolved_with_the_family_it_looked_like) ... ok
test_citations_come_from_the_authoring_module_and_name_the_slot (tests.test_architecture.SourceIndexTests.test_citations_come_from_the_authoring_module_and_name_the_slot) ... ok
test_each_family_resolves_where_section_5_says_it_does (tests.test_architecture.SourceIndexTests.test_each_family_resolves_where_section_5_says_it_does) ... ok
test_every_cited_tag_is_resolved_or_unresolved_exactly_once (tests.test_architecture.SourceIndexTests.test_every_cited_tag_is_resolved_or_unresolved_exactly_once) ... ok
test_the_index_declares_its_format_its_root_and_its_documents (tests.test_architecture.SourceIndexTests.test_the_index_declares_its_format_its_root_and_its_documents) ... ok
test_without_a_root_every_tag_is_unresolved_and_the_file_says_why (tests.test_architecture.SourceIndexTests.test_without_a_root_every_tag_is_unresolved_and_the_file_says_why) ... ok
test_a_relative_flag_overrides_the_default_against_the_repository (tests.test_architecture.SourcesRootTests.test_a_relative_flag_overrides_the_default_against_the_repository) ... ok
test_an_absolute_flag_is_the_root_it_names (tests.test_architecture.SourcesRootTests.test_an_absolute_flag_is_the_root_it_names) ... ok
test_rebuild_forwards_the_root_it_was_given_to_the_emit_host (tests.test_architecture.SourcesRootTests.test_rebuild_forwards_the_root_it_was_given_to_the_emit_host) ... ok
test_the_default_root_ignores_the_repository_the_run_was_pointed_at (tests.test_architecture.SourcesRootTests.test_the_default_root_ignores_the_repository_the_run_was_pointed_at) ... ok
test_the_default_root_is_the_workzone_beside_the_checkout (tests.test_architecture.SourcesRootTests.test_the_default_root_is_the_workzone_beside_the_checkout) ... ok
test_the_index_records_which_root_it_used_and_how_it_was_chosen (tests.test_architecture.SourcesRootTests.test_the_index_records_which_root_it_used_and_how_it_was_chosen) ... ok
test_the_readme_documents_the_default_and_the_override (tests.test_architecture.SourcesRootTests.test_the_readme_documents_the_default_and_the_override) ... ok
test_the_rebuild_verb_accepts_the_root_and_defaults_to_none (tests.test_architecture.SourcesRootTests.test_the_rebuild_verb_accepts_the_root_and_defaults_to_none) ... ok
test_exact_overlay_allocations_and_source_pins (tests.test_architecture.StorageAttemptCaptureTests.test_exact_overlay_allocations_and_source_pins) ... ok
test_lifecycle_cache_refuses_changed_declaration (tests.test_architecture.StorageAttemptCaptureTests.test_lifecycle_cache_refuses_changed_declaration) ... ok
test_overlay_corruption_and_removing_owner_refuse (tests.test_architecture.StorageAttemptCaptureTests.test_overlay_corruption_and_removing_owner_refuse) ... ok
test_overlay_loads_without_sibling_checkout (tests.test_architecture.StorageAttemptCaptureTests.test_overlay_loads_without_sibling_checkout) ... ok
test_reused_semantic_baseline_requires_exact_provenance (tests.test_architecture.StorageAttemptCaptureTests.test_reused_semantic_baseline_requires_exact_provenance) ... ok
test_a_second_call_produces_identical_documents (tests.test_architecture.StreamBundleDocumentTests.test_a_second_call_produces_identical_documents) ... ok
test_an_answerable_question_says_why_in_the_shape_a_blocked_one_uses (tests.test_architecture.StreamBundleDocumentTests.test_an_answerable_question_says_why_in_the_shape_a_blocked_one_uses)
An answerable row carries the reason for its flag, as emitted data. ... ok
test_bundle_carries_the_read_only_documents_and_their_formats (tests.test_architecture.StreamBundleDocumentTests.test_bundle_carries_the_read_only_documents_and_their_formats) ... ok
test_decide_now_names_blockers_gates_offers_and_leans_by_slot (tests.test_architecture.StreamBundleDocumentTests.test_decide_now_names_blockers_gates_offers_and_leans_by_slot) ... ok
test_every_question_appears_exactly_once_with_its_slot_and_status (tests.test_architecture.StreamBundleDocumentTests.test_every_question_appears_exactly_once_with_its_slot_and_status) ... ok
test_roots_and_tiers_are_the_capture_hosts_own_answers (tests.test_architecture.StreamBundleDocumentTests.test_roots_and_tiers_are_the_capture_hosts_own_answers) ... ok
test_the_readme_documents_the_bundle_layout_and_the_lens_files (tests.test_architecture.StreamBundleDocumentTests.test_the_readme_documents_the_bundle_layout_and_the_lens_files) ... ok
test_the_source_index_cites_the_base_declarations_own_tags_by_emitted_slot (tests.test_architecture.StreamBundleDocumentTests.test_the_source_index_cites_the_base_declarations_own_tags_by_emitted_slot)
The index is the only emitted place a QUESTION's own tags appear. ... ok
test_validation_carries_the_error_shape_when_capture_is_rejected (tests.test_architecture.StreamBundleDocumentTests.test_validation_carries_the_error_shape_when_capture_is_rejected) ... ok
test_a_finding_travels_as_data_and_a_warning_leaves_the_bundle_valid (tests.test_architecture.StreamChainBundleTests.test_a_finding_travels_as_data_and_a_warning_leaves_the_bundle_valid) ... ok
test_a_stream_record_names_its_kind_parent_chain_and_overlay (tests.test_architecture.StreamChainBundleTests.test_a_stream_record_names_its_kind_parent_chain_and_overlay) ... ok
test_every_stream_of_the_chain_has_its_own_documents_and_one_index (tests.test_architecture.StreamChainBundleTests.test_every_stream_of_the_chain_has_its_own_documents_and_one_index) ... ok
test_the_answerable_reason_names_the_ruling_that_decided_a_prerequisite (tests.test_architecture.StreamChainBundleTests.test_the_answerable_reason_names_the_ruling_that_decided_a_prerequisite)
The golden reason of the fixture chain, where a prerequisite was ruled on. ... ok
test_the_base_documents_are_what_a_base_only_bundle_writes (tests.test_architecture.StreamChainBundleTests.test_the_base_documents_are_what_a_base_only_bundle_writes) ... ok
test_the_readme_documents_the_stream_vocabulary_and_every_code (tests.test_architecture.StreamChainBundleTests.test_the_readme_documents_the_stream_vocabulary_and_every_code) ... ok
test_the_ruled_questions_carry_their_ruling_and_the_gate_that_was_met (tests.test_architecture.StreamChainBundleTests.test_the_ruled_questions_carry_their_ruling_and_the_gate_that_was_met) ... ok
test_a_diff_is_the_same_document_every_run (tests.test_architecture.StreamDiffDocumentTests.test_a_diff_is_the_same_document_every_run) ... ok
test_every_perspective_names_the_records_its_lens_gained_and_lost (tests.test_architecture.StreamDiffDocumentTests.test_every_perspective_names_the_records_its_lens_gained_and_lost) ... ok
test_the_base_to_stream_a_diff_names_the_rulings_the_gate_and_the_question (tests.test_architecture.StreamDiffDocumentTests.test_the_base_to_stream_a_diff_names_the_rulings_the_gate_and_the_question) ... ok
test_the_document_carries_the_contract_envelope_and_its_correspondence (tests.test_architecture.StreamDiffDocumentTests.test_the_document_carries_the_contract_envelope_and_its_correspondence) ... ok
test_the_readme_documents_the_manager_verbs_and_every_diff_field (tests.test_architecture.StreamDiffDocumentTests.test_the_readme_documents_the_manager_verbs_and_every_diff_field) ... ok
test_the_reference_order_of_an_assertion_is_not_a_difference (tests.test_architecture.StreamDiffDocumentTests.test_the_reference_order_of_an_assertion_is_not_a_difference) ... ok
test_the_stream_a_to_stream_b_diff_names_the_reopen_and_the_new_selection (tests.test_architecture.StreamDiffDocumentTests.test_the_stream_a_to_stream_b_diff_names_the_reopen_and_the_new_selection) ... ok
test_a_generated_overlay_declares_the_record_it_is_captured_under (tests.test_architecture.StreamDiscoveryTests.test_a_generated_overlay_declares_the_record_it_is_captured_under) ... ok
test_a_parent_no_overlay_declares_is_refused_with_a_named_code (tests.test_architecture.StreamDiscoveryTests.test_a_parent_no_overlay_declares_is_refused_with_a_named_code) ... ok
test_a_registration_is_read_and_never_run (tests.test_architecture.StreamDiscoveryTests.test_a_registration_is_read_and_never_run) ... ok
test_a_registration_that_disagrees_with_its_module_is_refused (tests.test_architecture.StreamDiscoveryTests.test_a_registration_that_disagrees_with_its_module_is_refused) ... ok
test_an_id_two_overlays_declare_is_refused_with_a_named_code (tests.test_architecture.StreamDiscoveryTests.test_an_id_two_overlays_declare_is_refused_with_a_named_code) ... ok
test_an_overlay_that_declares_nothing_is_not_a_stream (tests.test_architecture.StreamDiscoveryTests.test_an_overlay_that_declares_nothing_is_not_a_stream) ... ok
test_discovery_lists_exactly_the_streams_this_repository_declares (tests.test_architecture.StreamDiscoveryTests.test_discovery_lists_exactly_the_streams_this_repository_declares) ... ok
test_every_overlay_carries_the_record_the_registry_files_it_under (tests.test_architecture.StreamDiscoveryTests.test_every_overlay_carries_the_record_the_registry_files_it_under) ... ok
test_the_readme_documents_the_registration_form_and_the_discovery_rule (tests.test_architecture.StreamDiscoveryTests.test_the_readme_documents_the_registration_form_and_the_discovery_rule) ... ok
test_every_streamed_perspective_quotes_the_declaration_in_its_legend (tests.test_architecture.StreamPerspectiveTests.test_every_streamed_perspective_quotes_the_declaration_in_its_legend)
The legends of the bundle's own lenses carry `doc`, read from the catalogue. ... ok
test_the_closure_is_the_records_section_five_names_and_no_others (tests.test_architecture.StreamPerspectiveTests.test_the_closure_is_the_records_section_five_names_and_no_others) ... ok
test_the_emitted_member_is_the_question_the_decide_now_list_offers_first (tests.test_architecture.StreamPerspectiveTests.test_the_emitted_member_is_the_question_the_decide_now_list_offers_first) ... ok
test_the_member_is_the_decisions_lens_restricted_to_that_closure (tests.test_architecture.StreamPerspectiveTests.test_the_member_is_the_decisions_lens_restricted_to_that_closure) ... ok
test_the_record_names_every_perspective_and_why_three_carry_no_file (tests.test_architecture.StreamPerspectiveTests.test_the_record_names_every_perspective_and_why_three_carry_no_file) ... ok

----------------------------------------------------------------------
Ran 182 tests in 2.896s

OK
fast-test timing: startup=0.059s execution=2.896s budget=5.0s

```

## Gyld affected type check retained baseline debt
Command: ['uvx', '--quiet', '--python', '3.13', 'mypy@1.18.1', '--python-version', '3.11', '--check-untyped-defs', '--explicit-package-bases', 'scripts/capture_glade_crdt_production.py', 'scripts/test_fast.py', 'tests/test_architecture.py']
Exit: 1; wall: 1.388s
```text
scripts/capture_gryth_ui_architecture.py:14: error: Cannot find implementation or library stub for module named "gyld.adapters"  [import-not-found]
scripts/capture_gryth_ui_architecture.py:15: error: Cannot find implementation or library stub for module named "gyld.authoring.capture"  [import-not-found]
scripts/capture_gryth_ui_architecture.py:15: error: Cannot find implementation or library stub for module named "gyld.authoring"  [import-not-found]
scripts/capture_gryth_ui_architecture.py:16: error: Cannot find implementation or library stub for module named "gyld.model"  [import-not-found]
scripts/capture_gryth_ui_architecture.py:17: error: Cannot find implementation or library stub for module named "gyld.query"  [import-not-found]
scripts/capture_gryth_ui_architecture.py:18: error: Cannot find implementation or library stub for module named "gyld.view"  [import-not-found]
scripts/lens_geometry.py:34: error: Cannot find implementation or library stub for module named "gyld.model"  [import-not-found]
scripts/capture_glade_problem.py:16: error: Cannot find implementation or library stub for module named "gyld.adapters"  [import-not-found]
scripts/capture_glade_problem.py:17: error: Cannot find implementation or library stub for module named "gyld.authoring.capture"  [import-not-found]
scripts/capture_glade_problem.py:17: error: Cannot find implementation or library stub for module named "gyld.authoring"  [import-not-found]
scripts/capture_glade_problem.py:18: error: Cannot find implementation or library stub for module named "gyld.model"  [import-not-found]
scripts/capture_glade_problem.py:19: error: Cannot find implementation or library stub for module named "gyld.query"  [import-not-found]
scripts/capture_glade_problem.py:20: error: Cannot find implementation or library stub for module named "gyld.view"  [import-not-found]
scripts/check_architecture.py:350: error: "object" has no attribute "__iter__"; maybe "__dir__" or "__str__"? (not iterable)  [attr-defined]
scripts/check_architecture.py:354: error: "object" has no attribute "items"  [attr-defined]
scripts/evaluate_gryth_ui.py:17: error: Cannot find implementation or library stub for module named "gyld.adapters"  [import-not-found]
scripts/evaluate_gryth_ui.py:18: error: Cannot find implementation or library stub for module named "gyld.app"  [import-not-found]
scripts/evaluate_gryth_ui.py:19: error: Cannot find implementation or library stub for module named "gyld.authoring.capture"  [import-not-found]
scripts/evaluate_gryth_ui.py:19: error: Cannot find implementation or library stub for module named "gyld.authoring"  [import-not-found]
scripts/evaluate_gryth_ui.py:20: error: Cannot find implementation or library stub for module named "gyld.change"  [import-not-found]
scripts/evaluate_gryth_ui.py:21: error: Cannot find implementation or library stub for module named "gyld.evaluation"  [import-not-found]
scripts/evaluate_gryth_ui.py:22: error: Cannot find implementation or library stub for module named "gyld.model"  [import-not-found]
scripts/evaluate_gryth_ui.py:23: error: Cannot find implementation or library stub for module named "gyld.model.codec"  [import-not-found]
scripts/evaluate_gryth_ui.py:24: error: Cannot find implementation or library stub for module named "gyld.query"  [import-not-found]
scripts/evaluate_gryth_ui.py:25: error: Cannot find implementation or library stub for module named "gyld.view"  [import-not-found]
scripts/capture_glade_decisions.py:17: error: Cannot find implementation or library stub for module named "gyld.adapters"  [import-not-found]
scripts/capture_glade_decisions.py:18: error: Cannot find implementation or library stub for module named "gyld.authoring.capture"  [import-not-found]
scripts/capture_glade_decisions.py:18: error: Cannot find implementation or library stub for module named "gyld.authoring"  [import-not-found]
scripts/capture_glade_decisions.py:19: error: Cannot find implementation or library stub for module named "gyld.model"  [import-not-found]
scripts/capture_glade_decisions.py:20: error: Cannot find implementation or library stub for module named "gyld.query"  [import-not-found]
scripts/capture_glade_decisions.py:21: error: Cannot find implementation or library stub for module named "gyld.view"  [import-not-found]
scripts/render_gyld_arch.py:15: error: Cannot find implementation or library stub for module named "gyld.adapters"  [import-not-found]
scripts/render_gyld_arch.py:16: error: Cannot find implementation or library stub for module named "gyld.authoring"  [import-not-found]
scripts/render_gyld_arch.py:17: error: Cannot find implementation or library stub for module named "gyld.model"  [import-not-found]
scripts/render_gyld_arch.py:18: error: Cannot find implementation or library stub for module named "gyld.query"  [import-not-found]
scripts/render_gyld_arch.py:19: error: Cannot find implementation or library stub for module named "gyld.view"  [import-not-found]
scripts/capture_glade_architecture.py:12: error: Cannot find implementation or library stub for module named "gyld.adapters"  [import-not-found]
scripts/capture_glade_architecture.py:13: error: Cannot find implementation or library stub for module named "gyld.authoring.capture"  [import-not-found]
scripts/capture_glade_architecture.py:13: error: Cannot find implementation or library stub for module named "gyld.authoring"  [import-not-found]
scripts/capture_glade_architecture.py:14: error: Cannot find implementation or library stub for module named "gyld.model"  [import-not-found]
scripts/capture_glade_architecture.py:15: error: Cannot find implementation or library stub for module named "gyld.query"  [import-not-found]
scripts/capture_glade_architecture.py:16: error: Cannot find implementation or library stub for module named "gyld.view"  [import-not-found]
scripts/render_glade_architecture.py:16: error: Cannot find implementation or library stub for module named "gyld.adapters"  [import-not-found]
scripts/capture_decision_stream.py:46: error: Cannot find implementation or library stub for module named "gyld.authoring.capture"  [import-not-found]
scripts/capture_decision_stream.py:46: error: Cannot find implementation or library stub for module named "gyld.authoring"  [import-not-found]
scripts/capture_decision_stream.py:47: error: Cannot find implementation or library stub for module named "gyld.model"  [import-not-found]
scripts/capture_glade_independent_crdt.py:13: error: Cannot find implementation or library stub for module named "gyld.authoring.capture"  [import-not-found]
scripts/capture_glade_independent_crdt.py:13: error: Cannot find implementation or library stub for module named "gyld.authoring"  [import-not-found]
scripts/capture_glade_independent_crdt.py:14: error: Cannot find implementation or library stub for module named "gyld.model"  [import-not-found]
scripts/evaluate_iroh_integration.py:17: error: Cannot find implementation or library stub for module named "gyld.adapters"  [import-not-found]
scripts/evaluate_iroh_integration.py:18: error: Cannot find implementation or library stub for module named "gyld.app"  [import-not-found]
scripts/evaluate_iroh_integration.py:19: error: Cannot find implementation or library stub for module named "gyld.authoring.capture"  [import-not-found]
scripts/evaluate_iroh_integration.py:19: error: Cannot find implementation or library stub for module named "gyld.authoring"  [import-not-found]
scripts/evaluate_iroh_integration.py:20: error: Cannot find implementation or library stub for module named "gyld.change"  [import-not-found]
scripts/evaluate_iroh_integration.py:21: error: Cannot find implementation or library stub for module named "gyld.evaluation"  [import-not-found]
scripts/evaluate_iroh_integration.py:22: error: Cannot find implementation or library stub for module named "gyld.model"  [import-not-found]
scripts/evaluate_iroh_integration.py:23: error: Cannot find implementation or library stub for module named "gyld.model.codec"  [import-not-found]
scripts/evaluate_iroh_integration.py:24: error: Cannot find implementation or library stub for module named "gyld.query"  [import-not-found]
scripts/evaluate_iroh_integration.py:25: error: Cannot find implementation or library stub for module named "gyld.view"  [import-not-found]
scripts/emit_decision_streams.py:45: error: Cannot find implementation or library stub for module named "gyld.adapters"  [import-not-found]
scripts/emit_decision_streams.py:46: error: Cannot find implementation or library stub for module named "gyld.model"  [import-not-found]
scripts/emit_decision_streams.py:47: error: Cannot find implementation or library stub for module named "gyld.query"  [import-not-found]
scripts/capture_glade_crdt_production.py:9: error: Cannot find implementation or library stub for module named "gyld.authoring"  [import-not-found]
scripts/capture_glade_crdt_production.py:9: note: See https://mypy.readthedocs.io/en/stable/running_mypy.html#missing-imports
scripts/capture_glade_crdt_production.py:10: error: Cannot find implementation or library stub for module named "gyld.model"  [import-not-found]
scripts/manage_decision_streams.py:50: error: Cannot find implementation or library stub for module named "gyld.model"  [import-not-found]
scripts/test_fast.py:118: error: Incompatible types in assignment (expression has type "TestSuite", variable has type "str")  [assignment]
scripts/test_fast.py:120: error: Argument 1 to "run" of "TextTestRunner" has incompatible type "str"; expected "TestSuite | TestCase"  [arg-type]
tests/test_architecture.py:11: error: Cannot find implementation or library stub for module named "gyld.model"  [import-not-found]
tests/test_architecture.py:400: error: Item "None" of "Any | None" has no attribute "cleanup"  [union-attr]
tests/test_architecture.py:1111: error: Need type annotation for "offered" (hint: "offered: dict[<type>, <type>] = ...")  [var-annotated]
Found 70 errors in 17 files (checked 3 source files)

```

## Gyld affected type check with repository source path; retained six baseline errors
Command: ['uvx', '--quiet', '--python', '3.13', 'mypy@1.18.1', '--python-version', '3.11', '--check-untyped-defs', '--explicit-package-bases', 'scripts/capture_glade_crdt_production.py', 'scripts/test_fast.py', 'tests/test_architecture.py']
Exit: 1; wall: 1.160s
```text
scripts/check_architecture.py:350: error: "object" has no attribute "__iter__"; maybe "__dir__" or "__str__"? (not iterable)  [attr-defined]
scripts/check_architecture.py:354: error: "object" has no attribute "items"  [attr-defined]
scripts/test_fast.py:118: error: Incompatible types in assignment (expression has type "TestSuite", variable has type "str")  [assignment]
scripts/test_fast.py:120: error: Argument 1 to "run" of "TextTestRunner" has incompatible type "str"; expected "TestSuite | TestCase"  [arg-type]
tests/test_architecture.py:400: error: Item "None" of "Any | None" has no attribute "cleanup"  [union-attr]
tests/test_architecture.py:1111: error: Need type annotation for "offered" (hint: "offered: dict[<type>, <type>] = ...")  [var-annotated]
Found 6 errors in 3 files (checked 3 source files)

```

## Gyld instructed source-path typecheck; unchanged six baseline errors
Command: ['uvx', '--quiet', '--python', '3.13', 'mypy@1.18.1', '--python-version', '3.11', '--check-untyped-defs', '--explicit-package-bases', 'scripts/capture_glade_crdt_production.py', 'scripts/test_fast.py', 'tests/test_architecture.py']
Exit: 1; wall: 1.083s
```text
scripts/check_architecture.py:350: error: "object" has no attribute "__iter__"; maybe "__dir__" or "__str__"? (not iterable)  [attr-defined]
scripts/check_architecture.py:354: error: "object" has no attribute "items"  [attr-defined]
scripts/test_fast.py:118: error: Incompatible types in assignment (expression has type "TestSuite", variable has type "str")  [assignment]
scripts/test_fast.py:120: error: Argument 1 to "run" of "TextTestRunner" has incompatible type "str"; expected "TestSuite | TestCase"  [arg-type]
tests/test_architecture.py:400: error: Item "None" of "Any | None" has no attribute "cleanup"  [union-attr]
tests/test_architecture.py:1111: error: Need type annotation for "offered" (hint: "offered: dict[<type>, <type>] = ...")  [var-annotated]
Found 6 errors in 3 files (checked 3 source files)

```

## Corrected committed candidate vector and language gate
Command: ['sh', 'glade/contracts/crdt-recovery-codec/check-vectors.sh']
Exit: 0; wall: 1.024s
```text
Candidate content representation PASS; unqualified for remote use until committed pin and accepted B1 crypto
......
----------------------------------------------------------------------
Ran 6 tests in 0.569s

OK
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.19s
     Running tests/vectors.rs (glade/contracts/target/debug/deps/vectors-e6054aa97de7077a)

running 4 tests
test closed_maps_reject_unknown_duplicate_reordered_or_wrong_context_fields ... ok
test malformed_signature_length_and_wrong_exact_domain_refuse_signed_envelope_shape ... ok
test bounded_malformed_canonical_vectors_fail_closed ... ok
test all_remote_profile_categories_derive_exact_bytes_and_digests_from_semantic_inputs ... ok

test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

Python independent profile vectors: 21 positive + negative controls PASS
(node:94075) ExperimentalWarning: Transform Types is an experimental feature and might change at any time
(Use `node --trace-warnings ...` to show where the warning was created)
TypeScript independent profile vectors: 21 positive + 18 negative controls PASS

```

## Strict pre-remote expected refusal pending genuine B1 evidence
Command: ['sh', 'glade/contracts/crdt-recovery-codec/check-vectors.sh', '--pre-remote']
Exit: 1; wall: 0.458s
```text
Traceback (most recent call last):
  File "/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-codec/compat/gate.py", line 106, in <module>
    validate(Path(sys.argv[1]), strict=strict)
  File "/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-codec/compat/gate.py", line 53, in validate
    validate_remote(root, pins)
  File "/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-codec/compat/gate.py", line 84, in validate_remote
    raise ValueError("genuine B1 crypto qualification absent")
ValueError: genuine B1 crypto qualification absent

```

## Corrected Gyld standalone sidecar capture and inherited budget controls
Command: ['python3', '-B', '-m', 'unittest', 'tests.test_architecture.ProductionCrdtCaptureTests', 'tests.test_architecture.FastExecutionBudgetTests']
Exit: 1; wall: 0.143s
```text
EE
======================================================================
ERROR: test_architecture (unittest.loader._FailedTest.test_architecture)
----------------------------------------------------------------------
ImportError: Failed to import test module: test_architecture
Traceback (most recent call last):
  File "/opt/homebrew/Cellar/python@3.14/3.14.3_1/Frameworks/Python.framework/Versions/3.14/lib/python3.14/unittest/loader.py", line 137, in loadTestsFromName
    module = __import__(module_name)
  File "/Volumes/projects/limbo/gyld-wz/gyld/tests/test_architecture.py", line 11, in <module>
    from gyld.model import Snapshot
ModuleNotFoundError: No module named 'gyld'


======================================================================
ERROR: test_architecture (unittest.loader._FailedTest.test_architecture)
----------------------------------------------------------------------
ImportError: Failed to import test module: test_architecture
Traceback (most recent call last):
  File "/opt/homebrew/Cellar/python@3.14/3.14.3_1/Frameworks/Python.framework/Versions/3.14/lib/python3.14/unittest/loader.py", line 137, in loadTestsFromName
    module = __import__(module_name)
  File "/Volumes/projects/limbo/gyld-wz/gyld/tests/test_architecture.py", line 11, in <module>
    from gyld.model import Snapshot
ModuleNotFoundError: No module named 'gyld'


----------------------------------------------------------------------
Ran 2 tests in 0.000s

FAILED (errors=2)

```

## Corrected Gyld standalone sidecar and budget controls with repository source path
Command: ['python3', '-B', '-m', 'unittest', 'tests.test_architecture.ProductionCrdtCaptureTests', 'tests.test_architecture.FastExecutionBudgetTests']
Exit: 0; wall: 0.916s
```text
......
----------------------------------------------------------------------
Ran 6 tests in 0.790s

OK

```
