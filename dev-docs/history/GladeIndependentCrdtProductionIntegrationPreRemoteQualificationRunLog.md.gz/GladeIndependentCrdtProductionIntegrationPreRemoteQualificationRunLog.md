
## glade-ic3-pre-remote-accepted.log
Command: ['sh', 'glade/contracts/crdt-recovery-codec/check-vectors.sh', '--pre-remote']
Pre-remote committed corpus/B1 accepted-evidence gate PASS
...EF.
======================================================================
ERROR: test_nonexistent_commit_and_absent_crypto_evidence_refuse_remote (__main__.PinGateTests.test_nonexistent_commit_and_absent_crypto_evidence_refuse_remote)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-codec/compat/test_gate.py", line 52, in test_nonexistent_commit_and_absent_crypto_evidence_refuse_remote
    validate_remote(root, pins)
  File "/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-codec/compat/gate.py", line 85, in validate_remote
    raw = committed_bytes(repository, qualification["evidence_revision"], qualification["path"])
          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/owebeeone/.asdf/installs/python/3.11.16/lib/python3.11/unittest/mock.py", line 1124, in __call__
    return self._mock_call(*args, **kwargs)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/owebeeone/.asdf/installs/python/3.11.16/lib/python3.11/unittest/mock.py", line 1128, in _mock_call
    return self._execute_mock_call(*args, **kwargs)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/owebeeone/.asdf/installs/python/3.11.16/lib/python3.11/unittest/mock.py", line 1189, in _execute_mock_call
    result = effect(*args, **kwargs)
             ^^^^^^^^^^^^^^^^^^^^^^^
  File "/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-codec/compat/test_gate.py", line 50, in <lambda>
    with patch("gate.committed_bytes", side_effect=lambda repository, revision, path: (root / path.removeprefix("contracts/crdt-recovery-codec/")).read_bytes()):
                                                                                      ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/owebeeone/.asdf/installs/python/3.11.16/lib/python3.11/pathlib.py", line 1050, in read_bytes
    with self.open(mode='rb') as f:
         ^^^^^^^^^^^^^^^^^^^^
  File "/Users/owebeeone/.asdf/installs/python/3.11.16/lib/python3.11/pathlib.py", line 1044, in open
    return io.open(self, mode, buffering, encoding, errors, newline)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
FileNotFoundError: [Errno 2] No such file or directory: '/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-codec/node/qualification/ic3-b1.json'

======================================================================
FAIL: test_pre_remote_refuses_uncommitted_candidate_content_pins (__main__.PinGateTests.test_pre_remote_refuses_uncommitted_candidate_content_pins)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-codec/compat/test_gate.py", line 25, in test_pre_remote_refuses_uncommitted_candidate_content_pins
    with self.assertRaises(ValueError):
AssertionError: ValueError not raised

----------------------------------------------------------------------
Ran 6 tests in 0.641s

FAILED (failures=1, errors=1)

Exit: 1; wall: 1.190s

## glade-ic3-negative-fixture-correction.log
# Accepted-tree negative fixture correction
Initial executed RED source: /tmp/glade-ic3-pre-remote-accepted.log; SHA256 c1c56f840e3733304c273a02aec726489c300454d20f7272f9d9955b79d94fdc

Command: ['sh', 'glade/contracts/crdt-recovery-codec/check-vectors.sh', '--pre-remote']
Pre-remote committed corpus/B1 accepted-evidence gate PASS
...EF.
======================================================================
ERROR: test_nonexistent_commit_and_absent_crypto_evidence_refuse_remote (__main__.PinGateTests.test_nonexistent_commit_and_absent_crypto_evidence_refuse_remote)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-codec/compat/test_gate.py", line 52, in test_nonexistent_commit_and_absent_crypto_evidence_refuse_remote
    validate_remote(root, pins)
  File "/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-codec/compat/gate.py", line 85, in validate_remote
    raw = committed_bytes(repository, qualification["evidence_revision"], qualification["path"])
          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/owebeeone/.asdf/installs/python/3.11.16/lib/python3.11/unittest/mock.py", line 1124, in __call__
    return self._mock_call(*args, **kwargs)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/owebeeone/.asdf/installs/python/3.11.16/lib/python3.11/unittest/mock.py", line 1128, in _mock_call
    return self._execute_mock_call(*args, **kwargs)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/owebeeone/.asdf/installs/python/3.11.16/lib/python3.11/unittest/mock.py", line 1189, in _execute_mock_call
    result = effect(*args, **kwargs)
             ^^^^^^^^^^^^^^^^^^^^^^^
  File "/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-codec/compat/test_gate.py", line 50, in <lambda>
    with patch("gate.committed_bytes", side_effect=lambda repository, revision, path: (root / path.removeprefix("contracts/crdt-recovery-codec/")).read_bytes()):
                                                                                      ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/owebeeone/.asdf/installs/python/3.11.16/lib/python3.11/pathlib.py", line 1050, in read_bytes
    with self.open(mode='rb') as f:
         ^^^^^^^^^^^^^^^^^^^^
  File "/Users/owebeeone/.asdf/installs/python/3.11.16/lib/python3.11/pathlib.py", line 1044, in open
    return io.open(self, mode, buffering, encoding, errors, newline)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
FileNotFoundError: [Errno 2] No such file or directory: '/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-codec/node/qualification/ic3-b1.json'

======================================================================
FAIL: test_pre_remote_refuses_uncommitted_candidate_content_pins (__main__.PinGateTests.test_pre_remote_refuses_uncommitted_candidate_content_pins)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-codec/compat/test_gate.py", line 25, in test_pre_remote_refuses_uncommitted_candidate_content_pins
    with self.assertRaises(ValueError):
AssertionError: ValueError not raised

----------------------------------------------------------------------
Ran 6 tests in 0.641s

FAILED (failures=1, errors=1)

Exit: 1; wall: 1.190s

## Focused negative fixtures GREEN
Command: ['python3', '-m', 'unittest', '-v', 'test_gate.PinGateTests.test_pre_remote_refuses_uncommitted_candidate_content_pins', 'test_gate.PinGateTests.test_nonexistent_commit_and_absent_crypto_evidence_refuse_remote']
Cwd: glade/contracts/crdt-recovery-codec/compat
Exit: 1; wall: 0.408s
test_pre_remote_refuses_uncommitted_candidate_content_pins (test_gate.PinGateTests.test_pre_remote_refuses_uncommitted_candidate_content_pins) ... ok
test_nonexistent_commit_and_absent_crypto_evidence_refuse_remote (test_gate.PinGateTests.test_nonexistent_commit_and_absent_crypto_evidence_refuse_remote) ... FAIL

======================================================================
FAIL: test_nonexistent_commit_and_absent_crypto_evidence_refuse_remote (test_gate.PinGateTests.test_nonexistent_commit_and_absent_crypto_evidence_refuse_remote)
----------------------------------------------------------------------
ValueError: implementation commit content mismatch

During handling of the above exception, another exception occurred:

Traceback (most recent call last):
  File "/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-codec/compat/test_gate.py", line 65, in test_nonexistent_commit_and_absent_crypto_evidence_refuse_remote
    with self.assertRaisesRegex(ValueError, "genuine B1 crypto qualification absent"):
AssertionError: "genuine B1 crypto qualification absent" does not match "implementation commit content mismatch"

----------------------------------------------------------------------
Ran 2 tests in 0.309s

FAILED (failures=1)

## Focused fixture hashes made independent of parent re-pin
Command: ['python3', '-m', 'unittest', '-v', 'test_gate.PinGateTests.test_pre_remote_refuses_uncommitted_candidate_content_pins', 'test_gate.PinGateTests.test_nonexistent_commit_and_absent_crypto_evidence_refuse_remote']
Cwd: glade/contracts/crdt-recovery-codec/compat
Exit: 0; wall: 0.274s
test_pre_remote_refuses_uncommitted_candidate_content_pins (test_gate.PinGateTests.test_pre_remote_refuses_uncommitted_candidate_content_pins) ... ok
test_nonexistent_commit_and_absent_crypto_evidence_refuse_remote (test_gate.PinGateTests.test_nonexistent_commit_and_absent_crypto_evidence_refuse_remote) ... ok

----------------------------------------------------------------------
Ran 2 tests in 0.196s

OK

## glade-ic3-pre-remote-accepted-green.log
Command: ['sh', 'glade/contracts/crdt-recovery-codec/check-vectors.sh', '--pre-remote']
Pre-remote committed corpus/B1 accepted-evidence gate PASS
......
----------------------------------------------------------------------
Ran 6 tests in 0.583s

OK
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.05s
     Running tests/vectors.rs (glade/contracts/target/debug/deps/vectors-e6054aa97de7077a)

running 4 tests
test closed_maps_reject_unknown_duplicate_reordered_or_wrong_context_fields ... ok
test malformed_signature_length_and_wrong_exact_domain_refuse_signed_envelope_shape ... ok
test bounded_malformed_canonical_vectors_fail_closed ... ok
test all_remote_profile_categories_derive_exact_bytes_and_digests_from_semantic_inputs ... ok

test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

Python independent profile vectors: 21 positive + negative controls PASS
(node:88940) ExperimentalWarning: Transform Types is an experimental feature and might change at any time
(Use `node --trace-warnings ...` to show where the warning was created)
TypeScript independent profile vectors: 21 positive + 18 negative controls PASS

Exit: 0; wall: 1.524s
