# IC3 B remediation2 chronological commands
Candidate base Glade d3fded040d6e3c459cd5f975d6c672873356cc23. No acceptance claimed.

## R6 and R4 initial public behavioral RED
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--test', 'ic3_disk', 'ic3_disk_remediation2', '--', '--nocapture']
Exit: 101; wall: 14.702s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 13.14s
     Running tests/ic3_disk.rs (glade/node/target/debug/deps/ic3_disk-79b05533cd314114)

running 4 tests

thread 'ic3_disk_remediation2::oversized_drained_result_can_discharge_only_as_compact_permanent_loss' (172729259) panicked at tests/ic3_disk_remediation2/mod.rs:95:5:
M+1 owned drained result must fit compact reserved loss without normal admission
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace
test ic3_disk_remediation2::oversized_drained_result_can_discharge_only_as_compact_permanent_loss ... FAILED

thread 'ic3_disk_remediation2::ingress_uses_retained_complete_interval_not_first_narrow_interval' (172729258) panicked at tests/ic3_disk_remediation2/mod.rs:78:5:
retained [20,100] straddles deadline50; no consumable permit
test ic3_disk_remediation2::ingress_uses_retained_complete_interval_not_first_narrow_interval ... FAILED

thread 'ic3_disk_remediation2::public_begin_must_recheck_exact_retained_revocation' (172729261) panicked at tests/ic3_disk_remediation2/mod.rs:52:5:
new retained revoked/expired cut must fence before Started
test ic3_disk_remediation2::public_begin_must_recheck_exact_retained_revocation ... FAILED

thread 'ic3_disk_remediation2::public_begin_must_recheck_exact_retained_expiry' (172729260) panicked at tests/ic3_disk_remediation2/mod.rs:52:5:
new retained revoked/expired cut must fence before Started
test ic3_disk_remediation2::public_begin_must_recheck_exact_retained_expiry ... FAILED

failures:

failures:
    ic3_disk_remediation2::ingress_uses_retained_complete_interval_not_first_narrow_interval
    ic3_disk_remediation2::oversized_drained_result_can_discharge_only_as_compact_permanent_loss
    ic3_disk_remediation2::public_begin_must_recheck_exact_retained_expiry
    ic3_disk_remediation2::public_begin_must_recheck_exact_retained_revocation

test result: FAILED. 0 passed; 4 failed; 0 ignored; 0 measured; 24 filtered out; finished in 0.82s

error: test failed, to rerun pass `--test ic3_disk`

```

## R6 and R4 scoped first GREEN
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--test', 'ic3_disk', 'ic3_disk_remediation2', '--', '--nocapture']
Exit: 101; wall: 2.176s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
error[E0425]: cannot find type `TrustedCut` in this scope
  --> src/independent/records/authentication.rs:18:14
   |
18 | ) -> Result<(TrustedCut, PolicyBody), Fault> {
   |              ^^^^^^^^^^ not found in this scope
   |
help: consider importing this struct through its public re-export
   |
 2 + use crate::independent::TrustedCut;
   |

For more information about this error, try `rustc --explain E0425`.
error: could not compile `glade-node` (lib) due to 1 previous error

```

## R6 and R4 scoped GREEN after missing import correction
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--test', 'ic3_disk', 'ic3_disk_remediation2', '--', '--nocapture']
Exit: 101; wall: 0.578s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
error[E0382]: use of partially moved value: `cut`
    --> src/independent/records/authentication.rs:77:9
     |
  23 |     let time = cut.time.ok_or(Fault::Unavailable)?;
     |                         ------------------------- `cut.time` partially moved due to this method call
...
  77 |     Ok((cut, policy))
     |         ^^^ value used here after partial move
     |
note: `Option::<T>::ok_or` takes ownership of the receiver `self`, which moves `cut.time`
    --> /Users/owebeeone/.rustup/toolchains/stable-aarch64-apple-darwin/lib/rustlib/src/rust/library/core/src/option.rs:1337:45
     |
1337 |     pub const fn ok_or<E: [const] Destruct>(self, err: E) -> Result<T, E> {
     |                                             ^^^^
     = note: partial move occurs because `cut.time` has type `Option<glade_crdt_admission_data::TimeInterval>`, which does not implement the `Copy` trait
help: consider calling `.as_ref()` to borrow the value's contents
     |
  23 |     let time = cut.time.as_ref().ok_or(Fault::Unavailable)?;
     |                        +++++++++
help: consider calling `.as_mut()` to mutably borrow the value's contents
     |
  23 |     let time = cut.time.as_mut().ok_or(Fault::Unavailable)?;
     |                        +++++++++
help: you can `clone` the value and consume it, but this might not be your desired behavior
     |
  23 |     let time = cut.time.clone().ok_or(Fault::Unavailable)?;
     |                        ++++++++

For more information about this error, try `rustc --explain E0382`.
error: could not compile `glade-node` (lib) due to 1 previous error

```

## R6 and R4 scoped compiled corrected implementation
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--test', 'ic3_disk', 'ic3_disk_remediation2', '--', '--nocapture']
Exit: 101; wall: 3.675s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 2.26s
     Running tests/ic3_disk.rs (glade/node/target/debug/deps/ic3_disk-79b05533cd314114)

running 4 tests
test ic3_disk_remediation2::ingress_uses_retained_complete_interval_not_first_narrow_interval ... ok
test ic3_disk_remediation2::oversized_drained_result_can_discharge_only_as_compact_permanent_loss ... ok

thread 'ic3_disk_remediation2::public_begin_must_recheck_exact_retained_expiry' (172734960) panicked at tests/ic3_disk_remediation2/mod.rs:57:5:
assertion `left == right` failed
  left: Pending
 right: Closed
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace
test ic3_disk_remediation2::public_begin_must_recheck_exact_retained_expiry ... FAILED

thread 'ic3_disk_remediation2::public_begin_must_recheck_exact_retained_revocation' (172734961) panicked at tests/ic3_disk_remediation2/mod.rs:57:5:
assertion `left == right` failed
  left: Pending
 right: Closed
test ic3_disk_remediation2::public_begin_must_recheck_exact_retained_revocation ... FAILED

failures:

failures:
    ic3_disk_remediation2::public_begin_must_recheck_exact_retained_expiry
    ic3_disk_remediation2::public_begin_must_recheck_exact_retained_revocation

test result: FAILED. 2 passed; 2 failed; 0 ignored; 0 measured; 24 filtered out; finished in 0.71s

error: test failed, to rerun pass `--test ic3_disk`

```

## R6 and R4 exact retained cut and original Fence lifecycle GREEN
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--test', 'ic3_disk', 'ic3_disk_remediation2', '--', '--nocapture']
Exit: 0; wall: 3.430s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 1.85s
     Running tests/ic3_disk.rs (glade/node/target/debug/deps/ic3_disk-79b05533cd314114)

running 4 tests
test ic3_disk_remediation2::ingress_uses_retained_complete_interval_not_first_narrow_interval ... ok
test ic3_disk_remediation2::oversized_drained_result_can_discharge_only_as_compact_permanent_loss ... ok
test ic3_disk_remediation2::public_begin_must_recheck_exact_retained_expiry ... ok
test ic3_disk_remediation2::public_begin_must_recheck_exact_retained_revocation ... ok

test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 24 filtered out; finished in 0.87s


```

## Remediation2 public success failure edge and five actual process deaths
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--test', 'ic3_disk', 'ic3_disk_remediation2', '--', '--nocapture']
Exit: 0; wall: 3.949s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 1.06s
     Running tests/ic3_disk.rs (glade/node/target/debug/deps/ic3_disk-79b05533cd314114)

running 7 tests
test ic3_disk_remediation2::remediation2_child ... ignored, owned public corrected-cut and oversized-loss crash child
test ic3_disk_remediation2::ingress_uses_retained_complete_interval_not_first_narrow_interval ... ok
test ic3_disk_remediation2::stable_valid_complete_interval_still_admits_and_never_started_guard_abandons ... ok
test ic3_disk_remediation2::oversized_drained_result_can_discharge_only_as_compact_permanent_loss ... ok
test ic3_disk_remediation2::public_begin_must_recheck_exact_retained_expiry ... ok
test ic3_disk_remediation2::public_begin_must_recheck_exact_retained_revocation ... ok
test ic3_disk_remediation2::corrected_denials_and_oversized_loss_custody_survive_actual_process_death ... ok

test result: ok. 6 passed; 0 failed; 1 ignored; 0 measured; 24 filtered out; finished in 2.18s


```

## Full public affected disk consumer and helper audit controls
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--test', 'ic3_disk', '--', '--nocapture']
Exit: 0; wall: 8.027s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 2.34s
     Running tests/ic3_disk.rs (glade/node/target/debug/deps/ic3_disk-79b05533cd314114)

running 32 tests
test ic3_disk_remediation2::ingress_uses_retained_complete_interval_not_first_narrow_interval ... ok
test genuine_fresh_replica_opens_owned_validated_genesis_and_reopens_same_identity ... ok
test actual_owned_begin_precedes_factory_and_active_guard_suppresses_complete_cut ... ok
test ic3_disk_remediation2::remediation2_child ... ignored, owned public corrected-cut and oversized-loss crash child
test ic3_disk_remediation2::oversized_drained_result_can_discharge_only_as_compact_permanent_loss ... ok
test genuine_challenge_response_custody_and_consumption_survive_owned_reopen ... ok
test finite_authenticated_empty_round_settles_exact_observation_and_never_started_abandons ... ok
test ic3_disk_remediation::loss::public_continuation_child ... ignored, owned public ingress continuation crash child
test ic3_disk_remediation2::stable_valid_complete_interval_still_admits_and_never_started_guard_abandons ... ok
test ic3_disk_remediation::exact_nonempty_inventory_settles_and_retains_exact_missing_obligation ... ok
test ic3_disk_native::actual_storage_attempt_host_narrow_open_preserves_replica_created_namespace_and_owner ... ok
test ic3_disk_remediation::loss::public_refused_drained_settlement_can_select_conservative_loss_and_close ... ok
test ic3_disk_remediation::malformed_prefix_cannot_be_replaced_by_signed_empty ... ok
test ic3_disk_remediation::observations::denied_policy_child ... ignored, owned public denied current-policy observation crash child
test ic3_disk_native::actual_native_attempt_provider_recovers_and_returns_immutable_terminal_for_exact_request ... ok
test ic3_disk_native::trusted_floor_refuses_data_only_rollback_and_missing_floor_after_real_local_commit ... ok
test ic3_disk_remediation::observations::denied_challenge_retains_advanced_time_before_reopen_can_reauthorize ... ok
test ic3_disk_native::actual_genuine_local_commit_persists_owned_callback_history_and_exact_original_receipt ... ok
test ic3_disk_remediation::observations::failed_marker_establishment_never_consults_current_source ... ok
test ic3_disk_remediation2::public_begin_must_recheck_exact_retained_expiry ... ok
test ic3_disk_remediation::observations::learned_chained_revocation_survives_actual_process_death_and_older_provider ... ok
test ic3_disk_remediation::observations::learned_denial_with_failed_publication_keeps_full_and_narrow_reopen_unavailable ... ok
test ic3_disk_remediation2::public_begin_must_recheck_exact_retained_revocation ... ok
test ic3_disk_remediation::observations::capacity_refusal_after_learning_keeps_marker_unavailable_and_survives_both_open_forms ... ok
test ic3_disk_remediation::exact_retired_prepare_replay_recovers_original_attempt_before_and_after_reopen ... ok
test ic3_disk_remediation::receive_error_cannot_be_replaced_by_signed_empty ... ok
test ic3_disk_remediation::observations::denied_response_retains_time_and_denied_ingress_retains_peer_revocation ... ok
test ic3_disk_remediation::signed_nonempty_cannot_be_replaced_by_different_signed_empty ... ok
test ic3_disk_remediation::observations::receive_only_holder_advances_trusted_time_and_converges_without_append_grants ... ok
test ic3_disk_remediation::loss::public_refusal_unknown_and_capacity_loss_survive_actual_process_death ... ok
test ic3_disk_remediation2::earlier_verify_and_seal_replies_do_not_admit_after_their_retained_cut_advances ... ok
test ic3_disk_remediation2::corrected_denials_and_oversized_loss_custody_survive_actual_process_death ... ok

test result: ok. 29 passed; 0 failed; 3 ignored; 0 measured; 0 filtered out; finished in 5.00s


```

## New consumer source selection behavioral RED
Command: ['cargo', 'test', '--manifest-path', 'glade/contracts/Cargo.toml', '--locked', '--offline', '-p', 'glade-crdt-recovery-api', '--test', 'source_boundaries', 'actual_node_independent_subtree_and_disabled_branches_are_checked', '--', '--nocapture']
Exit: 101; wall: 1.587s
```text
   Compiling glade-crdt-recovery-api v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-api)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 1.01s
     Running tests/source_boundaries.rs (glade/contracts/target/debug/deps/source_boundaries-d87c63d050de1dbe)

running 1 test

thread 'actual_node_independent_subtree_and_disabled_branches_are_checked' (172751794) panicked at crdt-recovery-api/tests/source_boundaries.rs:97:5:
new public remediation consumer must be parsed, including disabled branches
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace
test actual_node_independent_subtree_and_disabled_branches_are_checked ... FAILED

failures:

failures:
    actual_node_independent_subtree_and_disabled_branches_are_checked

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 3 filtered out; finished in 0.00s

error: test failed, to rerun pass `-p glade-crdt-recovery-api --test source_boundaries`

```

## Affected contract production adopter gate
Command: ['sh', 'glade/contracts/check.sh', 'crdt-production']
Exit: 0; wall: 10.078s
```text
Architecture boundaries: PASS (workspace libraries, declared dependencies, traits and conformance targets)
   Compiling glade-crdt-recovery-api v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-api)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.32s
     Running unittests src/lib.rs (glade/contracts/target/debug/deps/glade_crdt_admission_core-932f6277b6041d9c)

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/encoder_complete.rs (glade/contracts/target/debug/deps/encoder_complete-0c61aeec9660768e)

running 10 tests
test plan::namespaces_issuance_owner_and_storage_promise_are_part_of_bytes ... ok
test fork::fork_pairs_have_complete_candidate_identity_and_evidence ... ok
test candidate::all_candidate_evidence_and_inner_op_bytes ... ok
test plan::complete_plan_header_and_optional_local_cut ... ok
test stage::all_staged_candidate_seal_and_receipt_fields ... ok
test descriptor::all_descriptor_parsed_fields_and_bounds ... ok
test facts::all_staged_facts_and_certificate_fields ... ok
test seal_scope::full_seal_descriptor_and_evidence ... ok
test seal::full_sealing_query_continuations ... ok
test verify::full_verification_query_continuations ... ok

test result: ok. 10 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

     Running tests/fixture_composition.rs (glade/contracts/target/debug/deps/fixture_composition-65d2eb16df52c7d1)

running 7 tests
test historical_prior_cut_fixture_registers_multiline_inspect_through_full_helper ... ok
test mandatory_text_replica_journeys_do_not_construct_fresh_host_per_drive_call ... ok
test lookup_fixture_owns_full_request_and_bounded_history_not_only_secondary_index ... ok
test trusted_seed_retains_reservations_outcomes_and_rejects_inconsistent_history ... ok
test configured_provider_matches_core_cut_and_changes_independently ... ok
test seeded_terminal_requires_original_custody_and_accounting ... ok
test seeded_custody_is_explicit_and_consecutive_port_publications_keep_history ... ok

test result: ok. 7 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/kernel_edges.rs (glade/contracts/target/debug/deps/kernel_edges-0e6067bcb16c3e14)

running 21 tests
test admission::pending_origins_reserve_the_origin_limit_before_verification ... ok
test admission::retained_candidates_and_verifications_share_pending_capacity ... ok
test admission::oversized_proof_cannot_allocate_a_verification_continuation ... ok
test encoder::storage_batch_limit_refuses_before_any_prepare_or_invocation ... ok
test admission::restored_fork_cut_derives_one_coherent_quarantine_and_eligible_set ... ok
test admission::outstanding_verification_prevents_complete_local_and_is_bounded ... ok
test frontier::already_retained_exact_frontier_hash_preserves_complete_local ... ok
test frontier::frontier_union_cannot_exceed_pending_items_or_clear_previous_observation ... ok
test frontier::empty_peer_frontier_offers_all_local_history ... ok
test encoder::full_encoded_continuation_footprint_consumes_edit_quota ... ok
test storage::prepared_reply_cannot_replace_original_attempt_mapping ... ok
test admission::committed_local_custody_retains_the_actual_seal_named_by_original_receipt ... ok
test encoder::unretained_historical_batch_due_to_encoder_limit_is_sticky_incomplete ... ok
test storage::lost_prepare_ack_can_recover_original_plan_while_original_invocation_is_live ... ok
test admission::signed_historical_rival_outside_permit_sequence_is_security_not_conviction ... ok
test admission::signed_invalid_payload_is_security_custody_without_conviction ... ok
test frontier::announced_missing_frontier_survives_unrelated_publication ... ok
test storage::prepare_request_from_retained_old_owner_has_no_current_callback_authority ... ok
test frontier::different_arriving_hash_cannot_complete_an_announced_missing_slot ... ok
test admission::no_prior_admission_local_intent_keeps_real_seal_for_historical_replay ... ok
test encoder::encoder_is_deterministic_and_binds_descriptor_facts_and_seal_continuations ... ok

test result: ok. 21 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/records_host_contract.rs (glade/contracts/target/debug/deps/records_host_contract-377bbaa390d43bf2)

running 22 tests
test icd006_delayed_prior_cut_committed_callback_retains_historical_admission ... ok
test icd003_legacy_and_strong_descriptors_do_not_activate_independent_admission ... ok
test icd006_stale_verification_after_policy_change_cannot_seal_or_commit ... ok
test icd007_zero_base_prev_refs_and_exact_safe_numbers ... ok
test icd002_partitioned_admission_commits_without_a_holder ... ok
test icd006_historical_authorization_is_separate_from_current_revocation ... ok
test icd006_offline_window_and_clock_uncertainty_refuse_new_intent ... ok
test icd007_reused_canonical_origin_and_numeric_overflow_refuse ... ok
test icd005_evidence_reply_binds_mode_bytes_scope_and_candidate ... ok
test icd004_same_display_names_do_not_share_instance_rights_or_callbacks ... ok
test icd010_old_receipt_retry_does_not_reauthorize_or_reappend ... ok
test icd010_commit_callbacks_bind_batch_revision_and_have_three_distinct_outcomes ... ok
test icd010_lookup_recovery_binds_request_and_restores_original_receipt ... ok
test icd008_successor_requests_predecessor_without_advancing_head ... ok
test icd013_recovery_exhaustion_is_explicit_and_cannot_spend_edit_budget ... ok
test icd010_unknown_commit_retains_reservation_and_foreign_callback_cannot_accept ... ok
test prior_cut_inspect40_distinguishes_issued_authority_from_identical_unissued_reply ... ok
test icd013_edit_capacity_preserves_recovery_reserves ... ok
test icd007_new_epoch_uses_new_origin_and_old_retries_stay_old ... ok
test icd009_qualified_dependent_custody_survives_quarantined_support_but_local_intent_refuses ... ok
test icd009_two_qualified_rivals_quarantine_both_and_dependents_in_either_order ... ok
test icd006_revoked_expired_unadmitted_rival_preserves_ad_and_receipts ... ok

test result: ok. 22 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

     Running tests/recovery_contract.rs (glade/contracts/target/debug/deps/recovery_contract-8cab13edcccedff2)

running 6 tests
test lookup_invocation_counter_exhaustion_refuses_without_wrap_or_reservation_loss ... ok
test retention_committed_lookup_binds_batch_storage_revision_and_empty_receipts ... ok
test trusted_restoration_invalidates_live_lookup_and_preserves_identity_high_water ... ok
test repeated_unknown_lookup_retires_invocation_and_old_replies_preserve_new_lookup ... ok
test genuine_e0_fork_then_fresh_e1_local_recovery_keeps_ab_and_old_receipts_both_orders ... ok
test every_atomic_kind_recovers_committed_absent_and_unknown_without_fake_admission ... ok

test result: ok. 6 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

     Running tests/remediation1.rs (glade/contracts/target/debug/deps/remediation1-be8535f3fccf7f31)

running 16 tests
test frontier::frontier_bytes_include_existing_candidate_charge_and_parked_verification ... ok
test frontier::frontier_retained_slot_aggregate_bytes_exact_boundary_and_one_over ... ok
test frontier::frontier_names_empty_exact_limit_over_limit_and_huge_are_bounded ... ok
test exhaustion::local_intent_counter_refusal_alone_does_not_taint_known_history ... ok
test pending::frontier_cannot_steal_slots_reserved_by_an_unpublished_candidate_plan ... ok
test exhaustion::historical_plan_exhaustion_remains_sticky_through_resume_restore ... ok
test exhaustion::historical_query_exhaustion_remains_sticky_through_resume_restore ... ok
test pending::prospective_two_missing_slots_refuse_before_emission_or_candidate_staging ... ok
test pending::multiple_candidates_and_frontier_slots_share_deduplicated_prospective_cap ... ok
test pending::predecessor_and_ref_to_the_same_missing_slot_emit_one_request ... ok
test terminal::late_pending_and_refused_never_reopen_an_authentic_terminal ... ok
test integrity::already_qualified_fork_cannot_stage_new_work_after_stop ... ok
test pending::exact_slot_limit_and_overlap_union_commit_without_duplicate_reservations ... ok
test integrity::integrity_stop_preserves_owned_started_attempt_and_genuine_late_commit ... ok
test integrity::parked_verification_and_seal_cannot_create_new_work_after_authenticated_stop ... ok
test terminal::held_started_and_terminal_inspect_both_orders_all_four_kinds_and_outcomes ... ok

test result: ok. 16 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

     Running tests/remediation2.rs (glade/contracts/target/debug/deps/remediation2-c6ddfa10c99b9612)

running 3 tests
test fresh_historical_offer_during_held_started_a_is_explicitly_incomplete ... ok
test two_issued_queries_verified_historical_b_during_held_started_a_is_explicitly_incomplete ... ok
test local_intent_only_busy_refusal_does_not_taint_known_history ... ok

test result: ok. 3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

     Running tests/representation.rs (glade/contracts/target/debug/deps/representation-b4c77cef7d79e0fa)

running 2 tests
test operation_bytes_and_digest_are_derived_and_owned ... ok
test pure_step_is_deterministic_preserves_caller_input_and_read_only_state ... ok

test result: ok. 2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/source_boundaries.rs (glade/contracts/target/debug/deps/source_boundaries-cfcb6000711a5cc4)

running 4 tests
test ic3_data_boundary_is_independent_of_the_pure_algorithm ... ok
test checks_disabled_branch_instead_of_skipping_cfg ... ok
test disabled_associated_foreign_and_field_declarations_are_checked ... ok
test tranche_sources_have_explicit_conditional_boundaries ... ok

test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.11s

     Running tests/storage_attempt_contract.rs (glade/contracts/target/debug/deps/storage_attempt_contract-a98f1e5df7b04b9e)

running 15 tests
test identical_unissued_lookup_reply_cannot_acquire_callback_authority ... ok
test sta006_current_prestart_observation_emits_fence_without_erasing_plan ... ok
test sta009_restored_attempt_and_invocation_floors_preserve_pending ... ok
test issued_lookup_retains_full_request_on_consumption ... ok
test sta008_critical_pending_does_not_release_semantic_reservation ... ok
test sta005_contradictory_terminal_stops_instance_after_once_only_installation ... ok
test sta005_unissued_foreign_or_changed_retired_callback_cannot_create_integrity_stop ... ok
test sta001_callback_complete_binding_and_finite_invocation_namespace ... ok
test sta010_overflow_is_sticky_distinct_from_charges_and_partial_repair ... ok
test sta003_pending_lookup_retains_started_write_until_late_commit_all_kinds ... ok
test sta002_kernel_prepare_keeps_exact_plan_after_lost_ack ... ok
test sta011_existing_twenty_seven_and_text_consumers_keep_actual_port_path ... ok
test sta011_driver_uses_caller_owned_session_across_continuations ... ok
test sta004_noncommit_retains_tombstone_and_rescheduling_uses_fresh_plan ... ok
test sta007_all_kinds_install_original_terminal_without_double_charge ... ok

test result: ok. 15 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running unittests src/lib.rs (glade/contracts/target/debug/deps/glade_crdt_admission_data-829261682f5780f4)

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/representation.rs (glade/contracts/target/debug/deps/representation-a11dd961075c09ca)

running 1 test
test canonical_operation_owns_bytes_and_recomputes_digest ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/source_boundaries.rs (glade/contracts/target/debug/deps/source_boundaries-15d7213681b61363)

running 3 tests
test checks_disabled_branch_instead_of_skipping_cfg ... ok
test disabled_associated_foreign_and_field_declarations_are_checked ... ok
test tranche_sources_have_explicit_conditional_boundaries ... ok

test result: ok. 3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

     Running unittests src/lib.rs (glade/contracts/target/debug/deps/glade_crdt_evidence_api-0ab689c801ef5981)

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/public_contract.rs (glade/contracts/target/debug/deps/public_contract-a450847ecdbb9cfb)

running 2 tests
test concrete_provider_must_supply_all_three_trusted_operations ... ok
test required_evidence_methods_have_no_default_provider ... ok

test result: ok. 2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/source_boundaries.rs (glade/contracts/target/debug/deps/source_boundaries-d9ef5b5c6b238cc5)

running 3 tests
test checks_disabled_branch_instead_of_skipping_cfg ... ok
test disabled_associated_foreign_and_field_declarations_are_checked ... ok
test tranche_sources_have_explicit_conditional_boundaries ... ok

test result: ok. 3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running unittests src/lib.rs (glade/contracts/target/debug/deps/glade_crdt_recovery_api-86172c5c56e8b27f)

running 1 test
test ingress::tests::live_started_unjoined_receive_refuses_both_retirement_eligibility_queries ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/public_contract.rs (glade/contracts/target/debug/deps/public_contract-5bc6e82aa5aa7537)

running 9 tests
test abandoned_capability_cannot_start_work_again ... ok
test cancelled_started_async_receive_does_not_imply_drain_or_abandon ... ok
test issued_guard_identity_is_not_reissued_by_same_session ... ok
test live_never_started_owned_guard_can_abandon_only_once ... ok
test issuer_capacity_is_finite_and_retirement_does_not_reissue_history ... ok
test another_authority_refuses_before_constructing_or_consuming_future ... ok
test eligibility_queries_preserve_owned_lifecycle_and_refuse_foreign_closed_or_started ... ok
test owned_receive_drains_before_settlement_and_close ... ok
test normal_settlement_matches_only_owned_success_and_refuses_over_bound_before_comparison ... ok

test result: ok. 9 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/source_boundaries.rs (glade/contracts/target/debug/deps/source_boundaries-d87c63d050de1dbe)

running 4 tests
test checks_disabled_branch_instead_of_skipping_cfg ... ok
test disabled_associated_foreign_and_field_declarations_are_checked ... ok
test tranche_sources_have_explicit_conditional_boundaries ... ok
test actual_node_independent_subtree_and_disabled_branches_are_checked ... ok

test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.16s

     Running unittests src/lib.rs (glade/contracts/target/debug/deps/glade_crdt_recovery_codec-249926a6c91406e4)

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/batch_decode.rs (glade/contracts/target/debug/deps/batch_decode-c338073ef4bd3146)

running 3 tests
test unchanged_private_encoder_has_a_complete_bounded_decoder ... ok
test batch_operations_share_the_existing_aggregate_item_budget ... ok
test interned_blob_references_cannot_amplify_owned_decoding_past_budget ... ok

test result: ok. 3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/image.rs (glade/contracts/target/debug/deps/image-ff97efb1b877942d)

running 4 tests
test interrupted_intent_preserves_issuance_and_guard_floors_without_next_image ... ok
test full_image_retains_all_kernel_callbacks_attempts_guards_issuance_and_loss ... ok
test image_hash_and_external_selection_do_not_require_a_hash_fixed_point ... ok
test corrupt_truncated_trailing_unknown_versions_and_capacity_fail_closed ... ok

test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.14s

     Running tests/remediation1.rs (glade/contracts/target/debug/deps/remediation1-4606bedf9a4f1344)

running 6 tests
test root_operation_depth_includes_the_embedded_interpretation_boundary ... ok
test root_operation_name_limit_applies_inside_opaque_canonical_bytes ... ok
test root_operation_item_budget_includes_interpreted_refs_cumulatively ... ok
test nested_candidate_and_remote_transfer_cannot_hide_operation_name ... ok
test concrete_container_roots_cannot_substitute_plan_for_guard ... ok
test repeated_nested_operations_share_one_budget_not_one_budget_each ... ok

test result: ok. 6 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/roundtrip.rs (glade/contracts/target/debug/deps/roundtrip-afbf6185948b82a4)

running 6 tests
test accepted_signature_domains_are_full_and_zero_terminated ... ok
test type_domain_cannot_substitute_plan_identity_for_receive_guard ... ok
test remote_profile_is_exact_canonical_integer_key_map_without_recovery_magic ... ok
test inventory_empty_is_exact_observation_not_a_completeness_claim ... ok
test proof_body_requires_exact_purpose_version_signature_shape_and_type ... ok
test identity_roundtrip_preserves_full_namespaces_and_unsigned_floor ... ok

test result: ok. 6 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/source_boundaries.rs (glade/contracts/target/debug/deps/source_boundaries-b49e6bf7138dd73f)

running 3 tests
test checks_disabled_branch_instead_of_skipping_cfg ... ok
test disabled_associated_foreign_and_field_declarations_are_checked ... ok
test tranche_sources_have_explicit_conditional_boundaries ... ok

test result: ok. 3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.05s

     Running tests/vectors.rs (glade/contracts/target/debug/deps/vectors-e6054aa97de7077a)

running 4 tests
test closed_maps_reject_unknown_duplicate_reordered_or_wrong_context_fields ... ok
test malformed_signature_length_and_wrong_exact_domain_refuse_signed_envelope_shape ... ok
test bounded_malformed_canonical_vectors_fail_closed ... ok
test all_remote_profile_categories_derive_exact_bytes_and_digests_from_semantic_inputs ... ok

test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running unittests src/lib.rs (glade/contracts/target/debug/deps/glade_crdt_storage_attempt_api-183ed550d5084400)

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/conformance_mutants.rs (glade/contracts/target/debug/deps/conformance_mutants-62cbd41425c44fca)

running 1 test
test shared_public_port_probe_accepts_fixture_and_rejects_six_semantic_mutants ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/public_contract.rs (glade/contracts/target/debug/deps/public_contract-5dd65e92533e6d9b)

running 28 tests
test finite_attempt_invocation_and_name_bounds_refuse_without_wrap ... ok
test historical_accepted_batch_keeps_original_receipt_without_local_prestart ... ok
test host_serialized_observation_cannot_be_replaced_by_caller_current_claim ... ok
test restoration_rejects_corrupt_cardinality_floor_and_history_limit ... ok
test lost_prepare_ack_and_queued_late_prepare_recover_exactly_one_attempt ... ok
test restored_capacity_and_binding_phase_consistency_are_validated ... ok
test restored_started_and_committed_cuts_must_fit_their_immutable_windows ... ok
test authentic_two_commit_recovery_rejects_distinct_duplicate_revision ... ok
test full_retained_commit_history_rejects_missing_head_gaps_and_unbacked_current_revision ... ok
test sta001_exact_binding_exhaustion_and_invocation_identity ... ok
test restored_noncommit_must_retain_its_bindings_unchanged_revision ... ok
test sta002_exact_plan_dedup_no_overlap_and_independent_instances ... ok
test sta004_fence_excludes_late_begin_and_reprepare_uses_new_identity ... ok
test sta005_commit_wins_fence_race_and_receipts_are_original ... ok
test sta007_retention_receipts_cannot_be_synthetic ... ok
test sta003_absent_terminal_is_pending_for_all_kinds ... ok
test sta008_critical_reserve_exhaustion_cannot_manufacture_negative_finality ... ok
test sequential_commits_repeated_noncommit_and_independent_revision_spaces_restore ... ok
test sta006_prestart_checks_entire_window_and_historical_has_no_current_admit_check ... ok
test sta009_exclusive_recovery_and_close_keep_issuance_floors ... ok
test started_absent_lookup_late_publication_and_fence_use_same_predicate ... ok
test started_cut_is_not_rechecked_after_revocation_or_delayed_begin_ack ... ok
test restoration_rejects_identity_and_unresolved_overlap_but_keeps_history_and_y ... ok
test trusted_observation_injection_has_finite_instance_and_name_bounds ... ok
test validated_restore_retains_all_attempts_and_invocation_namespace_without_auto_commit ... ok
test sparse_invocation_restore_preserves_actual_remaining_capacity ... ok
test reopen_validates_retained_consumption_before_changing_owner_or_floors ... ok
test fresh_revision_mismatch_refuses_before_reserved_or_queued_for_every_kind ... ok

test result: ok. 28 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/source_boundaries.rs (glade/contracts/target/debug/deps/source_boundaries-625bf4e5641d0a44)

running 5 tests
test checks_disabled_branch_instead_of_skipping_cfg ... ok
test rejects_missing_identity_callback_ownership_and_terminality_fields ... ok
test disabled_associated_foreign_and_field_declarations_are_checked ... ok
test actual_port_preserves_required_boundary_shape ... ok
test tranche_sources_have_explicit_conditional_boundaries ... ok

test result: ok. 5 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.03s

   Doc-tests glade_crdt_admission_core

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

   Doc-tests glade_crdt_admission_data

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

   Doc-tests glade_crdt_evidence_api

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

   Doc-tests glade_crdt_recovery_api

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

   Doc-tests glade_crdt_recovery_codec

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

   Doc-tests glade_crdt_storage_attempt_api

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

    Checking glade-crdt-recovery-api v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-api)
    Finished `dev` profile [unoptimized + debuginfo] target(s) in 0.18s

```

## Affected records lifecycle and 148 retained physical cut witnesses
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'independent::records', '--', '--skip', 'actual_signed_candidate_security_and_fork_native_kinds_171_os_cuts', '--nocapture']
Exit: 101; wall: 44.914s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 5.06s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 33 tests
test independent::records::tests::content::controls::genuine_ordinary_policy_observation_cannot_consume_preallocated_critical_region ... ok
test independent::records::tests::content::ingress::failed_guard_establishment_never_returns_a_consumable_owned_permit ... ok
test independent::records::tests::content::ingress::exact_selected_permanent_ingress_loss_is_validated_but_never_complete ... ok
test independent::records::tests::content::ingress::drained_partial_receive_can_retain_loss_and_close_without_false_complete_on_restart ... ok
test independent::records::tests::content::ingress::record_observation_resumes_only_exact_owned_drained_refused_continuation ... ok
test independent::records::tests::content::ingress::unknown_abandon_retains_unretired_owned_permit_until_durable_selection ... ok
test independent::records::tests::content::ingress::unknown_settlement_keeps_exact_owned_observation_and_failed_loss_write_keeps_floor_guard ... ok
test independent::records::tests::content::ingress_capacity::admitted_guard_critical_loss_can_settle_when_ordinary_image_region_is_full ... ok
test independent::records::tests::content::ingress_cuts::ingress_cut_child ... ignored, owned real guard process child
test independent::records::tests::content::controls::original_verified_continuation_rejects_mutated_facts_before_load ... ok
test independent::records::tests::content::controls::unavailable_verification_retains_provider_observed_floor_before_reply ... ok

thread 'independent::records::tests::content::fences::actual_reserved_fence_wins_and_late_exact_or_contrary_callbacks_never_reopen_terminal' (172753798) panicked at src/independent/records/tests/../tests/fences.rs:102:10:
original core-issued fence
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace
test independent::records::tests::content::fences::actual_reserved_fence_wins_and_late_exact_or_contrary_callbacks_never_reopen_terminal ... FAILED
test independent::records::tests::content::fences::close_retains_actual_reserved_plan_and_stops_new_input_until_original_callback_drains ... ok
test independent::records::tests::content::marker_cuts::marker_cut_child ... ignored, owned authenticated pre-observation crash child
test independent::records::tests::content::controls::full_selected_state_refuses_omitted_terminal_request_and_mutated_projection ... ok
test independent::records::tests::content::native_cuts::native_cut_child ... ignored, owned child of authenticated native cut qualification
test independent::records::tests::content::controls::structurally_valid_pending_next_with_bad_authenticated_state_refuses_before_floor_selection ... ok
test independent::records::tests::content::observation_restart::observation_floor_child ... ignored, owned child of genuine observation floor-ahead witness
test independent::records::tests::content::controls::durable_current_expiry_floor_preserves_historical_original_receipt_and_projection ... ok
test independent::records::tests::content::fences::actual_killed_protected_started_cut_commits_original_receipt_despite_current_revocation ... ok
test independent::records::tests::content::oversized_loss::failed_oversized_loss_publication_preserves_exact_original_owned_continuation ... ok
test independent::records::tests::content::restart::terminal_before_callback_child ... ignored, owned child of genuine native terminal restart witness
test independent::records::tests::content::observation_restart::actual_process_kill_keeps_new_observed_floor_and_refuses_missing_observation_image ... ok
test independent::records::tests::content::ingress_capacity::guard_history_and_critical_discharge_reservation_refuse_before_new_consumption ... ok
test independent::records::tests::content::ingress_cancellation::owned_cancel_is_joined_before_loss_close_and_x_cannot_block_independent_y ... ok
test independent::records::tests::content::restart::actual_process_kill_recovers_original_owned_seal_continuation_without_new_link_authority ... ok
test independent::records::tests::content::kinds::genuine_already_accepted_fork_proof_keeps_original_zero_new_receipt_batch_shape ... ok
test independent::records::tests::content::restart::actual_process_kill_recovers_selected_terminal_through_original_core_callback_before_load ... ok
test independent::records::tests::content::kinds::each_genuine_kind_keeps_live_and_retired_prepare_authority_while_reserved ... ok
test independent::records::tests::content::kinds::all_four_genuine_native_kinds_couple_original_custody_and_reopen_projection ... ok
test independent::records::tests::content::marker_cuts::actual_process_death_at_all_26_marker_and_observation_selection_cuts ... ok
test independent::records::tests::content::ingress_cuts::actual_process_kill_guard_begin_settle_abandon_loss_and_consumed_prefix_reopen_honestly ... ok
test independent::records::tests::content::native_cuts::actual_signed_host_process_kill_reopens_prepare_started_and_terminal_cuts ... ok

failures:

failures:
    independent::records::tests::content::fences::actual_reserved_fence_wins_and_late_exact_or_contrary_callbacks_never_reopen_terminal

test result: FAILED. 27 passed; 1 failed; 5 ignored; 0 measured; 384 filtered out; finished in 38.80s

error: test failed, to rerun pass `--lib`

```

## Node declared architecture adopter gate
Command: ['cargo', 'run', '--quiet', '--locked', '--offline', '--manifest-path', 'glade-discover/tools/architecture-check/Cargo.toml', '--', 'glade/node']
Exit: 0; wall: 0.764s
```text
Architecture boundaries: PASS (workspace libraries, declared dependencies, traits and conformance targets)

```

## Unchanged process-global policy and disabled branches
Command: ['python3', 'glade/scripts/checks/check_process_globals.py', '--repo', 'glade']
Exit: 0; wall: 0.713s
```text
process-global state guard: 151 files, 3 allowlisted items (0 debt, 3 permanent); nothing new

```

## Canonical three-language retained representation gate
Command: ['sh', 'glade/contracts/crdt-recovery-codec/check-vectors.sh']
Exit: 0; wall: 0.904s
```text
Candidate content representation PASS; unqualified for remote use until committed pin and accepted B1 crypto
......
----------------------------------------------------------------------
Ran 6 tests in 0.574s

OK
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.07s
     Running tests/vectors.rs (glade/contracts/target/debug/deps/vectors-e6054aa97de7077a)

running 4 tests
test closed_maps_reject_unknown_duplicate_reordered_or_wrong_context_fields ... ok
test malformed_signature_length_and_wrong_exact_domain_refuse_signed_envelope_shape ... ok
test bounded_malformed_canonical_vectors_fail_closed ... ok
test all_remote_profile_categories_derive_exact_bytes_and_digests_from_semantic_inputs ... ok

test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

Python independent profile vectors: 21 positive + negative controls PASS
(node:96655) ExperimentalWarning: Transform Types is an experimental feature and might change at any time
(Use `node --trace-warnings ...` to show where the warning was created)
TypeScript independent profile vectors: 21 positive + 18 negative controls PASS

```

## Original Fence winner late contrary assertions preserved after exact-request fixture adaptation
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'independent::records::tests::content::fences', '--', '--nocapture']
Exit: 0; wall: 3.949s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 1.96s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 3 tests
test independent::records::tests::content::fences::close_retains_actual_reserved_plan_and_stops_new_input_until_original_callback_drains ... ok
test independent::records::tests::content::fences::actual_reserved_fence_wins_and_late_exact_or_contrary_callbacks_never_reopen_terminal ... ok
test independent::records::tests::content::fences::actual_killed_protected_started_cut_commits_original_receipt_despite_current_revocation ... ok

test result: ok. 3 passed; 0 failed; 0 ignored; 0 measured; 414 filtered out; finished in 0.94s


```

## Three corrected original Fence crash and reattachment cuts
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'retained_cut_crash', '--', '--nocapture']
Exit: 101; wall: 7.264s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 5.79s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 2 tests
test independent::records::tests::content::retained_cut_crash::retained_cut_child ... ignored, owned exact retained-cut Fence crash child

thread 'independent::records::tests::content::retained_cut_crash::actual_death_before_during_after_original_fence_replays_exact_noncommit_without_reminting' (172761440) panicked at src/independent/records/tests/../tests/retained_cut_crash.rs:137:66:
called `Result::unwrap()` on an `Err` value: Integrity
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace
test independent::records::tests::content::retained_cut_crash::actual_death_before_during_after_original_fence_replays_exact_noncommit_without_reminting ... FAILED

failures:

failures:
    independent::records::tests::content::retained_cut_crash::actual_death_before_during_after_original_fence_replays_exact_noncommit_without_reminting

test result: FAILED. 0 passed; 1 failed; 1 ignored; 0 measured; 417 filtered out; finished in 0.41s

error: test failed, to rerun pass `--lib`

```

## Corrected selected Observation issuance custody at three original Fence death cuts
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'retained_cut_crash', '--', '--nocapture']
Exit: 0; wall: 6.874s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 4.11s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 2 tests
test independent::records::tests::content::retained_cut_crash::retained_cut_child ... ignored, owned exact retained-cut Fence crash child
test independent::records::tests::content::retained_cut_crash::actual_death_before_during_after_original_fence_replays_exact_noncommit_without_reminting ... ok

test result: ok. 1 passed; 0 failed; 1 ignored; 0 measured; 417 filtered out; finished in 1.70s


```

## Affected authentication boundary and assembly controls
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--test', 'ic3_auth', '--test', 'ic3_boundary', '--test', 'assembly_di']
Exit: 101; wall: 0.345s
```text
error: no test target named `assembly_di` in default-run packages

help: a target with a similar name exists: `assembly`

```

## Affected authentication boundary and actual assembly controls corrected selector
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--test', 'ic3_auth', '--test', 'ic3_boundary', '--test', 'assembly']
Exit: 0; wall: 8.015s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 5.26s
     Running tests/assembly/main.rs (glade/node/target/debug/deps/assembly-3721822e7bd6d1d9)

running 30 tests
test conformance::cl_002_the_fake_clock_reads_epoch_milliseconds ... ok
test conformance::cl_002_the_system_clock_reads_epoch_milliseconds ... ok
test conformance::cl_001_the_fake_clock_is_one_instant_behind_every_handle ... ok
test conformance::gr_003_an_unreadable_in_memory_fold_is_unavailable ... ok
test conformance::gr_002_in_the_in_memory_fold_revocation_wins_in_either_order ... ok
test conformance::ca_003_the_fake_networks_futures_are_lazy_and_recv_is_cancel_safe ... ok
test conformance::ca_005_the_fake_network_names_each_far_end ... ok
test conformance::ca_004_a_fake_port_gives_its_endpoint_up_by_value ... ok
test conformance::ca_001_the_fake_network_carries_frames_whole_once_and_in_order ... ok
test conformance::ca_002_the_fake_network_holds_the_frame_limit_both_ways ... ok
test conformance::gr_001_the_in_memory_fold_matches_exactly ... ok
test conformance::gr_003_the_grant_fold_the_module_builds_is_unavailable ... ok
test conformance::si_001_the_keyed_test_signer_round_trips_every_purpose ... ok
test conformance::si_002_the_keyed_test_signer_binds_bytes_purpose_and_signer ... ok
test conformance::si_003_the_keyed_test_signer_refuses_without_key_material ... ok
test conformance::ca_006_the_fake_network_binds_each_link_to_its_session ... ok
test each_carrier_role_is_its_own_occurrence_and_the_record_transport_rides_the_peer_one ... ok
test a_test_composition_constructs_no_real_provider ... ok
test one_scope_hands_out_one_occurrence_of_every_binding ... ok
test conformance::si_003_the_node_signer_without_a_key_refuses_both_ways ... ok
test one_grant_selection_reaches_admission ... ok
test the_directory_profile_hosts_every_directory_record_kind_and_nothing_else ... ok
test records_refuse_an_op_outside_the_directory_profile_before_verifying_it ... ok
test one_clock_substitution_reaches_the_directory_and_admission ... ok
test a_concurrent_first_access_of_a_lazy_binding_constructs_once_per_scope ... ok
test conformance::si_002_the_node_signer_binds_bytes_purpose_and_signer ... ok
test sibling_scopes_share_nothing_and_meet_only_through_the_network ... ok
test one_record_host_selection_reaches_the_directory ... ok
test conformance::gr_001_to_003_the_nodes_grant_fold_keeps_the_grant_contract ... ok
test conformance::si_001_the_node_signer_round_trips_every_purpose ... ok

test result: ok. 30 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/ic3_auth.rs (glade/node/target/debug/deps/ic3_auth-e1bc2d4362c83d32)

running 16 tests
test ic3_auth_extra::strict_ed25519_refuses_small_order_writer_and_changed_domain ... ok
test genuine_overlimit_operation_is_refused_before_payload_interpretation ... ok
test genuine_historical_admission_verifies_exact_scoped_signed_records ... ok
test released_payload_duplicate_properties_remain_supported ... ok
test ic3_auth_extra::distinct_fresh_origin_qualifies_but_reused_origin_epoch_or_issuance_refuses ... ok
test ic3_auth_extra::bare_signed_rival_does_not_convict_but_original_signed_admission_qualifies ... ok
test provider_observation_is_genuine_current_signed_policy_and_owned_clock ... ok
test bad_signature_wrong_domain_or_altered_namespace_are_invalid ... ok
test every_local_verification_requires_new_possession_not_operation_cache_reuse ... ok
test root_signature_does_not_authorize_an_unsupported_merge_corpus ... ok
test trusted_source_cannot_regress_observed_clock_or_policy_floor ... ok
test ic3_auth_extra::all_evidence_layers_reject_validly_signed_changed_bindings_or_wrong_keys ... ok
test signed_invalid_payload_is_authenticated_security_data_not_qualified_admission ... ok
test local_possession_seal_and_foreign_or_replayed_session_controls ... ok
test uncertain_expired_or_revoked_current_cut_does_not_change_historical_validity ... ok
test genuine_provider_matches_shared_released_text_syntax_rows ... ok

test result: ok. 16 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.05s

     Running tests/ic3_boundary.rs (glade/node/target/debug/deps/ic3_boundary-330d971e6f6496b5)

running 6 tests
test standalone_refuser_has_no_fabricated_validated_image ... ok
test standalone_refuser_never_issues_a_consume_permit ... ok
test standalone_refuser_rejects_caller_created_permit_before_callback ... ok
test actual_assembled_evidence_verify_seal_and_observe_refuse ... ok
test consumer_detects_recovery_selection_mutant_instead_of_discarding_host ... ok
test production_composition_recovers_a_genuinely_persistent_validated_image ... ok

test result: ok. 6 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.05s


```

## Strict pre-remote remains expected refusal
Command: ['sh', 'glade/contracts/crdt-recovery-codec/check-vectors.sh', '--pre-remote']
Exit: 1; wall: 0.487s
```text
Traceback (most recent call last):
  File "/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-codec/compat/gate.py", line 106, in <module>
    validate(Path(sys.argv[1]), strict=strict)
  File "/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-codec/compat/gate.py", line 53, in validate
    validate_remote(root, pins)
  File "/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-codec/compat/gate.py", line 84, in validate_remote
    raise ValueError("genuine B1 crypto qualification absent")
ValueError: genuine B1 crypto qualification absent

```

## Node affected all-features all-targets clippy retaining baseline debt
Command: ['cargo', 'clippy', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--all-features', '--all-targets']
Exit: 0; wall: 4.539s
```text
    Checking glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
warning: this can be `std::io::Error::other(_)`
   --> src/claims.rs:138:5
    |
138 |     io::Error::new(io::ErrorKind::Other, e)
    |     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    |
    = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
    = note: `#[warn(clippy::io_other_error)]` on by default
help: use `std::io::Error::other`
    |
138 -     io::Error::new(io::ErrorKind::Other, e)
138 +     io::Error::other(e)
    |

warning: this can be `std::io::Error::other(_)`
  --> src/exchange.rs:53:5
   |
53 |     io::Error::new(io::ErrorKind::Other, e)
   |     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
   |
   = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
help: use `std::io::Error::other`
   |
53 -     io::Error::new(io::ErrorKind::Other, e)
53 +     io::Error::other(e)
   |

warning: this can be `std::io::Error::other(_)`
  --> src/iroh_carrier.rs:68:5
   |
68 |     io::Error::new(io::ErrorKind::Other, e)
   |     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
   |
   = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
help: use `std::io::Error::other`
   |
68 -     io::Error::new(io::ErrorKind::Other, e)
68 +     io::Error::other(e)
   |

warning: this can be `std::io::Error::other(_)`
  --> src/mesh.rs:63:5
   |
63 |     io::Error::new(io::ErrorKind::Other, e)
   |     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
   |
   = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
help: use `std::io::Error::other`
   |
63 -     io::Error::new(io::ErrorKind::Other, e)
63 +     io::Error::other(e)
   |

warning: this can be `std::io::Error::other(_)`
   --> src/server.rs:458:18
    |
458 |         other => std::io::Error::new(std::io::ErrorKind::Other, format!("{other:?}")),
    |                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    |
    = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
help: use `std::io::Error::other`
    |
458 -         other => std::io::Error::new(std::io::ErrorKind::Other, format!("{other:?}")),
458 +         other => std::io::Error::other(format!("{other:?}")),
    |

warning: doc list item without indentation
 --> src/ws.rs:3:5
  |
3 | //! (which is text-only) for **binary** frames: glade carries CBOR, not text.
  |     ^
  |
  = help: if this is supposed to be its own paragraph, add a blank line
  = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#doc_lazy_continuation
  = note: `#[warn(clippy::doc_lazy_continuation)]` on by default
help: indent this line
  |
3 | //!   (which is text-only) for **binary** frames: glade carries CBOR, not text.
  |     ++

warning: doc list item without indentation
 --> src/ws.rs:4:5
  |
4 | //! Enough to talk to a browser/Node WebSocket: the upgrade handshake, masked
  |     ^
  |
  = help: if this is supposed to be its own paragraph, add a blank line
  = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#doc_lazy_continuation
help: indent this line
  |
4 | //!   Enough to talk to a browser/Node WebSocket: the upgrade handshake, masked
  |     ++

warning: doc list item without indentation
 --> src/ws.rs:5:5
  |
5 | //! client->server and unmasked server->client binary frames; close surfaced;
  |     ^
  |
  = help: if this is supposed to be its own paragraph, add a blank line
  = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#doc_lazy_continuation
help: indent this line
  |
5 | //!   client->server and unmasked server->client binary frames; close surfaced;
  |     ++

warning: doc list item without indentation
 --> src/ws.rs:6:5
  |
6 | //! ping/pong skipped (trusted localhost).
  |     ^
  |
  = help: if this is supposed to be its own paragraph, add a blank line
  = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#doc_lazy_continuation
help: indent this line
  |
6 | //!   ping/pong skipped (trusted localhost).
  |     ++

warning: `glade-node` (lib) generated 9 warnings (run `cargo clippy --fix --lib -p glade-node -- ` to apply 5 suggestions)
warning: `glade-node` (lib test) generated 9 warnings (9 duplicates)
    Finished `dev` profile [unoptimized + debuginfo] target(s) in 4.47s

```

## Final affected records controls and 151 selected process cuts
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'independent::records', '--', '--skip', 'actual_signed_candidate_security_and_fork_native_kinds_171_os_cuts', '--nocapture']
Exit: 0; wall: 38.248s
```text
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.15s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 35 tests
test independent::records::tests::content::controls::genuine_ordinary_policy_observation_cannot_consume_preallocated_critical_region ... ok
test independent::records::tests::content::ingress::exact_selected_permanent_ingress_loss_is_validated_but_never_complete ... ok
test independent::records::tests::content::ingress::failed_guard_establishment_never_returns_a_consumable_owned_permit ... ok
test independent::records::tests::content::ingress::drained_partial_receive_can_retain_loss_and_close_without_false_complete_on_restart ... ok
test independent::records::tests::content::ingress::record_observation_resumes_only_exact_owned_drained_refused_continuation ... ok
test independent::records::tests::content::ingress::unknown_abandon_retains_unretired_owned_permit_until_durable_selection ... ok
test independent::records::tests::content::ingress::unknown_settlement_keeps_exact_owned_observation_and_failed_loss_write_keeps_floor_guard ... ok
test independent::records::tests::content::ingress_capacity::admitted_guard_critical_loss_can_settle_when_ordinary_image_region_is_full ... ok
test independent::records::tests::content::ingress_cuts::ingress_cut_child ... ignored, owned real guard process child
test independent::records::tests::content::controls::original_verified_continuation_rejects_mutated_facts_before_load ... ok
test independent::records::tests::content::controls::unavailable_verification_retains_provider_observed_floor_before_reply ... ok
test independent::records::tests::content::controls::structurally_valid_pending_next_with_bad_authenticated_state_refuses_before_floor_selection ... ok
test independent::records::tests::content::fences::close_retains_actual_reserved_plan_and_stops_new_input_until_original_callback_drains ... ok
test independent::records::tests::content::marker_cuts::marker_cut_child ... ignored, owned authenticated pre-observation crash child
test independent::records::tests::content::fences::actual_reserved_fence_wins_and_late_exact_or_contrary_callbacks_never_reopen_terminal ... ok
test independent::records::tests::content::native_cuts::native_cut_child ... ignored, owned child of authenticated native cut qualification
test independent::records::tests::content::controls::full_selected_state_refuses_omitted_terminal_request_and_mutated_projection ... ok
test independent::records::tests::content::observation_restart::observation_floor_child ... ignored, owned child of genuine observation floor-ahead witness
test independent::records::tests::content::fences::actual_killed_protected_started_cut_commits_original_receipt_despite_current_revocation ... ok
test independent::records::tests::content::controls::durable_current_expiry_floor_preserves_historical_original_receipt_and_projection ... ok
test independent::records::tests::content::oversized_loss::failed_oversized_loss_publication_preserves_exact_original_owned_continuation ... ok
test independent::records::tests::content::restart::terminal_before_callback_child ... ignored, owned child of genuine native terminal restart witness
test independent::records::tests::content::observation_restart::actual_process_kill_keeps_new_observed_floor_and_refuses_missing_observation_image ... ok
test independent::records::tests::content::retained_cut_crash::retained_cut_child ... ignored, owned exact retained-cut Fence crash child
test independent::records::tests::content::ingress_capacity::guard_history_and_critical_discharge_reservation_refuse_before_new_consumption ... ok
test independent::records::tests::content::kinds::genuine_already_accepted_fork_proof_keeps_original_zero_new_receipt_batch_shape ... ok
test independent::records::tests::content::ingress_cancellation::owned_cancel_is_joined_before_loss_close_and_x_cannot_block_independent_y ... ok
test independent::records::tests::content::restart::actual_process_kill_recovers_original_owned_seal_continuation_without_new_link_authority ... ok
test independent::records::tests::content::restart::actual_process_kill_recovers_selected_terminal_through_original_core_callback_before_load ... ok
test independent::records::tests::content::kinds::each_genuine_kind_keeps_live_and_retired_prepare_authority_while_reserved ... ok
test independent::records::tests::content::kinds::all_four_genuine_native_kinds_couple_original_custody_and_reopen_projection ... ok
test independent::records::tests::content::retained_cut_crash::actual_death_before_during_after_original_fence_replays_exact_noncommit_without_reminting ... ok
test independent::records::tests::content::marker_cuts::actual_process_death_at_all_26_marker_and_observation_selection_cuts ... ok
test independent::records::tests::content::ingress_cuts::actual_process_kill_guard_begin_settle_abandon_loss_and_consumed_prefix_reopen_honestly ... ok
test independent::records::tests::content::native_cuts::actual_signed_host_process_kill_reopens_prepare_started_and_terminal_cuts ... ok

test result: ok. 29 passed; 0 failed; 6 ignored; 0 measured; 384 filtered out; finished in 38.06s


```

## Final formatting retained compatibility and immutable artifacts audit
Command: ['python3', '/tmp/ic3-br2-check-final.py']
Exit: 0; wall: 0.390s
```text
Affected exact formatting PASS: 10 node + 1 contract files
Current compatibility45 and canonical27 unchanged; accepted crypto null
Prior five consumer docs verified against their original committed root; current scoped additions separately pinned
Protected existing initial/typed/B/Rem1 evidence, manifests, logs and complete review testimony unchanged: 23
Manifests/lock versions, role/edge policy and process-global allowance unchanged

```

## Final owned public disk consumers after issuance coupling
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--test', 'ic3_disk', '--', '--nocapture']
Exit: 0; wall: 6.729s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 1.10s
     Running tests/ic3_disk.rs (glade/node/target/debug/deps/ic3_disk-79b05533cd314114)

running 32 tests
test ic3_disk_remediation2::ingress_uses_retained_complete_interval_not_first_narrow_interval ... ok
test genuine_fresh_replica_opens_owned_validated_genesis_and_reopens_same_identity ... ok
test actual_owned_begin_precedes_factory_and_active_guard_suppresses_complete_cut ... ok
test ic3_disk_remediation2::remediation2_child ... ignored, owned public corrected-cut and oversized-loss crash child
test ic3_disk_remediation2::oversized_drained_result_can_discharge_only_as_compact_permanent_loss ... ok
test genuine_challenge_response_custody_and_consumption_survive_owned_reopen ... ok
test finite_authenticated_empty_round_settles_exact_observation_and_never_started_abandons ... ok
test ic3_disk_remediation::loss::public_continuation_child ... ignored, owned public ingress continuation crash child
test ic3_disk_remediation2::stable_valid_complete_interval_still_admits_and_never_started_guard_abandons ... ok
test ic3_disk_remediation::exact_nonempty_inventory_settles_and_retains_exact_missing_obligation ... ok
test ic3_disk_native::actual_storage_attempt_host_narrow_open_preserves_replica_created_namespace_and_owner ... ok
test ic3_disk_remediation::malformed_prefix_cannot_be_replaced_by_signed_empty ... ok
test ic3_disk_remediation::loss::public_refused_drained_settlement_can_select_conservative_loss_and_close ... ok
test ic3_disk_remediation::observations::denied_policy_child ... ignored, owned public denied current-policy observation crash child
test ic3_disk_native::actual_native_attempt_provider_recovers_and_returns_immutable_terminal_for_exact_request ... ok
test ic3_disk_native::trusted_floor_refuses_data_only_rollback_and_missing_floor_after_real_local_commit ... ok
test ic3_disk_remediation::observations::denied_challenge_retains_advanced_time_before_reopen_can_reauthorize ... ok
test ic3_disk_native::actual_genuine_local_commit_persists_owned_callback_history_and_exact_original_receipt ... ok
test ic3_disk_remediation::observations::failed_marker_establishment_never_consults_current_source ... ok
test ic3_disk_remediation2::public_begin_must_recheck_exact_retained_expiry ... ok
test ic3_disk_remediation2::public_begin_must_recheck_exact_retained_revocation ... ok
test ic3_disk_remediation::observations::learned_chained_revocation_survives_actual_process_death_and_older_provider ... ok
test ic3_disk_remediation::observations::learned_denial_with_failed_publication_keeps_full_and_narrow_reopen_unavailable ... ok
test ic3_disk_remediation::observations::capacity_refusal_after_learning_keeps_marker_unavailable_and_survives_both_open_forms ... ok
test ic3_disk_remediation::exact_retired_prepare_replay_recovers_original_attempt_before_and_after_reopen ... ok
test ic3_disk_remediation::receive_error_cannot_be_replaced_by_signed_empty ... ok
test ic3_disk_remediation::observations::denied_response_retains_time_and_denied_ingress_retains_peer_revocation ... ok
test ic3_disk_remediation::signed_nonempty_cannot_be_replaced_by_different_signed_empty ... ok
test ic3_disk_remediation::observations::receive_only_holder_advances_trusted_time_and_converges_without_append_grants ... ok
test ic3_disk_remediation::loss::public_refusal_unknown_and_capacity_loss_survive_actual_process_death ... ok
test ic3_disk_remediation2::earlier_verify_and_seal_replies_do_not_admit_after_their_retained_cut_advances ... ok
test ic3_disk_remediation2::corrected_denials_and_oversized_loss_custody_survive_actual_process_death ... ok

test result: ok. 29 passed; 0 failed; 3 ignored; 0 measured; 0 filtered out; finished in 4.93s


```

## Final disabled-source scope including new process children
Command: ['cargo', 'test', '--manifest-path', 'glade/contracts/Cargo.toml', '--locked', '--offline', '-p', 'glade-crdt-recovery-api', '--test', 'source_boundaries']
Exit: 0; wall: 0.222s
```text
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.03s
     Running tests/source_boundaries.rs (glade/contracts/target/debug/deps/source_boundaries-d87c63d050de1dbe)

running 4 tests
test checks_disabled_branch_instead_of_skipping_cfg ... ok
test disabled_associated_foreign_and_field_declarations_are_checked ... ok
test tranche_sources_have_explicit_conditional_boundaries ... ok
test actual_node_independent_subtree_and_disabled_branches_are_checked ... ok

test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.15s


```

## Final source process-global policy unchanged allowance
Command: ['python3', 'glade/scripts/checks/check_process_globals.py', '--repo', 'glade']
Exit: 0; wall: 0.678s
```text
process-global state guard: 152 files, 3 allowlisted items (0 debt, 3 permanent); nothing new

```
