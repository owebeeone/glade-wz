
## B1 genuine historical and trusted-observation actual compiling capability RED
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_auth']
Exit: 101; wall: 8.728s
```text
   Compiling glade-crdt-recovery-codec v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-codec)
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
warning: field `certificate` is never read
  --> tests/ic3_auth_fixture/mod.rs:35:9
   |
32 | pub struct Fixture {
   |            ------- field in this struct
...
35 |     pub certificate: SignedRecord,
   |         ^^^^^^^^^^^
   |
   = note: `#[warn(dead_code)]` (part of `#[warn(unused)]`) on by default

warning: `glade-node` (test "ic3_auth") generated 1 warning
    Finished `test` profile [unoptimized + debuginfo] target(s) in 8.25s
     Running tests/ic3_auth.rs (glade/node/target/debug/deps/ic3_auth-d29f661d7892e84b)

running 2 tests
test genuine_historical_admission_verifies_exact_scoped_signed_records ... FAILED
test provider_observation_is_genuine_current_signed_policy_and_owned_clock ... FAILED

failures:

---- genuine_historical_admission_verifies_exact_scoped_signed_records stdout ----

thread 'genuine_historical_admission_verifies_exact_scoped_signed_records' (171833345) panicked at tests/ic3_auth.rs:17:9:
genuine historical admission must verify

---- provider_observation_is_genuine_current_signed_policy_and_owned_clock stdout ----

thread 'provider_observation_is_genuine_current_signed_policy_and_owned_clock' (171833346) panicked at tests/ic3_auth.rs:40:10:
configured genuine policy/time provider: Unavailable
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace


failures:
    genuine_historical_admission_verifies_exact_scoped_signed_records
    provider_observation_is_genuine_current_signed_policy_and_owned_clock

test result: FAILED. 0 passed; 2 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

error: test failed, to rerun pass `--test ic3_auth`

```

## B1 bad-signature/domain/identity actual semantic refusal RED
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_auth', 'bad_signature_wrong_domain_or_altered_namespace_are_invalid', '--', '--exact']
Exit: 101; wall: 1.072s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
warning: field `certificate` is never read
  --> tests/ic3_auth_fixture/mod.rs:35:9
   |
32 | pub struct Fixture {
   |            ------- field in this struct
...
35 |     pub certificate: SignedRecord,
   |         ^^^^^^^^^^^
   |
   = note: `#[warn(dead_code)]` (part of `#[warn(unused)]`) on by default

warning: `glade-node` (test "ic3_auth") generated 1 warning
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.58s
     Running tests/ic3_auth.rs (glade/node/target/debug/deps/ic3_auth-d29f661d7892e84b)

running 1 test
test bad_signature_wrong_domain_or_altered_namespace_are_invalid ... FAILED

failures:

---- bad_signature_wrong_domain_or_altered_namespace_are_invalid stdout ----

thread 'bad_signature_wrong_domain_or_altered_namespace_are_invalid' (171836166) panicked at tests/ic3_auth.rs:77:9:
assertion `left == right` failed: mutation0
  left: Unavailable
 right: Invalid
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace


failures:
    bad_signature_wrong_domain_or_altered_namespace_are_invalid

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 2 filtered out; finished in 0.00s

error: test failed, to rerun pass `--test ic3_auth`

```

## B1 genuine invalid-payload security classification RED
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_auth', 'signed_invalid_payload_is_authenticated_security_data_not_qualified_admission', '--', '--exact']
Exit: 101; wall: 1.579s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 1.11s
     Running tests/ic3_auth.rs (glade/node/target/debug/deps/ic3_auth-d29f661d7892e84b)

running 1 test
test signed_invalid_payload_is_authenticated_security_data_not_qualified_admission ... FAILED

failures:

---- signed_invalid_payload_is_authenticated_security_data_not_qualified_admission stdout ----

thread 'signed_invalid_payload_is_authenticated_security_data_not_qualified_admission' (171858200) panicked at tests/ic3_auth.rs:101:9:
authentic signed invalid payload retains its verifier classification
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace


failures:
    signed_invalid_payload_is_authenticated_security_data_not_qualified_admission

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 3 filtered out; finished in 0.00s

error: test failed, to rerun pass `--test ic3_auth`

```

## B1 genuine historical signature namespace and owned observation GREEN
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_auth']
Exit: 0; wall: 12.576s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 12.07s
     Running tests/ic3_auth.rs (glade/node/target/debug/deps/ic3_auth-d29f661d7892e84b)

running 4 tests
test provider_observation_is_genuine_current_signed_policy_and_owned_clock ... ok
test genuine_historical_admission_verifies_exact_scoped_signed_records ... ok
test signed_invalid_payload_is_authenticated_security_data_not_qualified_admission ... ok
test bad_signature_wrong_domain_or_altered_namespace_are_invalid ... ok

test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s


```

## B1 possession seal/current controls and observed-floor regression RED
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_auth']
Exit: 101; wall: 1.888s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 1.38s
     Running tests/ic3_auth.rs (glade/node/target/debug/deps/ic3_auth-d29f661d7892e84b)

running 7 tests
test trusted_source_cannot_regress_observed_clock_or_policy_floor ... FAILED
test provider_observation_is_genuine_current_signed_policy_and_owned_clock ... ok
test genuine_historical_admission_verifies_exact_scoped_signed_records ... ok
test signed_invalid_payload_is_authenticated_security_data_not_qualified_admission ... ok
test bad_signature_wrong_domain_or_altered_namespace_are_invalid ... ok
test uncertain_expired_or_revoked_current_cut_does_not_change_historical_validity ... ok
test local_possession_seal_and_foreign_or_replayed_session_controls ... ok

failures:

---- trusted_source_cannot_regress_observed_clock_or_policy_floor stdout ----

thread 'trusted_source_cannot_regress_observed_clock_or_policy_floor' (171866723) panicked at tests/ic3_auth.rs:325:5:
assertion `left == right` failed
  left: Ok(EvidenceObservation { instance: Instance { descriptor: [106, 112, 80, 115, 206, 61, 227, 118, 144, 79, 213, 227, 34, 128, 156, 165, 211, 75, 245, 227, 197, 157, 251, 107, 251, 46, 13, 255, 180, 214, 0, 21], incarnation: "fresh-ic3" }, node: [136, 75, 136, 87, 244, 234, 161, 97, 60, 97, 80, 77, 179, 77, 75, 234, 243, 70, 81, 122, 14, 49, 222, 60, 221, 212, 217, 180, 32, 29, 157, 11], policy: Bytes { value: [167, 0, 1, 1, 108, 83, 105, 103, 110, 101, 100, 82, 101, 99, 111, 114, 100, 2, 120, 24, 103, 108, 97, 100, 101, 47, 105, 99, 51, 47, 118, 49, 47, 112, 111, 108, 105, 99, 121, 45, 99, 117, 116, 0, 3, 72, 0, 0, 0, 0, 0, 0, 0, 1, 4, 88, 32, 102, 190, 126, 51, 44, 122, 69, 51, 50, 189, 157, 10, 127, 125, 176, 85, 245, 197, 239, 26, 6, 173, 166, 109, 152, 179, 159, 182, 129, 12, 71, 58, 5, 89, 5, 226, 172, 0, 1, 1, 106, 80, 111, 108, 105, 99, 121, 66, 111, 100, 121, 2, 162, 0, 88, 32, 106, 112, 80, 115, 206, 61, 227, 118, 144, 79, 213, 227, 34, 128, 156, 165, 211, 75, 245, 227, 197, 157, 251, 107, 251, 46, 13, 255, 180, 214, 0, 21, 1, 105, 102, 114, 101, 115, 104, 45, 105, 99, 51, 3, 178, 0, 88, 32, 102, 190, 126, 51, 44, 122, 69, 51, 50, 189, 157, 10, 127, 125, 176, 85, 245, 197, 239, 26, 6, 173, 166, 109, 152, 179, 159, 182, 129, 12, 71, 58, 1, 89, 3, 104, 184, 35, 0, 1, 1, 110, 67, 114, 101, 97, 116, 105, 111, 110, 73, 110, 116, 101, 110, 116, 2, 88, 32, 102, 190, 126, 51, 44, 122, 69, 51, 50, 189, 157, 10, 127, 125, 176, 85, 245, 197, 239, 26, 6, 173, 166, 109, 152, 179, 159, 182, 129, 12, 71, 58, 3, 88, 32, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 4, 105, 102, 114, 101, 115, 104, 45, 105, 99, 51, 5, 114, 112, 114, 105, 118, 97, 116, 101, 58, 97, 108, 105, 99, 101, 58, 116, 101, 120, 116, 6, 101, 97, 108, 105, 99, 101, 7, 103, 112, 114, 105, 118, 97, 116, 101, 8, 104, 105, 99, 51, 45, 116, 101, 120, 116, 9, 104, 100, 111, 99, 117, 109, 101, 110, 116, 10, 64, 11, 88, 32, 170, 40, 65, 78, 191, 215, 116, 126, 141, 147, 158, 237, 82, 203, 139, 203, 174, 121, 54, 7, 87, 45, 34, 180, 81, 211, 1, 161, 227, 90, 4, 228, 12, 107, 105, 99, 51, 45, 116, 101, 120, 116, 47, 118, 49, 13, 129, 0, 14, 109, 105, 99, 51, 45, 101, 109, 112, 116, 121, 45, 107, 101, 121, 15, 88, 32, 0, 77, 178, 86, 2, 244, 51, 93, 2, 135, 247, 15, 155, 145, 243, 59, 219, 106, 163, 171, 105, 181, 252, 57, 205, 85, 46, 179, 186, 81, 101, 174, 16, 97, 49, 17, 65, 160, 18, 110, 99, 114, 100, 116, 46, 111, 114, 97, 99, 108, 101, 47, 118, 49, 19, 116, 116, 101, 120, 116, 95, 99, 114, 100, 116, 46, 112, 114, 111, 102, 105, 108, 101, 47, 118, 49, 20, 120, 35, 103, 108, 97, 100, 101, 46, 99, 114, 100, 116, 46, 105, 110, 100, 101, 112, 101, 110, 100, 101, 110, 116, 45, 97, 100, 109, 105, 115, 115, 105, 111, 110, 47, 118, 49, 21, 120, 25, 98, 111, 117, 110, 100, 101, 100, 45, 111, 102, 102, 108, 105, 110, 101, 45, 112, 101, 114, 109, 105, 116, 47, 118, 49, 22, 120, 26, 105, 99, 51, 45, 100, 105, 114, 101, 99, 116, 45, 114, 111, 111, 116, 45, 101, 100, 50, 53, 53, 49, 57, 47, 118, 49, 23, 116, 105, 99, 51, 45, 114, 101, 99, 111, 114, 100, 115, 45, 102, 108, 111, 111, 114, 47, 118, 49, 24, 24, 117, 102, 117, 108, 108, 45, 104, 105, 115, 116, 111, 114, 121, 45, 110, 111, 45, 103, 99, 47, 118, 49, 24, 25, 120, 26, 101, 120, 97, 99, 116, 45, 101, 118, 105, 100, 101, 110, 99, 101, 45, 102, 117, 108, 108, 45, 99, 117, 116, 47, 118, 49, 24, 26, 120, 51, 116, 97, 117, 116, 45, 115, 104, 97, 112, 101, 47, 116, 101, 120, 116, 95, 99, 114, 100, 116, 46, 112, 114, 111, 102, 105, 108, 101, 46, 118, 49, 47, 99, 111, 110, 99, 117, 114, 114, 101, 110, 116, 95, 115, 105, 98, 108, 105, 110, 103, 115, 24, 27, 97, 49, 24, 28, 88, 32, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 24, 29, 129, 0, 24, 30, 129, 1, 24, 31, 168, 0, 72, 0, 0, 0, 0, 0, 0, 32, 0, 1, 72, 0, 0, 0, 0, 0, 0, 0, 8, 2, 72, 0, 0, 0, 0, 0, 0, 0, 16, 3, 72, 0, 0, 0, 0, 0, 15, 66, 64, 4, 72, 0, 0, 0, 0, 0, 1, 134, 160, 5, 72, 0, 0, 0, 0, 0, 1, 134, 160, 6, 72, 0, 0, 0, 0, 0, 1, 134, 160, 7, 72, 0, 0, 0, 0, 0, 0, 0, 32, 24, 32, 168, 0, 169, 0, 72, 0, 0, 0, 0, 0, 0, 0, 2, 1, 72, 0, 0, 0, 0, 0, 0, 0, 32, 2, 72, 0, 0, 0, 0, 0, 0, 0, 128, 3, 72, 0, 0, 0, 0, 0, 7, 161, 32, 4, 72, 0, 0, 0, 0, 0, 0, 0, 8, 5, 72, 0, 0, 0, 0, 0, 0, 0, 8, 6, 72, 0, 0, 0, 0, 0, 0, 2, 0, 7, 72, 0, 0, 0, 0, 0, 1, 134, 160, 8, 72, 0, 0, 0, 0, 0, 0, 4, 0, 1, 164, 0, 72, 0, 0, 0, 0, 0, 15, 66, 64, 1, 72, 0, 0, 0, 0, 0, 0, 78, 32, 2, 72, 0, 0, 0, 0, 0, 0, 0, 64, 3, 72, 0, 0, 0, 0, 0, 0, 2, 0, 2, 72, 0, 0, 0, 0, 0, 15, 66, 64, 3, 72, 0, 0, 0, 0, 0, 0, 0, 64, 4, 72, 0, 0, 0, 0, 0, 0, 0, 64, 5, 72, 0, 0, 0, 0, 0, 1, 134, 160, 6, 72, 0, 0, 0, 0, 0, 0, 0, 128, 7, 72, 0, 0, 0, 0, 0, 1, 134, 160, 24, 33, 0, 24, 34, 72, 0, 0, 0, 0, 0, 0, 0, 0, 2, 103, 112, 114, 105, 118, 97, 116, 101, 3, 65, 160, 4, 88, 45, 163, 0, 110, 99, 114, 100, 116, 46, 111, 114, 97, 99, 108, 101, 47, 118, 49, 1, 116, 116, 101, 120, 116, 95, 99, 114, 100, 116, 46, 112, 114, 111, 102, 105, 108, 101, 47, 118, 49, 2, 100, 67, 114, 100, 116, 5, 107, 105, 99, 51, 45, 116, 101, 120, 116, 47, 118, 49, 6, 83, 161, 0, 112, 105, 99, 51, 45, 101, 109, 112, 116, 121, 45, 107, 101, 121, 47, 118, 49, 7, 109, 105, 99, 51, 45, 101, 109, 112, 116, 121, 45, 107, 101, 121, 8, 97, 49, 9, 120, 51, 116, 97, 117, 116, 45, 115, 104, 97, 112, 101, 47, 116, 101, 120, 116, 95, 99, 114, 100, 116, 46, 112, 114, 111, 102, 105, 108, 101, 46, 118, 49, 47, 99, 111, 110, 99, 117, 114, 114, 101, 110, 116, 95, 115, 105, 98, 108, 105, 110, 103, 115, 10, 97, 49, 11, 88, 32, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 12, 120, 26, 105, 99, 51, 45, 100, 105, 114, 101, 99, 116, 45, 114, 111, 111, 116, 45, 101, 100, 50, 53, 53, 49, 57, 47, 118, 49, 13, 116, 105, 99, 51, 45, 114, 101, 99, 111, 114, 100, 115, 45, 102, 108, 111, 111, 114, 47, 118, 49, 14, 117, 102, 117, 108, 108, 45, 104, 105, 115, 116, 111, 114, 121, 45, 110, 111, 45, 103, 99, 47, 118, 49, 15, 120, 26, 101, 120, 97, 99, 116, 45, 101, 118, 105, 100, 101, 110, 99, 101, 45, 102, 117, 108, 108, 45, 99, 117, 116, 47, 118, 49, 16, 0, 17, 72, 0, 0, 0, 0, 0, 0, 0, 0, 4, 88, 32, 112, 83, 161, 75, 137, 60, 130, 140, 191, 139, 118, 167, 160, 156, 176, 165, 15, 66, 178, 252, 148, 95, 60, 218, 116, 247, 12, 137, 170, 64, 51, 247, 5, 72, 0, 0, 0, 0, 0, 0, 0, 0, 6, 246, 7, 162, 0, 72, 0, 0, 0, 0, 0, 0, 0, 0, 1, 72, 0, 0, 0, 0, 0, 0, 3, 232, 8, 129, 164, 0, 101, 97, 108, 105, 99, 101, 1, 88, 32, 81, 28, 52, 161, 162, 203, 82, 29, 241, 107, 178, 70, 184, 222, 142, 121, 151, 206, 35, 92, 126, 118, 178, 42, 61, 117, 3, 162, 72, 25, 221, 138, 2, 129, 0, 3, 114, 112, 114, 105, 118, 97, 116, 101, 58, 97, 108, 105, 99, 101, 58, 116, 101, 120, 116, 9, 128, 10, 129, 88, 32, 136, 75, 136, 87, 244, 234, 161, 97, 60, 97, 80, 77, 179, 77, 75, 234, 243, 70, 81, 122, 14, 49, 222, 60, 221, 212, 217, 180, 32, 29, 157, 11, 11, 129, 88, 32, 136, 75, 136, 87, 244, 234, 161, 97, 60, 97, 80, 77, 179, 77, 75, 234, 243, 70, 81, 122, 14, 49, 222, 60, 221, 212, 217, 180, 32, 29, 157, 11, 6, 88, 64, 213, 242, 168, 146, 64, 62, 87, 81, 160, 121, 252, 187, 161, 163, 27, 181, 7, 71, 222, 41, 4, 76, 134, 147, 90, 17, 20, 52, 93, 166, 174, 200, 14, 215, 7, 102, 70, 18, 69, 149, 143, 76, 128, 47, 86, 170, 2, 246, 116, 210, 182, 136, 163, 108, 28, 115, 219, 116, 226, 244, 106, 12, 231, 2], digest: [16, 225, 251, 177, 77, 159, 221, 208, 163, 151, 57, 99, 94, 183, 0, 251, 216, 234, 165, 9, 184, 175, 226, 86, 51, 43, 139, 208, 4, 187, 11, 82] }, time: TimeInterval { earliest_ms: 19, latest_ms: 20 }, available: true, allowed: true })
 right: Err(Unavailable)
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace


failures:
    trusted_source_cannot_regress_observed_clock_or_policy_floor

test result: FAILED. 6 passed; 1 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

error: test failed, to rerun pass `--test ic3_auth`

```

## B1 fresh possession cannot be bypassed by an operation cache RED
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_auth', 'every_local_verification_requires_new_possession_not_operation_cache_reuse', '--', '--exact']
Exit: 101; wall: 1.119s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.55s
     Running tests/ic3_auth.rs (glade/node/target/debug/deps/ic3_auth-d29f661d7892e84b)

running 1 test
test every_local_verification_requires_new_possession_not_operation_cache_reuse ... FAILED

failures:

---- every_local_verification_requires_new_possession_not_operation_cache_reuse stdout ----

thread 'every_local_verification_requires_new_possession_not_operation_cache_reuse' (171870556) panicked at tests/ic3_auth.rs:355:5:
assertion `left == right` failed: a separate local attempt cannot reuse the consumed possession gate
  left: Verified(Facts { certificate: OriginCertificate { instance: Instance { descriptor: [106, 112, 80, 115, 206, 61, 227, 118, 144, 79, 213, 227, 34, 128, 156, 165, 211, 75, 245, 227, 197, 157, 251, 107, 251, 46, 13, 255, 180, 214, 0, 21], incarnation: "fresh-ic3" }, canonical_origin: "writer-e0", epoch: "e0", display_name: "writer", writer_key: [81, 28, 52, 161, 162, 203, 82, 29, 241, 107, 178, 70, 184, 222, 142, 121, 151, 206, 35, 92, 126, 118, 178, 42, 61, 117, 3, 162, 72, 25, 221, 138], requester: "alice", canonical: Bytes { value: [167, 0, 1, 1, 108, 83, 105, 103, 110, 101, 100, 82, 101, 99, 111, 114, 100, 2, 120, 32, 103, 108, 97, 100, 101, 47, 105, 99, 51, 47, 118, 49, 47, 111, 114, 105, 103, 105, 110, 45, 99, 101, 114, 116, 105, 102, 105, 99, 97, 116, 101, 0, 3, 72, 0, 0, 0, 0, 0, 0, 0, 1, 4, 88, 32, 102, 190, 126, 51, 44, 122, 69, 51, 50, 189, 157, 10, 127, 125, 176, 85, 245, 197, 239, 26, 6, 173, 166, 109, 152, 179, 159, 182, 129, 12, 71, 58, 5, 89, 5, 150, 172, 0, 1, 1, 111, 67, 101, 114, 116, 105, 102, 105, 99, 97, 116, 101, 66, 111, 100, 121, 2, 162, 0, 88, 32, 106, 112, 80, 115, 206, 61, 227, 118, 144, 79, 213, 227, 34, 128, 156, 165, 211, 75, 245, 227, 197, 157, 251, 107, 251, 46, 13, 255, 180, 214, 0, 21, 1, 105, 102, 114, 101, 115, 104, 45, 105, 99, 51, 3, 178, 0, 88, 32, 102, 190, 126, 51, 44, 122, 69, 51, 50, 189, 157, 10, 127, 125, 176, 85, 245, 197, 239, 26, 6, 173, 166, 109, 152, 179, 159, 182, 129, 12, 71, 58, 1, 89, 3, 104, 184, 35, 0, 1, 1, 110, 67, 114, 101, 97, 116, 105, 111, 110, 73, 110, 116, 101, 110, 116, 2, 88, 32, 102, 190, 126, 51, 44, 122, 69, 51, 50, 189, 157, 10, 127, 125, 176, 85, 245, 197, 239, 26, 6, 173, 166, 109, 152, 179, 159, 182, 129, 12, 71, 58, 3, 88, 32, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 4, 105, 102, 114, 101, 115, 104, 45, 105, 99, 51, 5, 114, 112, 114, 105, 118, 97, 116, 101, 58, 97, 108, 105, 99, 101, 58, 116, 101, 120, 116, 6, 101, 97, 108, 105, 99, 101, 7, 103, 112, 114, 105, 118, 97, 116, 101, 8, 104, 105, 99, 51, 45, 116, 101, 120, 116, 9, 104, 100, 111, 99, 117, 109, 101, 110, 116, 10, 64, 11, 88, 32, 170, 40, 65, 78, 191, 215, 116, 126, 141, 147, 158, 237, 82, 203, 139, 203, 174, 121, 54, 7, 87, 45, 34, 180, 81, 211, 1, 161, 227, 90, 4, 228, 12, 107, 105, 99, 51, 45, 116, 101, 120, 116, 47, 118, 49, 13, 129, 0, 14, 109, 105, 99, 51, 45, 101, 109, 112, 116, 121, 45, 107, 101, 121, 15, 88, 32, 0, 77, 178, 86, 2, 244, 51, 93, 2, 135, 247, 15, 155, 145, 243, 59, 219, 106, 163, 171, 105, 181, 252, 57, 205, 85, 46, 179, 186, 81, 101, 174, 16, 97, 49, 17, 65, 160, 18, 110, 99, 114, 100, 116, 46, 111, 114, 97, 99, 108, 101, 47, 118, 49, 19, 116, 116, 101, 120, 116, 95, 99, 114, 100, 116, 46, 112, 114, 111, 102, 105, 108, 101, 47, 118, 49, 20, 120, 35, 103, 108, 97, 100, 101, 46, 99, 114, 100, 116, 46, 105, 110, 100, 101, 112, 101, 110, 100, 101, 110, 116, 45, 97, 100, 109, 105, 115, 115, 105, 111, 110, 47, 118, 49, 21, 120, 25, 98, 111, 117, 110, 100, 101, 100, 45, 111, 102, 102, 108, 105, 110, 101, 45, 112, 101, 114, 109, 105, 116, 47, 118, 49, 22, 120, 26, 105, 99, 51, 45, 100, 105, 114, 101, 99, 116, 45, 114, 111, 111, 116, 45, 101, 100, 50, 53, 53, 49, 57, 47, 118, 49, 23, 116, 105, 99, 51, 45, 114, 101, 99, 111, 114, 100, 115, 45, 102, 108, 111, 111, 114, 47, 118, 49, 24, 24, 117, 102, 117, 108, 108, 45, 104, 105, 115, 116, 111, 114, 121, 45, 110, 111, 45, 103, 99, 47, 118, 49, 24, 25, 120, 26, 101, 120, 97, 99, 116, 45, 101, 118, 105, 100, 101, 110, 99, 101, 45, 102, 117, 108, 108, 45, 99, 117, 116, 47, 118, 49, 24, 26, 120, 51, 116, 97, 117, 116, 45, 115, 104, 97, 112, 101, 47, 116, 101, 120, 116, 95, 99, 114, 100, 116, 46, 112, 114, 111, 102, 105, 108, 101, 46, 118, 49, 47, 99, 111, 110, 99, 117, 114, 114, 101, 110, 116, 95, 115, 105, 98, 108, 105, 110, 103, 115, 24, 27, 97, 49, 24, 28, 88, 32, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 24, 29, 129, 0, 24, 30, 129, 1, 24, 31, 168, 0, 72, 0, 0, 0, 0, 0, 0, 32, 0, 1, 72, 0, 0, 0, 0, 0, 0, 0, 8, 2, 72, 0, 0, 0, 0, 0, 0, 0, 16, 3, 72, 0, 0, 0, 0, 0, 15, 66, 64, 4, 72, 0, 0, 0, 0, 0, 1, 134, 160, 5, 72, 0, 0, 0, 0, 0, 1, 134, 160, 6, 72, 0, 0, 0, 0, 0, 1, 134, 160, 7, 72, 0, 0, 0, 0, 0, 0, 0, 32, 24, 32, 168, 0, 169, 0, 72, 0, 0, 0, 0, 0, 0, 0, 2, 1, 72, 0, 0, 0, 0, 0, 0, 0, 32, 2, 72, 0, 0, 0, 0, 0, 0, 0, 128, 3, 72, 0, 0, 0, 0, 0, 7, 161, 32, 4, 72, 0, 0, 0, 0, 0, 0, 0, 8, 5, 72, 0, 0, 0, 0, 0, 0, 0, 8, 6, 72, 0, 0, 0, 0, 0, 0, 2, 0, 7, 72, 0, 0, 0, 0, 0, 1, 134, 160, 8, 72, 0, 0, 0, 0, 0, 0, 4, 0, 1, 164, 0, 72, 0, 0, 0, 0, 0, 15, 66, 64, 1, 72, 0, 0, 0, 0, 0, 0, 78, 32, 2, 72, 0, 0, 0, 0, 0, 0, 0, 64, 3, 72, 0, 0, 0, 0, 0, 0, 2, 0, 2, 72, 0, 0, 0, 0, 0, 15, 66, 64, 3, 72, 0, 0, 0, 0, 0, 0, 0, 64, 4, 72, 0, 0, 0, 0, 0, 0, 0, 64, 5, 72, 0, 0, 0, 0, 0, 1, 134, 160, 6, 72, 0, 0, 0, 0, 0, 0, 0, 128, 7, 72, 0, 0, 0, 0, 0, 1, 134, 160, 24, 33, 0, 24, 34, 72, 0, 0, 0, 0, 0, 0, 0, 0, 2, 103, 112, 114, 105, 118, 97, 116, 101, 3, 65, 160, 4, 88, 45, 163, 0, 110, 99, 114, 100, 116, 46, 111, 114, 97, 99, 108, 101, 47, 118, 49, 1, 116, 116, 101, 120, 116, 95, 99, 114, 100, 116, 46, 112, 114, 111, 102, 105, 108, 101, 47, 118, 49, 2, 100, 67, 114, 100, 116, 5, 107, 105, 99, 51, 45, 116, 101, 120, 116, 47, 118, 49, 6, 83, 161, 0, 112, 105, 99, 51, 45, 101, 109, 112, 116, 121, 45, 107, 101, 121, 47, 118, 49, 7, 109, 105, 99, 51, 45, 101, 109, 112, 116, 121, 45, 107, 101, 121, 8, 97, 49, 9, 120, 51, 116, 97, 117, 116, 45, 115, 104, 97, 112, 101, 47, 116, 101, 120, 116, 95, 99, 114, 100, 116, 46, 112, 114, 111, 102, 105, 108, 101, 46, 118, 49, 47, 99, 111, 110, 99, 117, 114, 114, 101, 110, 116, 95, 115, 105, 98, 108, 105, 110, 103, 115, 10, 97, 49, 11, 88, 32, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 12, 120, 26, 105, 99, 51, 45, 100, 105, 114, 101, 99, 116, 45, 114, 111, 111, 116, 45, 101, 100, 50, 53, 53, 49, 57, 47, 118, 49, 13, 116, 105, 99, 51, 45, 114, 101, 99, 111, 114, 100, 115, 45, 102, 108, 111, 111, 114, 47, 118, 49, 14, 117, 102, 117, 108, 108, 45, 104, 105, 115, 116, 111, 114, 121, 45, 110, 111, 45, 103, 99, 47, 118, 49, 15, 120, 26, 101, 120, 97, 99, 116, 45, 101, 118, 105, 100, 101, 110, 99, 101, 45, 102, 117, 108, 108, 45, 99, 117, 116, 47, 118, 49, 16, 0, 17, 72, 0, 0, 0, 0, 0, 0, 0, 0, 4, 114, 112, 114, 105, 118, 97, 116, 101, 58, 97, 108, 105, 99, 101, 58, 116, 101, 120, 116, 5, 105, 119, 114, 105, 116, 101, 114, 45, 101, 48, 6, 98, 101, 48, 7, 102, 119, 114, 105, 116, 101, 114, 8, 88, 32, 81, 28, 52, 161, 162, 203, 82, 29, 241, 107, 178, 70, 184, 222, 142, 121, 151, 206, 35, 92, 126, 118, 178, 42, 61, 117, 3, 162, 72, 25, 221, 138, 9, 101, 97, 108, 105, 99, 101, 10, 88, 32, 112, 83, 161, 75, 137, 60, 130, 140, 191, 139, 118, 167, 160, 156, 176, 165, 15, 66, 178, 252, 148, 95, 60, 218, 116, 247, 12, 137, 170, 64, 51, 247, 11, 72, 0, 0, 0, 0, 0, 0, 0, 0, 6, 88, 64, 16, 164, 236, 75, 168, 158, 80, 110, 190, 101, 179, 17, 161, 75, 62, 46, 17, 81, 151, 111, 21, 221, 137, 44, 211, 81, 148, 105, 222, 214, 48, 51, 38, 80, 235, 48, 91, 214, 136, 190, 151, 44, 83, 226, 13, 183, 35, 67, 222, 238, 218, 148, 22, 247, 142, 5, 204, 56, 172, 108, 178, 86, 148, 1], digest: [173, 143, 216, 115, 119, 0, 26, 131, 186, 22, 131, 221, 21, 152, 188, 105, 183, 157, 99, 115, 62, 6, 75, 13, 65, 236, 121, 198, 143, 176, 50, 228] } }, descriptor_valid: true, payload_valid: true, signatures_valid: true, issuance_unique: true, permit_window: Window { not_before_ms: 10, not_after_ms: 100 }, permit_first_seq: 0, permit_last_seq: 8, current_allowed: true, historical_admitter_authorized: false, historical_policy_allowed: false, historical_time: None })
 right: Invalid
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace


failures:
    every_local_verification_requires_new_possession_not_operation_cache_reuse

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 7 filtered out; finished in 0.00s

error: test failed, to rerun pass `--test ic3_auth`

```

## B1 single-use possession and monotonic provider observations GREEN
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_auth']
Exit: 101; wall: 1.479s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
error[E0425]: cannot find value `for_seal` in this scope
   --> src/independent/auth.rs:433:37
    |
433 |                 let authorized = if for_seal {
    |                                     ^^^^^^^^ not found in this scope

error[E0061]: this method takes 2 arguments but 3 arguments were supplied
   --> src/independent/auth.rs:474:34
    |
474 |         let verdict = match self.checked(&query, &query.query.mode, false) {
    |                                  ^^^^^^^                            ----- unexpected argument #3 of type `bool`
    |
note: method defined here
   --> src/independent/auth.rs:284:8
    |
284 |     fn checked(&mut self, bound: &BoundQuery, mode: &Mode) -> Result<Facts, Fault> {
    |        ^^^^^^^
help: remove the extra argument
    |
474 -         let verdict = match self.checked(&query, &query.query.mode, false) {
474 +         let verdict = match self.checked(&query, &query.query.mode) {
    |

error[E0061]: this method takes 2 arguments but 3 arguments were supplied
   --> src/independent/auth.rs:521:30
    |
521 |             let facts = self.checked(&bound, mode, true)?;
    |                              ^^^^^^^               ---- unexpected argument #3 of type `bool`
    |
note: method defined here
   --> src/independent/auth.rs:284:8
    |
284 |     fn checked(&mut self, bound: &BoundQuery, mode: &Mode) -> Result<Facts, Fault> {
    |        ^^^^^^^
help: remove the extra argument
    |
521 -             let facts = self.checked(&bound, mode, true)?;
521 +             let facts = self.checked(&bound, mode)?;
    |

Some errors have detailed explanations: E0061, E0425.
For more information about an error, try `rustc --explain E0061`.
error: could not compile `glade-node` (lib) due to 3 previous errors

```

## B1 corrected compiling single-use possession and monotonic observations
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_auth']
Exit: 0; wall: 2.145s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 1.68s
     Running tests/ic3_auth.rs (glade/node/target/debug/deps/ic3_auth-d29f661d7892e84b)

running 8 tests
test provider_observation_is_genuine_current_signed_policy_and_owned_clock ... ok
test bad_signature_wrong_domain_or_altered_namespace_are_invalid ... ok
test trusted_source_cannot_regress_observed_clock_or_policy_floor ... ok
test every_local_verification_requires_new_possession_not_operation_cache_reuse ... ok
test signed_invalid_payload_is_authenticated_security_data_not_qualified_admission ... ok
test genuine_historical_admission_verifies_exact_scoped_signed_records ... ok
test local_possession_seal_and_foreign_or_replayed_session_controls ... ok
test uncertain_expired_or_revoked_current_cut_does_not_change_historical_validity ... ok

test result: ok. 8 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s


```

## B1 signed unsupported corpus identity RED
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_auth', 'root_signature_does_not_authorize_an_unsupported_merge_corpus', '--', '--exact']
Exit: 101; wall: 1.091s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.58s
     Running tests/ic3_auth.rs (glade/node/target/debug/deps/ic3_auth-d29f661d7892e84b)

running 1 test
test root_signature_does_not_authorize_an_unsupported_merge_corpus ... FAILED

failures:

---- root_signature_does_not_authorize_an_unsupported_merge_corpus stdout ----

thread 'root_signature_does_not_authorize_an_unsupported_merge_corpus' (171879419) panicked at tests/ic3_auth.rs:400:5:
unsupported signed corpus must refuse
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace


failures:
    root_signature_does_not_authorize_an_unsupported_merge_corpus

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 8 filtered out; finished in 0.00s

error: test failed, to rerun pass `--test ic3_auth`

```

## B1 genuine pinned text corpus compatibility GREEN
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_auth']
Exit: 0; wall: 1.984s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 1.49s
     Running tests/ic3_auth.rs (glade/node/target/debug/deps/ic3_auth-d29f661d7892e84b)

running 9 tests
test provider_observation_is_genuine_current_signed_policy_and_owned_clock ... ok
test genuine_historical_admission_verifies_exact_scoped_signed_records ... ok
test root_signature_does_not_authorize_an_unsupported_merge_corpus ... ok
test signed_invalid_payload_is_authenticated_security_data_not_qualified_admission ... ok
test trusted_source_cannot_regress_observed_clock_or_policy_floor ... ok
test bad_signature_wrong_domain_or_altered_namespace_are_invalid ... ok
test every_local_verification_requires_new_possession_not_operation_cache_reuse ... ok
test local_possession_seal_and_foreign_or_replayed_session_controls ... ok
test uncertain_expired_or_revoked_current_cut_does_not_change_historical_validity ... ok

test result: ok. 9 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.02s


```

## B1 released duplicate-property/BOM payload regression RED
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_auth', 'released_payload_duplicate_properties_and_utf8_bom_remain_supported', '--', '--exact']
Exit: 101; wall: 1.115s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.61s
     Running tests/ic3_auth.rs (glade/node/target/debug/deps/ic3_auth-d29f661d7892e84b)

running 1 test
test released_payload_duplicate_properties_and_utf8_bom_remain_supported ... FAILED

failures:

---- released_payload_duplicate_properties_and_utf8_bom_remain_supported stdout ----

thread 'released_payload_duplicate_properties_and_utf8_bom_remain_supported' (171884611) panicked at tests/ic3_auth.rs:435:9:
released JSON.parse/TextDecoder behavior must be retained
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace


failures:
    released_payload_duplicate_properties_and_utf8_bom_remain_supported

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 9 filtered out; finished in 0.00s

error: test failed, to rerun pass `--test ic3_auth`

```

## B1 released JSON duplicate/BOM/UTF16 behavior GREEN
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_auth']
Exit: 0; wall: 3.513s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 2.97s
     Running tests/ic3_auth.rs (glade/node/target/debug/deps/ic3_auth-d29f661d7892e84b)

running 10 tests
test root_signature_does_not_authorize_an_unsupported_merge_corpus ... ok
test provider_observation_is_genuine_current_signed_policy_and_owned_clock ... ok
test genuine_historical_admission_verifies_exact_scoped_signed_records ... ok
test trusted_source_cannot_regress_observed_clock_or_policy_floor ... ok
test signed_invalid_payload_is_authenticated_security_data_not_qualified_admission ... ok
test bad_signature_wrong_domain_or_altered_namespace_are_invalid ... ok
test released_payload_duplicate_properties_and_utf8_bom_remain_supported ... ok
test every_local_verification_requires_new_possession_not_operation_cache_reuse ... ok
test local_possession_seal_and_foreign_or_replayed_session_controls ... ok
test uncertain_expired_or_revoked_current_cut_does_not_change_historical_validity ... ok

test result: ok. 10 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s


```

## B1 actual released Glial payload consumer shared rows
Command: ['node', '--experimental-transform-types', 'glade/node/tests/ic3_text_consumer.mjs', '/Volumes/projects/limbo/glade-wz/glial/src/text_crdt.ts']
Exit: 0; wall: 0.100s
```text
Actual released Glial text decoder: 35 shared rows PASS
(node:25469) ExperimentalWarning: Transform Types is an experimental feature and might change at any time
(Use `node --trace-warnings ...` to show where the warning was created)

```

## B1 genuine provider shared released payload shape rows
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_auth']
Exit: 0; wall: 1.115s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.56s
     Running tests/ic3_auth.rs (glade/node/target/debug/deps/ic3_auth-d29f661d7892e84b)

running 11 tests
test root_signature_does_not_authorize_an_unsupported_merge_corpus ... ok
test signed_invalid_payload_is_authenticated_security_data_not_qualified_admission ... ok
test provider_observation_is_genuine_current_signed_policy_and_owned_clock ... ok
test bad_signature_wrong_domain_or_altered_namespace_are_invalid ... ok
test genuine_historical_admission_verifies_exact_scoped_signed_records ... ok
test trusted_source_cannot_regress_observed_clock_or_policy_floor ... ok
test every_local_verification_requires_new_possession_not_operation_cache_reuse ... ok
test released_payload_duplicate_properties_and_utf8_bom_remain_supported ... ok
test local_possession_seal_and_foreign_or_replayed_session_controls ... ok
test uncertain_expired_or_revoked_current_cut_does_not_change_historical_validity ... ok
test genuine_provider_matches_shared_released_text_syntax_rows ... ok

test result: ok. 11 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.05s


```

## B1 finite operation footprint before payload interpretation RED
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_auth', 'genuine_overlimit_operation_is_refused_before_payload_interpretation', '--', '--exact']
Exit: 101; wall: 1.111s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.59s
     Running tests/ic3_auth.rs (glade/node/target/debug/deps/ic3_auth-d29f661d7892e84b)

running 1 test
test genuine_overlimit_operation_is_refused_before_payload_interpretation ... FAILED

failures:

---- genuine_overlimit_operation_is_refused_before_payload_interpretation stdout ----

thread 'genuine_overlimit_operation_is_refused_before_payload_interpretation' (171892039) panicked at tests/ic3_auth.rs:497:5:
assertion failed: matches!(provider(&f).verify(BoundQuery
    { query: q, identity: f.identity }).verdict, Verdict::Unavailable)
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace


failures:
    genuine_overlimit_operation_is_refused_before_payload_interpretation

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 11 filtered out; finished in 0.00s

error: test failed, to rerun pass `--test ic3_auth`

```

## B1 finite operation and complete existing controls GREEN
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_auth']
Exit: 0; wall: 2.020s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 1.48s
     Running tests/ic3_auth.rs (glade/node/target/debug/deps/ic3_auth-d29f661d7892e84b)

running 12 tests
test root_signature_does_not_authorize_an_unsupported_merge_corpus ... ok
test provider_observation_is_genuine_current_signed_policy_and_owned_clock ... ok
test bad_signature_wrong_domain_or_altered_namespace_are_invalid ... ok
test signed_invalid_payload_is_authenticated_security_data_not_qualified_admission ... ok
test genuine_overlimit_operation_is_refused_before_payload_interpretation ... ok
test genuine_historical_admission_verifies_exact_scoped_signed_records ... ok
test trusted_source_cannot_regress_observed_clock_or_policy_floor ... ok
test released_payload_duplicate_properties_and_utf8_bom_remain_supported ... ok
test every_local_verification_requires_new_possession_not_operation_cache_reuse ... ok
test local_possession_seal_and_foreign_or_replayed_session_controls ... ok
test uncertain_expired_or_revoked_current_cut_does_not_change_historical_validity ... ok
test genuine_provider_matches_shared_released_text_syntax_rows ... ok

test result: ok. 12 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.05s


```

## Owner scope exclusion 2026-10-04
Owner: "no - it does not warrant anything - ignore it" (BOM). Removed newly introduced BOM-specific rows/support from the current tranche; existing Glial remains unchanged. Historical executed results remain as chronology. Current shared rows=32. No complete byte-level JSON equivalence claim including BOM. No further BOM investigation or special gate.

## B1 remaining scoped actual Glial payload rows
Command: ['node', '--experimental-transform-types', 'glade/node/tests/ic3_text_consumer.mjs', '/Volumes/projects/limbo/glade-wz/glial/src/text_crdt.ts']
Exit: 0; wall: 0.094s
```text
Actual released Glial text decoder: 32 shared rows PASS
(node:27309) ExperimentalWarning: Transform Types is an experimental feature and might change at any time
(Use `node --trace-warnings ...` to show where the warning was created)

```

## B1 owner-scoped provider controls before cohesion split
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_auth']
Exit: 0; wall: 2.065s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 1.51s
     Running tests/ic3_auth.rs (glade/node/target/debug/deps/ic3_auth-d29f661d7892e84b)

running 12 tests
test root_signature_does_not_authorize_an_unsupported_merge_corpus ... ok
test provider_observation_is_genuine_current_signed_policy_and_owned_clock ... ok
test genuine_overlimit_operation_is_refused_before_payload_interpretation ... ok
test released_payload_duplicate_properties_remain_supported ... ok
test genuine_historical_admission_verifies_exact_scoped_signed_records ... ok
test trusted_source_cannot_regress_observed_clock_or_policy_floor ... ok
test bad_signature_wrong_domain_or_altered_namespace_are_invalid ... ok
test signed_invalid_payload_is_authenticated_security_data_not_qualified_admission ... ok
test every_local_verification_requires_new_possession_not_operation_cache_reuse ... ok
test local_possession_seal_and_foreign_or_replayed_session_controls ... ok
test uncertain_expired_or_revoked_current_cut_does_not_change_historical_validity ... ok
test genuine_provider_matches_shared_released_text_syntax_rows ... ok

test result: ok. 12 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.04s


```

## B1 syntax-aware provider cohesion split preserves behavior
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_auth']
Exit: 0; wall: 3.330s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
warning: unused import: `super::*`
 --> src/independent/auth/provider.rs:7:5
  |
7 | use super::*;
  |     ^^^^^^^^
  |
  = note: `#[warn(unused_imports)]` (part of `#[warn(unused)]`) on by default

warning: `glade-node` (lib) generated 1 warning (run `cargo fix --lib -p glade-node` to apply 1 suggestion)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 2.76s
     Running tests/ic3_auth.rs (glade/node/target/debug/deps/ic3_auth-d29f661d7892e84b)

running 12 tests
test genuine_overlimit_operation_is_refused_before_payload_interpretation ... ok
test genuine_historical_admission_verifies_exact_scoped_signed_records ... ok
test released_payload_duplicate_properties_remain_supported ... ok
test provider_observation_is_genuine_current_signed_policy_and_owned_clock ... ok
test root_signature_does_not_authorize_an_unsupported_merge_corpus ... ok
test trusted_source_cannot_regress_observed_clock_or_policy_floor ... ok
test every_local_verification_requires_new_possession_not_operation_cache_reuse ... ok
test signed_invalid_payload_is_authenticated_security_data_not_qualified_admission ... ok
test bad_signature_wrong_domain_or_altered_namespace_are_invalid ... ok
test local_possession_seal_and_foreign_or_replayed_session_controls ... ok
test uncertain_expired_or_revoked_current_cut_does_not_change_historical_validity ... ok
test genuine_provider_matches_shared_released_text_syntax_rows ... ok

test result: ok. 12 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.05s


```

## B1 scope key domain issuance bare-rival and fresh E1 genuine controls
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_auth']
Exit: 0; wall: 1.983s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
warning: unused import: `super::*`
 --> src/independent/auth/provider.rs:7:5
  |
7 | use super::*;
  |     ^^^^^^^^
  |
  = note: `#[warn(unused_imports)]` (part of `#[warn(unused)]`) on by default

warning: `glade-node` (lib) generated 1 warning (run `cargo fix --lib -p glade-node` to apply 1 suggestion)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 1.42s
     Running tests/ic3_auth.rs (glade/node/target/debug/deps/ic3_auth-d29f661d7892e84b)

running 16 tests
test ic3_auth_extra::strict_ed25519_refuses_small_order_writer_and_changed_domain ... ok
test provider_observation_is_genuine_current_signed_policy_and_owned_clock ... ok
test genuine_historical_admission_verifies_exact_scoped_signed_records ... ok
test genuine_overlimit_operation_is_refused_before_payload_interpretation ... ok
test root_signature_does_not_authorize_an_unsupported_merge_corpus ... ok
test ic3_auth_extra::distinct_fresh_origin_qualifies_but_reused_origin_epoch_or_issuance_refuses ... ok
test released_payload_duplicate_properties_remain_supported ... ok
test bad_signature_wrong_domain_or_altered_namespace_are_invalid ... ok
test trusted_source_cannot_regress_observed_clock_or_policy_floor ... ok
test every_local_verification_requires_new_possession_not_operation_cache_reuse ... ok
test ic3_auth_extra::bare_signed_rival_does_not_convict_but_original_signed_admission_qualifies ... ok
test signed_invalid_payload_is_authenticated_security_data_not_qualified_admission ... ok
test local_possession_seal_and_foreign_or_replayed_session_controls ... ok
test ic3_auth_extra::all_evidence_layers_reject_validly_signed_changed_bindings_or_wrong_keys ... ok
test uncertain_expired_or_revoked_current_cut_does_not_change_historical_validity ... ok
test genuine_provider_matches_shared_released_text_syntax_rows ... ok

test result: ok. 16 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.05s


```

## B1 adopting node architecture boundary
Command: ['cargo', 'run', '--quiet', '--locked', '--offline', '--manifest-path', 'glade-discover/tools/architecture-check/Cargo.toml', '--', 'glade/node']
Exit: 0; wall: 0.931s
```text
Architecture boundaries: PASS (workspace libraries, declared dependencies, traits and conformance targets)

```

## B1 process-global ratchet unchanged
Command: ['python3', 'glade/scripts/checks/check_process_globals.py']
Exit: 0; wall: 0.574s
```text
process-global state guard: 112 files, 3 allowlisted items (0 debt, 3 permanent); nothing new

```

## B1 retained default refusing assembly
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_boundary']
Exit: 0; wall: 2.353s
```text
    Blocking waiting for file lock on package cache
    Blocking waiting for file lock on package cache
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 1.63s
     Running tests/ic3_boundary.rs (glade/node/target/debug/deps/ic3_boundary-32e8ca973e5e411b)

running 6 tests
test production_composition_recovers_a_genuinely_persistent_validated_image ... ignored, IC3B assembled open and validated recovery success remain RED; physical restart is deferred
test standalone_refuser_has_no_fabricated_validated_image ... ok
test standalone_refuser_never_issues_a_consume_permit ... ok
test standalone_refuser_rejects_caller_created_permit_before_callback ... ok
test consumer_detects_recovery_selection_mutant_instead_of_discarding_host ... ok
test actual_assembled_evidence_verify_seal_and_observe_refuse ... ok

test result: ok. 5 passed; 0 failed; 1 ignored; 0 measured; 0 filtered out; finished in 0.00s


```

## B1 focused genuine provider final
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_auth']
Exit: 0; wall: 2.812s
```text
    Blocking waiting for file lock on package cache
    Blocking waiting for file lock on package cache
    Blocking waiting for file lock on package cache
    Blocking waiting for file lock on build directory
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 2.19s
     Running tests/ic3_auth.rs (glade/node/target/debug/deps/ic3_auth-d29f661d7892e84b)

running 16 tests
test ic3_auth_extra::strict_ed25519_refuses_small_order_writer_and_changed_domain ... ok
test root_signature_does_not_authorize_an_unsupported_merge_corpus ... ok
test genuine_overlimit_operation_is_refused_before_payload_interpretation ... ok
test released_payload_duplicate_properties_remain_supported ... ok
test bad_signature_wrong_domain_or_altered_namespace_are_invalid ... ok
test provider_observation_is_genuine_current_signed_policy_and_owned_clock ... ok
test ic3_auth_extra::distinct_fresh_origin_qualifies_but_reused_origin_epoch_or_issuance_refuses ... ok
test genuine_historical_admission_verifies_exact_scoped_signed_records ... ok
test every_local_verification_requires_new_possession_not_operation_cache_reuse ... ok
test signed_invalid_payload_is_authenticated_security_data_not_qualified_admission ... ok
test ic3_auth_extra::bare_signed_rival_does_not_convict_but_original_signed_admission_qualifies ... ok
test trusted_source_cannot_regress_observed_clock_or_policy_floor ... ok
test local_possession_seal_and_foreign_or_replayed_session_controls ... ok
test ic3_auth_extra::all_evidence_layers_reject_validly_signed_changed_bindings_or_wrong_keys ... ok
test uncertain_expired_or_revoked_current_cut_does_not_change_historical_validity ... ok
test genuine_provider_matches_shared_released_text_syntax_rows ... ok

test result: ok. 16 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.04s


```

## B1 retained production contract adopter
Command: ['sh', 'glade/contracts/check.sh', 'crdt-production']
Exit: 0; wall: 9.208s
```text
Architecture boundaries: PASS (workspace libraries, declared dependencies, traits and conformance targets)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.06s
     Running unittests src/lib.rs (glade/contracts/target/debug/deps/glade_crdt_admission_core-932f6277b6041d9c)

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/encoder_complete.rs (glade/contracts/target/debug/deps/encoder_complete-0c61aeec9660768e)

running 10 tests
test candidate::all_candidate_evidence_and_inner_op_bytes ... ok
test plan::complete_plan_header_and_optional_local_cut ... ok
test plan::namespaces_issuance_owner_and_storage_promise_are_part_of_bytes ... ok
test stage::all_staged_candidate_seal_and_receipt_fields ... ok
test descriptor::all_descriptor_parsed_fields_and_bounds ... ok
test seal::full_sealing_query_continuations ... ok
test facts::all_staged_facts_and_certificate_fields ... ok
test fork::fork_pairs_have_complete_candidate_identity_and_evidence ... ok
test verify::full_verification_query_continuations ... ok
test seal_scope::full_seal_descriptor_and_evidence ... ok

test result: ok. 10 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

     Running tests/fixture_composition.rs (glade/contracts/target/debug/deps/fixture_composition-65d2eb16df52c7d1)

running 7 tests
test historical_prior_cut_fixture_registers_multiline_inspect_through_full_helper ... ok
test configured_provider_matches_core_cut_and_changes_independently ... ok
test mandatory_text_replica_journeys_do_not_construct_fresh_host_per_drive_call ... ok
test lookup_fixture_owns_full_request_and_bounded_history_not_only_secondary_index ... ok
test trusted_seed_retains_reservations_outcomes_and_rejects_inconsistent_history ... ok
test seeded_terminal_requires_original_custody_and_accounting ... ok
test seeded_custody_is_explicit_and_consecutive_port_publications_keep_history ... ok

test result: ok. 7 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/kernel_edges.rs (glade/contracts/target/debug/deps/kernel_edges-0e6067bcb16c3e14)

running 21 tests
test admission::retained_candidates_and_verifications_share_pending_capacity ... ok
test admission::pending_origins_reserve_the_origin_limit_before_verification ... ok
test encoder::storage_batch_limit_refuses_before_any_prepare_or_invocation ... ok
test admission::restored_fork_cut_derives_one_coherent_quarantine_and_eligible_set ... ok
test admission::oversized_proof_cannot_allocate_a_verification_continuation ... ok
test admission::outstanding_verification_prevents_complete_local_and_is_bounded ... ok
test frontier::frontier_union_cannot_exceed_pending_items_or_clear_previous_observation ... ok
test frontier::already_retained_exact_frontier_hash_preserves_complete_local ... ok
test frontier::empty_peer_frontier_offers_all_local_history ... ok
test admission::committed_local_custody_retains_the_actual_seal_named_by_original_receipt ... ok
test admission::signed_historical_rival_outside_permit_sequence_is_security_not_conviction ... ok
test encoder::full_encoded_continuation_footprint_consumes_edit_quota ... ok
test storage::lost_prepare_ack_can_recover_original_plan_while_original_invocation_is_live ... ok
test frontier::announced_missing_frontier_survives_unrelated_publication ... ok
test encoder::unretained_historical_batch_due_to_encoder_limit_is_sticky_incomplete ... ok
test admission::signed_invalid_payload_is_security_custody_without_conviction ... ok
test storage::prepare_request_from_retained_old_owner_has_no_current_callback_authority ... ok
test admission::no_prior_admission_local_intent_keeps_real_seal_for_historical_replay ... ok
test storage::prepared_reply_cannot_replace_original_attempt_mapping ... ok
test frontier::different_arriving_hash_cannot_complete_an_announced_missing_slot ... ok
test encoder::encoder_is_deterministic_and_binds_descriptor_facts_and_seal_continuations ... ok

test result: ok. 21 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

     Running tests/records_host_contract.rs (glade/contracts/target/debug/deps/records_host_contract-377bbaa390d43bf2)

running 22 tests
test icd006_delayed_prior_cut_committed_callback_retains_historical_admission ... ok
test icd004_same_display_names_do_not_share_instance_rights_or_callbacks ... ok
test icd006_historical_authorization_is_separate_from_current_revocation ... ok
test icd006_stale_verification_after_policy_change_cannot_seal_or_commit ... ok
test icd003_legacy_and_strong_descriptors_do_not_activate_independent_admission ... ok
test icd007_zero_base_prev_refs_and_exact_safe_numbers ... ok
test icd002_partitioned_admission_commits_without_a_holder ... ok
test icd007_reused_canonical_origin_and_numeric_overflow_refuse ... ok
test icd005_evidence_reply_binds_mode_bytes_scope_and_candidate ... ok
test icd007_new_epoch_uses_new_origin_and_old_retries_stay_old ... ok
test icd006_offline_window_and_clock_uncertainty_refuse_new_intent ... ok
test icd010_old_receipt_retry_does_not_reauthorize_or_reappend ... ok
test icd010_lookup_recovery_binds_request_and_restores_original_receipt ... ok
test icd008_successor_requests_predecessor_without_advancing_head ... ok
test icd010_unknown_commit_retains_reservation_and_foreign_callback_cannot_accept ... ok
test icd013_recovery_exhaustion_is_explicit_and_cannot_spend_edit_budget ... ok
test icd013_edit_capacity_preserves_recovery_reserves ... ok
test icd010_commit_callbacks_bind_batch_revision_and_have_three_distinct_outcomes ... ok
test prior_cut_inspect40_distinguishes_issued_authority_from_identical_unissued_reply ... ok
test icd009_qualified_dependent_custody_survives_quarantined_support_but_local_intent_refuses ... ok
test icd006_revoked_expired_unadmitted_rival_preserves_ad_and_receipts ... ok
test icd009_two_qualified_rivals_quarantine_both_and_dependents_in_either_order ... ok

test result: ok. 22 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

     Running tests/recovery_contract.rs (glade/contracts/target/debug/deps/recovery_contract-8cab13edcccedff2)

running 6 tests
test lookup_invocation_counter_exhaustion_refuses_without_wrap_or_reservation_loss ... ok
test trusted_restoration_invalidates_live_lookup_and_preserves_identity_high_water ... ok
test retention_committed_lookup_binds_batch_storage_revision_and_empty_receipts ... ok
test repeated_unknown_lookup_retires_invocation_and_old_replies_preserve_new_lookup ... ok
test genuine_e0_fork_then_fresh_e1_local_recovery_keeps_ab_and_old_receipts_both_orders ... ok
test every_atomic_kind_recovers_committed_absent_and_unknown_without_fake_admission ... ok

test result: ok. 6 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

     Running tests/remediation1.rs (glade/contracts/target/debug/deps/remediation1-be8535f3fccf7f31)

running 16 tests
test frontier::frontier_bytes_include_existing_candidate_charge_and_parked_verification ... ok
test frontier::frontier_retained_slot_aggregate_bytes_exact_boundary_and_one_over ... ok
test pending::frontier_cannot_steal_slots_reserved_by_an_unpublished_candidate_plan ... ok
test exhaustion::local_intent_counter_refusal_alone_does_not_taint_known_history ... ok
test frontier::frontier_names_empty_exact_limit_over_limit_and_huge_are_bounded ... ok
test pending::prospective_two_missing_slots_refuse_before_emission_or_candidate_staging ... ok
test pending::predecessor_and_ref_to_the_same_missing_slot_emit_one_request ... ok
test exhaustion::historical_query_exhaustion_remains_sticky_through_resume_restore ... ok
test exhaustion::historical_plan_exhaustion_remains_sticky_through_resume_restore ... ok
test pending::multiple_candidates_and_frontier_slots_share_deduplicated_prospective_cap ... ok
test terminal::late_pending_and_refused_never_reopen_an_authentic_terminal ... ok
test integrity::already_qualified_fork_cannot_stage_new_work_after_stop ... ok
test pending::exact_slot_limit_and_overlap_union_commit_without_duplicate_reservations ... ok
test integrity::integrity_stop_preserves_owned_started_attempt_and_genuine_late_commit ... ok
test integrity::parked_verification_and_seal_cannot_create_new_work_after_authenticated_stop ... ok
test terminal::held_started_and_terminal_inspect_both_orders_all_four_kinds_and_outcomes ... ok

test result: ok. 16 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

     Running tests/remediation2.rs (glade/contracts/target/debug/deps/remediation2-c6ddfa10c99b9612)

running 3 tests
test two_issued_queries_verified_historical_b_during_held_started_a_is_explicitly_incomplete ... ok
test fresh_historical_offer_during_held_started_a_is_explicitly_incomplete ... ok
test local_intent_only_busy_refusal_does_not_taint_known_history ... ok

test result: ok. 3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

     Running tests/representation.rs (glade/contracts/target/debug/deps/representation-b4c77cef7d79e0fa)

running 2 tests
test operation_bytes_and_digest_are_derived_and_owned ... ok
test pure_step_is_deterministic_preserves_caller_input_and_read_only_state ... ok

test result: ok. 2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/source_boundaries.rs (glade/contracts/target/debug/deps/source_boundaries-cfcb6000711a5cc4)

running 4 tests
test ic3_data_boundary_is_independent_of_the_pure_algorithm ... ok
test checks_disabled_branch_instead_of_skipping_cfg ... ok
test disabled_associated_foreign_and_field_declarations_are_checked ... ok
test tranche_sources_have_explicit_conditional_boundaries ... ok

test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.12s

     Running tests/storage_attempt_contract.rs (glade/contracts/target/debug/deps/storage_attempt_contract-a98f1e5df7b04b9e)

running 15 tests
test sta006_current_prestart_observation_emits_fence_without_erasing_plan ... ok
test issued_lookup_retains_full_request_on_consumption ... ok
test sta009_restored_attempt_and_invocation_floors_preserve_pending ... ok
test sta008_critical_pending_does_not_release_semantic_reservation ... ok
test sta005_contradictory_terminal_stops_instance_after_once_only_installation ... ok
test sta001_callback_complete_binding_and_finite_invocation_namespace ... ok
test identical_unissued_lookup_reply_cannot_acquire_callback_authority ... ok
test sta005_unissued_foreign_or_changed_retired_callback_cannot_create_integrity_stop ... ok
test sta002_kernel_prepare_keeps_exact_plan_after_lost_ack ... ok
test sta003_pending_lookup_retains_started_write_until_late_commit_all_kinds ... ok
test sta010_overflow_is_sticky_distinct_from_charges_and_partial_repair ... ok
test sta004_noncommit_retains_tombstone_and_rescheduling_uses_fresh_plan ... ok
test sta007_all_kinds_install_original_terminal_without_double_charge ... ok
test sta011_driver_uses_caller_owned_session_across_continuations ... ok
test sta011_existing_twenty_seven_and_text_consumers_keep_actual_port_path ... ok

test result: ok. 15 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running unittests src/lib.rs (glade/contracts/target/debug/deps/glade_crdt_admission_data-829261682f5780f4)

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/representation.rs (glade/contracts/target/debug/deps/representation-a11dd961075c09ca)

running 1 test
test canonical_operation_owns_bytes_and_recomputes_digest ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/source_boundaries.rs (glade/contracts/target/debug/deps/source_boundaries-15d7213681b61363)

running 3 tests
test checks_disabled_branch_instead_of_skipping_cfg ... ok
test disabled_associated_foreign_and_field_declarations_are_checked ... ok
test tranche_sources_have_explicit_conditional_boundaries ... ok

test result: ok. 3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

     Running unittests src/lib.rs (glade/contracts/target/debug/deps/glade_crdt_evidence_api-0ab689c801ef5981)

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/public_contract.rs (glade/contracts/target/debug/deps/public_contract-a450847ecdbb9cfb)

running 2 tests
test concrete_provider_must_supply_all_three_trusted_operations ... ok
test required_evidence_methods_have_no_default_provider ... ok

test result: ok. 2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/source_boundaries.rs (glade/contracts/target/debug/deps/source_boundaries-d9ef5b5c6b238cc5)

running 3 tests
test checks_disabled_branch_instead_of_skipping_cfg ... ok
test disabled_associated_foreign_and_field_declarations_are_checked ... ok
test tranche_sources_have_explicit_conditional_boundaries ... ok

test result: ok. 3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

     Running unittests src/lib.rs (glade/contracts/target/debug/deps/glade_crdt_recovery_api-86172c5c56e8b27f)

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/public_contract.rs (glade/contracts/target/debug/deps/public_contract-5bc6e82aa5aa7537)

running 7 tests
test issued_guard_identity_is_not_reissued_by_same_session ... ok
test issuer_capacity_is_finite_and_retirement_does_not_reissue_history ... ok
test live_never_started_owned_guard_can_abandon_only_once ... ok
test another_authority_refuses_before_constructing_or_consuming_future ... ok
test abandoned_capability_cannot_start_work_again ... ok
test cancelled_started_async_receive_does_not_imply_drain_or_abandon ... ok
test owned_receive_drains_before_settlement_and_close ... ok

test result: ok. 7 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/source_boundaries.rs (glade/contracts/target/debug/deps/source_boundaries-d87c63d050de1dbe)

running 4 tests
test checks_disabled_branch_instead_of_skipping_cfg ... ok
test disabled_associated_foreign_and_field_declarations_are_checked ... ok
test tranche_sources_have_explicit_conditional_boundaries ... ok
test actual_node_independent_subtree_and_disabled_branches_are_checked ... ok

test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.02s

     Running unittests src/lib.rs (glade/contracts/target/debug/deps/glade_crdt_recovery_codec-249926a6c91406e4)

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/batch_decode.rs (glade/contracts/target/debug/deps/batch_decode-c338073ef4bd3146)

running 3 tests
test unchanged_private_encoder_has_a_complete_bounded_decoder ... ok
test batch_operations_share_the_existing_aggregate_item_budget ... ok
test interned_blob_references_cannot_amplify_owned_decoding_past_budget ... ok

test result: ok. 3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/image.rs (glade/contracts/target/debug/deps/image-ff97efb1b877942d)

running 4 tests
test interrupted_intent_preserves_issuance_and_guard_floors_without_next_image ... ok
test full_image_retains_all_kernel_callbacks_attempts_guards_issuance_and_loss ... ok
test image_hash_and_external_selection_do_not_require_a_hash_fixed_point ... ok
test corrupt_truncated_trailing_unknown_versions_and_capacity_fail_closed ... ok

test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.12s

     Running tests/remediation1.rs (glade/contracts/target/debug/deps/remediation1-4606bedf9a4f1344)

running 6 tests
test root_operation_depth_includes_the_embedded_interpretation_boundary ... ok
test root_operation_name_limit_applies_inside_opaque_canonical_bytes ... ok
test root_operation_item_budget_includes_interpreted_refs_cumulatively ... ok
test nested_candidate_and_remote_transfer_cannot_hide_operation_name ... ok
test repeated_nested_operations_share_one_budget_not_one_budget_each ... ok
test concrete_container_roots_cannot_substitute_plan_for_guard ... ok

test result: ok. 6 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/roundtrip.rs (glade/contracts/target/debug/deps/roundtrip-afbf6185948b82a4)

running 6 tests
test accepted_signature_domains_are_full_and_zero_terminated ... ok
test type_domain_cannot_substitute_plan_identity_for_receive_guard ... ok
test remote_profile_is_exact_canonical_integer_key_map_without_recovery_magic ... ok
test inventory_empty_is_exact_observation_not_a_completeness_claim ... ok
test identity_roundtrip_preserves_full_namespaces_and_unsigned_floor ... ok
test proof_body_requires_exact_purpose_version_signature_shape_and_type ... ok

test result: ok. 6 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/source_boundaries.rs (glade/contracts/target/debug/deps/source_boundaries-b49e6bf7138dd73f)

running 3 tests
test checks_disabled_branch_instead_of_skipping_cfg ... ok
test disabled_associated_foreign_and_field_declarations_are_checked ... ok
test tranche_sources_have_explicit_conditional_boundaries ... ok

test result: ok. 3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.06s

     Running tests/vectors.rs (glade/contracts/target/debug/deps/vectors-e6054aa97de7077a)

running 4 tests
test closed_maps_reject_unknown_duplicate_reordered_or_wrong_context_fields ... ok
test malformed_signature_length_and_wrong_exact_domain_refuse_signed_envelope_shape ... ok
test bounded_malformed_canonical_vectors_fail_closed ... ok
test all_remote_profile_categories_derive_exact_bytes_and_digests_from_semantic_inputs ... ok

test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

     Running unittests src/lib.rs (glade/contracts/target/debug/deps/glade_crdt_storage_attempt_api-183ed550d5084400)

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/conformance_mutants.rs (glade/contracts/target/debug/deps/conformance_mutants-62cbd41425c44fca)

running 1 test
test shared_public_port_probe_accepts_fixture_and_rejects_six_semantic_mutants ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/public_contract.rs (glade/contracts/target/debug/deps/public_contract-5dd65e92533e6d9b)

running 28 tests
test finite_attempt_invocation_and_name_bounds_refuse_without_wrap ... ok
test restoration_rejects_corrupt_cardinality_floor_and_history_limit ... ok
test host_serialized_observation_cannot_be_replaced_by_caller_current_claim ... ok
test historical_accepted_batch_keeps_original_receipt_without_local_prestart ... ok
test restored_capacity_and_binding_phase_consistency_are_validated ... ok
test lost_prepare_ack_and_queued_late_prepare_recover_exactly_one_attempt ... ok
test restored_started_and_committed_cuts_must_fit_their_immutable_windows ... ok
test restored_noncommit_must_retain_its_bindings_unchanged_revision ... ok
test authentic_two_commit_recovery_rejects_distinct_duplicate_revision ... ok
test full_retained_commit_history_rejects_missing_head_gaps_and_unbacked_current_revision ... ok
test sta001_exact_binding_exhaustion_and_invocation_identity ... ok
test sta002_exact_plan_dedup_no_overlap_and_independent_instances ... ok
test restoration_rejects_identity_and_unresolved_overlap_but_keeps_history_and_y ... ok
test sta005_commit_wins_fence_race_and_receipts_are_original ... ok
test sequential_commits_repeated_noncommit_and_independent_revision_spaces_restore ... ok
test sta004_fence_excludes_late_begin_and_reprepare_uses_new_identity ... ok
test sta003_absent_terminal_is_pending_for_all_kinds ... ok
test sta007_retention_receipts_cannot_be_synthetic ... ok
test sta006_prestart_checks_entire_window_and_historical_has_no_current_admit_check ... ok
test sta008_critical_reserve_exhaustion_cannot_manufacture_negative_finality ... ok
test sta009_exclusive_recovery_and_close_keep_issuance_floors ... ok
test started_cut_is_not_rechecked_after_revocation_or_delayed_begin_ack ... ok
test started_absent_lookup_late_publication_and_fence_use_same_predicate ... ok
test trusted_observation_injection_has_finite_instance_and_name_bounds ... ok
test validated_restore_retains_all_attempts_and_invocation_namespace_without_auto_commit ... ok
test sparse_invocation_restore_preserves_actual_remaining_capacity ... ok
test reopen_validates_retained_consumption_before_changing_owner_or_floors ... ok
test fresh_revision_mismatch_refuses_before_reserved_or_queued_for_every_kind ... ok

test result: ok. 28 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/source_boundaries.rs (glade/contracts/target/debug/deps/source_boundaries-625bf4e5641d0a44)

running 5 tests
test checks_disabled_branch_instead_of_skipping_cfg ... ok
test rejects_missing_identity_callback_ownership_and_terminality_fields ... ok
test disabled_associated_foreign_and_field_declarations_are_checked ... ok
test actual_port_preserves_required_boundary_shape ... ok
test tranche_sources_have_explicit_conditional_boundaries ... ok

test result: ok. 5 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.04s

   Doc-tests glade_crdt_admission_core

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

   Doc-tests glade_crdt_admission_data

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

   Doc-tests glade_crdt_evidence_api

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

   Doc-tests glade_crdt_recovery_api

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

   Doc-tests glade_crdt_recovery_codec

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

   Doc-tests glade_crdt_storage_attempt_api

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

    Finished `dev` profile [unoptimized + debuginfo] target(s) in 0.06s

```

## B1 affected node assembly consumers
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'node_assembly']
Exit: 0; wall: 9.907s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 9.10s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-022b56b7ae6ded8d)

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 364 filtered out; finished in 0.00s


```

## B1 pinned signer consumer
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'signing::tests']
Exit: 0; wall: 8.771s
```text
    Blocking waiting for file lock on build directory
    Finished `test` profile [unoptimized + debuginfo] target(s) in 8.00s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-022b56b7ae6ded8d)

running 3 tests
test signing::tests::a_signature_is_pure_ed25519_over_the_tag_then_the_message ... ok
test signing::tests::a_small_order_id_signs_nothing ... ok
test signing::tests::no_tag_is_a_prefix_of_another ... ok

test result: ok. 3 passed; 0 failed; 0 ignored; 0 measured; 361 filtered out; finished in 0.00s


```

## B1 node clippy scoped affected provider
Command: ['cargo', 'clippy', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', '--test', 'ic3_auth', '--', '-D', 'warnings']
Exit: 101; wall: 8.814s
```text
    Blocking waiting for file lock on build directory
    Checking glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
error: this can be `std::io::Error::other(_)`
   --> src/claims.rs:138:5
    |
138 |     io::Error::new(io::ErrorKind::Other, e)
    |     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    |
    = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
    = note: `-D clippy::io-other-error` implied by `-D warnings`
    = help: to override `-D warnings` add `#[allow(clippy::io_other_error)]`
help: use `std::io::Error::other`
    |
138 -     io::Error::new(io::ErrorKind::Other, e)
138 +     io::Error::other(e)
    |

error: this can be `std::io::Error::other(_)`
  --> src/exchange.rs:53:5
   |
53 |     io::Error::new(io::ErrorKind::Other, e)
   |     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
   |
   = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
help: use `std::io::Error::other`
   |
53 -     io::Error::new(io::ErrorKind::Other, e)
53 +     io::Error::other(e)
   |

error: this can be `std::io::Error::other(_)`
  --> src/iroh_carrier.rs:68:5
   |
68 |     io::Error::new(io::ErrorKind::Other, e)
   |     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
   |
   = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
help: use `std::io::Error::other`
   |
68 -     io::Error::new(io::ErrorKind::Other, e)
68 +     io::Error::other(e)
   |

error: this can be `std::io::Error::other(_)`
  --> src/mesh.rs:63:5
   |
63 |     io::Error::new(io::ErrorKind::Other, e)
   |     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
   |
   = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
help: use `std::io::Error::other`
   |
63 -     io::Error::new(io::ErrorKind::Other, e)
63 +     io::Error::other(e)
   |

error: this can be `std::io::Error::other(_)`
   --> src/server.rs:458:18
    |
458 |         other => std::io::Error::new(std::io::ErrorKind::Other, format!("{other:?}")),
    |                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    |
    = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
help: use `std::io::Error::other`
    |
458 -         other => std::io::Error::new(std::io::ErrorKind::Other, format!("{other:?}")),
458 +         other => std::io::Error::other(format!("{other:?}")),
    |

error: doc list item without indentation
 --> src/ws.rs:3:5
  |
3 | //! (which is text-only) for **binary** frames: glade carries CBOR, not text.
  |     ^
  |
  = help: if this is supposed to be its own paragraph, add a blank line
  = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#doc_lazy_continuation
  = note: `-D clippy::doc-lazy-continuation` implied by `-D warnings`
  = help: to override `-D warnings` add `#[allow(clippy::doc_lazy_continuation)]`
help: indent this line
  |
3 | //!   (which is text-only) for **binary** frames: glade carries CBOR, not text.
  |     ++

error: doc list item without indentation
 --> src/ws.rs:4:5
  |
4 | //! Enough to talk to a browser/Node WebSocket: the upgrade handshake, masked
  |     ^
  |
  = help: if this is supposed to be its own paragraph, add a blank line
  = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#doc_lazy_continuation
help: indent this line
  |
4 | //!   Enough to talk to a browser/Node WebSocket: the upgrade handshake, masked
  |     ++

error: doc list item without indentation
 --> src/ws.rs:5:5
  |
5 | //! client->server and unmasked server->client binary frames; close surfaced;
  |     ^
  |
  = help: if this is supposed to be its own paragraph, add a blank line
  = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#doc_lazy_continuation
help: indent this line
  |
5 | //!   client->server and unmasked server->client binary frames; close surfaced;
  |     ++

error: doc list item without indentation
 --> src/ws.rs:6:5
  |
6 | //! ping/pong skipped (trusted localhost).
  |     ^
  |
  = help: if this is supposed to be its own paragraph, add a blank line
  = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#doc_lazy_continuation
help: indent this line
  |
6 | //!   ping/pong skipped (trusted localhost).
  |     ++

error: could not compile `glade-node` (lib) due to 9 previous errors

```

## B1 actual released text consumer current scoped rows
Command: ['node', '--experimental-transform-types', 'glade/node/tests/ic3_text_consumer.mjs', '/Volumes/projects/limbo/glade-wz/glial/src/text_crdt.ts']
Exit: 0; wall: 0.081s
```text
Actual released Glial text decoder: 32 shared rows PASS
(node:32100) ExperimentalWarning: Transform Types is an experimental feature and might change at any time
(Use `node --trace-warnings ...` to show where the warning was created)

```

## B1 preserved strict remote prerequisite refusal
Command: ['sh', 'glade/contracts/crdt-recovery-codec/check-vectors.sh', '--pre-remote']
Exit: 1; wall: 0.422s
```text
Traceback (most recent call last):
  File "/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-codec/compat/gate.py", line 106, in <module>
    validate(Path(sys.argv[1]), strict=strict)
  File "/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-codec/compat/gate.py", line 53, in validate
    validate_remote(root, pins)
  File "/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-codec/compat/gate.py", line 84, in validate_remote
    raise ValueError("genuine B1 crypto qualification absent")
ValueError: genuine B1 crypto qualification absent

```

## B1 actual assembly affected consumer target after zero-selection correction
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'assembly']
Exit: 0; wall: 1.762s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 1.03s
     Running tests/assembly/main.rs (glade/node/target/debug/deps/assembly-025321a5b5fa040f)

running 30 tests
test conformance::cl_002_the_fake_clock_reads_epoch_milliseconds ... ok
test conformance::cl_002_the_system_clock_reads_epoch_milliseconds ... ok
test conformance::cl_001_the_fake_clock_is_one_instant_behind_every_handle ... ok
test conformance::gr_002_in_the_in_memory_fold_revocation_wins_in_either_order ... ok
test conformance::gr_003_an_unreadable_in_memory_fold_is_unavailable ... ok
test conformance::gr_001_the_in_memory_fold_matches_exactly ... ok
test conformance::gr_003_the_grant_fold_the_module_builds_is_unavailable ... ok
test conformance::si_001_the_keyed_test_signer_round_trips_every_purpose ... ok
test conformance::si_002_the_keyed_test_signer_binds_bytes_purpose_and_signer ... ok
test conformance::si_003_the_keyed_test_signer_refuses_without_key_material ... ok
test conformance::ca_003_the_fake_networks_futures_are_lazy_and_recv_is_cancel_safe ... ok
test conformance::ca_002_the_fake_network_holds_the_frame_limit_both_ways ... ok
test conformance::ca_005_the_fake_network_names_each_far_end ... ok
test conformance::si_003_the_node_signer_without_a_key_refuses_both_ways ... ok
test conformance::ca_004_a_fake_port_gives_its_endpoint_up_by_value ... ok
test conformance::ca_001_the_fake_network_carries_frames_whole_once_and_in_order ... ok
test conformance::ca_006_the_fake_network_binds_each_link_to_its_session ... ok
test one_scope_hands_out_one_occurrence_of_every_binding ... ok
test one_grant_selection_reaches_admission ... ok
test each_carrier_role_is_its_own_occurrence_and_the_record_transport_rides_the_peer_one ... ok
test a_test_composition_constructs_no_real_provider ... ok
test the_directory_profile_hosts_every_directory_record_kind_and_nothing_else ... ok
test conformance::si_002_the_node_signer_binds_bytes_purpose_and_signer ... ok
test a_concurrent_first_access_of_a_lazy_binding_constructs_once_per_scope ... ok
test records_refuse_an_op_outside_the_directory_profile_before_verifying_it ... ok
test conformance::si_001_the_node_signer_round_trips_every_purpose ... ok
test one_clock_substitution_reaches_the_directory_and_admission ... ok
test sibling_scopes_share_nothing_and_meet_only_through_the_network ... ok
test conformance::gr_001_to_003_the_nodes_grant_fold_keeps_the_grant_contract ... ok
test one_record_host_selection_reaches_the_directory ... ok

test result: ok. 30 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s


```

## B1 clippy diagnostic enumeration retaining nine baseline errors
Command: ['cargo', 'clippy', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', '--test', 'ic3_auth']
Exit: 0; wall: 2.034s
```text
    Checking glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
warning: this can be `std::io::Error::other(_)`
   --> src/claims.rs:138:5
    |
138 |     io::Error::new(io::ErrorKind::Other, e)
    |     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    |
    = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
    = note: `#[warn(clippy::io_other_error)]` on by default
help: use `std::io::Error::other`
    |
138 -     io::Error::new(io::ErrorKind::Other, e)
138 +     io::Error::other(e)
    |

warning: this can be `std::io::Error::other(_)`
  --> src/exchange.rs:53:5
   |
53 |     io::Error::new(io::ErrorKind::Other, e)
   |     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
   |
   = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
help: use `std::io::Error::other`
   |
53 -     io::Error::new(io::ErrorKind::Other, e)
53 +     io::Error::other(e)
   |

warning: this can be `std::io::Error::other(_)`
  --> src/iroh_carrier.rs:68:5
   |
68 |     io::Error::new(io::ErrorKind::Other, e)
   |     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
   |
   = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
help: use `std::io::Error::other`
   |
68 -     io::Error::new(io::ErrorKind::Other, e)
68 +     io::Error::other(e)
   |

warning: this can be `std::io::Error::other(_)`
  --> src/mesh.rs:63:5
   |
63 |     io::Error::new(io::ErrorKind::Other, e)
   |     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
   |
   = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
help: use `std::io::Error::other`
   |
63 -     io::Error::new(io::ErrorKind::Other, e)
63 +     io::Error::other(e)
   |

warning: this can be `std::io::Error::other(_)`
   --> src/server.rs:458:18
    |
458 |         other => std::io::Error::new(std::io::ErrorKind::Other, format!("{other:?}")),
    |                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    |
    = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
help: use `std::io::Error::other`
    |
458 -         other => std::io::Error::new(std::io::ErrorKind::Other, format!("{other:?}")),
458 +         other => std::io::Error::other(format!("{other:?}")),
    |

warning: doc list item without indentation
 --> src/ws.rs:3:5
  |
3 | //! (which is text-only) for **binary** frames: glade carries CBOR, not text.
  |     ^
  |
  = help: if this is supposed to be its own paragraph, add a blank line
  = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#doc_lazy_continuation
  = note: `#[warn(clippy::doc_lazy_continuation)]` on by default
help: indent this line
  |
3 | //!   (which is text-only) for **binary** frames: glade carries CBOR, not text.
  |     ++

warning: doc list item without indentation
 --> src/ws.rs:4:5
  |
4 | //! Enough to talk to a browser/Node WebSocket: the upgrade handshake, masked
  |     ^
  |
  = help: if this is supposed to be its own paragraph, add a blank line
  = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#doc_lazy_continuation
help: indent this line
  |
4 | //!   Enough to talk to a browser/Node WebSocket: the upgrade handshake, masked
  |     ++

warning: doc list item without indentation
 --> src/ws.rs:5:5
  |
5 | //! client->server and unmasked server->client binary frames; close surfaced;
  |     ^
  |
  = help: if this is supposed to be its own paragraph, add a blank line
  = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#doc_lazy_continuation
help: indent this line
  |
5 | //!   client->server and unmasked server->client binary frames; close surfaced;
  |     ++

warning: doc list item without indentation
 --> src/ws.rs:6:5
  |
6 | //! ping/pong skipped (trusted localhost).
  |     ^
  |
  = help: if this is supposed to be its own paragraph, add a blank line
  = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#doc_lazy_continuation
help: indent this line
  |
6 | //!   ping/pong skipped (trusted localhost).
  |     ++

warning: `glade-node` (lib) generated 9 warnings (run `cargo clippy --fix --lib -p glade-node -- ` to apply 5 suggestions)
warning: for loop over a single element
   --> tests/ic3_auth.rs:410:5
    |
410 | /     for payload in [br#"{"atom_id":42,"atom_id":"a","kind":"delete"}"#.as_slice()] {
411 | |         let mut q = f.query.clone();
412 | |         let mut op = q.operation.inner().clone();
413 | |         op.payload = payload.to_vec();
...   |
436 | |         );
437 | |     }
    | |_____^
    |
    = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#single_element_loop
    = note: `#[warn(clippy::single_element_loop)]` on by default
help: try
    |
410 ~     {
411 +         let payload = br#"{"atom_id":42,"atom_id":"a","kind":"delete"}"#.as_slice();
412 +         let mut q = f.query.clone();
413 +         let mut op = q.operation.inner().clone();
414 +         op.payload = payload.to_vec();
415 +         q.operation = Operation::new(op);
416 +         q.evidence = Fixture::proofs(
417 +             &q.instance,
418 +             &f.identity,
419 +             &q.descriptor,
420 +             &f.certificate,
421 +             &f.policy,
422 +             &q.operation,
423 +             Some((glade_node::signing::public_key(&NODE), &NODE)),
424 +         );
425 +         let Verdict::Verified(facts) = provider(&f)
426 +             .verify(BoundQuery {
427 +                 query: q,
428 +                 identity: f.identity.clone(),
429 +             })
430 +             .verdict
431 +         else {
432 +             panic!("authenticated profile edit")
433 +         };
434 +         assert!(
435 +             facts.payload_valid,
436 +             "released JSON.parse duplicate-property behavior must be retained"
437 +         );
438 +     }
    |

warning: `glade-node` (test "ic3_auth") generated 1 warning (run `cargo clippy --fix --test "ic3_auth" -p glade-node -- ` to apply 1 suggestion)
    Finished `dev` profile [unoptimized + debuginfo] target(s) in 1.96s

```

## B1 final scoped warning correction provider
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_auth']
Exit: 0; wall: 1.143s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.62s
     Running tests/ic3_auth.rs (glade/node/target/debug/deps/ic3_auth-d29f661d7892e84b)

running 16 tests
test ic3_auth_extra::strict_ed25519_refuses_small_order_writer_and_changed_domain ... ok
test root_signature_does_not_authorize_an_unsupported_merge_corpus ... ok
test genuine_overlimit_operation_is_refused_before_payload_interpretation ... ok
test provider_observation_is_genuine_current_signed_policy_and_owned_clock ... ok
test genuine_historical_admission_verifies_exact_scoped_signed_records ... ok
test every_local_verification_requires_new_possession_not_operation_cache_reuse ... ok
test released_payload_duplicate_properties_remain_supported ... ok
test bad_signature_wrong_domain_or_altered_namespace_are_invalid ... ok
test ic3_auth_extra::distinct_fresh_origin_qualifies_but_reused_origin_epoch_or_issuance_refuses ... ok
test ic3_auth_extra::bare_signed_rival_does_not_convict_but_original_signed_admission_qualifies ... ok
test signed_invalid_payload_is_authenticated_security_data_not_qualified_admission ... ok
test trusted_source_cannot_regress_observed_clock_or_policy_floor ... ok
test local_possession_seal_and_foreign_or_replayed_session_controls ... ok
test ic3_auth_extra::all_evidence_layers_reject_validly_signed_changed_bindings_or_wrong_keys ... ok
test uncertain_expired_or_revoked_current_cut_does_not_change_historical_validity ... ok
test genuine_provider_matches_shared_released_text_syntax_rows ... ok

test result: ok. 16 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.05s


```

## B1 final new source warning census with retained baseline
Command: ['cargo', 'clippy', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', '--test', 'ic3_auth']
Exit: 0; wall: 0.327s
```text
warning: this can be `std::io::Error::other(_)`
   --> src/claims.rs:138:5
    |
138 |     io::Error::new(io::ErrorKind::Other, e)
    |     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    |
    = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
    = note: `#[warn(clippy::io_other_error)]` on by default
help: use `std::io::Error::other`
    |
138 -     io::Error::new(io::ErrorKind::Other, e)
138 +     io::Error::other(e)
    |

warning: this can be `std::io::Error::other(_)`
  --> src/exchange.rs:53:5
   |
53 |     io::Error::new(io::ErrorKind::Other, e)
   |     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
   |
   = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
help: use `std::io::Error::other`
   |
53 -     io::Error::new(io::ErrorKind::Other, e)
53 +     io::Error::other(e)
   |

warning: this can be `std::io::Error::other(_)`
  --> src/iroh_carrier.rs:68:5
   |
68 |     io::Error::new(io::ErrorKind::Other, e)
   |     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
   |
   = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
help: use `std::io::Error::other`
   |
68 -     io::Error::new(io::ErrorKind::Other, e)
68 +     io::Error::other(e)
   |

warning: this can be `std::io::Error::other(_)`
  --> src/mesh.rs:63:5
   |
63 |     io::Error::new(io::ErrorKind::Other, e)
   |     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
   |
   = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
help: use `std::io::Error::other`
   |
63 -     io::Error::new(io::ErrorKind::Other, e)
63 +     io::Error::other(e)
   |

warning: this can be `std::io::Error::other(_)`
   --> src/server.rs:458:18
    |
458 |         other => std::io::Error::new(std::io::ErrorKind::Other, format!("{other:?}")),
    |                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    |
    = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
help: use `std::io::Error::other`
    |
458 -         other => std::io::Error::new(std::io::ErrorKind::Other, format!("{other:?}")),
458 +         other => std::io::Error::other(format!("{other:?}")),
    |

warning: doc list item without indentation
 --> src/ws.rs:3:5
  |
3 | //! (which is text-only) for **binary** frames: glade carries CBOR, not text.
  |     ^
  |
  = help: if this is supposed to be its own paragraph, add a blank line
  = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#doc_lazy_continuation
  = note: `#[warn(clippy::doc_lazy_continuation)]` on by default
help: indent this line
  |
3 | //!   (which is text-only) for **binary** frames: glade carries CBOR, not text.
  |     ++

warning: doc list item without indentation
 --> src/ws.rs:4:5
  |
4 | //! Enough to talk to a browser/Node WebSocket: the upgrade handshake, masked
  |     ^
  |
  = help: if this is supposed to be its own paragraph, add a blank line
  = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#doc_lazy_continuation
help: indent this line
  |
4 | //!   Enough to talk to a browser/Node WebSocket: the upgrade handshake, masked
  |     ++

warning: doc list item without indentation
 --> src/ws.rs:5:5
  |
5 | //! client->server and unmasked server->client binary frames; close surfaced;
  |     ^
  |
  = help: if this is supposed to be its own paragraph, add a blank line
  = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#doc_lazy_continuation
help: indent this line
  |
5 | //!   client->server and unmasked server->client binary frames; close surfaced;
  |     ++

warning: doc list item without indentation
 --> src/ws.rs:6:5
  |
6 | //! ping/pong skipped (trusted localhost).
  |     ^
  |
  = help: if this is supposed to be its own paragraph, add a blank line
  = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#doc_lazy_continuation
help: indent this line
  |
6 | //!   ping/pong skipped (trusted localhost).
  |     ++

warning: `glade-node` (lib) generated 9 warnings (run `cargo clippy --fix --lib -p glade-node -- ` to apply 5 suggestions)
    Checking glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `dev` profile [unoptimized + debuginfo] target(s) in 0.27s

```

## B1 final affected Rust formatting
Command: ['rustfmt', '--check', '--edition', '2024', 'glade/node/src/independent/mod.rs', 'glade/node/tests/ic3_auth.rs']
Exit: 0; wall: 0.043s
```text

```
