
## B1 genuine historical and trusted-observation actual compiling capability RED
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_auth']
Exit: 101; wall: 8.728s
```text
   Compiling glade-crdt-recovery-codec v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-codec)
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
warning: field `certificate` is never read
  --> tests/ic3_auth_fixture/mod.rs:35:9
   |
32 | pub struct Fixture {
   |            ------- field in this struct
...
35 |     pub certificate: SignedRecord,
   |         ^^^^^^^^^^^
   |
   = note: `#[warn(dead_code)]` (part of `#[warn(unused)]`) on by default

warning: `glade-node` (test "ic3_auth") generated 1 warning
    Finished `test` profile [unoptimized + debuginfo] target(s) in 8.25s
     Running tests/ic3_auth.rs (glade/node/target/debug/deps/ic3_auth-d29f661d7892e84b)

running 2 tests
test genuine_historical_admission_verifies_exact_scoped_signed_records ... FAILED
test provider_observation_is_genuine_current_signed_policy_and_owned_clock ... FAILED

failures:

---- genuine_historical_admission_verifies_exact_scoped_signed_records stdout ----

thread 'genuine_historical_admission_verifies_exact_scoped_signed_records' (171833345) panicked at tests/ic3_auth.rs:17:9:
genuine historical admission must verify

---- provider_observation_is_genuine_current_signed_policy_and_owned_clock stdout ----

thread 'provider_observation_is_genuine_current_signed_policy_and_owned_clock' (171833346) panicked at tests/ic3_auth.rs:40:10:
configured genuine policy/time provider: Unavailable
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace


failures:
    genuine_historical_admission_verifies_exact_scoped_signed_records
    provider_observation_is_genuine_current_signed_policy_and_owned_clock

test result: FAILED. 0 passed; 2 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

error: test failed, to rerun pass `--test ic3_auth`

```

## B1 bad-signature/domain/identity actual semantic refusal RED
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_auth', 'bad_signature_wrong_domain_or_altered_namespace_are_invalid', '--', '--exact']
Exit: 101; wall: 1.072s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
warning: field `certificate` is never read
  --> tests/ic3_auth_fixture/mod.rs:35:9
   |
32 | pub struct Fixture {
   |            ------- field in this struct
...
35 |     pub certificate: SignedRecord,
   |         ^^^^^^^^^^^
   |
   = note: `#[warn(dead_code)]` (part of `#[warn(unused)]`) on by default

warning: `glade-node` (test "ic3_auth") generated 1 warning
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.58s
     Running tests/ic3_auth.rs (glade/node/target/debug/deps/ic3_auth-d29f661d7892e84b)

running 1 test
test bad_signature_wrong_domain_or_altered_namespace_are_invalid ... FAILED

failures:

---- bad_signature_wrong_domain_or_altered_namespace_are_invalid stdout ----

thread 'bad_signature_wrong_domain_or_altered_namespace_are_invalid' (171836166) panicked at tests/ic3_auth.rs:77:9:
assertion `left == right` failed: mutation0
  left: Unavailable
 right: Invalid
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace


failures:
    bad_signature_wrong_domain_or_altered_namespace_are_invalid

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 2 filtered out; finished in 0.00s

error: test failed, to rerun pass `--test ic3_auth`

```

## B1 genuine invalid-payload security classification RED
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_auth', 'signed_invalid_payload_is_authenticated_security_data_not_qualified_admission', '--', '--exact']
Exit: 101; wall: 1.579s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 1.11s
     Running tests/ic3_auth.rs (glade/node/target/debug/deps/ic3_auth-d29f661d7892e84b)

running 1 test
test signed_invalid_payload_is_authenticated_security_data_not_qualified_admission ... FAILED

failures:

---- signed_invalid_payload_is_authenticated_security_data_not_qualified_admission stdout ----

thread 'signed_invalid_payload_is_authenticated_security_data_not_qualified_admission' (171858200) panicked at tests/ic3_auth.rs:101:9:
authentic signed invalid payload retains its verifier classification
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace


failures:
    signed_invalid_payload_is_authenticated_security_data_not_qualified_admission

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 3 filtered out; finished in 0.00s

error: test failed, to rerun pass `--test ic3_auth`

```

## B1 genuine historical signature namespace and owned observation GREEN
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_auth']
Exit: 0; wall: 12.576s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 12.07s
     Running tests/ic3_auth.rs (glade/node/target/debug/deps/ic3_auth-d29f661d7892e84b)

running 4 tests
test provider_observation_is_genuine_current_signed_policy_and_owned_clock ... ok
test genuine_historical_admission_verifies_exact_scoped_signed_records ... ok
test signed_invalid_payload_is_authenticated_security_data_not_qualified_admission ... ok
test bad_signature_wrong_domain_or_altered_namespace_are_invalid ... ok

test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s


```

## B1 possession seal/current controls and observed-floor regression RED
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_auth']
Exit: 101; wall: 1.888s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 1.38s
     Running tests/ic3_auth.rs (glade/node/target/debug/deps/ic3_auth-d29f661d7892e84b)

running 7 tests
test trusted_source_cannot_regress_observed_clock_or_policy_floor ... FAILED
test provider_observation_is_genuine_current_signed_policy_and_owned_clock ... ok
test genuine_historical_admission_verifies_exact_scoped_signed_records ... ok
test signed_invalid_payload_is_authenticated_security_data_not_qualified_admission ... ok
test bad_signature_wrong_domain_or_altered_namespace_are_invalid ... ok
test uncertain_expired_or_revoked_current_cut_does_not_change_historical_validity ... ok
test local_possession_seal_and_foreign_or_replayed_session_controls ... ok

failures:

---- trusted_source_cannot_regress_observed_clock_or_policy_floor stdout ----

thread 'trusted_source_cannot_regress_observed_clock_or_policy_floor' (171866723) panicked at tests/ic3_auth.rs:325:5:
assertion `left == right` failed
  left: Ok(EvidenceObservation { instance: Instance { descriptor: [106, 112, 80, 115, 206, 61, 227, 118, 144, 79, 213, 227, 34, 128, 156, 165, 211, 75, 245, 227, 197, 157, 251, 107, 251, 46, 13, 255, 180, 214, 0, 21], incarnation: "fresh-ic3" }, node: [136, 75, 136, 87, 244, 234, 161, 97, 60, 97, 80, 77, 179, 77, 75, 234, 243, 70, 81, 122, 14, 49, 222, 60, 221, 212, 217, 180, 32, 29, 157, 11], policy: Bytes { value: [167, 0, 1, 1, 108, 83, 105, 103, 110, 101, 100, 82, 101, 99, 111, 114, 100, 2, 120, 24, 103, 108, 97, 100, 101, 47, 105, 99, 51, 47, 118, 49, 47, 112, 111, 108, 105, 99, 121, 45, 99, 117, 116, 0, 3, 72, 0, 0, 0, 0, 0, 0, 0, 1, 4, 88, 32, 102, 190, 126, 51, 44, 122, 69, 51, 50, 189, 157, 10, 127, 125, 176, 85, 245, 197, 239, 26, 6, 173, 166, 109, 152, 179, 159, 182, 129, 12, 71, 58, 5, 89, 5, 226, 172, 0, 1, 1, 106, 80, 111, 108, 105, 99, 121, 66, 111, 100, 121, 2, 162, 0, 88, 32, 106, 112, 80, 115, 206, 61, 227, 118, 144, 79, 213, 227, 34, 128, 156, 165, 211, 75, 245, 227, 197, 157, 251, 107, 251, 46, 13, 255, 180, 214, 0, 21, 1, 105, 102, 114, 101, 115, 104, 45, 105, 99, 51, 3, 178, 0, 88, 32, 102, 190, 126, 51, 44, 122, 69, 51, 50, 189, 157, 10, 127, 125, 176, 85, 245, 197, 239, 26, 6, 173, 166, 109, 152, 179, 159, 182, 129, 12, 71, 58, 1, 89, 3, 104, 184, 35, 0, 1, 1, 110, 67, 114, 101, 97, 116, 105, 111, 110, 73, 110, 116, 101, 110, 116, 2, 88, 32, 102, 190, 126, 51, 44, 122, 69, 51, 50, 189, 157, 10, 127, 125, 176, 85, 245, 197, 239, 26, 6, 173, 166, 109, 152, 179, 159, 182, 129, 12, 71, 58, 3, 88, 32, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 4, 105, 102, 114, 101, 115, 104, 45, 105, 99, 51, 5, 114, 112, 114, 105, 118, 97, 116, 101, 58, 97, 108, 105, 99, 101, 58, 116, 101, 120, 116, 6, 101, 97, 108, 105, 99, 101, 7, 103, 112, 114, 105, 118, 97, 116, 101, 8, 104, 105, 99, 51, 45, 116, 101, 120, 116, 9, 104, 100, 111, 99, 117, 109, 101, 110, 116, 10, 64, 11, 88, 32, 170, 40, 65, 78, 191, 215, 116, 126, 141, 147, 158, 237, 82, 203, 139, 203, 174, 121, 54, 7, 87, 45, 34, 180, 81, 211, 1, 161, 227, 90, 4, 228, 12, 107, 105, 99, 51, 45, 116, 101, 120, 116, 47, 118, 49, 13, 129, 0, 14, 109, 105, 99, 51, 45, 101, 109, 112, 116, 121, 45, 107, 101, 121, 15, 88, 32, 0, 77, 178, 86, 2, 244, 51, 93, 2, 135, 247, 15, 155, 145, 243, 59, 219, 106, 163, 171, 105, 181, 252, 57, 205, 85, 46, 179, 186, 81, 101, 174, 16, 97, 49, 17, 65, 160, 18, 110, 99, 114, 100, 116, 46, 111, 114, 97, 99, 108, 101, 47, 118, 49, 19, 116, 116, 101, 120, 116, 95, 99, 114, 100, 116, 46, 112, 114, 111, 102, 105, 108, 101, 47, 118, 49, 20, 120, 35, 103, 108, 97, 100, 101, 46, 99, 114, 100, 116, 46, 105, 110, 100, 101, 112, 101, 110, 100, 101, 110, 116, 45, 97, 100, 109, 105, 115, 115, 105, 111, 110, 47, 118, 49, 21, 120, 25, 98, 111, 117, 110, 100, 101, 100, 45, 111, 102, 102, 108, 105, 110, 101, 45, 112, 101, 114, 109, 105, 116, 47, 118, 49, 22, 120, 26, 105, 99, 51, 45, 100, 105, 114, 101, 99, 116, 45, 114, 111, 111, 116, 45, 101, 100, 50, 53, 53, 49, 57, 47, 118, 49, 23, 116, 105, 99, 51, 45, 114, 101, 99, 111, 114, 100, 115, 45, 102, 108, 111, 111, 114, 47, 118, 49, 24, 24, 117, 102, 117, 108, 108, 45, 104, 105, 115, 116, 111, 114, 121, 45, 110, 111, 45, 103, 99, 47, 118, 49, 24, 25, 120, 26, 101, 120, 97, 99, 116, 45, 101, 118, 105, 100, 101, 110, 99, 101, 45, 102, 117, 108, 108, 45, 99, 117, 116, 47, 118, 49, 24, 26, 120, 51, 116, 97, 117, 116, 45, 115, 104, 97, 112, 101, 47, 116, 101, 120, 116, 95, 99, 114, 100, 116, 46, 112, 114, 111, 102, 105, 108, 101, 46, 118, 49, 47, 99, 111, 110, 99, 117, 114, 114, 101, 110, 116, 95, 115, 105, 98, 108, 105, 110, 103, 115, 24, 27, 97, 49, 24, 28, 88, 32, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 24, 29, 129, 0, 24, 30, 129, 1, 24, 31, 168, 0, 72, 0, 0, 0, 0, 0, 0, 32, 0, 1, 72, 0, 0, 0, 0, 0, 0, 0, 8, 2, 72, 0, 0, 0, 0, 0, 0, 0, 16, 3, 72, 0, 0, 0, 0, 0, 15, 66, 64, 4, 72, 0, 0, 0, 0, 0, 1, 134, 160, 5, 72, 0, 0, 0, 0, 0, 1, 134, 160, 6, 72, 0, 0, 0, 0, 0, 1, 134, 160, 7, 72, 0, 0, 0, 0, 0, 0, 0, 32, 24, 32, 168, 0, 169, 0, 72, 0, 0, 0, 0, 0, 0, 0, 2, 1, 72, 0, 0, 0, 0, 0, 0, 0, 32, 2, 72, 0, 0, 0, 0, 0, 0, 0, 128, 3, 72, 0, 0, 0, 0, 0, 7, 161, 32, 4, 72, 0, 0, 0, 0, 0, 0, 0, 8, 5, 72, 0, 0, 0, 0, 0, 0, 0, 8, 6, 72, 0, 0, 0, 0, 0, 0, 2, 0, 7, 72, 0, 0, 0, 0, 0, 1, 134, 160, 8, 72, 0, 0, 0, 0, 0, 0, 4, 0, 1, 164, 0, 72, 0, 0, 0, 0, 0, 15, 66, 64, 1, 72, 0, 0, 0, 0, 0, 0, 78, 32, 2, 72, 0, 0, 0, 0, 0, 0, 0, 64, 3, 72, 0, 0, 0, 0, 0, 0, 2, 0, 2, 72, 0, 0, 0, 0, 0, 15, 66, 64, 3, 72, 0, 0, 0, 0, 0, 0, 0, 64, 4, 72, 0, 0, 0, 0, 0, 0, 0, 64, 5, 72, 0, 0, 0, 0, 0, 1, 134, 160, 6, 72, 0, 0, 0, 0, 0, 0, 0, 128, 7, 72, 0, 0, 0, 0, 0, 1, 134, 160, 24, 33, 0, 24, 34, 72, 0, 0, 0, 0, 0, 0, 0, 0, 2, 103, 112, 114, 105, 118, 97, 116, 101, 3, 65, 160, 4, 88, 45, 163, 0, 110, 99, 114, 100, 116, 46, 111, 114, 97, 99, 108, 101, 47, 118, 49, 1, 116, 116, 101, 120, 116, 95, 99, 114, 100, 116, 46, 112, 114, 111, 102, 105, 108, 101, 47, 118, 49, 2, 100, 67, 114, 100, 116, 5, 107, 105, 99, 51, 45, 116, 101, 120, 116, 47, 118, 49, 6, 83, 161, 0, 112, 105, 99, 51, 45, 101, 109, 112, 116, 121, 45, 107, 101, 121, 47, 118, 49, 7, 109, 105, 99, 51, 45, 101, 109, 112, 116, 121, 45, 107, 101, 121, 8, 97, 49, 9, 120, 51, 116, 97, 117, 116, 45, 115, 104, 97, 112, 101, 47, 116, 101, 120, 116, 95, 99, 114, 100, 116, 46, 112, 114, 111, 102, 105, 108, 101, 46, 118, 49, 47, 99, 111, 110, 99, 117, 114, 114, 101, 110, 116, 95, 115, 105, 98, 108, 105, 110, 103, 115, 10, 97, 49, 11, 88, 32, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 12, 120, 26, 105, 99, 51, 45, 100, 105, 114, 101, 99, 116, 45, 114, 111, 111, 116, 45, 101, 100, 50, 53, 53, 49, 57, 47, 118, 49, 13, 116, 105, 99, 51, 45, 114, 101, 99, 111, 114, 100, 115, 45, 102, 108, 111, 111, 114, 47, 118, 49, 14, 117, 102, 117, 108, 108, 45, 104, 105, 115, 116, 111, 114, 121, 45, 110, 111, 45, 103, 99, 47, 118, 49, 15, 120, 26, 101, 120, 97, 99, 116, 45, 101, 118, 105, 100, 101, 110, 99, 101, 45, 102, 117, 108, 108, 45, 99, 117, 116, 47, 118, 49, 16, 0, 17, 72, 0, 0, 0, 0, 0, 0, 0, 0, 4, 88, 32, 112, 83, 161, 75, 137, 60, 130, 140, 191, 139, 118, 167, 160, 156, 176, 165, 15, 66, 178, 252, 148, 95, 60, 218, 116, 247, 12, 137, 170, 64, 51, 247, 5, 72, 0, 0, 0, 0, 0, 0, 0, 0, 6, 246, 7, 162, 0, 72, 0, 0, 0, 0, 0, 0, 0, 0, 1, 72, 0, 0, 0, 0, 0, 0, 3, 232, 8, 129, 164, 0, 101, 97, 108, 105, 99, 101, 1, 88, 32, 81, 28, 52, 161, 162, 203, 82, 29, 241, 107, 178, 70, 184, 222, 142, 121, 151, 206, 35, 92, 126, 118, 178, 42, 61, 117, 3, 162, 72, 25, 221, 138, 2, 129, 0, 3, 114, 112, 114, 105, 118, 97, 116, 101, 58, 97, 108, 105, 99, 101, 58, 116, 101, 120, 116, 9, 128, 10, 129, 88, 32, 136, 75, 136, 87, 244, 234, 161, 97, 60, 97, 80, 77, 179, 77, 75, 234, 243, 70, 81, 122, 14, 49, 222, 60, 221, 212, 217, 180, 32, 29, 157, 11, 11, 129, 88, 32, 136, 75, 136, 87, 244, 234, 161, 97, 60, 97, 80, 77, 179, 77, 75, 234, 243, 70, 81, 122, 14, 49, 222, 60, 221, 212, 217, 180, 32, 29, 157, 11, 6, 88, 64, 213, 242, 168, 146, 64, 62, 87, 81, 160, 121, 252, 187, 161, 163, 27, 181, 7, 71, 222, 41, 4, 76, 134, 147, 90, 17, 20, 52, 93, 166, 174, 200, 14, 215, 7, 102, 70, 18, 69, 149, 143, 76, 128, 47, 86, 170, 2, 246, 116, 210, 182, 136, 163, 108, 28, 115, 219, 116, 226, 244, 106, 12, 231, 2], digest: [16, 225, 251, 177, 77, 159, 221, 208, 163, 151, 57, 99, 94, 183, 0, 251, 216, 234, 165, 9, 184, 175, 226, 86, 51, 43, 139, 208, 4, 187, 11, 82] }, time: TimeInterval { earliest_ms: 19, latest_ms: 20 }, available: true, allowed: true })
 right: Err(Unavailable)
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace


failures:
    trusted_source_cannot_regress_observed_clock_or_policy_floor

test result: FAILED. 6 passed; 1 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

error: test failed, to rerun pass `--test ic3_auth`

```

## B1 fresh possession cannot be bypassed by an operation cache RED
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_auth', 'every_local_verification_requires_new_possession_not_operation_cache_reuse', '--', '--exact']
Exit: 101; wall: 1.119s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.55s
     Running tests/ic3_auth.rs (glade/node/target/debug/deps/ic3_auth-d29f661d7892e84b)

running 1 test
test every_local_verification_requires_new_possession_not_operation_cache_reuse ... FAILED

failures:

---- every_local_verification_requires_new_possession_not_operation_cache_reuse stdout ----

thread 'every_local_verification_requires_new_possession_not_operation_cache_reuse' (171870556) panicked at tests/ic3_auth.rs:355:5:
assertion `left == right` failed: a separate local attempt cannot reuse the consumed possession gate
  left: Verified(Facts { certificate: OriginCertificate { instance: Instance { descriptor: [106, 112, 80, 115, 206, 61, 227, 118, 144, 79, 213, 227, 34, 128, 156, 165, 211, 75, 245, 227, 197, 157, 251, 107, 251, 46, 13, 255, 180, 214, 0, 21], incarnation: "fresh-ic3" }, canonical_origin: "writer-e0", epoch: "e0", display_name: "writer", writer_key: [81, 28, 52, 161, 162, 203, 82, 29, 241, 107, 178, 70, 184, 222, 142, 121, 151, 206, 35, 92, 126, 118, 178, 42, 61, 117, 3, 162, 72, 25, 221, 138], requester: "alice", canonical: Bytes { value: [167, 0, 1, 1, 108, 83, 105, 103, 110, 101, 100, 82, 101, 99, 111, 114, 100, 2, 120, 32, 103, 108, 97, 100, 101, 47, 105, 99, 51, 47, 118, 49, 47, 111, 114, 105, 103, 105, 110, 45, 99, 101, 114, 116, 105, 102, 105, 99, 97, 116, 101, 0, 3, 72, 0, 0, 0, 0, 0, 0, 0, 1, 4, 88, 32, 102, 190, 126, 51, 44, 122, 69, 51, 50, 189, 157, 10, 127, 125, 176, 85, 245, 197, 239, 26, 6, 173, 166, 109, 152, 179, 159, 182, 129, 12, 71, 58, 5, 89, 5, 150, 172, 0, 1, 1, 111, 67, 101, 114, 116, 105, 102, 105, 99, 97, 116, 101, 66, 111, 100, 121, 2, 162, 0, 88, 32, 106, 112, 80, 115, 206, 61, 227, 118, 144, 79, 213, 227, 34, 128, 156, 165, 211, 75, 245, 227, 197, 157, 251, 107, 251, 46, 13, 255, 180, 214, 0, 21, 1, 105, 102, 114, 101, 115, 104, 45, 105, 99, 51, 3, 178, 0, 88, 32, 102, 190, 126, 51, 44, 122, 69, 51, 50, 189, 157, 10, 127, 125, 176, 85, 245, 197, 239, 26, 6, 173, 166, 109, 152, 179, 159, 182, 129, 12, 71, 58, 1, 89, 3, 104, 184, 35, 0, 1, 1, 110, 67, 114, 101, 97, 116, 105, 111, 110, 73, 110, 116, 101, 110, 116, 2, 88, 32, 102, 190, 126, 51, 44, 122, 69, 51, 50, 189, 157, 10, 127, 125, 176, 85, 245, 197, 239, 26, 6, 173, 166, 109, 152, 179, 159, 182, 129, 12, 71, 58, 3, 88, 32, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 4, 105, 102, 114, 101, 115, 104, 45, 105, 99, 51, 5, 114, 112, 114, 105, 118, 97, 116, 101, 58, 97, 108, 105, 99, 101, 58, 116, 101, 120, 116, 6, 101, 97, 108, 105, 99, 101, 7, 103, 112, 114, 105, 118, 97, 116, 101, 8, 104, 105, 99, 51, 45, 116, 101, 120, 116, 9, 104, 100, 111, 99, 117, 109, 101, 110, 116, 10, 64, 11, 88, 32, 170, 40, 65, 78, 191, 215, 116, 126, 141, 147, 158, 237, 82, 203, 139, 203, 174, 121, 54, 7, 87, 45, 34, 180, 81, 211, 1, 161, 227, 90, 4, 228, 12, 107, 105, 99, 51, 45, 116, 101, 120, 116, 47, 118, 49, 13, 129, 0, 14, 109, 105, 99, 51, 45, 101, 109, 112, 116, 121, 45, 107, 101, 121, 15, 88, 32, 0, 77, 178, 86, 2, 244, 51, 93, 2, 135, 247, 15, 155, 145, 243, 59, 219, 106, 163, 171, 105, 181, 252, 57, 205, 85, 46, 179, 186, 81, 101, 174, 16, 97, 49, 17, 65, 160, 18, 110, 99, 114, 100, 116, 46, 111, 114, 97, 99, 108, 101, 47, 118, 49, 19, 116, 116, 101, 120, 116, 95, 99, 114, 100, 116, 46, 112, 114, 111, 102, 105, 108, 101, 47, 118, 49, 20, 120, 35, 103, 108, 97, 100, 101, 46, 99, 114, 100, 116, 46, 105, 110, 100, 101, 112, 101, 110, 100, 101, 110, 116, 45, 97, 100, 109, 105, 115, 115, 105, 111, 110, 47, 118, 49, 21, 120, 25, 98, 111, 117, 110, 100, 101, 100, 45, 111, 102, 102, 108, 105, 110, 101, 45, 112, 101, 114, 109, 105, 116, 47, 118, 49, 22, 120, 26, 105, 99, 51, 45, 100, 105, 114, 101, 99, 116, 45, 114, 111, 111, 116, 45, 101, 100, 50, 53, 53, 49, 57, 47, 118, 49, 23, 116, 105, 99, 51, 45, 114, 101, 99, 111, 114, 100, 115, 45, 102, 108, 111, 111, 114, 47, 118, 49, 24, 24, 117, 102, 117, 108, 108, 45, 104, 105, 115, 116, 111, 114, 121, 45, 110, 111, 45, 103, 99, 47, 118, 49, 24, 25, 120, 26, 101, 120, 97, 99, 116, 45, 101, 118, 105, 100, 101, 110, 99, 101, 45, 102, 117, 108, 108, 45, 99, 117, 116, 47, 118, 49, 24, 26, 120, 51, 116, 97, 117, 116, 45, 115, 104, 97, 112, 101, 47, 116, 101, 120, 116, 95, 99, 114, 100, 116, 46, 112, 114, 111, 102, 105, 108, 101, 46, 118, 49, 47, 99, 111, 110, 99, 117, 114, 114, 101, 110, 116, 95, 115, 105, 98, 108, 105, 110, 103, 115, 24, 27, 97, 49, 24, 28, 88, 32, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 24, 29, 129, 0, 24, 30, 129, 1, 24, 31, 168, 0, 72, 0, 0, 0, 0, 0, 0, 32, 0, 1, 72, 0, 0, 0, 0, 0, 0, 0, 8, 2, 72, 0, 0, 0, 0, 0, 0, 0, 16, 3, 72, 0, 0, 0, 0, 0, 15, 66, 64, 4, 72, 0, 0, 0, 0, 0, 1, 134, 160, 5, 72, 0, 0, 0, 0, 0, 1, 134, 160, 6, 72, 0, 0, 0, 0, 0, 1, 134, 160, 7, 72, 0, 0, 0, 0, 0, 0, 0, 32, 24, 32, 168, 0, 169, 0, 72, 0, 0, 0, 0, 0, 0, 0, 2, 1, 72, 0, 0, 0, 0, 0, 0, 0, 32, 2, 72, 0, 0, 0, 0, 0, 0, 0, 128, 3, 72, 0, 0, 0, 0, 0, 7, 161, 32, 4, 72, 0, 0, 0, 0, 0, 0, 0, 8, 5, 72, 0, 0, 0, 0, 0, 0, 0, 8, 6, 72, 0, 0, 0, 0, 0, 0, 2, 0, 7, 72, 0, 0, 0, 0, 0, 1, 134, 160, 8, 72, 0, 0, 0, 0, 0, 0, 4, 0, 1, 164, 0, 72, 0, 0, 0, 0, 0, 15, 66, 64, 1, 72, 0, 0, 0, 0, 0, 0, 78, 32, 2, 72, 0, 0, 0, 0, 0, 0, 0, 64, 3, 72, 0, 0, 0, 0, 0, 0, 2, 0, 2, 72, 0, 0, 0, 0, 0, 15, 66, 64, 3, 72, 0, 0, 0, 0, 0, 0, 0, 64, 4, 72, 0, 0, 0, 0, 0, 0, 0, 64, 5, 72, 0, 0, 0, 0, 0, 1, 134, 160, 6, 72, 0, 0, 0, 0, 0, 0, 0, 128, 7, 72, 0, 0, 0, 0, 0, 1, 134, 160, 24, 33, 0, 24, 34, 72, 0, 0, 0, 0, 0, 0, 0, 0, 2, 103, 112, 114, 105, 118, 97, 116, 101, 3, 65, 160, 4, 88, 45, 163, 0, 110, 99, 114, 100, 116, 46, 111, 114, 97, 99, 108, 101, 47, 118, 49, 1, 116, 116, 101, 120, 116, 95, 99, 114, 100, 116, 46, 112, 114, 111, 102, 105, 108, 101, 47, 118, 49, 2, 100, 67, 114, 100, 116, 5, 107, 105, 99, 51, 45, 116, 101, 120, 116, 47, 118, 49, 6, 83, 161, 0, 112, 105, 99, 51, 45, 101, 109, 112, 116, 121, 45, 107, 101, 121, 47, 118, 49, 7, 109, 105, 99, 51, 45, 101, 109, 112, 116, 121, 45, 107, 101, 121, 8, 97, 49, 9, 120, 51, 116, 97, 117, 116, 45, 115, 104, 97, 112, 101, 47, 116, 101, 120, 116, 95, 99, 114, 100, 116, 46, 112, 114, 111, 102, 105, 108, 101, 46, 118, 49, 47, 99, 111, 110, 99, 117, 114, 114, 101, 110, 116, 95, 115, 105, 98, 108, 105, 110, 103, 115, 10, 97, 49, 11, 88, 32, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 12, 120, 26, 105, 99, 51, 45, 100, 105, 114, 101, 99, 116, 45, 114, 111, 111, 116, 45, 101, 100, 50, 53, 53, 49, 57, 47, 118, 49, 13, 116, 105, 99, 51, 45, 114, 101, 99, 111, 114, 100, 115, 45, 102, 108, 111, 111, 114, 47, 118, 49, 14, 117, 102, 117, 108, 108, 45, 104, 105, 115, 116, 111, 114, 121, 45, 110, 111, 45, 103, 99, 47, 118, 49, 15, 120, 26, 101, 120, 97, 99, 116, 45, 101, 118, 105, 100, 101, 110, 99, 101, 45, 102, 117, 108, 108, 45, 99, 117, 116, 47, 118, 49, 16, 0, 17, 72, 0, 0, 0, 0, 0, 0, 0, 0, 4, 114, 112, 114, 105, 118, 97, 116, 101, 58, 97, 108, 105, 99, 101, 58, 116, 101, 120, 116, 5, 105, 119, 114, 105, 116, 101, 114, 45, 101, 48, 6, 98, 101, 48, 7, 102, 119, 114, 105, 116, 101, 114, 8, 88, 32, 81, 28, 52, 161, 162, 203, 82, 29, 241, 107, 178, 70, 184, 222, 142, 121, 151, 206, 35, 92, 126, 118, 178, 42, 61, 117, 3, 162, 72, 25, 221, 138, 9, 101, 97, 108, 105, 99, 101, 10, 88, 32, 112, 83, 161, 75, 137, 60, 130, 140, 191, 139, 118, 167, 160, 156, 176, 165, 15, 66, 178, 252, 148, 95, 60, 218, 116, 247, 12, 137, 170, 64, 51, 247, 11, 72, 0, 0, 0, 0, 0, 0, 0, 0, 6, 88, 64, 16, 164, 236, 75, 168, 158, 80, 110, 190, 101, 179, 17, 161, 75, 62, 46, 17, 81, 151, 111, 21, 221, 137, 44, 211, 81, 148, 105, 222, 214, 48, 51, 38, 80, 235, 48, 91, 214, 136, 190, 151, 44, 83, 226, 13, 183, 35, 67, 222, 238, 218, 148, 22, 247, 142, 5, 204, 56, 172, 108, 178, 86, 148, 1], digest: [173, 143, 216, 115, 119, 0, 26, 131, 186, 22, 131, 221, 21, 152, 188, 105, 183, 157, 99, 115, 62, 6, 75, 13, 65, 236, 121, 198, 143, 176, 50, 228] } }, descriptor_valid: true, payload_valid: true, signatures_valid: true, issuance_unique: true, permit_window: Window { not_before_ms: 10, not_after_ms: 100 }, permit_first_seq: 0, permit_last_seq: 8, current_allowed: true, historical_admitter_authorized: false, historical_policy_allowed: false, historical_time: None })
 right: Invalid
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace


failures:
    every_local_verification_requires_new_possession_not_operation_cache_reuse

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 7 filtered out; finished in 0.00s

error: test failed, to rerun pass `--test ic3_auth`

```

## B1 single-use possession and monotonic provider observations GREEN
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_auth']
Exit: 101; wall: 1.479s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
error[E0425]: cannot find value `for_seal` in this scope
   --> src/independent/auth.rs:433:37
    |
433 |                 let authorized = if for_seal {
    |                                     ^^^^^^^^ not found in this scope

error[E0061]: this method takes 2 arguments but 3 arguments were supplied
   --> src/independent/auth.rs:474:34
    |
474 |         let verdict = match self.checked(&query, &query.query.mode, false) {
    |                                  ^^^^^^^                            ----- unexpected argument #3 of type `bool`
    |
note: method defined here
   --> src/independent/auth.rs:284:8
    |
284 |     fn checked(&mut self, bound: &BoundQuery, mode: &Mode) -> Result<Facts, Fault> {
    |        ^^^^^^^
help: remove the extra argument
    |
474 -         let verdict = match self.checked(&query, &query.query.mode, false) {
474 +         let verdict = match self.checked(&query, &query.query.mode) {
    |

error[E0061]: this method takes 2 arguments but 3 arguments were supplied
   --> src/independent/auth.rs:521:30
    |
521 |             let facts = self.checked(&bound, mode, true)?;
    |                              ^^^^^^^               ---- unexpected argument #3 of type `bool`
    |
note: method defined here
   --> src/independent/auth.rs:284:8
    |
284 |     fn checked(&mut self, bound: &BoundQuery, mode: &Mode) -> Result<Facts, Fault> {
    |        ^^^^^^^
help: remove the extra argument
    |
521 -             let facts = self.checked(&bound, mode, true)?;
521 +             let facts = self.checked(&bound, mode)?;
    |

Some errors have detailed explanations: E0061, E0425.
For more information about an error, try `rustc --explain E0061`.
error: could not compile `glade-node` (lib) due to 3 previous errors

```

## B1 corrected compiling single-use possession and monotonic observations
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_auth']
Exit: 0; wall: 2.145s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 1.68s
     Running tests/ic3_auth.rs (glade/node/target/debug/deps/ic3_auth-d29f661d7892e84b)

running 8 tests
test provider_observation_is_genuine_current_signed_policy_and_owned_clock ... ok
test bad_signature_wrong_domain_or_altered_namespace_are_invalid ... ok
test trusted_source_cannot_regress_observed_clock_or_policy_floor ... ok
test every_local_verification_requires_new_possession_not_operation_cache_reuse ... ok
test signed_invalid_payload_is_authenticated_security_data_not_qualified_admission ... ok
test genuine_historical_admission_verifies_exact_scoped_signed_records ... ok
test local_possession_seal_and_foreign_or_replayed_session_controls ... ok
test uncertain_expired_or_revoked_current_cut_does_not_change_historical_validity ... ok

test result: ok. 8 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s


```

## B1 signed unsupported corpus identity RED
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_auth', 'root_signature_does_not_authorize_an_unsupported_merge_corpus', '--', '--exact']
Exit: 101; wall: 1.091s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.58s
     Running tests/ic3_auth.rs (glade/node/target/debug/deps/ic3_auth-d29f661d7892e84b)

running 1 test
test root_signature_does_not_authorize_an_unsupported_merge_corpus ... FAILED

failures:

---- root_signature_does_not_authorize_an_unsupported_merge_corpus stdout ----

thread 'root_signature_does_not_authorize_an_unsupported_merge_corpus' (171879419) panicked at tests/ic3_auth.rs:400:5:
unsupported signed corpus must refuse
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace


failures:
    root_signature_does_not_authorize_an_unsupported_merge_corpus

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 8 filtered out; finished in 0.00s

error: test failed, to rerun pass `--test ic3_auth`

```

## B1 genuine pinned text corpus compatibility GREEN
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_auth']
Exit: 0; wall: 1.984s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 1.49s
     Running tests/ic3_auth.rs (glade/node/target/debug/deps/ic3_auth-d29f661d7892e84b)

running 9 tests
test provider_observation_is_genuine_current_signed_policy_and_owned_clock ... ok
test genuine_historical_admission_verifies_exact_scoped_signed_records ... ok
test root_signature_does_not_authorize_an_unsupported_merge_corpus ... ok
test signed_invalid_payload_is_authenticated_security_data_not_qualified_admission ... ok
test trusted_source_cannot_regress_observed_clock_or_policy_floor ... ok
test bad_signature_wrong_domain_or_altered_namespace_are_invalid ... ok
test every_local_verification_requires_new_possession_not_operation_cache_reuse ... ok
test local_possession_seal_and_foreign_or_replayed_session_controls ... ok
test uncertain_expired_or_revoked_current_cut_does_not_change_historical_validity ... ok

test result: ok. 9 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.02s


```

## B1 released duplicate-property/BOM payload regression RED
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_auth', 'released_payload_duplicate_properties_and_utf8_bom_remain_supported', '--', '--exact']
Exit: 101; wall: 1.115s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.61s
     Running tests/ic3_auth.rs (glade/node/target/debug/deps/ic3_auth-d29f661d7892e84b)

running 1 test
test released_payload_duplicate_properties_and_utf8_bom_remain_supported ... FAILED

failures:

---- released_payload_duplicate_properties_and_utf8_bom_remain_supported stdout ----

thread 'released_payload_duplicate_properties_and_utf8_bom_remain_supported' (171884611) panicked at tests/ic3_auth.rs:435:9:
released JSON.parse/TextDecoder behavior must be retained
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace


failures:
    released_payload_duplicate_properties_and_utf8_bom_remain_supported

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 9 filtered out; finished in 0.00s

error: test failed, to rerun pass `--test ic3_auth`

```

## B1 released JSON duplicate/BOM/UTF16 behavior GREEN
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_auth']
Exit: 0; wall: 3.513s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 2.97s
     Running tests/ic3_auth.rs (glade/node/target/debug/deps/ic3_auth-d29f661d7892e84b)

running 10 tests
test root_signature_does_not_authorize_an_unsupported_merge_corpus ... ok
test provider_observation_is_genuine_current_signed_policy_and_owned_clock ... ok
test genuine_historical_admission_verifies_exact_scoped_signed_records ... ok
test trusted_source_cannot_regress_observed_clock_or_policy_floor ... ok
test signed_invalid_payload_is_authenticated_security_data_not_qualified_admission ... ok
test bad_signature_wrong_domain_or_altered_namespace_are_invalid ... ok
test released_payload_duplicate_properties_and_utf8_bom_remain_supported ... ok
test every_local_verification_requires_new_possession_not_operation_cache_reuse ... ok
test local_possession_seal_and_foreign_or_replayed_session_controls ... ok
test uncertain_expired_or_revoked_current_cut_does_not_change_historical_validity ... ok

test result: ok. 10 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s


```

## B1 actual released Glial payload consumer shared rows
Command: ['node', '--experimental-transform-types', 'glade/node/tests/ic3_text_consumer.mjs', '/Volumes/projects/limbo/glade-wz/glial/src/text_crdt.ts']
Exit: 0; wall: 0.100s
```text
Actual released Glial text decoder: 35 shared rows PASS
(node:25469) ExperimentalWarning: Transform Types is an experimental feature and might change at any time
(Use `node --trace-warnings ...` to show where the warning was created)

```

## B1 genuine provider shared released payload shape rows
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_auth']
Exit: 0; wall: 1.115s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.56s
     Running tests/ic3_auth.rs (glade/node/target/debug/deps/ic3_auth-d29f661d7892e84b)

running 11 tests
test root_signature_does_not_authorize_an_unsupported_merge_corpus ... ok
test signed_invalid_payload_is_authenticated_security_data_not_qualified_admission ... ok
test provider_observation_is_genuine_current_signed_policy_and_owned_clock ... ok
test bad_signature_wrong_domain_or_altered_namespace_are_invalid ... ok
test genuine_historical_admission_verifies_exact_scoped_signed_records ... ok
test trusted_source_cannot_regress_observed_clock_or_policy_floor ... ok
test every_local_verification_requires_new_possession_not_operation_cache_reuse ... ok
test released_payload_duplicate_properties_and_utf8_bom_remain_supported ... ok
test local_possession_seal_and_foreign_or_replayed_session_controls ... ok
test uncertain_expired_or_revoked_current_cut_does_not_change_historical_validity ... ok
test genuine_provider_matches_shared_released_text_syntax_rows ... ok

test result: ok. 11 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.05s


```

## B1 finite operation footprint before payload interpretation RED
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_auth', 'genuine_overlimit_operation_is_refused_before_payload_interpretation', '--', '--exact']
Exit: 101; wall: 1.111s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.59s
     Running tests/ic3_auth.rs (glade/node/target/debug/deps/ic3_auth-d29f661d7892e84b)

running 1 test
test genuine_overlimit_operation_is_refused_before_payload_interpretation ... FAILED

failures:

---- genuine_overlimit_operation_is_refused_before_payload_interpretation stdout ----

thread 'genuine_overlimit_operation_is_refused_before_payload_interpretation' (171892039) panicked at tests/ic3_auth.rs:497:5:
assertion failed: matches!(provider(&f).verify(BoundQuery
    { query: q, identity: f.identity }).verdict, Verdict::Unavailable)
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace


failures:
    genuine_overlimit_operation_is_refused_before_payload_interpretation

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 11 filtered out; finished in 0.00s

error: test failed, to rerun pass `--test ic3_auth`

```

## B1 finite operation and complete existing controls GREEN
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_auth']
Exit: 0; wall: 2.020s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 1.48s
     Running tests/ic3_auth.rs (glade/node/target/debug/deps/ic3_auth-d29f661d7892e84b)

running 12 tests
test root_signature_does_not_authorize_an_unsupported_merge_corpus ... ok
test provider_observation_is_genuine_current_signed_policy_and_owned_clock ... ok
test bad_signature_wrong_domain_or_altered_namespace_are_invalid ... ok
test signed_invalid_payload_is_authenticated_security_data_not_qualified_admission ... ok
test genuine_overlimit_operation_is_refused_before_payload_interpretation ... ok
test genuine_historical_admission_verifies_exact_scoped_signed_records ... ok
test trusted_source_cannot_regress_observed_clock_or_policy_floor ... ok
test released_payload_duplicate_properties_and_utf8_bom_remain_supported ... ok
test every_local_verification_requires_new_possession_not_operation_cache_reuse ... ok
test local_possession_seal_and_foreign_or_replayed_session_controls ... ok
test uncertain_expired_or_revoked_current_cut_does_not_change_historical_validity ... ok
test genuine_provider_matches_shared_released_text_syntax_rows ... ok

test result: ok. 12 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.05s


```

## Owner scope exclusion 2026-10-04
Owner: "no - it does not warrant anything - ignore it" (BOM). Removed newly introduced BOM-specific rows/support from the current tranche; existing Glial remains unchanged. Historical executed results remain as chronology. Current shared rows=32. No complete byte-level JSON equivalence claim including BOM. No further BOM investigation or special gate.

## B1 remaining scoped actual Glial payload rows
Command: ['node', '--experimental-transform-types', 'glade/node/tests/ic3_text_consumer.mjs', '/Volumes/projects/limbo/glade-wz/glial/src/text_crdt.ts']
Exit: 0; wall: 0.094s
```text
Actual released Glial text decoder: 32 shared rows PASS
(node:27309) ExperimentalWarning: Transform Types is an experimental feature and might change at any time
(Use `node --trace-warnings ...` to show where the warning was created)

```

## B1 owner-scoped provider controls before cohesion split
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_auth']
Exit: 0; wall: 2.065s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 1.51s
     Running tests/ic3_auth.rs (glade/node/target/debug/deps/ic3_auth-d29f661d7892e84b)

running 12 tests
test root_signature_does_not_authorize_an_unsupported_merge_corpus ... ok
test provider_observation_is_genuine_current_signed_policy_and_owned_clock ... ok
test genuine_overlimit_operation_is_refused_before_payload_interpretation ... ok
test released_payload_duplicate_properties_remain_supported ... ok
test genuine_historical_admission_verifies_exact_scoped_signed_records ... ok
test trusted_source_cannot_regress_observed_clock_or_policy_floor ... ok
test bad_signature_wrong_domain_or_altered_namespace_are_invalid ... ok
test signed_invalid_payload_is_authenticated_security_data_not_qualified_admission ... ok
test every_local_verification_requires_new_possession_not_operation_cache_reuse ... ok
test local_possession_seal_and_foreign_or_replayed_session_controls ... ok
test uncertain_expired_or_revoked_current_cut_does_not_change_historical_validity ... ok
test genuine_provider_matches_shared_released_text_syntax_rows ... ok

test result: ok. 12 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.04s


```

## B1 syntax-aware provider cohesion split preserves behavior
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_auth']
Exit: 0; wall: 3.330s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
warning: unused import: `super::*`
 --> src/independent/auth/provider.rs:7:5
  |
7 | use super::*;
  |     ^^^^^^^^
  |
  = note: `#[warn(unused_imports)]` (part of `#[warn(unused)]`) on by default

warning: `glade-node` (lib) generated 1 warning (run `cargo fix --lib -p glade-node` to apply 1 suggestion)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 2.76s
     Running tests/ic3_auth.rs (glade/node/target/debug/deps/ic3_auth-d29f661d7892e84b)

running 12 tests
test genuine_overlimit_operation_is_refused_before_payload_interpretation ... ok
test genuine_historical_admission_verifies_exact_scoped_signed_records ... ok
test released_payload_duplicate_properties_remain_supported ... ok
test provider_observation_is_genuine_current_signed_policy_and_owned_clock ... ok
test root_signature_does_not_authorize_an_unsupported_merge_corpus ... ok
test trusted_source_cannot_regress_observed_clock_or_policy_floor ... ok
test every_local_verification_requires_new_possession_not_operation_cache_reuse ... ok
test signed_invalid_payload_is_authenticated_security_data_not_qualified_admission ... ok
test bad_signature_wrong_domain_or_altered_namespace_are_invalid ... ok
test local_possession_seal_and_foreign_or_replayed_session_controls ... ok
test uncertain_expired_or_revoked_current_cut_does_not_change_historical_validity ... ok
test genuine_provider_matches_shared_released_text_syntax_rows ... ok

test result: ok. 12 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.05s


```

## B1 scope key domain issuance bare-rival and fresh E1 genuine controls
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_auth']
Exit: 0; wall: 1.983s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
warning: unused import: `super::*`
 --> src/independent/auth/provider.rs:7:5
  |
7 | use super::*;
  |     ^^^^^^^^
  |
  = note: `#[warn(unused_imports)]` (part of `#[warn(unused)]`) on by default

warning: `glade-node` (lib) generated 1 warning (run `cargo fix --lib -p glade-node` to apply 1 suggestion)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 1.42s
     Running tests/ic3_auth.rs (glade/node/target/debug/deps/ic3_auth-d29f661d7892e84b)

running 16 tests
test ic3_auth_extra::strict_ed25519_refuses_small_order_writer_and_changed_domain ... ok
test provider_observation_is_genuine_current_signed_policy_and_owned_clock ... ok
test genuine_historical_admission_verifies_exact_scoped_signed_records ... ok
test genuine_overlimit_operation_is_refused_before_payload_interpretation ... ok
test root_signature_does_not_authorize_an_unsupported_merge_corpus ... ok
test ic3_auth_extra::distinct_fresh_origin_qualifies_but_reused_origin_epoch_or_issuance_refuses ... ok
test released_payload_duplicate_properties_remain_supported ... ok
test bad_signature_wrong_domain_or_altered_namespace_are_invalid ... ok
test trusted_source_cannot_regress_observed_clock_or_policy_floor ... ok
test every_local_verification_requires_new_possession_not_operation_cache_reuse ... ok
test ic3_auth_extra::bare_signed_rival_does_not_convict_but_original_signed_admission_qualifies ... ok
test signed_invalid_payload_is_authenticated_security_data_not_qualified_admission ... ok
test local_possession_seal_and_foreign_or_replayed_session_controls ... ok
test ic3_auth_extra::all_evidence_layers_reject_validly_signed_changed_bindings_or_wrong_keys ... ok
test uncertain_expired_or_revoked_current_cut_does_not_change_historical_validity ... ok
test genuine_provider_matches_shared_released_text_syntax_rows ... ok

test result: ok. 16 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.05s


```

## B1 adopting node architecture boundary
Command: ['cargo', 'run', '--quiet', '--locked', '--offline', '--manifest-path', 'glade-discover/tools/architecture-check/Cargo.toml', '--', 'glade/node']
Exit: 0; wall: 0.931s
```text
Architecture boundaries: PASS (workspace libraries, declared dependencies, traits and conformance targets)

```

## B1 process-global ratchet unchanged
Command: ['python3', 'glade/scripts/checks/check_process_globals.py']
Exit: 0; wall: 0.574s
```text
process-global state guard: 112 files, 3 allowlisted items (0 debt, 3 permanent); nothing new

```

## B1 retained default refusing assembly
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_boundary']
Exit: 0; wall: 2.353s
```text
    Blocking waiting for file lock on package cache
    Blocking waiting for file lock on package cache
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 1.63s
     Running tests/ic3_boundary.rs (glade/node/target/debug/deps/ic3_boundary-32e8ca973e5e411b)

running 6 tests
test production_composition_recovers_a_genuinely_persistent_validated_image ... ignored, IC3B assembled open and validated recovery success remain RED; physical restart is deferred
test standalone_refuser_has_no_fabricated_validated_image ... ok
test standalone_refuser_never_issues_a_consume_permit ... ok
test standalone_refuser_rejects_caller_created_permit_before_callback ... ok
test consumer_detects_recovery_selection_mutant_instead_of_discarding_host ... ok
test actual_assembled_evidence_verify_seal_and_observe_refuse ... ok

test result: ok. 5 passed; 0 failed; 1 ignored; 0 measured; 0 filtered out; finished in 0.00s


```

## B1 focused genuine provider final
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_auth']
Exit: 0; wall: 2.812s
```text
    Blocking waiting for file lock on package cache
    Blocking waiting for file lock on package cache
    Blocking waiting for file lock on package cache
    Blocking waiting for file lock on build directory
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 2.19s
     Running tests/ic3_auth.rs (glade/node/target/debug/deps/ic3_auth-d29f661d7892e84b)

running 16 tests
test ic3_auth_extra::strict_ed25519_refuses_small_order_writer_and_changed_domain ... ok
test root_signature_does_not_authorize_an_unsupported_merge_corpus ... ok
test genuine_overlimit_operation_is_refused_before_payload_interpretation ... ok
test released_payload_duplicate_properties_remain_supported ... ok
test bad_signature_wrong_domain_or_altered_namespace_are_invalid ... ok
test provider_observation_is_genuine_current_signed_policy_and_owned_clock ... ok
test ic3_auth_extra::distinct_fresh_origin_qualifies_but_reused_origin_epoch_or_issuance_refuses ... ok
test genuine_historical_admission_verifies_exact_scoped_signed_records ... ok
test every_local_verification_requires_new_possession_not_operation_cache_reuse ... ok
test signed_invalid_payload_is_authenticated_security_data_not_qualified_admission ... ok
test ic3_auth_extra::bare_signed_rival_does_not_convict_but_original_signed_admission_qualifies ... ok
test trusted_source_cannot_regress_observed_clock_or_policy_floor ... ok
test local_possession_seal_and_foreign_or_replayed_session_controls ... ok
test ic3_auth_extra::all_evidence_layers_reject_validly_signed_changed_bindings_or_wrong_keys ... ok
test uncertain_expired_or_revoked_current_cut_does_not_change_historical_validity ... ok
test genuine_provider_matches_shared_released_text_syntax_rows ... ok

test result: ok. 16 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.04s


```

## B1 retained production contract adopter
Command: ['sh', 'glade/contracts/check.sh', 'crdt-production']
Exit: 0; wall: 9.208s
```text
Architecture boundaries: PASS (workspace libraries, declared dependencies, traits and conformance targets)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.06s
     Running unittests src/lib.rs (glade/contracts/target/debug/deps/glade_crdt_admission_core-932f6277b6041d9c)

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/encoder_complete.rs (glade/contracts/target/debug/deps/encoder_complete-0c61aeec9660768e)

running 10 tests
test candidate::all_candidate_evidence_and_inner_op_bytes ... ok
test plan::complete_plan_header_and_optional_local_cut ... ok
test plan::namespaces_issuance_owner_and_storage_promise_are_part_of_bytes ... ok
test stage::all_staged_candidate_seal_and_receipt_fields ... ok
test descriptor::all_descriptor_parsed_fields_and_bounds ... ok
test seal::full_sealing_query_continuations ... ok
test facts::all_staged_facts_and_certificate_fields ... ok
test fork::fork_pairs_have_complete_candidate_identity_and_evidence ... ok
test verify::full_verification_query_continuations ... ok
test seal_scope::full_seal_descriptor_and_evidence ... ok

test result: ok. 10 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

     Running tests/fixture_composition.rs (glade/contracts/target/debug/deps/fixture_composition-65d2eb16df52c7d1)

running 7 tests
test historical_prior_cut_fixture_registers_multiline_inspect_through_full_helper ... ok
test configured_provider_matches_core_cut_and_changes_independently ... ok
test mandatory_text_replica_journeys_do_not_construct_fresh_host_per_drive_call ... ok
test lookup_fixture_owns_full_request_and_bounded_history_not_only_secondary_index ... ok
test trusted_seed_retains_reservations_outcomes_and_rejects_inconsistent_history ... ok
test seeded_terminal_requires_original_custody_and_accounting ... ok
test seeded_custody_is_explicit_and_consecutive_port_publications_keep_history ... ok

test result: ok. 7 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/kernel_edges.rs (glade/contracts/target/debug/deps/kernel_edges-0e6067bcb16c3e14)

running 21 tests
test admission::retained_candidates_and_verifications_share_pending_capacity ... ok
test admission::pending_origins_reserve_the_origin_limit_before_verification ... ok
test encoder::storage_batch_limit_refuses_before_any_prepare_or_invocation ... ok
test admission::restored_fork_cut_derives_one_coherent_quarantine_and_eligible_set ... ok
test admission::oversized_proof_cannot_allocate_a_verification_continuation ... ok
test admission::outstanding_verification_prevents_complete_local_and_is_bounded ... ok
test frontier::frontier_union_cannot_exceed_pending_items_or_clear_previous_observation ... ok
test frontier::already_retained_exact_frontier_hash_preserves_complete_local ... ok
test frontier::empty_peer_frontier_offers_all_local_history ... ok
test admission::committed_local_custody_retains_the_actual_seal_named_by_original_receipt ... ok
test admission::signed_historical_rival_outside_permit_sequence_is_security_not_conviction ... ok
test encoder::full_encoded_continuation_footprint_consumes_edit_quota ... ok
test storage::lost_prepare_ack_can_recover_original_plan_while_original_invocation_is_live ... ok
test frontier::announced_missing_frontier_survives_unrelated_publication ... ok
test encoder::unretained_historical_batch_due_to_encoder_limit_is_sticky_incomplete ... ok
test admission::signed_invalid_payload_is_security_custody_without_conviction ... ok
test storage::prepare_request_from_retained_old_owner_has_no_current_callback_authority ... ok
test admission::no_prior_admission_local_intent_keeps_real_seal_for_historical_replay ... ok
test storage::prepared_reply_cannot_replace_original_attempt_mapping ... ok
test frontier::different_arriving_hash_cannot_complete_an_announced_missing_slot ... ok
test encoder::encoder_is_deterministic_and_binds_descriptor_facts_and_seal_continuations ... ok

test result: ok. 21 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

     Running tests/records_host_contract.rs (glade/contracts/target/debug/deps/records_host_contract-377bbaa390d43bf2)

running 22 tests
test icd006_delayed_prior_cut_committed_callback_retains_historical_admission ... ok
test icd004_same_display_names_do_not_share_instance_rights_or_callbacks ... ok
test icd006_historical_authorization_is_separate_from_current_revocation ... ok
test icd006_stale_verification_after_policy_change_cannot_seal_or_commit ... ok
test icd003_legacy_and_strong_descriptors_do_not_activate_independent_admission ... ok
test icd007_zero_base_prev_refs_and_exact_safe_numbers ... ok
test icd002_partitioned_admission_commits_without_a_holder ... ok
test icd007_reused_canonical_origin_and_numeric_overflow_refuse ... ok
test icd005_evidence_reply_binds_mode_bytes_scope_and_candidate ... ok
test icd007_new_epoch_uses_new_origin_and_old_retries_stay_old ... ok
test icd006_offline_window_and_clock_uncertainty_refuse_new_intent ... ok
test icd010_old_receipt_retry_does_not_reauthorize_or_reappend ... ok
test icd010_lookup_recovery_binds_request_and_restores_original_receipt ... ok
test icd008_successor_requests_predecessor_without_advancing_head ... ok
test icd010_unknown_commit_retains_reservation_and_foreign_callback_cannot_accept ... ok
test icd013_recovery_exhaustion_is_explicit_and_cannot_spend_edit_budget ... ok
test icd013_edit_capacity_preserves_recovery_reserves ... ok
test icd010_commit_callbacks_bind_batch_revision_and_have_three_distinct_outcomes ... ok
test prior_cut_inspect40_distinguishes_issued_authority_from_identical_unissued_reply ... ok
test icd009_qualified_dependent_custody_survives_quarantined_support_but_local_intent_refuses ... ok
test icd006_revoked_expired_unadmitted_rival_preserves_ad_and_receipts ... ok
test icd009_two_qualified_rivals_quarantine_both_and_dependents_in_either_order ... ok

test result: ok. 22 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

     Running tests/recovery_contract.rs (glade/contracts/target/debug/deps/recovery_contract-8cab13edcccedff2)

running 6 tests
test lookup_invocation_counter_exhaustion_refuses_without_wrap_or_reservation_loss ... ok
test trusted_restoration_invalidates_live_lookup_and_preserves_identity_high_water ... ok
test retention_committed_lookup_binds_batch_storage_revision_and_empty_receipts ... ok
test repeated_unknown_lookup_retires_invocation_and_old_replies_preserve_new_lookup ... ok
test genuine_e0_fork_then_fresh_e1_local_recovery_keeps_ab_and_old_receipts_both_orders ... ok
test every_atomic_kind_recovers_committed_absent_and_unknown_without_fake_admission ... ok

test result: ok. 6 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

     Running tests/remediation1.rs (glade/contracts/target/debug/deps/remediation1-be8535f3fccf7f31)

running 16 tests
test frontier::frontier_bytes_include_existing_candidate_charge_and_parked_verification ... ok
test frontier::frontier_retained_slot_aggregate_bytes_exact_boundary_and_one_over ... ok
test pending::frontier_cannot_steal_slots_reserved_by_an_unpublished_candidate_plan ... ok
test exhaustion::local_intent_counter_refusal_alone_does_not_taint_known_history ... ok
test frontier::frontier_names_empty_exact_limit_over_limit_and_huge_are_bounded ... ok
test pending::prospective_two_missing_slots_refuse_before_emission_or_candidate_staging ... ok
test pending::predecessor_and_ref_to_the_same_missing_slot_emit_one_request ... ok
test exhaustion::historical_query_exhaustion_remains_sticky_through_resume_restore ... ok
test exhaustion::historical_plan_exhaustion_remains_sticky_through_resume_restore ... ok
test pending::multiple_candidates_and_frontier_slots_share_deduplicated_prospective_cap ... ok
test terminal::late_pending_and_refused_never_reopen_an_authentic_terminal ... ok
test integrity::already_qualified_fork_cannot_stage_new_work_after_stop ... ok
test pending::exact_slot_limit_and_overlap_union_commit_without_duplicate_reservations ... ok
test integrity::integrity_stop_preserves_owned_started_attempt_and_genuine_late_commit ... ok
test integrity::parked_verification_and_seal_cannot_create_new_work_after_authenticated_stop ... ok
test terminal::held_started_and_terminal_inspect_both_orders_all_four_kinds_and_outcomes ... ok

test result: ok. 16 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

     Running tests/remediation2.rs (glade/contracts/target/debug/deps/remediation2-c6ddfa10c99b9612)

running 3 tests
test two_issued_queries_verified_historical_b_during_held_started_a_is_explicitly_incomplete ... ok
test fresh_historical_offer_during_held_started_a_is_explicitly_incomplete ... ok
test local_intent_only_busy_refusal_does_not_taint_known_history ... ok

test result: ok. 3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

     Running tests/representation.rs (glade/contracts/target/debug/deps/representation-b4c77cef7d79e0fa)

running 2 tests
test operation_bytes_and_digest_are_derived_and_owned ... ok
test pure_step_is_deterministic_preserves_caller_input_and_read_only_state ... ok

test result: ok. 2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/source_boundaries.rs (glade/contracts/target/debug/deps/source_boundaries-cfcb6000711a5cc4)

running 4 tests
test ic3_data_boundary_is_independent_of_the_pure_algorithm ... ok
test checks_disabled_branch_instead_of_skipping_cfg ... ok
test disabled_associated_foreign_and_field_declarations_are_checked ... ok
test tranche_sources_have_explicit_conditional_boundaries ... ok

test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.12s

     Running tests/storage_attempt_contract.rs (glade/contracts/target/debug/deps/storage_attempt_contract-a98f1e5df7b04b9e)

running 15 tests
test sta006_current_prestart_observation_emits_fence_without_erasing_plan ... ok
test issued_lookup_retains_full_request_on_consumption ... ok
test sta009_restored_attempt_and_invocation_floors_preserve_pending ... ok
test sta008_critical_pending_does_not_release_semantic_reservation ... ok
test sta005_contradictory_terminal_stops_instance_after_once_only_installation ... ok
test sta001_callback_complete_binding_and_finite_invocation_namespace ... ok
test identical_unissued_lookup_reply_cannot_acquire_callback_authority ... ok
test sta005_unissued_foreign_or_changed_retired_callback_cannot_create_integrity_stop ... ok
test sta002_kernel_prepare_keeps_exact_plan_after_lost_ack ... ok
test sta003_pending_lookup_retains_started_write_until_late_commit_all_kinds ... ok
test sta010_overflow_is_sticky_distinct_from_charges_and_partial_repair ... ok
test sta004_noncommit_retains_tombstone_and_rescheduling_uses_fresh_plan ... ok
test sta007_all_kinds_install_original_terminal_without_double_charge ... ok
test sta011_driver_uses_caller_owned_session_across_continuations ... ok
test sta011_existing_twenty_seven_and_text_consumers_keep_actual_port_path ... ok

test result: ok. 15 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running unittests src/lib.rs (glade/contracts/target/debug/deps/glade_crdt_admission_data-829261682f5780f4)

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/representation.rs (glade/contracts/target/debug/deps/representation-a11dd961075c09ca)

running 1 test
test canonical_operation_owns_bytes_and_recomputes_digest ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/source_boundaries.rs (glade/contracts/target/debug/deps/source_boundaries-15d7213681b61363)

running 3 tests
test checks_disabled_branch_instead_of_skipping_cfg ... ok
test disabled_associated_foreign_and_field_declarations_are_checked ... ok
test tranche_sources_have_explicit_conditional_boundaries ... ok

test result: ok. 3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

     Running unittests src/lib.rs (glade/contracts/target/debug/deps/glade_crdt_evidence_api-0ab689c801ef5981)

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/public_contract.rs (glade/contracts/target/debug/deps/public_contract-a450847ecdbb9cfb)

running 2 tests
test concrete_provider_must_supply_all_three_trusted_operations ... ok
test required_evidence_methods_have_no_default_provider ... ok

test result: ok. 2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/source_boundaries.rs (glade/contracts/target/debug/deps/source_boundaries-d9ef5b5c6b238cc5)

running 3 tests
test checks_disabled_branch_instead_of_skipping_cfg ... ok
test disabled_associated_foreign_and_field_declarations_are_checked ... ok
test tranche_sources_have_explicit_conditional_boundaries ... ok

test result: ok. 3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

     Running unittests src/lib.rs (glade/contracts/target/debug/deps/glade_crdt_recovery_api-86172c5c56e8b27f)

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/public_contract.rs (glade/contracts/target/debug/deps/public_contract-5bc6e82aa5aa7537)

running 7 tests
test issued_guard_identity_is_not_reissued_by_same_session ... ok
test issuer_capacity_is_finite_and_retirement_does_not_reissue_history ... ok
test live_never_started_owned_guard_can_abandon_only_once ... ok
test another_authority_refuses_before_constructing_or_consuming_future ... ok
test abandoned_capability_cannot_start_work_again ... ok
test cancelled_started_async_receive_does_not_imply_drain_or_abandon ... ok
test owned_receive_drains_before_settlement_and_close ... ok

test result: ok. 7 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/source_boundaries.rs (glade/contracts/target/debug/deps/source_boundaries-d87c63d050de1dbe)

running 4 tests
test checks_disabled_branch_instead_of_skipping_cfg ... ok
test disabled_associated_foreign_and_field_declarations_are_checked ... ok
test tranche_sources_have_explicit_conditional_boundaries ... ok
test actual_node_independent_subtree_and_disabled_branches_are_checked ... ok

test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.02s

     Running unittests src/lib.rs (glade/contracts/target/debug/deps/glade_crdt_recovery_codec-249926a6c91406e4)

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/batch_decode.rs (glade/contracts/target/debug/deps/batch_decode-c338073ef4bd3146)

running 3 tests
test unchanged_private_encoder_has_a_complete_bounded_decoder ... ok
test batch_operations_share_the_existing_aggregate_item_budget ... ok
test interned_blob_references_cannot_amplify_owned_decoding_past_budget ... ok

test result: ok. 3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/image.rs (glade/contracts/target/debug/deps/image-ff97efb1b877942d)

running 4 tests
test interrupted_intent_preserves_issuance_and_guard_floors_without_next_image ... ok
test full_image_retains_all_kernel_callbacks_attempts_guards_issuance_and_loss ... ok
test image_hash_and_external_selection_do_not_require_a_hash_fixed_point ... ok
test corrupt_truncated_trailing_unknown_versions_and_capacity_fail_closed ... ok

test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.12s

     Running tests/remediation1.rs (glade/contracts/target/debug/deps/remediation1-4606bedf9a4f1344)

running 6 tests
test root_operation_depth_includes_the_embedded_interpretation_boundary ... ok
test root_operation_name_limit_applies_inside_opaque_canonical_bytes ... ok
test root_operation_item_budget_includes_interpreted_refs_cumulatively ... ok
test nested_candidate_and_remote_transfer_cannot_hide_operation_name ... ok
test repeated_nested_operations_share_one_budget_not_one_budget_each ... ok
test concrete_container_roots_cannot_substitute_plan_for_guard ... ok

test result: ok. 6 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/roundtrip.rs (glade/contracts/target/debug/deps/roundtrip-afbf6185948b82a4)

running 6 tests
test accepted_signature_domains_are_full_and_zero_terminated ... ok
test type_domain_cannot_substitute_plan_identity_for_receive_guard ... ok
test remote_profile_is_exact_canonical_integer_key_map_without_recovery_magic ... ok
test inventory_empty_is_exact_observation_not_a_completeness_claim ... ok
test identity_roundtrip_preserves_full_namespaces_and_unsigned_floor ... ok
test proof_body_requires_exact_purpose_version_signature_shape_and_type ... ok

test result: ok. 6 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/source_boundaries.rs (glade/contracts/target/debug/deps/source_boundaries-b49e6bf7138dd73f)

running 3 tests
test checks_disabled_branch_instead_of_skipping_cfg ... ok
test disabled_associated_foreign_and_field_declarations_are_checked ... ok
test tranche_sources_have_explicit_conditional_boundaries ... ok

test result: ok. 3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.06s

     Running tests/vectors.rs (glade/contracts/target/debug/deps/vectors-e6054aa97de7077a)

running 4 tests
test closed_maps_reject_unknown_duplicate_reordered_or_wrong_context_fields ... ok
test malformed_signature_length_and_wrong_exact_domain_refuse_signed_envelope_shape ... ok
test bounded_malformed_canonical_vectors_fail_closed ... ok
test all_remote_profile_categories_derive_exact_bytes_and_digests_from_semantic_inputs ... ok

test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

     Running unittests src/lib.rs (glade/contracts/target/debug/deps/glade_crdt_storage_attempt_api-183ed550d5084400)

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/conformance_mutants.rs (glade/contracts/target/debug/deps/conformance_mutants-62cbd41425c44fca)

running 1 test
test shared_public_port_probe_accepts_fixture_and_rejects_six_semantic_mutants ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/public_contract.rs (glade/contracts/target/debug/deps/public_contract-5dd65e92533e6d9b)

running 28 tests
test finite_attempt_invocation_and_name_bounds_refuse_without_wrap ... ok
test restoration_rejects_corrupt_cardinality_floor_and_history_limit ... ok
test host_serialized_observation_cannot_be_replaced_by_caller_current_claim ... ok
test historical_accepted_batch_keeps_original_receipt_without_local_prestart ... ok
test restored_capacity_and_binding_phase_consistency_are_validated ... ok
test lost_prepare_ack_and_queued_late_prepare_recover_exactly_one_attempt ... ok
test restored_started_and_committed_cuts_must_fit_their_immutable_windows ... ok
test restored_noncommit_must_retain_its_bindings_unchanged_revision ... ok
test authentic_two_commit_recovery_rejects_distinct_duplicate_revision ... ok
test full_retained_commit_history_rejects_missing_head_gaps_and_unbacked_current_revision ... ok
test sta001_exact_binding_exhaustion_and_invocation_identity ... ok
test sta002_exact_plan_dedup_no_overlap_and_independent_instances ... ok
test restoration_rejects_identity_and_unresolved_overlap_but_keeps_history_and_y ... ok
test sta005_commit_wins_fence_race_and_receipts_are_original ... ok
test sequential_commits_repeated_noncommit_and_independent_revision_spaces_restore ... ok
test sta004_fence_excludes_late_begin_and_reprepare_uses_new_identity ... ok
test sta003_absent_terminal_is_pending_for_all_kinds ... ok
test sta007_retention_receipts_cannot_be_synthetic ... ok
test sta006_prestart_checks_entire_window_and_historical_has_no_current_admit_check ... ok
test sta008_critical_reserve_exhaustion_cannot_manufacture_negative_finality ... ok
test sta009_exclusive_recovery_and_close_keep_issuance_floors ... ok
test started_cut_is_not_rechecked_after_revocation_or_delayed_begin_ack ... ok
test started_absent_lookup_late_publication_and_fence_use_same_predicate ... ok
test trusted_observation_injection_has_finite_instance_and_name_bounds ... ok
test validated_restore_retains_all_attempts_and_invocation_namespace_without_auto_commit ... ok
test sparse_invocation_restore_preserves_actual_remaining_capacity ... ok
test reopen_validates_retained_consumption_before_changing_owner_or_floors ... ok
test fresh_revision_mismatch_refuses_before_reserved_or_queued_for_every_kind ... ok

test result: ok. 28 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/source_boundaries.rs (glade/contracts/target/debug/deps/source_boundaries-625bf4e5641d0a44)

running 5 tests
test checks_disabled_branch_instead_of_skipping_cfg ... ok
test rejects_missing_identity_callback_ownership_and_terminality_fields ... ok
test disabled_associated_foreign_and_field_declarations_are_checked ... ok
test actual_port_preserves_required_boundary_shape ... ok
test tranche_sources_have_explicit_conditional_boundaries ... ok

test result: ok. 5 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.04s

   Doc-tests glade_crdt_admission_core

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

   Doc-tests glade_crdt_admission_data

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

   Doc-tests glade_crdt_evidence_api

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

   Doc-tests glade_crdt_recovery_api

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

   Doc-tests glade_crdt_recovery_codec

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

   Doc-tests glade_crdt_storage_attempt_api

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

    Finished `dev` profile [unoptimized + debuginfo] target(s) in 0.06s

```

## B1 affected node assembly consumers
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'node_assembly']
Exit: 0; wall: 9.907s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 9.10s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-022b56b7ae6ded8d)

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 364 filtered out; finished in 0.00s


```

## B1 pinned signer consumer
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'signing::tests']
Exit: 0; wall: 8.771s
```text
    Blocking waiting for file lock on build directory
    Finished `test` profile [unoptimized + debuginfo] target(s) in 8.00s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-022b56b7ae6ded8d)

running 3 tests
test signing::tests::a_signature_is_pure_ed25519_over_the_tag_then_the_message ... ok
test signing::tests::a_small_order_id_signs_nothing ... ok
test signing::tests::no_tag_is_a_prefix_of_another ... ok

test result: ok. 3 passed; 0 failed; 0 ignored; 0 measured; 361 filtered out; finished in 0.00s


```

## B1 node clippy scoped affected provider
Command: ['cargo', 'clippy', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', '--test', 'ic3_auth', '--', '-D', 'warnings']
Exit: 101; wall: 8.814s
```text
    Blocking waiting for file lock on build directory
    Checking glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
error: this can be `std::io::Error::other(_)`
   --> src/claims.rs:138:5
    |
138 |     io::Error::new(io::ErrorKind::Other, e)
    |     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    |
    = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
    = note: `-D clippy::io-other-error` implied by `-D warnings`
    = help: to override `-D warnings` add `#[allow(clippy::io_other_error)]`
help: use `std::io::Error::other`
    |
138 -     io::Error::new(io::ErrorKind::Other, e)
138 +     io::Error::other(e)
    |

error: this can be `std::io::Error::other(_)`
  --> src/exchange.rs:53:5
   |
53 |     io::Error::new(io::ErrorKind::Other, e)
   |     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
   |
   = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
help: use `std::io::Error::other`
   |
53 -     io::Error::new(io::ErrorKind::Other, e)
53 +     io::Error::other(e)
   |

error: this can be `std::io::Error::other(_)`
  --> src/iroh_carrier.rs:68:5
   |
68 |     io::Error::new(io::ErrorKind::Other, e)
   |     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
   |
   = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
help: use `std::io::Error::other`
   |
68 -     io::Error::new(io::ErrorKind::Other, e)
68 +     io::Error::other(e)
   |

error: this can be `std::io::Error::other(_)`
  --> src/mesh.rs:63:5
   |
63 |     io::Error::new(io::ErrorKind::Other, e)
   |     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
   |
   = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
help: use `std::io::Error::other`
   |
63 -     io::Error::new(io::ErrorKind::Other, e)
63 +     io::Error::other(e)
   |

error: this can be `std::io::Error::other(_)`
   --> src/server.rs:458:18
    |
458 |         other => std::io::Error::new(std::io::ErrorKind::Other, format!("{other:?}")),
    |                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    |
    = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
help: use `std::io::Error::other`
    |
458 -         other => std::io::Error::new(std::io::ErrorKind::Other, format!("{other:?}")),
458 +         other => std::io::Error::other(format!("{other:?}")),
    |

error: doc list item without indentation
 --> src/ws.rs:3:5
  |
3 | //! (which is text-only) for **binary** frames: glade carries CBOR, not text.
  |     ^
  |
  = help: if this is supposed to be its own paragraph, add a blank line
  = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#doc_lazy_continuation
  = note: `-D clippy::doc-lazy-continuation` implied by `-D warnings`
  = help: to override `-D warnings` add `#[allow(clippy::doc_lazy_continuation)]`
help: indent this line
  |
3 | //!   (which is text-only) for **binary** frames: glade carries CBOR, not text.
  |     ++

error: doc list item without indentation
 --> src/ws.rs:4:5
  |
4 | //! Enough to talk to a browser/Node WebSocket: the upgrade handshake, masked
  |     ^
  |
  = help: if this is supposed to be its own paragraph, add a blank line
  = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#doc_lazy_continuation
help: indent this line
  |
4 | //!   Enough to talk to a browser/Node WebSocket: the upgrade handshake, masked
  |     ++

error: doc list item without indentation
 --> src/ws.rs:5:5
  |
5 | //! client->server and unmasked server->client binary frames; close surfaced;
  |     ^
  |
  = help: if this is supposed to be its own paragraph, add a blank line
  = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#doc_lazy_continuation
help: indent this line
  |
5 | //!   client->server and unmasked server->client binary frames; close surfaced;
  |     ++

error: doc list item without indentation
 --> src/ws.rs:6:5
  |
6 | //! ping/pong skipped (trusted localhost).
  |     ^
  |
  = help: if this is supposed to be its own paragraph, add a blank line
  = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#doc_lazy_continuation
help: indent this line
  |
6 | //!   ping/pong skipped (trusted localhost).
  |     ++

error: could not compile `glade-node` (lib) due to 9 previous errors

```

## B1 actual released text consumer current scoped rows
Command: ['node', '--experimental-transform-types', 'glade/node/tests/ic3_text_consumer.mjs', '/Volumes/projects/limbo/glade-wz/glial/src/text_crdt.ts']
Exit: 0; wall: 0.081s
```text
Actual released Glial text decoder: 32 shared rows PASS
(node:32100) ExperimentalWarning: Transform Types is an experimental feature and might change at any time
(Use `node --trace-warnings ...` to show where the warning was created)

```

## B1 preserved strict remote prerequisite refusal
Command: ['sh', 'glade/contracts/crdt-recovery-codec/check-vectors.sh', '--pre-remote']
Exit: 1; wall: 0.422s
```text
Traceback (most recent call last):
  File "/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-codec/compat/gate.py", line 106, in <module>
    validate(Path(sys.argv[1]), strict=strict)
  File "/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-codec/compat/gate.py", line 53, in validate
    validate_remote(root, pins)
  File "/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-codec/compat/gate.py", line 84, in validate_remote
    raise ValueError("genuine B1 crypto qualification absent")
ValueError: genuine B1 crypto qualification absent

```

## B1 actual assembly affected consumer target after zero-selection correction
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'assembly']
Exit: 0; wall: 1.762s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 1.03s
     Running tests/assembly/main.rs (glade/node/target/debug/deps/assembly-025321a5b5fa040f)

running 30 tests
test conformance::cl_002_the_fake_clock_reads_epoch_milliseconds ... ok
test conformance::cl_002_the_system_clock_reads_epoch_milliseconds ... ok
test conformance::cl_001_the_fake_clock_is_one_instant_behind_every_handle ... ok
test conformance::gr_002_in_the_in_memory_fold_revocation_wins_in_either_order ... ok
test conformance::gr_003_an_unreadable_in_memory_fold_is_unavailable ... ok
test conformance::gr_001_the_in_memory_fold_matches_exactly ... ok
test conformance::gr_003_the_grant_fold_the_module_builds_is_unavailable ... ok
test conformance::si_001_the_keyed_test_signer_round_trips_every_purpose ... ok
test conformance::si_002_the_keyed_test_signer_binds_bytes_purpose_and_signer ... ok
test conformance::si_003_the_keyed_test_signer_refuses_without_key_material ... ok
test conformance::ca_003_the_fake_networks_futures_are_lazy_and_recv_is_cancel_safe ... ok
test conformance::ca_002_the_fake_network_holds_the_frame_limit_both_ways ... ok
test conformance::ca_005_the_fake_network_names_each_far_end ... ok
test conformance::si_003_the_node_signer_without_a_key_refuses_both_ways ... ok
test conformance::ca_004_a_fake_port_gives_its_endpoint_up_by_value ... ok
test conformance::ca_001_the_fake_network_carries_frames_whole_once_and_in_order ... ok
test conformance::ca_006_the_fake_network_binds_each_link_to_its_session ... ok
test one_scope_hands_out_one_occurrence_of_every_binding ... ok
test one_grant_selection_reaches_admission ... ok
test each_carrier_role_is_its_own_occurrence_and_the_record_transport_rides_the_peer_one ... ok
test a_test_composition_constructs_no_real_provider ... ok
test the_directory_profile_hosts_every_directory_record_kind_and_nothing_else ... ok
test conformance::si_002_the_node_signer_binds_bytes_purpose_and_signer ... ok
test a_concurrent_first_access_of_a_lazy_binding_constructs_once_per_scope ... ok
test records_refuse_an_op_outside_the_directory_profile_before_verifying_it ... ok
test conformance::si_001_the_node_signer_round_trips_every_purpose ... ok
test one_clock_substitution_reaches_the_directory_and_admission ... ok
test sibling_scopes_share_nothing_and_meet_only_through_the_network ... ok
test conformance::gr_001_to_003_the_nodes_grant_fold_keeps_the_grant_contract ... ok
test one_record_host_selection_reaches_the_directory ... ok

test result: ok. 30 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s


```

## B1 clippy diagnostic enumeration retaining nine baseline errors
Command: ['cargo', 'clippy', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', '--test', 'ic3_auth']
Exit: 0; wall: 2.034s
```text
    Checking glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
warning: this can be `std::io::Error::other(_)`
   --> src/claims.rs:138:5
    |
138 |     io::Error::new(io::ErrorKind::Other, e)
    |     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    |
    = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
    = note: `#[warn(clippy::io_other_error)]` on by default
help: use `std::io::Error::other`
    |
138 -     io::Error::new(io::ErrorKind::Other, e)
138 +     io::Error::other(e)
    |

warning: this can be `std::io::Error::other(_)`
  --> src/exchange.rs:53:5
   |
53 |     io::Error::new(io::ErrorKind::Other, e)
   |     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
   |
   = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
help: use `std::io::Error::other`
   |
53 -     io::Error::new(io::ErrorKind::Other, e)
53 +     io::Error::other(e)
   |

warning: this can be `std::io::Error::other(_)`
  --> src/iroh_carrier.rs:68:5
   |
68 |     io::Error::new(io::ErrorKind::Other, e)
   |     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
   |
   = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
help: use `std::io::Error::other`
   |
68 -     io::Error::new(io::ErrorKind::Other, e)
68 +     io::Error::other(e)
   |

warning: this can be `std::io::Error::other(_)`
  --> src/mesh.rs:63:5
   |
63 |     io::Error::new(io::ErrorKind::Other, e)
   |     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
   |
   = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
help: use `std::io::Error::other`
   |
63 -     io::Error::new(io::ErrorKind::Other, e)
63 +     io::Error::other(e)
   |

warning: this can be `std::io::Error::other(_)`
   --> src/server.rs:458:18
    |
458 |         other => std::io::Error::new(std::io::ErrorKind::Other, format!("{other:?}")),
    |                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    |
    = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
help: use `std::io::Error::other`
    |
458 -         other => std::io::Error::new(std::io::ErrorKind::Other, format!("{other:?}")),
458 +         other => std::io::Error::other(format!("{other:?}")),
    |

warning: doc list item without indentation
 --> src/ws.rs:3:5
  |
3 | //! (which is text-only) for **binary** frames: glade carries CBOR, not text.
  |     ^
  |
  = help: if this is supposed to be its own paragraph, add a blank line
  = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#doc_lazy_continuation
  = note: `#[warn(clippy::doc_lazy_continuation)]` on by default
help: indent this line
  |
3 | //!   (which is text-only) for **binary** frames: glade carries CBOR, not text.
  |     ++

warning: doc list item without indentation
 --> src/ws.rs:4:5
  |
4 | //! Enough to talk to a browser/Node WebSocket: the upgrade handshake, masked
  |     ^
  |
  = help: if this is supposed to be its own paragraph, add a blank line
  = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#doc_lazy_continuation
help: indent this line
  |
4 | //!   Enough to talk to a browser/Node WebSocket: the upgrade handshake, masked
  |     ++

warning: doc list item without indentation
 --> src/ws.rs:5:5
  |
5 | //! client->server and unmasked server->client binary frames; close surfaced;
  |     ^
  |
  = help: if this is supposed to be its own paragraph, add a blank line
  = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#doc_lazy_continuation
help: indent this line
  |
5 | //!   client->server and unmasked server->client binary frames; close surfaced;
  |     ++

warning: doc list item without indentation
 --> src/ws.rs:6:5
  |
6 | //! ping/pong skipped (trusted localhost).
  |     ^
  |
  = help: if this is supposed to be its own paragraph, add a blank line
  = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#doc_lazy_continuation
help: indent this line
  |
6 | //!   ping/pong skipped (trusted localhost).
  |     ++

warning: `glade-node` (lib) generated 9 warnings (run `cargo clippy --fix --lib -p glade-node -- ` to apply 5 suggestions)
warning: for loop over a single element
   --> tests/ic3_auth.rs:410:5
    |
410 | /     for payload in [br#"{"atom_id":42,"atom_id":"a","kind":"delete"}"#.as_slice()] {
411 | |         let mut q = f.query.clone();
412 | |         let mut op = q.operation.inner().clone();
413 | |         op.payload = payload.to_vec();
...   |
436 | |         );
437 | |     }
    | |_____^
    |
    = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#single_element_loop
    = note: `#[warn(clippy::single_element_loop)]` on by default
help: try
    |
410 ~     {
411 +         let payload = br#"{"atom_id":42,"atom_id":"a","kind":"delete"}"#.as_slice();
412 +         let mut q = f.query.clone();
413 +         let mut op = q.operation.inner().clone();
414 +         op.payload = payload.to_vec();
415 +         q.operation = Operation::new(op);
416 +         q.evidence = Fixture::proofs(
417 +             &q.instance,
418 +             &f.identity,
419 +             &q.descriptor,
420 +             &f.certificate,
421 +             &f.policy,
422 +             &q.operation,
423 +             Some((glade_node::signing::public_key(&NODE), &NODE)),
424 +         );
425 +         let Verdict::Verified(facts) = provider(&f)
426 +             .verify(BoundQuery {
427 +                 query: q,
428 +                 identity: f.identity.clone(),
429 +             })
430 +             .verdict
431 +         else {
432 +             panic!("authenticated profile edit")
433 +         };
434 +         assert!(
435 +             facts.payload_valid,
436 +             "released JSON.parse duplicate-property behavior must be retained"
437 +         );
438 +     }
    |

warning: `glade-node` (test "ic3_auth") generated 1 warning (run `cargo clippy --fix --test "ic3_auth" -p glade-node -- ` to apply 1 suggestion)
    Finished `dev` profile [unoptimized + debuginfo] target(s) in 1.96s

```

## B1 final scoped warning correction provider
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_auth']
Exit: 0; wall: 1.143s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.62s
     Running tests/ic3_auth.rs (glade/node/target/debug/deps/ic3_auth-d29f661d7892e84b)

running 16 tests
test ic3_auth_extra::strict_ed25519_refuses_small_order_writer_and_changed_domain ... ok
test root_signature_does_not_authorize_an_unsupported_merge_corpus ... ok
test genuine_overlimit_operation_is_refused_before_payload_interpretation ... ok
test provider_observation_is_genuine_current_signed_policy_and_owned_clock ... ok
test genuine_historical_admission_verifies_exact_scoped_signed_records ... ok
test every_local_verification_requires_new_possession_not_operation_cache_reuse ... ok
test released_payload_duplicate_properties_remain_supported ... ok
test bad_signature_wrong_domain_or_altered_namespace_are_invalid ... ok
test ic3_auth_extra::distinct_fresh_origin_qualifies_but_reused_origin_epoch_or_issuance_refuses ... ok
test ic3_auth_extra::bare_signed_rival_does_not_convict_but_original_signed_admission_qualifies ... ok
test signed_invalid_payload_is_authenticated_security_data_not_qualified_admission ... ok
test trusted_source_cannot_regress_observed_clock_or_policy_floor ... ok
test local_possession_seal_and_foreign_or_replayed_session_controls ... ok
test ic3_auth_extra::all_evidence_layers_reject_validly_signed_changed_bindings_or_wrong_keys ... ok
test uncertain_expired_or_revoked_current_cut_does_not_change_historical_validity ... ok
test genuine_provider_matches_shared_released_text_syntax_rows ... ok

test result: ok. 16 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.05s


```

## B1 final new source warning census with retained baseline
Command: ['cargo', 'clippy', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', '--test', 'ic3_auth']
Exit: 0; wall: 0.327s
```text
warning: this can be `std::io::Error::other(_)`
   --> src/claims.rs:138:5
    |
138 |     io::Error::new(io::ErrorKind::Other, e)
    |     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    |
    = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
    = note: `#[warn(clippy::io_other_error)]` on by default
help: use `std::io::Error::other`
    |
138 -     io::Error::new(io::ErrorKind::Other, e)
138 +     io::Error::other(e)
    |

warning: this can be `std::io::Error::other(_)`
  --> src/exchange.rs:53:5
   |
53 |     io::Error::new(io::ErrorKind::Other, e)
   |     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
   |
   = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
help: use `std::io::Error::other`
   |
53 -     io::Error::new(io::ErrorKind::Other, e)
53 +     io::Error::other(e)
   |

warning: this can be `std::io::Error::other(_)`
  --> src/iroh_carrier.rs:68:5
   |
68 |     io::Error::new(io::ErrorKind::Other, e)
   |     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
   |
   = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
help: use `std::io::Error::other`
   |
68 -     io::Error::new(io::ErrorKind::Other, e)
68 +     io::Error::other(e)
   |

warning: this can be `std::io::Error::other(_)`
  --> src/mesh.rs:63:5
   |
63 |     io::Error::new(io::ErrorKind::Other, e)
   |     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
   |
   = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
help: use `std::io::Error::other`
   |
63 -     io::Error::new(io::ErrorKind::Other, e)
63 +     io::Error::other(e)
   |

warning: this can be `std::io::Error::other(_)`
   --> src/server.rs:458:18
    |
458 |         other => std::io::Error::new(std::io::ErrorKind::Other, format!("{other:?}")),
    |                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    |
    = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
help: use `std::io::Error::other`
    |
458 -         other => std::io::Error::new(std::io::ErrorKind::Other, format!("{other:?}")),
458 +         other => std::io::Error::other(format!("{other:?}")),
    |

warning: doc list item without indentation
 --> src/ws.rs:3:5
  |
3 | //! (which is text-only) for **binary** frames: glade carries CBOR, not text.
  |     ^
  |
  = help: if this is supposed to be its own paragraph, add a blank line
  = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#doc_lazy_continuation
  = note: `#[warn(clippy::doc_lazy_continuation)]` on by default
help: indent this line
  |
3 | //!   (which is text-only) for **binary** frames: glade carries CBOR, not text.
  |     ++

warning: doc list item without indentation
 --> src/ws.rs:4:5
  |
4 | //! Enough to talk to a browser/Node WebSocket: the upgrade handshake, masked
  |     ^
  |
  = help: if this is supposed to be its own paragraph, add a blank line
  = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#doc_lazy_continuation
help: indent this line
  |
4 | //!   Enough to talk to a browser/Node WebSocket: the upgrade handshake, masked
  |     ++

warning: doc list item without indentation
 --> src/ws.rs:5:5
  |
5 | //! client->server and unmasked server->client binary frames; close surfaced;
  |     ^
  |
  = help: if this is supposed to be its own paragraph, add a blank line
  = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#doc_lazy_continuation
help: indent this line
  |
5 | //!   client->server and unmasked server->client binary frames; close surfaced;
  |     ++

warning: doc list item without indentation
 --> src/ws.rs:6:5
  |
6 | //! ping/pong skipped (trusted localhost).
  |     ^
  |
  = help: if this is supposed to be its own paragraph, add a blank line
  = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#doc_lazy_continuation
help: indent this line
  |
6 | //!   ping/pong skipped (trusted localhost).
  |     ++

warning: `glade-node` (lib) generated 9 warnings (run `cargo clippy --fix --lib -p glade-node -- ` to apply 5 suggestions)
    Checking glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `dev` profile [unoptimized + debuginfo] target(s) in 0.27s

```

## B1 final affected Rust formatting
Command: ['rustfmt', '--check', '--edition', '2024', 'glade/node/src/independent/mod.rs', 'glade/node/tests/ic3_auth.rs']
Exit: 0; wall: 0.043s
```text

```

## B2 preserve actual legacy executable before physical source changes
Command: ['cargo', 'build', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--bin', 'glade-node']
Exit: 0; wall: 6.277s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `dev` profile [unoptimized + debuginfo] target(s) in 6.24s

```

## B2 physical root foundation compiling behavioral RED
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'independent::disk::tests::fresh_layout_has_stable_exclusive_custody_and_legacy_refusal_marker']
Exit: 101; wall: 8.945s
```text
    Blocking waiting for file lock on build directory
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 8.09s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-022b56b7ae6ded8d)

running 1 test
test independent::disk::tests::fresh_layout_has_stable_exclusive_custody_and_legacy_refusal_marker ... FAILED

failures:

---- independent::disk::tests::fresh_layout_has_stable_exclusive_custody_and_legacy_refusal_marker stdout ----

thread 'independent::disk::tests::fresh_layout_has_stable_exclusive_custody_and_legacy_refusal_marker' (171931536) panicked at src/independent/disk.rs:33:14:
fresh physical layout obtains actual lifetime root locks: Unavailable
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace


failures:
    independent::disk::tests::fresh_layout_has_stable_exclusive_custody_and_legacy_refusal_marker

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 364 filtered out; finished in 0.00s

error: test failed, to rerun pass `--lib`

```

B2 provenance correction: the first legacy-binary build overlapped the typed physical-stub edit, so it is not attributed to clean e8097861. Its executable is not used as the pinned old-binary witness. A read-only git archive of exact e8097861 is compiled separately; no Git/workzone structure is changed.

## B2 exact committed legacy source executable snapshot
Command: ['cargo', 'build', '--locked', '--offline', '--manifest-path', '/private/tmp/ic3-b2-legacy-e8097861/node/Cargo.toml', '--target-dir', '/Volumes/projects/limbo/glade-wz/glade/node/target', '--bin', 'glade-node']
Exit: 0; wall: 7.782s
```text
   Compiling glade-crdt-storage-attempt-api v0.0.0 (/private/tmp/ic3-b2-legacy-e8097861/contracts/crdt-storage-attempt-api)
   Compiling glade-wire v0.0.0 (/private/tmp/ic3-b2-legacy-e8097861/wire-rs)
   Compiling glade-clock-api v0.0.0 (/private/tmp/ic3-b2-legacy-e8097861/contracts/clock-api)
   Compiling glade-grant-api v0.0.0 (/private/tmp/ic3-b2-legacy-e8097861/contracts/grant-api)
   Compiling glade-carrier-api v0.0.0 (/private/tmp/ic3-b2-legacy-e8097861/contracts/carrier-api)
   Compiling glade-signer-api v0.0.0 (/private/tmp/ic3-b2-legacy-e8097861/contracts/signer-api)
   Compiling glade-persistence-api v0.0.0 (/private/tmp/ic3-b2-legacy-e8097861/contracts/persistence-api)
   Compiling glade-crdt-admission-data v0.0.0 (/private/tmp/ic3-b2-legacy-e8097861/contracts/crdt-admission-data)
   Compiling glade-crdt-recovery-api v0.0.0 (/private/tmp/ic3-b2-legacy-e8097861/contracts/crdt-recovery-api)
   Compiling glade-crdt-evidence-api v0.0.0 (/private/tmp/ic3-b2-legacy-e8097861/contracts/crdt-evidence-api)
   Compiling glade-crdt-recovery-codec v0.0.0 (/private/tmp/ic3-b2-legacy-e8097861/contracts/crdt-recovery-codec)
   Compiling glade-node v0.0.0 (/private/tmp/ic3-b2-legacy-e8097861/node)
    Finished `dev` profile [unoptimized + debuginfo] target(s) in 7.75s

```

B2 actual committed legacy executable preserved:
```json
{
  "implementation_revision": "e8097861c9559ce9753b75231ee2aac8f9e28064",
  "build": "cargo build --locked --offline --manifest-path /private/tmp/ic3-b2-legacy-e8097861/node/Cargo.toml --target-dir /Volumes/projects/limbo/glade-wz/glade/node/target --bin glade-node",
  "binary": "/private/tmp/ic3-b2-legacy-e8097861/glade-node-legacy",
  "sha256": "5da9c9da8eb48da7f1ac484674b0f2238b59735714960c3109eccf4e1b42b4d4"
}
```

## B2 physical root foundation GREEN
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'independent::disk::tests::fresh_layout_has_stable_exclusive_custody_and_legacy_refusal_marker']
Exit: 0; wall: 4.083s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 3.22s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-022b56b7ae6ded8d)

running 1 test
test independent::disk::tests::fresh_layout_has_stable_exclusive_custody_and_legacy_refusal_marker ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 364 filtered out; finished in 0.02s


```

## B2 registered root reopen clone and ownership compiling behavioral RED
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'independent::disk::tests::registered_roots_reopen_but_live_lock_wrong_registration_and_data_clone_refuse']
Exit: 101; wall: 3.696s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 2.81s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-022b56b7ae6ded8d)

running 1 test
test independent::disk::tests::registered_roots_reopen_but_live_lock_wrong_registration_and_data_clone_refuse ... FAILED

failures:

---- independent::disk::tests::registered_roots_reopen_but_live_lock_wrong_registration_and_data_clone_refuse stdout ----

thread 'independent::disk::tests::registered_roots_reopen_but_live_lock_wrong_registration_and_data_clone_refuse' (171937771) panicked at src/independent/disk.rs:153:9:
assertion failed: matches!(DiskLayout::open(&data, &floor, [75; 32]), Err(Fault::Ownership))
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace


failures:
    independent::disk::tests::registered_roots_reopen_but_live_lock_wrong_registration_and_data_clone_refuse

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 365 filtered out; finished in 0.02s

error: test failed, to rerun pass `--lib`

```

## B2 registered physical root foundation GREEN
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'independent::disk::tests']
Exit: 0; wall: 4.034s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 3.06s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-022b56b7ae6ded8d)

running 2 tests
test independent::disk::tests::fresh_layout_has_stable_exclusive_custody_and_legacy_refusal_marker ... ok
test independent::disk::tests::registered_roots_reopen_but_live_lock_wrong_registration_and_data_clone_refuse ... ok

test result: ok. 2 passed; 0 failed; 0 ignored; 0 measured; 364 filtered out; finished in 0.03s


```

## B2 actual committed legacy executable fresh root refusal
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'independent::disk::tests']
Exit: 101; wall: 6.588s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 4.71s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-022b56b7ae6ded8d)

running 3 tests
test independent::disk::tests::registered_roots_reopen_but_live_lock_wrong_registration_and_data_clone_refuse ... FAILED
test independent::disk::tests::fresh_layout_has_stable_exclusive_custody_and_legacy_refusal_marker ... ok
test independent::disk::tests::actual_committed_legacy_executable_refuses_the_disposable_ic3_root ... ok

failures:

---- independent::disk::tests::registered_roots_reopen_but_live_lock_wrong_registration_and_data_clone_refuse stdout ----

thread 'independent::disk::tests::registered_roots_reopen_but_live_lock_wrong_registration_and_data_clone_refuse' (171942210) panicked at src/independent/disk.rs:250:9:
assertion failed: matches!(DiskLayout::open(&data, &floor, [74; 32]), Err(Fault::Integrity))
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace


failures:
    independent::disk::tests::registered_roots_reopen_but_live_lock_wrong_registration_and_data_clone_refuse

test result: FAILED. 2 passed; 1 failed; 0 ignored; 0 measured; 364 filtered out; finished in 0.95s

error: test failed, to rerun pass `--lib`

```

## B2 explicit actual legacy executable witness selection
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'independent::disk::tests::actual_committed_legacy_executable_refuses_the_disposable_ic3_root', '--', '--ignored']
Exit: 0; wall: 2.577s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 1.60s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-022b56b7ae6ded8d)

running 1 test
test independent::disk::tests::actual_committed_legacy_executable_refuses_the_disposable_ic3_root ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 366 filtered out; finished in 0.05s


```

## B2 isolated normal layout scope after separating legacy executable prerequisite
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'independent::disk::tests']
Exit: 0; wall: 0.206s
```text
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.13s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-022b56b7ae6ded8d)

running 3 tests
test independent::disk::tests::actual_committed_legacy_executable_refuses_the_disposable_ic3_root ... ignored, B2 qualification requires the preserved exact committed legacy executable fixture
test independent::disk::tests::fresh_layout_has_stable_exclusive_custody_and_legacy_refusal_marker ... ok
test independent::disk::tests::registered_roots_reopen_but_live_lock_wrong_registration_and_data_clone_refuse ... ok

test result: ok. 2 passed; 0 failed; 1 ignored; 0 measured; 364 filtered out; finished in 0.04s


```

## B2 actual bounded reserved slot compiling behavioral RED
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'independent::disk::slots::tests::actual_reserved_slot_roundtrips_exact_bounded_bytes_and_rejects_torn_or_extra_data']
Exit: 101; wall: 4.106s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
warning: field `capacity` is never read
 --> src/independent/disk/slots.rs:7:5
  |
5 | pub(super) struct SlotFile {
  |                   -------- field in this struct
6 |     file: File,
7 |     capacity: usize,
  |     ^^^^^^^^
  |
  = note: `#[warn(dead_code)]` (part of `#[warn(unused)]`) on by default

warning: `glade-node` (lib test) generated 1 warning
    Finished `test` profile [unoptimized + debuginfo] target(s) in 3.23s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-022b56b7ae6ded8d)

running 1 test
test independent::disk::slots::tests::actual_reserved_slot_roundtrips_exact_bounded_bytes_and_rejects_torn_or_extra_data ... FAILED

failures:

---- independent::disk::slots::tests::actual_reserved_slot_roundtrips_exact_bounded_bytes_and_rejects_torn_or_extra_data stdout ----

thread 'independent::disk::slots::tests::actual_reserved_slot_roundtrips_exact_bounded_bytes_and_rejects_torn_or_extra_data' (171948406) panicked at src/independent/disk/slots.rs:30:55:
real bounded reservation writes actual bytes: Unavailable
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace


failures:
    independent::disk::slots::tests::actual_reserved_slot_roundtrips_exact_bounded_bytes_and_rejects_torn_or_extra_data

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 367 filtered out; finished in 0.00s

error: test failed, to rerun pass `--lib`

```

## B2 actual bounded reserved slot GREEN
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'independent::disk::slots::tests']
Exit: 0; wall: 4.074s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 3.16s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-022b56b7ae6ded8d)

running 1 test
test independent::disk::slots::tests::actual_reserved_slot_roundtrips_exact_bounded_bytes_and_rejects_torn_or_extra_data ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 367 filtered out; finished in 0.02s


```

## B2 changed physical slot length before mutation compiling behavioral RED
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'independent::disk::slots::tests']
Exit: 101; wall: 2.973s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 2.10s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-022b56b7ae6ded8d)

running 1 test
test independent::disk::slots::tests::actual_reserved_slot_roundtrips_exact_bounded_bytes_and_rejects_torn_or_extra_data ... FAILED

failures:

---- independent::disk::slots::tests::actual_reserved_slot_roundtrips_exact_bounded_bytes_and_rejects_torn_or_extra_data stdout ----

thread 'independent::disk::slots::tests::actual_reserved_slot_roundtrips_exact_bounded_bytes_and_rejects_torn_or_extra_data' (171951160) panicked at src/independent/disk/slots.rs:147:9:
corrupt slot length cannot be silently repaired or resized
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace


failures:
    independent::disk::slots::tests::actual_reserved_slot_roundtrips_exact_bounded_bytes_and_rejects_torn_or_extra_data

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 367 filtered out; finished in 0.02s

error: test failed, to rerun pass `--lib`

```

## B2 immutable actual slot reservation length GREEN
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'independent::disk::slots::tests']
Exit: 0; wall: 3.138s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 2.25s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-022b56b7ae6ded8d)

running 1 test
test independent::disk::slots::tests::actual_reserved_slot_roundtrips_exact_bounded_bytes_and_rejects_torn_or_extra_data ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 367 filtered out; finished in 0.02s


```

## B2 atomic bounded floor compiling behavioral RED
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'independent::disk::floors::tests']
Exit: 101; wall: 8.148s
```text
    Blocking waiting for file lock on build directory
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
warning: variants `Written`, `FileSynced`, and `DirectorySynced` are never constructed
 --> src/independent/disk/floors.rs:5:5
  |
4 | pub(super) enum FloorCut {
  |                 -------- variants in this enum
5 |     Written,
  |     ^^^^^^^
6 |     FileSynced,
  |     ^^^^^^^^^^
7 |     Renamed,
8 |     DirectorySynced,
  |     ^^^^^^^^^^^^^^^
  |
  = note: `FloorCut` has derived impls for the traits `Debug` and `Clone`, but these are intentionally ignored during dead code analysis
  = note: `#[warn(dead_code)]` (part of `#[warn(unused)]`) on by default

warning: `glade-node` (lib test) generated 1 warning
    Finished `test` profile [unoptimized + debuginfo] target(s) in 6.88s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-022b56b7ae6ded8d)

running 1 test
test independent::disk::floors::tests::bounded_floor_replacement_retains_installed_bytes_after_lost_rename_reply ... FAILED

failures:

---- independent::disk::floors::tests::bounded_floor_replacement_retains_installed_bytes_after_lost_rename_reply stdout ----

thread 'independent::disk::floors::tests::bounded_floor_replacement_retains_installed_bytes_after_lost_rename_reply' (171954626) panicked at src/independent/disk/floors.rs:31:47:
floor file+directory synchronized before acknowledgment: Unavailable
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace


failures:
    independent::disk::floors::tests::bounded_floor_replacement_retains_installed_bytes_after_lost_rename_reply

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 368 filtered out; finished in 0.00s

error: test failed, to rerun pass `--lib`

```

## B2 atomic bounded floor primitive GREEN
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'independent::disk::floors::tests']
Exit: 0; wall: 3.318s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 2.45s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-022b56b7ae6ded8d)

running 1 test
test independent::disk::floors::tests::bounded_floor_replacement_retains_installed_bytes_after_lost_rename_reply ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 368 filtered out; finished in 0.02s


```

## B2 complete physical floor cut exposure compiling behavioral RED
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'independent::disk::floors::tests::atomic_floor_exposes_each_exact_creation_partial_write_and_sync_cut']
Exit: 101; wall: 4.094s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 3.20s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-022b56b7ae6ded8d)

running 1 test
test independent::disk::floors::tests::atomic_floor_exposes_each_exact_creation_partial_write_and_sync_cut ... FAILED

failures:

---- independent::disk::floors::tests::atomic_floor_exposes_each_exact_creation_partial_write_and_sync_cut stdout ----

thread 'independent::disk::floors::tests::atomic_floor_exposes_each_exact_creation_partial_write_and_sync_cut' (171957611) panicked at src/independent/disk/floors.rs:125:9:
assertion `left == right` failed
  left: [Written, FileSynced, Renamed, DirectorySynced]
 right: [BeforeTemp, TempCreated, PartialWritten, Written, FileSynced, Renamed, DirectorySynced]
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace


failures:
    independent::disk::floors::tests::atomic_floor_exposes_each_exact_creation_partial_write_and_sync_cut

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 369 filtered out; finished in 0.01s

error: test failed, to rerun pass `--lib`

```

## B2 complete floor-cut exposure GREEN
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'independent::disk::floors::tests']
Exit: 0; wall: 2.404s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 1.53s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-022b56b7ae6ded8d)

running 2 tests
test independent::disk::floors::tests::atomic_floor_exposes_each_exact_creation_partial_write_and_sync_cut ... ok
test independent::disk::floors::tests::bounded_floor_replacement_retains_installed_bytes_after_lost_rename_reply ... ok

test result: ok. 2 passed; 0 failed; 0 ignored; 0 measured; 368 filtered out; finished in 0.01s


```

## B2 actual OS process kill seven floor primitive cuts
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'independent::disk::floors::tests::actual_process_kill_at_every_floor_cut_reopens_exact_old_or_installed_bytes']
Exit: 0; wall: 4.202s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 3.21s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-022b56b7ae6ded8d)

running 1 test
test independent::disk::floors::tests::actual_process_kill_at_every_floor_cut_reopens_exact_old_or_installed_bytes ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 371 filtered out; finished in 0.14s


```

## B2 owned slot reopen and full cut exposure compiling behavioral RED
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'independent::disk::slots::tests::slot_reopens_and_exposes_exact_header_partial_body_and_sync_cuts']
Exit: 101; wall: 7.177s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 6.32s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-022b56b7ae6ded8d)

running 1 test
test independent::disk::slots::tests::slot_reopens_and_exposes_exact_header_partial_body_and_sync_cuts ... FAILED

failures:

---- independent::disk::slots::tests::slot_reopens_and_exposes_exact_header_partial_body_and_sync_cuts stdout ----

thread 'independent::disk::slots::tests::slot_reopens_and_exposes_exact_header_partial_body_and_sync_cuts' (171964339) panicked at src/independent/disk/slots.rs:177:68:
actual image cuts are owned: Unavailable
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace


failures:
    independent::disk::slots::tests::slot_reopens_and_exposes_exact_header_partial_body_and_sync_cuts

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 372 filtered out; finished in 0.01s

error: test failed, to rerun pass `--lib`

```

## B2 actual slot reopen and owned-cut exposure GREEN
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'independent::disk::slots::tests']
Exit: 0; wall: 4.712s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 3.80s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-022b56b7ae6ded8d)

running 2 tests
test independent::disk::slots::tests::slot_reopens_and_exposes_exact_header_partial_body_and_sync_cuts ... ok
test independent::disk::slots::tests::actual_reserved_slot_roundtrips_exact_bounded_bytes_and_rejects_torn_or_extra_data ... ok

test result: ok. 2 passed; 0 failed; 0 ignored; 0 measured; 371 filtered out; finished in 0.03s


```

## B2 private pending operation metadata compiling behavioral RED
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'independent::disk::metadata::tests']
Exit: 101; wall: 8.249s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
warning: multiple variants are never constructed
  --> src/independent/disk/metadata.rs:7:5
   |
 6 | pub(super) enum DiskOperation {
   |                 ------------- variants in this enum
 7 |     Checkpoint,
   |     ^^^^^^^^^^
 8 |     PrepareAccepted,
   |     ^^^^^^^^^^^^^^^
 9 |     PrepareCandidate,
   |     ^^^^^^^^^^^^^^^^
10 |     PrepareSecurity,
   |     ^^^^^^^^^^^^^^^
11 |     PrepareFork,
   |     ^^^^^^^^^^^
12 |     Start,
   |     ^^^^^
13 |     PublishAccepted,
   |     ^^^^^^^^^^^^^^^
14 |     PublishCandidate,
   |     ^^^^^^^^^^^^^^^^
15 |     PublishSecurity,
   |     ^^^^^^^^^^^^^^^
16 |     PublishFork,
   |     ^^^^^^^^^^^
17 |     Fence,
   |     ^^^^^
18 |     BeginIngress,
   |     ^^^^^^^^^^^^
19 |     SettleIngress,
20 |     AbandonIngress,
   |     ^^^^^^^^^^^^^^
21 |     Observation,
   |     ^^^^^^^^^^^
22 |     Lease,
   |     ^^^^^
   |
   = note: `DiskOperation` has derived impls for the traits `Debug` and `Clone`, but these are intentionally ignored during dead code analysis
   = note: `#[warn(dead_code)]` (part of `#[warn(unused)]`) on by default

warning: struct `FloorEnvelope` is never constructed
  --> src/independent/disk/metadata.rs:32:19
   |
32 | pub(super) struct FloorEnvelope {
   |                   ^^^^^^^^^^^^^

warning: `glade-node` (lib test) generated 2 warnings
    Finished `test` profile [unoptimized + debuginfo] target(s) in 7.37s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-022b56b7ae6ded8d)

running 1 test
test independent::disk::metadata::tests::private_pending_kind_survives_missing_image_and_rejects_other_root_identity ... FAILED

failures:

---- independent::disk::metadata::tests::private_pending_kind_survives_missing_image_and_rejects_other_root_identity stdout ----

thread 'independent::disk::metadata::tests::private_pending_kind_survives_missing_image_and_rejects_other_root_identity' (171979358) panicked at src/independent/disk/metadata.rs:60:69:
private canonical pending metadata: Invalid
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace


failures:
    independent::disk::metadata::tests::private_pending_kind_survives_missing_image_and_rejects_other_root_identity

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 373 filtered out; finished in 0.00s

error: test failed, to rerun pass `--lib`

```

## B2 private pending operation metadata exact persisted missing-image control GREEN
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'independent::disk::metadata::tests']
Exit: 0; wall: 7.587s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
warning: struct `FloorEnvelope` is never constructed
  --> src/independent/disk/metadata.rs:33:19
   |
33 | pub(super) struct FloorEnvelope {
   |                   ^^^^^^^^^^^^^
   |
   = note: `#[warn(dead_code)]` (part of `#[warn(unused)]`) on by default

warning: `glade-node` (lib test) generated 1 warning
    Finished `test` profile [unoptimized + debuginfo] target(s) in 6.61s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-022b56b7ae6ded8d)

running 1 test
test independent::disk::metadata::tests::private_pending_kind_survives_missing_image_and_rejects_other_root_identity ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 373 filtered out; finished in 0.01s


```

## B2 paired selection and fallback behavioral RED
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'independent::disk::paired::tests', '--', '--nocapture']
Exit: 101; wall: 9.171s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
warning: unused import: `PendingMetadata`
 --> src/independent/disk/paired.rs:3:53
  |
3 | use super::metadata::{DiskOperation, FloorEnvelope, PendingMetadata};
  |                                                     ^^^^^^^^^^^^^^^
  |
  = note: `#[warn(unused_imports)]` (part of `#[warn(unused)]`) on by default

warning: unused import: `SlotFile`
 --> src/independent/disk/paired.rs:4:20
  |
4 | use super::slots::{SlotFile, SlotCut};
  |                    ^^^^^^^^

warning: variant `Intent` is never constructed
 --> src/independent/disk/paired.rs:7:27
  |
7 | pub(super) enum PairCut { Intent(FloorCut), Image(SlotCut), Selection(FloorCut) }
  |                 -------   ^^^^^^
  |                 |
  |                 variant in this enum
  |
  = note: `PairCut` has derived impls for the traits `Debug` and `Clone`, but these are intentionally ignored during dead code analysis
  = note: `#[warn(dead_code)]` (part of `#[warn(unused)]`) on by default

warning: `glade-node` (lib test) generated 3 warnings (run `cargo fix --lib -p glade-node --tests` to apply 2 suggestions)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 8.20s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-022b56b7ae6ded8d)

running 2 tests

thread 'independent::disk::paired::tests::nonrecursive_pair_selection_and_exact_pending_fallback_retain_all_floors' (171992295) panicked at src/independent/disk/paired/tests.rs:25:5:
assertion `left != right` failed: selection hashes an existing nonrecursive image
  left: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
 right: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace
test independent::disk::paired::tests::nonrecursive_pair_selection_and_exact_pending_fallback_retain_all_floors ... FAILED

thread 'independent::disk::paired::tests::installed_next_image_finishes_lost_selection_reply_without_hash_recursion' (171992294) panicked at src/independent/disk/paired/tests.rs:49:118:
called `Result::unwrap()` on an `Err` value: Unavailable
test independent::disk::paired::tests::installed_next_image_finishes_lost_selection_reply_without_hash_recursion ... FAILED

failures:

failures:
    independent::disk::paired::tests::installed_next_image_finishes_lost_selection_reply_without_hash_recursion
    independent::disk::paired::tests::nonrecursive_pair_selection_and_exact_pending_fallback_retain_all_floors

test result: FAILED. 0 passed; 2 failed; 0 ignored; 0 measured; 374 filtered out; finished in 0.03s

error: test failed, to rerun pass `--lib`

```

## B2 paired selection and fallback GREEN attempt
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'independent::disk::paired::tests', '--', '--nocapture']
Exit: 0; wall: 10.283s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 9.21s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-022b56b7ae6ded8d)

running 2 tests
test independent::disk::paired::tests::installed_next_image_finishes_lost_selection_reply_without_hash_recursion ... ok
test independent::disk::paired::tests::nonrecursive_pair_selection_and_exact_pending_fallback_retain_all_floors ... ok

test result: ok. 2 passed; 0 failed; 0 ignored; 0 measured; 374 filtered out; finished in 0.09s


```

## B2 recovered exact settlement behavioral RED
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'independent::disk::paired::tests::completed_next_image', '--', '--nocapture']
Exit: 101; wall: 5.457s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 4.46s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-022b56b7ae6ded8d)

running 1 test

thread 'independent::disk::paired::tests::completed_next_image_installs_exact_guard_settlement_after_missing_selection' (172005624) panicked at src/independent/disk/paired/tests.rs:251:5:
assertion `left == right` failed: complete next image must recover exact intended settlement; absent next must stay active
  left: Some(Active(ReceiveGuard { id: GuardId { store: StoreIncarnation([1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]), instance: Instance { descriptor: [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2], incarnation: "structural-pair" }, number: 0 }, owner: Owner { store: StoreIncarnation([1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]), generation: 1 }, lease: 1, source: [15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15], channel: [16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16], role: "inventory", base_generation: 0, base_digest: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], max_bytes: 8192, max_items: 16, deadline_ms: 1000 }))
 right: Some(Settled { guard: ReceiveGuard { id: GuardId { store: StoreIncarnation([1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]), instance: Instance { descriptor: [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2], incarnation: "structural-pair" }, number: 0 }, owner: Owner { store: StoreIncarnation([1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]), generation: 1 }, lease: 1, source: [15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15], channel: [16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16], role: "inventory", base_generation: 0, base_digest: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], max_bytes: 8192, max_items: 16, deadline_ms: 1000 }, observation: [17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17], image_generation: 1 })
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace
test independent::disk::paired::tests::completed_next_image_installs_exact_guard_settlement_after_missing_selection ... FAILED

failures:

failures:
    independent::disk::paired::tests::completed_next_image_installs_exact_guard_settlement_after_missing_selection

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 376 filtered out; finished in 0.07s

error: test failed, to rerun pass `--lib`

```

## B2 exact recovery completion floor GREEN attempt
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'independent::disk::paired::tests', '--', '--nocapture']
Exit: 0; wall: 4.526s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 3.54s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-022b56b7ae6ded8d)

running 3 tests
test independent::disk::paired::tests::installed_next_image_finishes_lost_selection_reply_without_hash_recursion ... ok
test independent::disk::paired::tests::nonrecursive_pair_selection_and_exact_pending_fallback_retain_all_floors ... ok
test independent::disk::paired::tests::completed_next_image_installs_exact_guard_settlement_after_missing_selection ... ok

test result: ok. 3 passed; 0 failed; 0 ignored; 0 measured; 374 filtered out; finished in 0.11s


```

## B2 held root substitution before any trusted floor write behavioral RED
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'independent::disk::paired::tests::live_root', '--', '--nocapture']
Exit: 101; wall: 7.094s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 6.09s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-022b56b7ae6ded8d)

running 1 test

thread 'independent::disk::paired::tests::live_root_substitution_refuses_before_touching_trusted_selection' (172009660) panicked at src/independent/disk/paired/tests.rs:310:9:
assertion `left == right` failed: held root replacement must be rejected before any floor advance
  left: Bytes { value: [103, 108, 97, 100, 101, 46, 99, 114, 100, 116, 46, 114, 101, 99, 111, 118, 101, 114, 121, 0, 1, 130, 111, 73, 99, 51, 68, 105, 115, 107, 70, 108, 111, 111, 114, 47, 118, 49, 164, 0, 173, 0, 167, 0, 72, 0, 0, 0, 0, 0, 0, 0, 0, 1, 72, 0, 0, 0, 0, 0, 0, 0, 0, 2, 88, 32, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 88, 32, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 88, 32, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 72, 0, 0, 0, 0, 0, 0, 0, 0, 6, 128, 1, 72, 0, 0, 0, 0, 0, 0, 0, 1, 2, 162, 0, 88, 32, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 72, 0, 0, 0, 0, 0, 0, 0, 1, 3, 88, 32, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 4, 88, 32, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 5, 72, 0, 0, 0, 0, 0, 0, 0, 1, 6, 72, 0, 0, 0, 0, 0, 0, 0, 1, 7, 163, 0, 0, 1, 72, 0, 0, 0, 0, 0, 0, 0, 0, 2, 88, 32, 26, 109, 165, 41, 190, 9, 219, 166, 3, 213, 43, 80, 84, 96, 135, 170, 7, 99, 38, 199, 16, 156, 122, 88, 182, 217, 194, 167, 183, 11, 151, 64, 8, 72, 0, 0, 0, 0, 0, 0, 0, 0, 9, 72, 0, 0, 0, 0, 0, 0, 0, 0, 10, 72, 0, 0, 0, 0, 0, 0, 0, 0, 11, 128, 12, 129, 167, 0, 167, 0, 72, 0, 0, 0, 0, 0, 0, 0, 0, 1, 72, 0, 0, 0, 0, 0, 0, 0, 0, 2, 88, 32, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 88, 32, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 88, 32, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 72, 0, 0, 0, 0, 0, 0, 0, 0, 6, 128, 1, 163, 0, 0, 1, 72, 0, 0, 0, 0, 0, 0, 0, 0, 2, 88, 32, 26, 109, 165, 41, 190, 9, 219, 166, 3, 213, 43, 80, 84, 96, 135, 170, 7, 99, 38, 199, 16, 156, 122, 88, 182, 217, 194, 167, 183, 11, 151, 64, 2, 163, 0, 1, 1, 72, 0, 0, 0, 0, 0, 0, 0, 1, 2, 88, 32, 48, 234, 33, 193, 20, 129, 253, 129, 148, 231, 130, 39, 237, 174, 173, 109, 192, 179, 82, 165, 91, 131, 234, 255, 72, 20, 212, 114, 220, 109, 125, 84, 3, 72, 0, 0, 0, 0, 0, 0, 0, 0, 4, 72, 0, 0, 0, 0, 0, 0, 0, 0, 5, 72, 0, 0, 0, 0, 0, 0, 0, 0, 6, 128, 1, 129, 164, 0, 0, 1, 88, 32, 143, 90, 150, 20, 7, 202, 8, 18, 199, 243, 74, 177, 87, 29, 177, 79, 99, 187, 159, 131, 128, 243, 178, 151, 2, 225, 198, 206, 118, 98, 103, 68, 2, 163, 0, 0, 1, 72, 0, 0, 0, 0, 0, 0, 0, 0, 2, 88, 32, 26, 109, 165, 41, 190, 9, 219, 166, 3, 213, 43, 80, 84, 96, 135, 170, 7, 99, 38, 199, 16, 156, 122, 88, 182, 217, 194, 167, 183, 11, 151, 64, 3, 163, 0, 1, 1, 72, 0, 0, 0, 0, 0, 0, 0, 1, 2, 88, 32, 48, 234, 33, 193, 20, 129, 253, 129, 148, 231, 130, 39, 237, 174, 173, 109, 192, 179, 82, 165, 91, 131, 234, 255, 72, 20, 212, 114, 220, 109, 125, 84, 2, 129, 173, 0, 167, 0, 72, 0, 0, 0, 0, 0, 0, 0, 0, 1, 72, 0, 0, 0, 0, 0, 0, 0, 0, 2, 88, 32, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 88, 32, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 88, 32, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 72, 0, 0, 0, 0, 0, 0, 0, 0, 6, 128, 1, 72, 0, 0, 0, 0, 0, 0, 0, 1, 2, 162, 0, 88, 32, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 72, 0, 0, 0, 0, 0, 0, 0, 1, 3, 88, 32, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 4, 88, 32, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 5, 72, 0, 0, 0, 0, 0, 0, 0, 1, 6, 72, 0, 0, 0, 0, 0, 0, 0, 2, 7, 163, 0, 1, 1, 72, 0, 0, 0, 0, 0, 0, 0, 1, 2, 88, 32, 48, 234, 33, 193, 20, 129, 253, 129, 148, 231, 130, 39, 237, 174, 173, 109, 192, 179, 82, 165, 91, 131, 234, 255, 72, 20, 212, 114, 220, 109, 125, 84, 8, 72, 0, 0, 0, 0, 0, 0, 0, 0, 9, 72, 0, 0, 0, 0, 0, 0, 0, 0, 10, 72, 0, 0, 0, 0, 0, 0, 0, 0, 11, 128, 12, 246, 3, 128], digest: [38, 179, 193, 114, 80, 70, 165, 11, 110, 70, 24, 117, 237, 83, 11, 85, 86, 200, 209, 207, 196, 139, 37, 165, 72, 219, 30, 157, 174, 189, 169, 104] }
 right: Bytes { value: [103, 108, 97, 100, 101, 46, 99, 114, 100, 116, 46, 114, 101, 99, 111, 118, 101, 114, 121, 0, 1, 130, 111, 73, 99, 51, 68, 105, 115, 107, 70, 108, 111, 111, 114, 47, 118, 49, 164, 0, 173, 0, 167, 0, 72, 0, 0, 0, 0, 0, 0, 0, 0, 1, 72, 0, 0, 0, 0, 0, 0, 0, 0, 2, 88, 32, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 88, 32, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 88, 32, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 72, 0, 0, 0, 0, 0, 0, 0, 0, 6, 128, 1, 72, 0, 0, 0, 0, 0, 0, 0, 1, 2, 162, 0, 88, 32, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 72, 0, 0, 0, 0, 0, 0, 0, 1, 3, 88, 32, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 4, 88, 32, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 5, 72, 0, 0, 0, 0, 0, 0, 0, 1, 6, 72, 0, 0, 0, 0, 0, 0, 0, 0, 7, 163, 0, 0, 1, 72, 0, 0, 0, 0, 0, 0, 0, 0, 2, 88, 32, 26, 109, 165, 41, 190, 9, 219, 166, 3, 213, 43, 80, 84, 96, 135, 170, 7, 99, 38, 199, 16, 156, 122, 88, 182, 217, 194, 167, 183, 11, 151, 64, 8, 72, 0, 0, 0, 0, 0, 0, 0, 0, 9, 72, 0, 0, 0, 0, 0, 0, 0, 0, 10, 72, 0, 0, 0, 0, 0, 0, 0, 0, 11, 128, 12, 246, 1, 246, 2, 246, 3, 128], digest: [44, 106, 74, 245, 32, 2, 54, 104, 12, 182, 232, 247, 37, 142, 6, 209, 101, 116, 135, 67, 173, 254, 121, 217, 6, 81, 79, 178, 143, 58, 119, 37] }
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace
test independent::disk::paired::tests::live_root_substitution_refuses_before_touching_trusted_selection ... FAILED

failures:

failures:
    independent::disk::paired::tests::live_root_substitution_refuses_before_touching_trusted_selection

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 377 filtered out; finished in 0.05s

error: test failed, to rerun pass `--lib`

```

## B2 held root ownership and pair regressions GREEN
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'independent::disk::paired::tests', '--', '--nocapture']
Exit: 0; wall: 13.234s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 12.09s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-022b56b7ae6ded8d)

running 4 tests
test independent::disk::paired::tests::installed_next_image_finishes_lost_selection_reply_without_hash_recursion ... ok
test independent::disk::paired::tests::nonrecursive_pair_selection_and_exact_pending_fallback_retain_all_floors ... ok
test independent::disk::paired::tests::completed_next_image_installs_exact_guard_settlement_after_missing_selection ... ok
test independent::disk::paired::tests::live_root_substitution_refuses_before_touching_trusted_selection ... ok

test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 374 filtered out; finished in 0.18s


```

## B2 all nineteen actual paired OS process kill cuts
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'independent::disk::paired::tests::process::actual_process', '--', '--nocapture']
Exit: 0; wall: 5.961s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 3.93s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-022b56b7ae6ded8d)

running 1 test
test independent::disk::paired::tests::process::actual_process_kill_reopens_every_intent_image_selection_cut ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 379 filtered out; finished in 1.11s


```

## B2 genuine authenticated full-host genesis behavioral RED
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--test', 'ic3_disk', '--', '--nocapture']
Exit: 101; wall: 5.990s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
warning: struct `DiskLayout` is never constructed
  --> src/independent/disk.rs:11:19
   |
11 | pub(crate) struct DiskLayout {
   |                   ^^^^^^^^^^
   |
   = note: `#[warn(dead_code)]` (part of `#[warn(unused)]`) on by default

warning: associated items `owned`, `open`, and `provision` are never used
  --> src/independent/disk.rs:18:8
   |
17 | impl DiskLayout {
   | --------------- associated items in this implementation
18 |     fn owned(&self) -> Result<(), Fault> {
   |        ^^^^^
...
42 |     pub(crate) fn open(data: &Path, floor: &Path, registration: Digest) -> Result<Self, Fault> {
   |                   ^^^^
...
76 |     pub(crate) fn provision(
   |                   ^^^^^^^^^

warning: function `marker` is never used
   --> src/independent/disk.rs:109:4
    |
109 | fn marker(data: &Path, floor: &Path, registration: Digest) -> Result<Vec<u8>, Fault> {
    |    ^^^^^^

warning: function `regular` is never used
   --> src/independent/disk.rs:124:4
    |
124 | fn regular(path: &Path) -> Result<(), Fault> {
    |    ^^^^^^^

warning: function `lock_existing` is never used
   --> src/independent/disk.rs:130:4
    |
130 | fn lock_existing(directory: &Path) -> Result<File, Fault> {
    |    ^^^^^^^^^^^^^

warning: function `io_fault` is never used
   --> src/independent/disk.rs:148:4
    |
148 | fn io_fault(_: io::Error) -> Fault {
    |    ^^^^^^^^

warning: function `fresh_path` is never used
   --> src/independent/disk.rs:151:4
    |
151 | fn fresh_path(path: &Path) -> Result<PathBuf, Fault> {
    |    ^^^^^^^^^^

warning: function `lock_new` is never used
   --> src/independent/disk.rs:162:4
    |
162 | fn lock_new(directory: &Path) -> Result<File, Fault> {
    |    ^^^^^^^^

warning: function `write_new` is never used
   --> src/independent/disk.rs:168:4
    |
168 | fn write_new(path: &Path, bytes: &[u8]) -> Result<(), Fault> {
    |    ^^^^^^^^^

warning: function `sync_directory` is never used
   --> src/independent/disk.rs:173:4
    |
173 | fn sync_directory(path: &Path) -> Result<(), Fault> {
    |    ^^^^^^^^^^^^^^

warning: enum `FloorCut` is never used
 --> src/independent/disk/floors.rs:4:17
  |
4 | pub(super) enum FloorCut {
  |                 ^^^^^^^^

warning: function `replace` is never used
  --> src/independent/disk/floors.rs:13:15
   |
13 | pub(super) fn replace(
   |               ^^^^^^^

warning: function `read` is never used
  --> src/independent/disk/floors.rs:64:15
   |
64 | pub(super) fn read(path: &Path, limit: usize) -> Result<Bytes, Fault> {
   |               ^^^^

warning: enum `DiskOperation` is never used
 --> src/independent/disk/metadata.rs:7:17
  |
7 | pub(super) enum DiskOperation {
  |                 ^^^^^^^^^^^^^

warning: struct `PendingMetadata` is never constructed
  --> src/independent/disk/metadata.rs:26:19
   |
26 | pub(super) struct PendingMetadata {
   |                   ^^^^^^^^^^^^^^^

warning: struct `FloorEnvelope` is never constructed
  --> src/independent/disk/metadata.rs:33:19
   |
33 | pub(super) struct FloorEnvelope {
   |                   ^^^^^^^^^^^^^

warning: function `fields` is never used
   --> src/independent/disk/metadata.rs:101:4
    |
101 | fn fields(value: &Cbor, count: usize) -> Result<&[(i64, Cbor)], Error> {
    |    ^^^^^^

warning: function `operation` is never used
   --> src/independent/disk/metadata.rs:115:4
    |
115 | fn operation(value: &Cbor) -> Result<DiskOperation, Error> {
    |    ^^^^^^^^^

warning: enum `PairCut` is never used
 --> src/independent/disk/paired.rs:8:17
  |
8 | pub(super) enum PairCut {
  |                 ^^^^^^^

warning: struct `PairStore` is never constructed
  --> src/independent/disk/paired.rs:13:19
   |
13 | pub(super) struct PairStore {
   |                   ^^^^^^^^^

warning: associated items `create`, `open`, `read`, and `transact` are never used
   --> src/independent/disk/paired.rs:21:19
    |
 20 | impl PairStore {
    | -------------- associated items in this implementation
 21 |     pub(super) fn create(
    |                   ^^^^^^
...
 67 |     pub(super) fn open(layout: DiskLayout, bounds: DecodeLimits) -> Result<Self, Fault> {
    |                   ^^^^
...
136 |     fn read(
    |        ^^^^
...
151 |     pub(super) fn transact(
    |                   ^^^^^^^^

warning: function `codec_fault` is never used
 --> src/independent/disk/paired/validation.rs:3:15
  |
3 | pub(super) fn codec_fault(error: Error) -> Fault {
  |               ^^^^^^^^^^^

warning: function `pending` is never used
  --> src/independent/disk/paired/validation.rs:10:15
   |
10 | pub(super) fn pending(envelope: &FloorEnvelope) -> Result<(), Fault> {
   |               ^^^^^^^

warning: function `envelope` is never used
  --> src/independent/disk/paired/validation.rs:58:15
   |
58 | pub(super) fn envelope(
   |               ^^^^^^^^

warning: function `advance` is never used
  --> src/independent/disk/paired/validation.rs:90:15
   |
90 | pub(super) fn advance(old: &ReplicaFloor, next: &ReplicaFloor) -> Result<(), Fault> {
   |               ^^^^^^^

warning: function `capacity` is never used
   --> src/independent/disk/paired/validation.rs:128:15
    |
128 | pub(super) fn capacity(path: &Path, bounds: &DecodeLimits) -> Result<usize, Fault> {
    |               ^^^^^^^^

warning: struct `SlotFile` is never constructed
 --> src/independent/disk/slots.rs:5:19
  |
5 | pub(super) struct SlotFile {
  |                   ^^^^^^^^

warning: constant `MAGIC` is never used
  --> src/independent/disk/slots.rs:10:7
   |
10 | const MAGIC: &[u8] = b"glade.ic3.image\0\x01";
   |       ^^^^^

warning: constant `HEADER` is never used
  --> src/independent/disk/slots.rs:11:7
   |
11 | const HEADER: usize = MAGIC.len() + 8 + 32;
   |       ^^^^^^

warning: enum `SlotCut` is never used
  --> src/independent/disk/slots.rs:13:17
   |
13 | pub(super) enum SlotCut {
   |                 ^^^^^^^

warning: associated items `open`, `reserve`, `owned`, `write_image`, `write_image_with`, and `read_image` are never used
   --> src/independent/disk/slots.rs:21:19
    |
 20 | impl SlotFile {
    | ------------- associated items in this implementation
 21 |     pub(super) fn open(path: &Path, capacity: usize) -> Result<Self, Fault> {
    |                   ^^^^
...
 43 |     pub(super) fn reserve(path: &Path, capacity: usize) -> Result<Self, Fault> {
    |                   ^^^^^^^
...
 59 |     fn owned(&self) -> Result<(), Fault> {
    |        ^^^^^
...
 68 |     pub(super) fn write_image(&mut self, bytes: &Bytes) -> Result<(), Fault> {
    |                   ^^^^^^^^^^^
...
 71 |     pub(super) fn write_image_with(
    |                   ^^^^^^^^^^^^^^^^
...
112 |     pub(super) fn read_image(&mut self, digest: Digest) -> Result<Bytes, Fault> {
    |                   ^^^^^^^^^^

warning: function `zeroes` is never used
   --> src/independent/disk/slots.rs:157:4
    |
157 | fn zeroes(file: &mut File, mut count: usize) -> Result<(), Fault> {
    |    ^^^^^^

warning: function `object` is never used
   --> src/independent/disk.rs:180:8
    |
180 |     fn object(meta: &fs::Metadata) -> [u8; 16] {
    |        ^^^^^^

warning: function `identity` is never used
   --> src/independent/disk.rs:186:19
    |
186 |     pub(super) fn identity(path: &Path) -> io::Result<[u8; 16]> {
    |                   ^^^^^^^^

warning: function `file_identity` is never used
   --> src/independent/disk.rs:189:19
    |
189 |     pub(super) fn file_identity(file: &File) -> io::Result<[u8; 16]> {
    |                   ^^^^^^^^^^^^^

warning: function `create` is never used
   --> src/independent/disk.rs:192:19
    |
192 |     pub(super) fn create(path: &Path) -> io::Result<File> {
    |                   ^^^^^^

warning: function `sync_directory` is never used
   --> src/independent/disk.rs:200:19
    |
200 |     pub(super) fn sync_directory(path: &Path) -> io::Result<()> {
    |                   ^^^^^^^^^^^^^^

warning: fields `evidence` and `roots` are never read
  --> src/independent/records.rs:12:5
   |
11 | pub struct DiskHost<P: PolicyClock> {
   |            -------- fields in this struct
12 |     evidence: Option<GenuineEvidence<P>>,
   |     ^^^^^^^^
13 |     roots: DiskRootConfig,
   |     ^^^^^

warning: field `evidence` is never read
  --> src/independent/records.rs:16:5
   |
15 | pub struct DiskSession<P: PolicyClock> {
   |            ----------- field in this struct
16 |     evidence: GenuineEvidence<P>,
   |     ^^^^^^^^

warning: `glade-node` (lib) generated 39 warnings
warning: field `query` is never read
  --> tests/ic3_auth_fixture/mod.rs:37:9
   |
32 | pub struct Fixture {
   |            ------- field in this struct
...
37 |     pub query: Query,
   |         ^^^^^
   |
   = note: `#[warn(dead_code)]` (part of `#[warn(unused)]`) on by default

warning: `glade-node` (test "ic3_disk") generated 1 warning
    Finished `test` profile [unoptimized + debuginfo] target(s) in 5.44s
     Running tests/ic3_disk.rs (glade/node/target/debug/deps/ic3_disk-a378df87369b9225)

running 1 test

thread 'genuine_fresh_replica_opens_owned_validated_genesis_and_reopens_same_identity' (172019167) panicked at tests/ic3_disk.rs:75:10:
genuine provisioned disk session: Unavailable
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace
test genuine_fresh_replica_opens_owned_validated_genesis_and_reopens_same_identity ... FAILED

failures:

failures:
    genuine_fresh_replica_opens_owned_validated_genesis_and_reopens_same_identity

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

error: test failed, to rerun pass `--test ic3_disk`

```

## B2 pending next recovery resync-before-selection behavioral RED
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'independent::disk::paired::tests::failed_recovery', '--', '--nocapture']
Exit: 101; wall: 7.333s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
warning: fields `evidence` and `roots` are never read
  --> src/independent/records.rs:12:5
   |
11 | pub struct DiskHost<P: PolicyClock> {
   |            -------- fields in this struct
12 |     evidence: Option<GenuineEvidence<P>>,
   |     ^^^^^^^^
13 |     roots: DiskRootConfig,
   |     ^^^^^
   |
   = note: `#[warn(dead_code)]` (part of `#[warn(unused)]`) on by default

warning: field `evidence` is never read
  --> src/independent/records.rs:16:5
   |
15 | pub struct DiskSession<P: PolicyClock> {
   |            ----------- field in this struct
16 |     evidence: GenuineEvidence<P>,
   |     ^^^^^^^^

warning: `glade-node` (lib test) generated 2 warnings
    Finished `test` profile [unoptimized + debuginfo] target(s) in 6.24s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-022b56b7ae6ded8d)

running 1 test

thread 'independent::disk::paired::tests::failed_recovery_resync_keeps_original_pending_floor_and_does_not_select' (172024483) panicked at src/independent/disk/paired/tests.rs:379:5:
sync uncertainty cannot finalize recovered selection
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace
test independent::disk::paired::tests::failed_recovery_resync_keeps_original_pending_floor_and_does_not_select ... FAILED

failures:

failures:
    independent::disk::paired::tests::failed_recovery_resync_keeps_original_pending_floor_and_does_not_select

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 380 filtered out; finished in 0.06s

error: test failed, to rerun pass `--lib`

```

## B2 recovery validates and actually resyncs slot before selection GREEN
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'independent::disk::paired::tests', '--', '--nocapture']
Exit: 0; wall: 5.202s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
warning: fields `evidence` and `roots` are never read
  --> src/independent/records.rs:12:5
   |
11 | pub struct DiskHost<P: PolicyClock> {
   |            -------- fields in this struct
12 |     evidence: Option<GenuineEvidence<P>>,
   |     ^^^^^^^^
13 |     roots: DiskRootConfig,
   |     ^^^^^
   |
   = note: `#[warn(dead_code)]` (part of `#[warn(unused)]`) on by default

warning: field `evidence` is never read
  --> src/independent/records.rs:16:5
   |
15 | pub struct DiskSession<P: PolicyClock> {
   |            ----------- field in this struct
16 |     evidence: GenuineEvidence<P>,
   |     ^^^^^^^^

warning: `glade-node` (lib test) generated 2 warnings
    Finished `test` profile [unoptimized + debuginfo] target(s) in 2.79s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-022b56b7ae6ded8d)

running 7 tests
test independent::disk::paired::tests::process::pair_cut_child ... ignored, owned child of paired process-kill schedule
test independent::disk::paired::tests::failed_recovery_resync_keeps_original_pending_floor_and_does_not_select ... ok
test independent::disk::paired::tests::installed_next_image_finishes_lost_selection_reply_without_hash_recursion ... ok
test independent::disk::paired::tests::completed_next_image_installs_exact_guard_settlement_after_missing_selection ... ok
test independent::disk::paired::tests::nonrecursive_pair_selection_and_exact_pending_fallback_retain_all_floors ... ok
test independent::disk::paired::tests::live_root_substitution_refuses_before_touching_trusted_selection ... ok
test independent::disk::paired::tests::process::actual_process_kill_reopens_every_intent_image_selection_cut ... ok

test result: ok. 6 passed; 0 failed; 1 ignored; 0 measured; 374 filtered out; finished in 1.46s


```

## B2 genuine signed genesis disk-host GREEN attempt
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--test', 'ic3_disk', '--', '--nocapture']
Exit: 0; wall: 4.341s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
warning: unused import: `glade_crdt_admission_data::*`
 --> src/independent/records.rs:5:5
  |
5 | use glade_crdt_admission_data::*;
  |     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  |
  = note: `#[warn(unused_imports)]` (part of `#[warn(unused)]`) on by default

warning: type `FloorCut` is more private than the item `PairCut::Intent::0`
 --> src/independent/disk/paired.rs:9:12
  |
9 |     Intent(FloorCut),
  |            ^^^^^^^^ field `PairCut::Intent::0` is reachable at visibility `pub(in crate::independent)`
  |
note: but type `FloorCut` is only usable at visibility `pub(in crate::independent::disk)`
 --> src/independent/disk/floors.rs:4:1
  |
4 | pub(super) enum FloorCut {
  | ^^^^^^^^^^^^^^^^^^^^^^^^
  = note: `#[warn(private_interfaces)]` on by default

warning: type `SlotCut` is more private than the item `PairCut::Image::0`
  --> src/independent/disk/paired.rs:10:11
   |
10 |     Image(SlotCut),
   |           ^^^^^^^ field `PairCut::Image::0` is reachable at visibility `pub(in crate::independent)`
   |
note: but type `SlotCut` is only usable at visibility `pub(in crate::independent::disk)`
  --> src/independent/disk/slots.rs:13:1
   |
13 | pub(super) enum SlotCut {
   | ^^^^^^^^^^^^^^^^^^^^^^^

warning: type `FloorCut` is more private than the item `PairCut::Selection::0`
  --> src/independent/disk/paired.rs:11:15
   |
11 |     Selection(FloorCut),
   |               ^^^^^^^^ field `PairCut::Selection::0` is reachable at visibility `pub(in crate::independent)`
   |
note: but type `FloorCut` is only usable at visibility `pub(in crate::independent::disk)`
  --> src/independent/disk/floors.rs:4:1
   |
 4 | pub(super) enum FloorCut {
   | ^^^^^^^^^^^^^^^^^^^^^^^^

warning: method `floor_digest` is never used
  --> src/independent/disk/paired.rs:26:19
   |
22 | impl PairStore {
   | -------------- method in this implementation
...
26 |     pub(crate) fn floor_digest(&self) -> Result<Digest, Fault> {
   |                   ^^^^^^^^^^^^
   |
   = note: `#[warn(dead_code)]` (part of `#[warn(unused)]`) on by default

warning: `glade-node` (lib) generated 5 warnings (run `cargo fix --lib -p glade-node` to apply 1 suggestion)
warning: field `query` is never read
  --> tests/ic3_auth_fixture/mod.rs:37:9
   |
32 | pub struct Fixture {
   |            ------- field in this struct
...
37 |     pub query: Query,
   |         ^^^^^
   |
   = note: `#[warn(dead_code)]` (part of `#[warn(unused)]`) on by default

warning: `glade-node` (test "ic3_disk") generated 1 warning
    Finished `test` profile [unoptimized + debuginfo] target(s) in 3.78s
     Running tests/ic3_disk.rs (glade/node/target/debug/deps/ic3_disk-a378df87369b9225)

running 1 test
test genuine_fresh_replica_opens_owned_validated_genesis_and_reopens_same_identity ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.06s


```

## B2 reviewed normal core edge lock incorporation before behavioral RED
Command: ['cargo', 'check', '--manifest-path', 'glade/node/Cargo.toml', '--offline', '--lib']
Exit: 0; wall: 3.712s
```text
     Locking 1 package to latest compatible version
      Adding glade-crdt-admission-core v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-admission-core)
    Checking glade-crdt-admission-core v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-admission-core)
    Checking glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
warning: method `floor_digest` is never used
  --> src/independent/disk/paired.rs:26:19
   |
22 | impl PairStore {
   | -------------- method in this implementation
...
26 |     pub(crate) fn floor_digest(&self) -> Result<Digest, Fault> {
   |                   ^^^^^^^^^^^^
   |
   = note: `#[warn(dead_code)]` (part of `#[warn(unused)]`) on by default

warning: `glade-node` (lib) generated 1 warning
    Finished `dev` profile [unoptimized + debuginfo] target(s) in 3.65s

```

## B2 actual owned durable ingress and restart guard behavioral RED
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--test', 'ic3_disk', 'actual_owned', '--', '--nocapture']
Exit: 101; wall: 9.398s
```text
   Compiling glade-crdt-admission-core v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-admission-core)
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
warning: method `floor_digest` is never used
  --> src/independent/disk/paired.rs:26:19
   |
22 | impl PairStore {
   | -------------- method in this implementation
...
26 |     pub(crate) fn floor_digest(&self) -> Result<Digest, Fault> {
   |                   ^^^^^^^^^^^^
   |
   = note: `#[warn(dead_code)]` (part of `#[warn(unused)]`) on by default

warning: `glade-node` (lib) generated 1 warning
warning: field `query` is never read
  --> tests/ic3_auth_fixture/mod.rs:37:9
   |
32 | pub struct Fixture {
   |            ------- field in this struct
...
37 |     pub query: Query,
   |         ^^^^^
   |
   = note: `#[warn(dead_code)]` (part of `#[warn(unused)]`) on by default

warning: `glade-node` (test "ic3_disk") generated 1 warning
    Finished `test` profile [unoptimized + debuginfo] target(s) in 8.83s
     Running tests/ic3_disk.rs (glade/node/target/debug/deps/ic3_disk-79b05533cd314114)

running 1 test

thread 'actual_owned_begin_precedes_factory_and_active_guard_suppresses_complete_cut' (172052937) panicked at tests/ic3_disk.rs:146:10:
durable pre-consumption guard: Unavailable
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace
test actual_owned_begin_precedes_factory_and_active_guard_suppresses_complete_cut ... FAILED

failures:

failures:
    actual_owned_begin_precedes_factory_and_active_guard_suppresses_complete_cut

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 1 filtered out; finished in 0.04s

error: test failed, to rerun pass `--test ic3_disk`

```

## B2 durable guard leading image and actual core combined read GREEN attempt
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--test', 'ic3_disk', '--', '--nocapture']
Exit: 0; wall: 7.360s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
warning: field `query` is never read
  --> tests/ic3_auth_fixture/mod.rs:37:9
   |
32 | pub struct Fixture {
   |            ------- field in this struct
...
37 |     pub query: Query,
   |         ^^^^^
   |
   = note: `#[warn(dead_code)]` (part of `#[warn(unused)]`) on by default

warning: `glade-node` (test "ic3_disk") generated 1 warning
    Finished `test` profile [unoptimized + debuginfo] target(s) in 6.26s
     Running tests/ic3_disk.rs (glade/node/target/debug/deps/ic3_disk-79b05533cd314114)

running 2 tests
test genuine_fresh_replica_opens_owned_validated_genesis_and_reopens_same_identity ... ok
test actual_owned_begin_precedes_factory_and_active_guard_suppresses_complete_cut ... ok

test result: ok. 2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.52s


```

## B2 finite empty signed round settlement and never-started abandonment behavioral RED
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--test', 'ic3_disk', 'finite_authenticated', '--', '--nocapture']
Exit: 101; wall: 1.833s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
warning: field `query` is never read
  --> tests/ic3_auth_fixture/mod.rs:37:9
   |
32 | pub struct Fixture {
   |            ------- field in this struct
...
37 |     pub query: Query,
   |         ^^^^^
   |
   = note: `#[warn(dead_code)]` (part of `#[warn(unused)]`) on by default

warning: `glade-node` (test "ic3_disk") generated 1 warning
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.91s
     Running tests/ic3_disk.rs (glade/node/target/debug/deps/ic3_disk-79b05533cd314114)

running 1 test

thread 'finite_authenticated_empty_round_settles_exact_observation_and_never_started_abandons' (172119919) panicked at tests/ic3_disk.rs:262:5:
exact drained empty snapshot has finite normal completion
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace
test finite_authenticated_empty_round_settles_exact_observation_and_never_started_abandons ... FAILED

failures:

failures:
    finite_authenticated_empty_round_settles_exact_observation_and_never_started_abandons

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 2 filtered out; finished in 0.30s

error: test failed, to rerun pass `--test ic3_disk`

```

## B2 finite exact signed inventory settlement and abandonment GREEN attempt
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--test', 'ic3_disk', '--', '--nocapture']
Exit: 0; wall: 6.078s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
warning: field `query` is never read
  --> tests/ic3_auth_fixture/mod.rs:37:9
   |
32 | pub struct Fixture {
   |            ------- field in this struct
...
37 |     pub query: Query,
   |         ^^^^^
   |
   = note: `#[warn(dead_code)]` (part of `#[warn(unused)]`) on by default

warning: `glade-node` (test "ic3_disk") generated 1 warning
    Finished `test` profile [unoptimized + debuginfo] target(s) in 4.75s
     Running tests/ic3_disk.rs (glade/node/target/debug/deps/ic3_disk-79b05533cd314114)

running 3 tests
test genuine_fresh_replica_opens_owned_validated_genesis_and_reopens_same_identity ... ok
test actual_owned_begin_precedes_factory_and_active_guard_suppresses_complete_cut ... ok
test finite_authenticated_empty_round_settles_exact_observation_and_never_started_abandons ... ok

test result: ok. 3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.75s


```

## B2 invalid next physical image before intent behavioral RED
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'independent::disk::paired::tests::malformed_next', '--', '--nocapture']
Exit: 101; wall: 17.089s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 12.83s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test

thread 'independent::disk::paired::tests::malformed_next_image_is_refused_before_any_intent_or_slot_write' (172138612) panicked at src/independent/disk/paired/tests.rs:430:5:
assertion `left == right` failed: invalid next envelope cannot leave a durable pending intent
  left: [135, 124, 0, 201, 210, 176, 21, 155, 33, 151, 46, 114, 238, 5, 130, 84, 189, 252, 186, 252, 2, 224, 24, 72, 60, 215, 31, 58, 233, 132, 16, 6]
 right: [44, 106, 74, 245, 32, 2, 54, 104, 12, 182, 232, 247, 37, 142, 6, 209, 101, 116, 135, 67, 173, 254, 121, 217, 6, 81, 79, 178, 143, 58, 119, 37]
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace
test independent::disk::paired::tests::malformed_next_image_is_refused_before_any_intent_or_slot_write ... FAILED

failures:

failures:
    independent::disk::paired::tests::malformed_next_image_is_refused_before_any_intent_or_slot_write

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 381 filtered out; finished in 0.05s

error: test failed, to rerun pass `--lib`

```

## B2 complete next physical envelope preflight before writes GREEN
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'independent::disk::paired::tests', '--', '--nocapture']
Exit: 0; wall: 6.608s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 1.87s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 8 tests
test independent::disk::paired::tests::process::pair_cut_child ... ignored, owned child of paired process-kill schedule
test independent::disk::paired::tests::malformed_next_image_is_refused_before_any_intent_or_slot_write ... ok
test independent::disk::paired::tests::nonrecursive_pair_selection_and_exact_pending_fallback_retain_all_floors ... ok
test independent::disk::paired::tests::installed_next_image_finishes_lost_selection_reply_without_hash_recursion ... ok
test independent::disk::paired::tests::failed_recovery_resync_keeps_original_pending_floor_and_does_not_select ... ok
test independent::disk::paired::tests::completed_next_image_installs_exact_guard_settlement_after_missing_selection ... ok
test independent::disk::paired::tests::live_root_substitution_refuses_before_touching_trusted_selection ... ok
test independent::disk::paired::tests::process::actual_process_kill_reopens_every_intent_image_selection_cut ... ok

test result: ok. 7 passed; 0 failed; 1 ignored; 0 measured; 374 filtered out; finished in 3.82s


```

## B2 real signed session persistence and consumed reply restart behavioral RED
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--test', 'ic3_disk', 'genuine_challenge', '--', '--nocapture']
Exit: 101; wall: 3.188s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 2.08s
     Running tests/ic3_disk.rs (glade/node/target/debug/deps/ic3_disk-79b05533cd314114)

running 1 test

thread 'genuine_challenge_response_custody_and_consumption_survive_owned_reopen' (172219433) panicked at tests/ic3_disk.rs:332:10:
genuine challenge persists before response: Unavailable
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace
test genuine_challenge_response_custody_and_consumption_survive_owned_reopen ... FAILED

failures:

failures:
    genuine_challenge_response_custody_and_consumption_survive_owned_reopen

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 3 filtered out; finished in 0.51s

error: test failed, to rerun pass `--test ic3_disk`

```

## B2 genuine signed custody monotonic consume and nonce restart GREEN attempt
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--test', 'ic3_disk', '--', '--nocapture']
Exit: 0; wall: 2.573s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 1.70s
     Running tests/ic3_disk.rs (glade/node/target/debug/deps/ic3_disk-79b05533cd314114)

running 4 tests
test genuine_fresh_replica_opens_owned_validated_genesis_and_reopens_same_identity ... ok
test actual_owned_begin_precedes_factory_and_active_guard_suppresses_complete_cut ... ok
test genuine_challenge_response_custody_and_consumption_survive_owned_reopen ... ok
test finite_authenticated_empty_round_settles_exact_observation_and_never_started_abandons ... ok

test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.28s


```

## B2 genuine local operation real durable terminal and original receipt behavioral RED
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--test', 'ic3_disk', 'actual_genuine_local_commit', '--', '--nocapture']
Exit: 101; wall: 3.251s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 2.64s
     Running tests/ic3_disk.rs (glade/node/target/debug/deps/ic3_disk-79b05533cd314114)

running 1 test

thread 'actual_genuine_local_commit_persists_owned_callback_history_and_exact_original_receipt' (172241218) panicked at tests/ic3_disk.rs:34:6:
called `Result::unwrap()` on an `Err` value: Integrity
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace
test actual_genuine_local_commit_persists_owned_callback_history_and_exact_original_receipt ... FAILED

failures:

failures:
    actual_genuine_local_commit_persists_owned_callback_history_and_exact_original_receipt

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 4 filtered out; finished in 0.00s

error: test failed, to rerun pass `--test ic3_disk`

```

## B2 valid re-signed storage profile local-commit behavioral RED (prior fixture refusal not intended RED)
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--test', 'ic3_disk', 'actual_genuine_local_commit', '--', '--nocapture']
Exit: 101; wall: 1.819s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.70s
     Running tests/ic3_disk.rs (glade/node/target/debug/deps/ic3_disk-79b05533cd314114)

running 1 test

thread 'actual_genuine_local_commit_persists_owned_callback_history_and_exact_original_receipt' (172244218) panicked at tests/ic3_disk.rs:405:10:
actual genuine bounded durable admission path: Unavailable
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace
test actual_genuine_local_commit_persists_owned_callback_history_and_exact_original_receipt ... FAILED

failures:

failures:
    actual_genuine_local_commit_persists_owned_callback_history_and_exact_original_receipt

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 4 filtered out; finished in 0.10s

error: test failed, to rerun pass `--test ic3_disk`

```

## B2 binding helper compiling check
Command: ['cargo', 'check', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib']
Exit: 0; wall: 1.307s
```text
    Checking glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
warning: function `check` is never used
 --> src/independent/records/bindings.rs:5:15
  |
5 | pub(super) fn check<P: PolicyClock>(
  |               ^^^^^
  |
  = note: `#[warn(dead_code)]` (part of `#[warn(unused)]`) on by default

warning: function `qualified` is never used
   --> src/independent/records/bindings.rs:142:4
    |
142 | fn qualified(facts: &Facts) -> bool {
    |    ^^^^^^^^^

warning: function `record` is never used
   --> src/independent/records/bindings.rs:154:15
    |
154 | pub(super) fn record<P: PolicyClock>(
    |               ^^^^^^

warning: function `acceptance_proof` is never used
   --> src/independent/records/bindings.rs:178:15
    |
178 | pub(super) fn acceptance_proof<P: PolicyClock>(
    |               ^^^^^^^^^^^^^^^^

warning: `glade-node` (lib) generated 4 warnings
    Finished `dev` profile [unoptimized + debuginfo] target(s) in 1.26s

```

## B2 native runtime draft compiling local-commit check
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_disk', 'actual_genuine_local_commit', '--', '--exact']
Exit: 0; wall: 3.496s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
warning: unused import: `super::*`
 --> src/independent/records/validation.rs:2:5
  |
2 | use super::*;
  |     ^^^^^^^^
  |
  = note: `#[warn(unused_imports)]` (part of `#[warn(unused)]`) on by default

warning: `glade-node` (lib) generated 1 warning (run `cargo fix --lib -p glade-node` to apply 1 suggestion)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 2.88s
     Running tests/ic3_disk.rs (glade/node/target/debug/deps/ic3_disk-79b05533cd314114)

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 5 filtered out; finished in 0.00s


```

## B2 native runtime local-commit full assertion attempt (correct filter)
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_disk', 'actual_genuine_local_commit']
Exit: 101; wall: 0.534s
```text
warning: unused import: `super::*`
 --> src/independent/records/validation.rs:2:5
  |
2 | use super::*;
  |     ^^^^^^^^
  |
  = note: `#[warn(unused_imports)]` (part of `#[warn(unused)]`) on by default

warning: `glade-node` (lib) generated 1 warning (run `cargo fix --lib -p glade-node` to apply 1 suggestion)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.17s
     Running tests/ic3_disk.rs (glade/node/target/debug/deps/ic3_disk-79b05533cd314114)

running 1 test
test actual_genuine_local_commit_persists_owned_callback_history_and_exact_original_receipt ... FAILED

failures:

---- actual_genuine_local_commit_persists_owned_callback_history_and_exact_original_receipt stdout ----

thread 'actual_genuine_local_commit_persists_owned_callback_history_and_exact_original_receipt' (172296602) panicked at tests/ic3_disk.rs:415:9:
full cached State and Recovery validation
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace


failures:
    actual_genuine_local_commit_persists_owned_callback_history_and_exact_original_receipt

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 4 filtered out; finished in 0.31s

error: test failed, to rerun pass `--test ic3_disk`

```

## B2 full nonempty validator compiling local-commit attempt
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_disk', 'actual_genuine_local_commit']
Exit: 0; wall: 3.473s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 2.36s
     Running tests/ic3_disk.rs (glade/node/target/debug/deps/ic3_disk-79b05533cd314114)

running 1 test
test actual_genuine_local_commit_persists_owned_callback_history_and_exact_original_receipt ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 4 filtered out; finished in 0.51s


```

## B2 stored verified-continuation regression compile attempt
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'original_verified_continuation']
Exit: 101; wall: 1.009s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
error[E0433]: cannot find module or crate `cfg_if` in this scope
   --> src/independent/records.rs:316:1
    |
316 | cfg_if::cfg_if! {
    | ^^^^^^ use of unresolved module or unlinked crate `cfg_if`

error[E0433]: cannot find module or crate `cfg_if` in this scope
  --> src/lib.rs:53:1
   |
53 | cfg_if::cfg_if! {
   | ^^^^^^ use of unresolved module or unlinked crate `cfg_if`

For more information about this error, try `rustc --explain E0433`.
error: could not compile `glade-node` (lib test) due to 2 previous errors

```

## B2 stored verified-continuation compiling regression RED attempt
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'original_verified_continuation']
Exit: 101; wall: 3.683s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
error[E0425]: cannot find type `TrustedCut` in this scope
 --> src/independent/records/tests.rs:7:15
  |
7 | struct Source(TrustedCut);
  |               ^^^^^^^^^^ not found in this scope
  |
help: consider importing this struct through its public re-export
  |
2 + use crate::independent::TrustedCut;
  |

error[E0425]: cannot find type `TrustedCut` in this scope
 --> src/independent/records/tests.rs:9:37
  |
9 |     fn current(&mut self) -> Result<TrustedCut, Fault> {
  |                                     ^^^^^^^^^^ not found in this scope
  |
help: consider importing this struct through its public re-export
  |
2 + use crate::independent::TrustedCut;
  |

error[E0422]: cannot find struct, variant or union type `EvidenceConfig` in this scope
  --> src/independent/records/tests.rs:16:9
   |
16 |         EvidenceConfig {
   |         ^^^^^^^^^^^^^^ not found in this scope
   |
help: consider importing this struct through its public re-export
   |
 2 + use crate::independent::EvidenceConfig;
   |

error[E0422]: cannot find struct, variant or union type `TrustedCut` in this scope
  --> src/independent/records/tests.rs:25:16
   |
25 |         Source(TrustedCut {
   |                ^^^^^^^^^^ not found in this scope
   |
help: consider importing this struct through its public re-export
   |
 2 + use crate::independent::TrustedCut;
   |

error[E0422]: cannot find struct, variant or union type `SessionRequest` in this scope
   --> src/independent/records/../../../tests/ic3_disk/fixture.rs:49:26
    |
 49 |         .issue_challenge(SessionRequest {
    |                          ^^^^^^^^^^^^^^
    |
   ::: /Volumes/projects/limbo/glade-wz/glade/contracts/crdt-storage-attempt-api/src/lib.rs:154:1
    |
154 | pub struct BeginRequest {
    | ----------------------- similarly named struct `BeginRequest` defined here
    |
help: a struct with a similar name exists
    |
 49 -         .issue_challenge(SessionRequest {
 49 +         .issue_challenge(BeginRequest {
    |
help: consider importing this struct through its public re-export
    |
  2 + use crate::independent::SessionRequest;
    |

Some errors have detailed explanations: E0422, E0425.
For more information about an error, try `rustc --explain E0422`.
error: could not compile `glade-node` (lib test) due to 5 previous errors

```

## B2 stored verified-continuation behavioral RED
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'original_verified_continuation']
Exit: 101; wall: 6.958s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 5.86s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test
test independent::records::tests::controls::original_verified_continuation_rejects_mutated_facts_before_load ... FAILED

failures:

---- independent::records::tests::controls::original_verified_continuation_rejects_mutated_facts_before_load stdout ----

thread 'independent::records::tests::controls::original_verified_continuation_rejects_mutated_facts_before_load' (172305934) panicked at src/independent/records/tests/controls.rs:19:5:
mutated stored trusted Facts must be refused before exposing State
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace


failures:
    independent::records::tests::controls::original_verified_continuation_rejects_mutated_facts_before_load

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 382 filtered out; finished in 0.15s

error: test failed, to rerun pass `--lib`

```

## B2 stored verified-continuation regression GREEN
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'original_verified_continuation']
Exit: 0; wall: 4.400s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 3.31s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test
test independent::records::tests::controls::original_verified_continuation_rejects_mutated_facts_before_load ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 382 filtered out; finished in 0.14s


```

## B2 actual native StorageAttemptSession behavioral RED
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_disk', 'actual_native_attempt_provider']
Exit: 101; wall: 2.653s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 1.69s
     Running tests/ic3_disk.rs (glade/node/target/debug/deps/ic3_disk-79b05533cd314114)

running 1 test
test actual_native_attempt_provider_recovers_and_returns_immutable_terminal_for_exact_request ... FAILED

failures:

---- actual_native_attempt_provider_recovers_and_returns_immutable_terminal_for_exact_request stdout ----

thread 'actual_native_attempt_provider_recovers_and_returns_immutable_terminal_for_exact_request' (172309507) panicked at tests/ic3_disk.rs:468:72:
actual physical provider must recover full native attempts
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace


failures:
    actual_native_attempt_provider_recovers_and_returns_immutable_terminal_for_exact_request

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 5 filtered out; finished in 0.37s

error: test failed, to rerun pass `--test ic3_disk`

```

## B2 actual native StorageAttemptSession GREEN
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_disk', 'actual_native_attempt_provider']
Exit: 0; wall: 2.491s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 1.55s
     Running tests/ic3_disk.rs (glade/node/target/debug/deps/ic3_disk-79b05533cd314114)

running 1 test
test actual_native_attempt_provider_recovers_and_returns_immutable_terminal_for_exact_request ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 5 filtered out; finished in 0.37s


```

## B2 actual SIGKILL terminal-before-callback behavioral RED
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'actual_process_kill_recovers_selected_terminal']
Exit: 101; wall: 5.236s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 3.90s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test
test independent::records::tests::restart::actual_process_kill_recovers_selected_terminal_through_original_core_callback_before_load ... FAILED

failures:

---- independent::records::tests::restart::actual_process_kill_recovers_selected_terminal_through_original_core_callback_before_load stdout ----

thread 'independent::records::tests::restart::actual_process_kill_recovers_selected_terminal_through_original_core_callback_before_load' (172313208) panicked at src/independent/records/tests/restart.rs:55:5:
assertion `left == right` failed: before any usable read, replay exact original committed callback
  left: 0
 right: 1
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace


failures:
    independent::records::tests::restart::actual_process_kill_recovers_selected_terminal_through_original_core_callback_before_load

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 384 filtered out; finished in 0.37s

error: test failed, to rerun pass `--lib`

```

## B2 actual SIGKILL terminal-before-callback GREEN
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'actual_process_kill_recovers_selected_terminal']
Exit: 0; wall: 5.054s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 3.70s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test
test independent::records::tests::restart::actual_process_kill_recovers_selected_terminal_through_original_core_callback_before_load ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 384 filtered out; finished in 0.40s


```

## B2 complete selected custody mutation matrix behavioral RED
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'full_selected_state_refuses']
Exit: 101; wall: 5.285s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 3.93s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test
test independent::records::tests::controls::full_selected_state_refuses_omitted_terminal_request_and_mutated_projection ... FAILED

failures:

---- independent::records::tests::controls::full_selected_state_refuses_omitted_terminal_request_and_mutated_projection stdout ----

thread 'independent::records::tests::controls::full_selected_state_refuses_omitted_terminal_request_and_mutated_projection' (172316442) panicked at src/independent/records/tests/controls.rs:48:9:
full selected original custody mutation 0
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace


failures:
    independent::records::tests::controls::full_selected_state_refuses_omitted_terminal_request_and_mutated_projection

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 385 filtered out; finished in 0.37s

error: test failed, to rerun pass `--lib`

```

## B2 complete selected custody mutation matrix GREEN
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'full_selected_state_refuses']
Exit: 0; wall: 3.002s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 1.70s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test
test independent::records::tests::controls::full_selected_state_refuses_omitted_terminal_request_and_mutated_projection ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 385 filtered out; finished in 0.37s


```

## B2 omitted original prepare custody extension behavioral RED
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'full_selected_state_refuses']
Exit: 101; wall: 4.825s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 3.43s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test
test independent::records::tests::controls::full_selected_state_refuses_omitted_terminal_request_and_mutated_projection ... FAILED

failures:

---- independent::records::tests::controls::full_selected_state_refuses_omitted_terminal_request_and_mutated_projection stdout ----

thread 'independent::records::tests::controls::full_selected_state_refuses_omitted_terminal_request_and_mutated_projection' (172319218) panicked at src/independent/records/tests/controls.rs:49:9:
full selected original custody mutation 8
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace


failures:
    independent::records::tests::controls::full_selected_state_refuses_omitted_terminal_request_and_mutated_projection

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 385 filtered out; finished in 0.43s

error: test failed, to rerun pass `--lib`

```

## B2 omitted original prepare custody matrix GREEN
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'full_selected_state_refuses']
Exit: 0; wall: 3.328s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 1.95s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test
test independent::records::tests::controls::full_selected_state_refuses_omitted_terminal_request_and_mutated_projection ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 385 filtered out; finished in 0.42s


```

## B2 genuine native attempt all paired cut compile/behavior RED attempt
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'actual_signed_host_process_kill']
Exit: 101; wall: 3.726s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
error[E0432]: unresolved imports `crate::independent::disk::FloorCut`, `crate::independent::disk::PairCut`, `crate::independent::disk::SlotCut`
  --> src/independent/records/tests/native_cuts.rs:3:32
   |
 3 | use crate::independent::disk::{FloorCut, PairCut, SlotCut};
   |                                ^^^^^^^^  ^^^^^^^  ^^^^^^^ no `SlotCut` in `independent::disk`
   |                                |         |
   |                                |         no `PairCut` in `independent::disk`
   |                                no `FloorCut` in `independent::disk`
   |
note: enum `crate::independent::disk::paired::tests::FloorCut` exists but is inaccessible
  --> src/independent/disk/floors.rs:4:1
   |
 4 | pub(crate) enum FloorCut {
   | ^^^^^^^^^^^^^^^^^^^^^^^^ not accessible
note: enum `crate::independent::disk::paired::PairCut` exists but is inaccessible
  --> src/independent/disk/paired.rs:8:1
   |
 8 | pub(crate) enum PairCut {
   | ^^^^^^^^^^^^^^^^^^^^^^^ not accessible
note: enum `crate::independent::disk::slots::SlotCut` exists but is inaccessible
  --> src/independent/disk/slots.rs:13:1
   |
13 | pub(crate) enum SlotCut {
   | ^^^^^^^^^^^^^^^^^^^^^^^ not accessible

error[E0425]: cannot find type `PairCut` in module `super::disk`
  --> src/independent/records.rs:32:60
   |
32 |     observe_cut: Box<dyn FnMut(DiskOperation, super::disk::PairCut) -> Result<(), Fault> + Send>,
   |                                                            ^^^^^^^ not found in `super::disk`
   |
note: enum `crate::independent::disk::paired::PairCut` exists but is inaccessible
  --> src/independent/disk/paired.rs:8:1
   |
 8 | pub(crate) enum PairCut {
   | ^^^^^^^^^^^^^^^^^^^^^^^ not accessible

Some errors have detailed explanations: E0425, E0432.
For more information about an error, try `rustc --explain E0425`.
error: could not compile `glade-node` (lib test) due to 2 previous errors

```

## B2 genuine native attempt all paired cut behavioral RED
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'actual_signed_host_process_kill']
Exit: 101; wall: 7.245s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 4.02s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test
test independent::records::tests::native_cuts::actual_signed_host_process_kill_reopens_prepare_started_and_terminal_cuts ... FAILED

failures:

---- independent::records::tests::native_cuts::actual_signed_host_process_kill_reopens_prepare_started_and_terminal_cuts stdout ----

thread 'independent::records::tests::native_cuts::actual_signed_host_process_kill_reopens_prepare_started_and_terminal_cuts' (172323861) panicked at src/independent/records/tests/native_cuts.rs:56:93:
native 0/Intent(Renamed) must reattach retained plan: Integrity
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace


failures:
    independent::records::tests::native_cuts::actual_signed_host_process_kill_reopens_prepare_started_and_terminal_cuts

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 387 filtered out; finished in 2.23s

error: test failed, to rerun pass `--lib`

```

## B2 genuine native attempt 57 process-cut GREEN attempt
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'actual_signed_host_process_kill']
Exit: 0; wall: 27.544s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 2.86s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test
test independent::records::tests::native_cuts::actual_signed_host_process_kill_reopens_prepare_started_and_terminal_cuts ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 387 filtered out; finished in 23.76s


```

## B2 all four genuine native kind coupling and reopen controls
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'all_four_genuine_native_kinds']
Exit: 0; wall: 5.956s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 3.58s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test
test independent::records::tests::kinds::all_four_genuine_native_kinds_couple_original_custody_and_reopen_projection ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 388 filtered out; finished in 1.40s


```

## B2 genuine ordinary policy consumes critical reserve behavioral RED
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'genuine_ordinary_policy_observation']
Exit: 101; wall: 4.511s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 3.45s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test
test independent::records::tests::controls::genuine_ordinary_policy_observation_cannot_consume_preallocated_critical_region ... FAILED

failures:

---- independent::records::tests::controls::genuine_ordinary_policy_observation_cannot_consume_preallocated_critical_region stdout ----

thread 'independent::records::tests::controls::genuine_ordinary_policy_observation_cannot_consume_preallocated_critical_region' (172335428) panicked at src/independent/records/tests/controls.rs:74:5:
signed ordinary policy bytes must leave the physically allocated critical region available
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace


failures:
    independent::records::tests::controls::genuine_ordinary_policy_observation_cannot_consume_preallocated_critical_region

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 389 filtered out; finished in 0.09s

error: test failed, to rerun pass `--lib`

```

## B2 genuine ordinary policy protects allocated critical region GREEN
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'genuine_ordinary_policy_observation']
Exit: 0; wall: 3.694s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 2.65s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test
test independent::records::tests::controls::genuine_ordinary_policy_observation_cannot_consume_preallocated_critical_region ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 389 filtered out; finished in 0.06s


```

## B2 native commit and bounded future critical serialization controls
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_disk']
Exit: 0; wall: 5.359s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 3.72s
     Running tests/ic3_disk.rs (glade/node/target/debug/deps/ic3_disk-79b05533cd314114)

running 6 tests
test genuine_fresh_replica_opens_owned_validated_genesis_and_reopens_same_identity ... ok
test actual_owned_begin_precedes_factory_and_active_guard_suppresses_complete_cut ... ok
test genuine_challenge_response_custody_and_consumption_survive_owned_reopen ... ok
test finite_authenticated_empty_round_settles_exact_observation_and_never_started_abandons ... ok
test actual_native_attempt_provider_recovers_and_returns_immutable_terminal_for_exact_request ... ok
test actual_genuine_local_commit_persists_owned_callback_history_and_exact_original_receipt ... ok

test result: ok. 6 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.02s


```

## B2 actual SIGKILL owned seal continuation behavioral RED
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'actual_process_kill_recovers_original_owned_seal']
Exit: 101; wall: 6.086s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 4.87s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test
test independent::records::tests::restart::actual_process_kill_recovers_original_owned_seal_continuation_without_new_link_authority ... FAILED

failures:

---- independent::records::tests::restart::actual_process_kill_recovers_original_owned_seal_continuation_without_new_link_authority stdout ----

thread 'independent::records::tests::restart::actual_process_kill_recovers_original_owned_seal_continuation_without_new_link_authority' (172350322) panicked at src/independent/records/tests/restart.rs:97:5:
assertion `left == right` failed: restore original scoped signed possession/verification continuation, no harness Facts
  left: 0
 right: 1
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace


failures:
    independent::records::tests::restart::actual_process_kill_recovers_original_owned_seal_continuation_without_new_link_authority

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 390 filtered out; finished in 0.23s

error: test failed, to rerun pass `--lib`

```

## B2 actual SIGKILL exact seal continuation GREEN
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'actual_process_kill_recovers_original_owned_seal']
Exit: 0; wall: 4.975s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 3.56s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test
test independent::records::tests::restart::actual_process_kill_recovers_original_owned_seal_continuation_without_new_link_authority ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 390 filtered out; finished in 0.45s


```

## B2 expired current trusted floor preserves old receipt behavioral RED
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'durable_current_expiry_floor']
Exit: 101; wall: 4.904s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 3.48s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test
test independent::records::tests::controls::durable_current_expiry_floor_preserves_historical_original_receipt_and_projection ... FAILED

failures:

---- independent::records::tests::controls::durable_current_expiry_floor_preserves_historical_original_receipt_and_projection stdout ----

thread 'independent::records::tests::controls::durable_current_expiry_floor_preserves_historical_original_receipt_and_projection' (172356331) panicked at src/independent/records/tests/controls.rs:92:63:
current expiry cannot invalidate historical selected receipts
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace


failures:
    independent::records::tests::controls::durable_current_expiry_floor_preserves_historical_original_receipt_and_projection

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 391 filtered out; finished in 0.44s

error: test failed, to rerun pass `--lib`

```

## B2 expired current trusted floor preserves historical receipt GREEN
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'durable_current_expiry_floor']
Exit: 0; wall: 3.036s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 1.57s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test
test independent::records::tests::controls::durable_current_expiry_floor_preserves_historical_original_receipt_and_projection ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 391 filtered out; finished in 0.50s


```

## B2 unavailable verification observed floor behavioral RED
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'unavailable_verification_retains_provider']
Exit: 101; wall: 5.193s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
warning: function `retain_observed` is never used
   --> src/independent/records/runtime.rs:133:15
    |
133 | pub(super) fn retain_observed<P: PolicyClock>(session: &mut DiskSession<P>) -> Result<(), Fault> {
    |               ^^^^^^^^^^^^^^^
    |
    = note: `#[warn(dead_code)]` (part of `#[warn(unused)]`) on by default

warning: `glade-node` (lib test) generated 1 warning
    Finished `test` profile [unoptimized + debuginfo] target(s) in 4.13s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test
test independent::records::tests::controls::unavailable_verification_retains_provider_observed_floor_before_reply ... FAILED

failures:

---- independent::records::tests::controls::unavailable_verification_retains_provider_observed_floor_before_reply stdout ----

thread 'independent::records::tests::controls::unavailable_verification_retains_provider_observed_floor_before_reply' (172360153) panicked at src/independent/records/../../../tests/ic3_disk/fixture.rs:65:10:
called `Result::unwrap()` on an `Err` value: Ownership
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace


failures:
    independent::records::tests::controls::unavailable_verification_retains_provider_observed_floor_before_reply

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 392 filtered out; finished in 0.07s

error: test failed, to rerun pass `--lib`

```

## B2 unavailable verification observed floor actual behavioral RED (refilled trusted certificate configuration)
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'unavailable_verification_retains_provider']
Exit: 101; wall: 3.663s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
warning: function `retain_observed` is never used
   --> src/independent/records/runtime.rs:133:15
    |
133 | pub(super) fn retain_observed<P: PolicyClock>(session: &mut DiskSession<P>) -> Result<(), Fault> {
    |               ^^^^^^^^^^^^^^^
    |
    = note: `#[warn(dead_code)]` (part of `#[warn(unused)]`) on by default

warning: `glade-node` (lib test) generated 1 warning
    Finished `test` profile [unoptimized + debuginfo] target(s) in 2.52s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test
test independent::records::tests::controls::unavailable_verification_retains_provider_observed_floor_before_reply ... FAILED

failures:

---- independent::records::tests::controls::unavailable_verification_retains_provider_observed_floor_before_reply stdout ----

thread 'independent::records::tests::controls::unavailable_verification_retains_provider_observed_floor_before_reply' (172361577) panicked at src/independent/records/tests/controls.rs:129:5:
assertion `left == right` failed: unavailable provider verification must not forget its freshly observed monotone floor
  left: 20
 right: 80
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace


failures:
    independent::records::tests::controls::unavailable_verification_retains_provider_observed_floor_before_reply

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 392 filtered out; finished in 0.18s

error: test failed, to rerun pass `--lib`

```

## B2 unavailable verification observed floor GREEN
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'unavailable_verification_retains_provider']
Exit: 0; wall: 4.025s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 2.85s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test
test independent::records::tests::controls::unavailable_verification_retains_provider_observed_floor_before_reply ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 392 filtered out; finished in 0.23s


```

## B2 actual StorageAttemptHost narrow reopen behavioral RED
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_disk', 'actual_storage_attempt_host_narrow']
Exit: 101; wall: 2.445s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 1.72s
     Running tests/ic3_disk.rs (glade/node/target/debug/deps/ic3_disk-79b05533cd314114)

running 1 test
test actual_storage_attempt_host_narrow_open_preserves_replica_created_namespace_and_owner ... FAILED

failures:

---- actual_storage_attempt_host_narrow_open_preserves_replica_created_namespace_and_owner stdout ----

thread 'actual_storage_attempt_host_narrow_open_preserves_replica_created_namespace_and_owner' (172368885) panicked at tests/ic3_disk.rs:491:75:
actual narrow host must use the retained trusted namespace: Unavailable
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace


failures:
    actual_storage_attempt_host_narrow_open_preserves_replica_created_namespace_and_owner

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 6 filtered out; finished in 0.06s

error: test failed, to rerun pass `--test ic3_disk`

```

## B2 actual StorageAttemptHost narrow reopen GREEN
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_disk', 'actual_storage_attempt_host_narrow']
Exit: 101; wall: 0.649s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
error[E0277]: the trait bound `(String, Instance, [u8; 32], Owner, [u8; 32]): Canonical` is not satisfied
   --> src/independent/records/host.rs:10:32
    |
 10 |           let namespace = encode(&(
    |  _________________________------_^
    | |                         |
    | |                         required by a bound introduced by this call
 11 | |             "glade/ic3/records-plan/v1".to_string(),
 12 | |             evidence.config.descriptor.instance.clone(),
 13 | |             host.roots.registration,
 14 | |             request.owner.clone(),
 15 | |             request.invocation_namespace,
 16 | |         ), &evidence.config.limits).map_err(codec_fault)?.digest();
    | |_________^ unsatisfied trait bound
    |
    = help: the trait `glade_crdt_recovery_codec::Canonical` is not implemented for `(String, glade_crdt_admission_data::Instance, [u8; 32], Owner, [u8; 32])`
help: the trait `glade_crdt_recovery_codec::Canonical` is implemented for `(A, B)`
   --> /Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-codec/src/values.rs:184:1
    |
184 | impl<A: Canonical, B: Canonical> Canonical for (A, B) {
    | ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
note: required by a bound in `glade_crdt_recovery_codec::encode`
   --> /Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-codec/src/lib.rs:39:18
    |
 39 | pub fn encode<T: Canonical>(value: &T, limits: &DecodeLimits) -> Result<Bytes, Error> {
    |                  ^^^^^^^^^ required by this bound in `encode`
    = note: the full name for the type has been written to '/Volumes/projects/limbo/glade-wz/glade/node/target/debug/deps/glade_node-a3fd6730c0faf77d.long-type-10143618848572002729.txt'
    = note: consider using `--verbose` to print the full type name to the console

For more information about this error, try `rustc --explain E0277`.
error: could not compile `glade-node` (lib) due to 1 previous error

```

## B2 actual StorageAttemptHost narrow reopen actual GREEN attempt after closed tuple correction
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--test', 'ic3_disk', 'actual_storage_attempt_host_narrow']
Exit: 0; wall: 2.867s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 2.14s
     Running tests/ic3_disk.rs (glade/node/target/debug/deps/ic3_disk-79b05533cd314114)

running 1 test
test actual_storage_attempt_host_narrow_open_preserves_replica_created_namespace_and_owner ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 6 filtered out; finished in 0.11s


```

## B2 real SIGKILL observed floor ahead of old valid pending image RED
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'actual_process_kill_keeps_new_observed_floor']
Exit: 101; wall: 5.476s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 4.26s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test
test independent::records::tests::observation_restart::actual_process_kill_keeps_new_observed_floor_and_recovers_old_valid_pending_image ... FAILED

failures:

---- independent::records::tests::observation_restart::actual_process_kill_keeps_new_observed_floor_and_recovers_old_valid_pending_image stdout ----

thread 'independent::records::tests::observation_restart::actual_process_kill_keeps_new_observed_floor_and_recovers_old_valid_pending_image' (172376222) panicked at src/independent/records/tests/observation_restart.rs:54:62:
old valid image reattaches while authoritative new floor is never reset: Integrity
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace


failures:
    independent::records::tests::observation_restart::actual_process_kill_keeps_new_observed_floor_and_recovers_old_valid_pending_image

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 394 filtered out; finished in 0.21s

error: test failed, to rerun pass `--lib`

```

## B2 real SIGKILL observed floor ahead of valid old pending image GREEN
Command: ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'glade/node/Cargo.toml', '--lib', 'actual_process_kill_keeps_new_observed_floor']
Exit: 0; wall: 4.160s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 2.89s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test
test independent::records::tests::observation_restart::actual_process_kill_keeps_new_observed_floor_and_recovers_old_valid_pending_image ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 394 filtered out; finished in 0.30s


```

## B2 unknown abandonment retirement compiling behavioral RED
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'unknown_abandon_retains_unretired_owned_permit', '--', '--nocapture']
Exit: 101; wall: 5.050s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 3.98s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test

thread 'independent::records::tests::ingress::unknown_abandon_retains_unretired_owned_permit_until_durable_selection' (172394269) panicked at src/independent/records/tests/ingress.rs:18:5:
unknown physical result must not retire utility capability
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace
test independent::records::tests::ingress::unknown_abandon_retains_unretired_owned_permit_until_durable_selection ... FAILED

failures:

failures:
    independent::records::tests::ingress::unknown_abandon_retains_unretired_owned_permit_until_durable_selection

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 395 filtered out; finished in 0.07s

error: test failed, to rerun pass `--lib`

```

## B2 unknown abandonment retirement GREEN
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'unknown_abandon_retains_unretired_owned_permit', '--', '--nocapture']
Exit: 0; wall: 6.257s
```text
   Compiling glade-crdt-recovery-api v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-api)
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
warning: fields `permit`, `observation`, and `checkpoint` are never read
 --> src/independent/records/persist.rs:4:14
  |
4 |     Settle { permit: IngressPermit, observation: Observation, checkpoint: Checkpoint },
  |     ------   ^^^^^^                 ^^^^^^^^^^^               ^^^^^^^^^^
  |     |
  |     fields in this variant
  |
  = note: `#[warn(dead_code)]` (part of `#[warn(unused)]`) on by default

warning: field `permit` is never read
 --> src/independent/records/persist.rs:5:15
  |
5 |     Abandon { permit: IngressPermit },
  |     -------   ^^^^^^
  |     |
  |     field in this variant

warning: `glade-node` (lib test) generated 2 warnings
    Finished `test` profile [unoptimized + debuginfo] target(s) in 5.14s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test
test independent::records::tests::ingress::unknown_abandon_retains_unretired_owned_permit_until_durable_selection ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 395 filtered out; finished in 0.11s


```

## B2 nonmutating eligibility recovery API retained consumer GREEN
Command: ['cargo', 'test', '--manifest-path', 'glade/contracts/Cargo.toml', '--locked', '--offline', '-p', 'glade-crdt-recovery-api']
Exit: 101; wall: 2.608s
```text
   Compiling glade-crdt-recovery-api v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-api)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.66s
     Running unittests src/lib.rs (glade/contracts/target/debug/deps/glade_crdt_recovery_api-86172c5c56e8b27f)

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/public_contract.rs (glade/contracts/target/debug/deps/public_contract-5bc6e82aa5aa7537)

running 8 tests
test abandoned_capability_cannot_start_work_again ... ok
test cancelled_started_async_receive_does_not_imply_drain_or_abandon ... ok
test another_authority_refuses_before_constructing_or_consuming_future ... ok
test issued_guard_identity_is_not_reissued_by_same_session ... ok
test issuer_capacity_is_finite_and_retirement_does_not_reissue_history ... ok
test eligibility_queries_preserve_owned_lifecycle_and_refuse_foreign_closed_or_started ... ok
test live_never_started_owned_guard_can_abandon_only_once ... ok
test owned_receive_drains_before_settlement_and_close ... ok

test result: ok. 8 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/source_boundaries.rs (glade/contracts/target/debug/deps/source_boundaries-d87c63d050de1dbe)

running 4 tests
test checks_disabled_branch_instead_of_skipping_cfg ... ok
test disabled_associated_foreign_and_field_declarations_are_checked ... ok
test tranche_sources_have_explicit_conditional_boundaries ... ok
test actual_node_independent_subtree_and_disabled_branches_are_checked ... FAILED

failures:

---- actual_node_independent_subtree_and_disabled_branches_are_checked stdout ----

thread 'actual_node_independent_subtree_and_disabled_branches_are_checked' (172397843) panicked at crdt-recovery-api/tests/source_boundaries.rs:94:9:
/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-api/../../node/src/independent/records.rs
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace


failures:
    actual_node_independent_subtree_and_disabled_branches_are_checked

test result: FAILED. 3 passed; 1 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.07s

error: test failed, to rerun pass `-p glade-crdt-recovery-api --test source_boundaries`

```

## B2 unknown abandonment exact by-value retained continuation GREEN
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'unknown_abandon_retains_unretired_owned_permit', '--', '--nocapture']
Exit: 0; wall: 5.650s
```text
   Compiling glade-crdt-recovery-api v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-api)
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 4.58s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test
test independent::records::tests::ingress::unknown_abandon_retains_unretired_owned_permit_until_durable_selection ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 395 filtered out; finished in 0.08s


```

## B2 disabled-scope boundary refusal repaired API consumer GREEN
Command: ['cargo', 'test', '--manifest-path', 'glade/contracts/Cargo.toml', '--locked', '--offline', '-p', 'glade-crdt-recovery-api']
Exit: 0; wall: 0.227s
```text
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.01s
     Running unittests src/lib.rs (glade/contracts/target/debug/deps/glade_crdt_recovery_api-86172c5c56e8b27f)

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/public_contract.rs (glade/contracts/target/debug/deps/public_contract-5bc6e82aa5aa7537)

running 8 tests
test abandoned_capability_cannot_start_work_again ... ok
test another_authority_refuses_before_constructing_or_consuming_future ... ok
test cancelled_started_async_receive_does_not_imply_drain_or_abandon ... ok
test eligibility_queries_preserve_owned_lifecycle_and_refuse_foreign_closed_or_started ... ok
test issuer_capacity_is_finite_and_retirement_does_not_reissue_history ... ok
test issued_guard_identity_is_not_reissued_by_same_session ... ok
test live_never_started_owned_guard_can_abandon_only_once ... ok
test owned_receive_drains_before_settlement_and_close ... ok

test result: ok. 8 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/source_boundaries.rs (glade/contracts/target/debug/deps/source_boundaries-d87c63d050de1dbe)

running 4 tests
test checks_disabled_branch_instead_of_skipping_cfg ... ok
test disabled_associated_foreign_and_field_declarations_are_checked ... ok
test tranche_sources_have_explicit_conditional_boundaries ... ok
test actual_node_independent_subtree_and_disabled_branches_are_checked ... ok

test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.09s

   Doc-tests glade_crdt_recovery_api

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s


```

## B2 inline scoped include consumer path check
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'unknown_abandon_retains_unretired_owned_permit', '--', '--nocapture']
Exit: 101; wall: 0.892s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
error[E0583]: file not found for module `process`
   --> src/independent/disk/paired/tests.rs:340:1
    |
340 | mod process;
    | ^^^^^^^^^^^^
    |
    = help: to create the module `process`, create file "src/independent/disk/paired/process.rs" or "src/independent/disk/paired/process/mod.rs"
    = note: if there is a `mod process` elsewhere in the crate already, import it with `use crate::...` instead

error[E0583]: file not found for module `controls`
  --> src/independent/records/tests.rs:72:1
   |
72 | mod controls;
   | ^^^^^^^^^^^^^
   |
   = help: to create the module `controls`, create file "src/independent/records/controls.rs" or "src/independent/records/controls/mod.rs"
   = note: if there is a `mod controls` elsewhere in the crate already, import it with `use crate::...` instead

error[E0583]: file not found for module `restart`
  --> src/independent/records/tests.rs:74:1
   |
74 | mod restart;
   | ^^^^^^^^^^^^
   |
   = help: to create the module `restart`, create file "src/independent/records/restart.rs" or "src/independent/records/restart/mod.rs"
   = note: if there is a `mod restart` elsewhere in the crate already, import it with `use crate::...` instead

error[E0583]: file not found for module `native_cuts`
  --> src/independent/records/tests.rs:76:1
   |
76 | mod native_cuts;
   | ^^^^^^^^^^^^^^^^
   |
   = help: to create the module `native_cuts`, create file "src/independent/records/native_cuts.rs" or "src/independent/records/native_cuts/mod.rs"
   = note: if there is a `mod native_cuts` elsewhere in the crate already, import it with `use crate::...` instead

error[E0583]: file not found for module `kinds`
  --> src/independent/records/tests.rs:78:1
   |
78 | mod kinds;
   | ^^^^^^^^^^
   |
   = help: to create the module `kinds`, create file "src/independent/records/kinds.rs" or "src/independent/records/kinds/mod.rs"
   = note: if there is a `mod kinds` elsewhere in the crate already, import it with `use crate::...` instead

error[E0583]: file not found for module `observation_restart`
  --> src/independent/records/tests.rs:80:1
   |
80 | mod observation_restart;
   | ^^^^^^^^^^^^^^^^^^^^^^^^
   |
   = help: to create the module `observation_restart`, create file "src/independent/records/observation_restart.rs" or "src/independent/records/observation_restart/mod.rs"
   = note: if there is a `mod observation_restart` elsewhere in the crate already, import it with `use crate::...` instead

error[E0583]: file not found for module `ingress`
  --> src/independent/records/tests.rs:82:1
   |
82 | mod ingress;
   | ^^^^^^^^^^^^
   |
   = help: to create the module `ingress`, create file "src/independent/records/ingress.rs" or "src/independent/records/ingress/mod.rs"
   = note: if there is a `mod ingress` elsewhere in the crate already, import it with `use crate::...` instead

For more information about this error, try `rustc --explain E0583`.
error: could not compile `glade-node` (lib test) due to 7 previous errors

```

## B2 explicit inline scope relative module path consumer GREEN
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'unknown_abandon_retains_unretired_owned_permit', '--', '--nocapture']
Exit: 0; wall: 3.070s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 1.99s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test
test independent::records::tests::ingress::unknown_abandon_retains_unretired_owned_permit_until_durable_selection ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 395 filtered out; finished in 0.10s


```

## B2 close unresolved original native callback compiling behavioral RED
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'close_retains_actual_reserved_plan', '--', '--nocapture']
Exit: 101; wall: 4.691s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 3.46s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test

thread 'independent::records::tests::fences::close_retains_actual_reserved_plan_and_stops_new_input_until_original_callback_drains' (172403271) panicked at src/independent/records/tests/fences.rs:24:5:
assertion `left == right` failed: unresolved original native callback keeps root ownership
  left: Closed
 right: Pending
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace
test independent::records::tests::fences::close_retains_actual_reserved_plan_and_stops_new_input_until_original_callback_drains ... FAILED

failures:

failures:
    independent::records::tests::fences::close_retains_actual_reserved_plan_and_stops_new_input_until_original_callback_drains

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 396 filtered out; finished in 0.26s

error: test failed, to rerun pass `--lib`

```

## B2 close unresolved original native callback GREEN
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'close_retains_actual_reserved_plan', '--', '--nocapture']
Exit: 0; wall: 4.132s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 2.77s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test
test independent::records::tests::fences::close_retains_actual_reserved_plan_and_stops_new_input_until_original_callback_drains ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 396 filtered out; finished in 0.35s


```

## B2 exact conservative durable ingress loss compiling behavioral RED
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'exact_selected_permanent_ingress_loss', '--', '--nocapture']
Exit: 101; wall: 4.689s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 3.61s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test

thread 'independent::records::tests::ingress::exact_selected_permanent_ingress_loss_is_validated_but_never_complete' (172408368) panicked at src/independent/records/tests/ingress.rs:46:5:
exact durable conservative loss is usable for local append, not corruption
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace
test independent::records::tests::ingress::exact_selected_permanent_ingress_loss_is_validated_but_never_complete ... FAILED

failures:

failures:
    independent::records::tests::ingress::exact_selected_permanent_ingress_loss_is_validated_but_never_complete

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 397 filtered out; finished in 0.09s

error: test failed, to rerun pass `--lib`

```

## B2 exact conservative durable ingress loss GREEN
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'exact_selected_permanent_ingress_loss', '--', '--nocapture']
Exit: 0; wall: 6.006s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 4.92s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test
test independent::records::tests::ingress::exact_selected_permanent_ingress_loss_is_validated_but_never_complete ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 397 filtered out; finished in 0.09s


```

## B2 actual drained partial-loss close and conservative restart GREEN
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'drained_partial_receive', '--', '--nocapture']
Exit: 0; wall: 4.801s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 3.69s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test
test independent::records::tests::ingress::drained_partial_receive_can_retain_loss_and_close_without_false_complete_on_restart ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 398 filtered out; finished in 0.15s


```

## B2 actual NodeAssembly success witness genuinely signed input refuser behavioral RED
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--test', 'ic3_boundary', 'production_composition_recovers_a_genuinely_persistent_validated_image', '--', '--ignored', '--exact', '--nocapture']
Exit: 101; wall: 11.356s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
warning: fields `certificate`, `policy`, and `query` are never read
  --> tests/ic3_auth_fixture/mod.rs:35:9
   |
32 | pub struct Fixture {
   |            ------- fields in this struct
...
35 |     pub certificate: SignedRecord,
   |         ^^^^^^^^^^^
36 |     pub policy: SignedRecord,
   |         ^^^^^^
37 |     pub query: Query,
   |         ^^^^^
   |
   = note: `#[warn(dead_code)]` (part of `#[warn(unused)]`) on by default

warning: `glade-node` (test "ic3_boundary") generated 1 warning
    Finished `test` profile [unoptimized + debuginfo] target(s) in 10.40s
     Running tests/ic3_boundary.rs (glade/node/target/debug/deps/ic3_boundary-330d971e6f6496b5)

running 1 test

thread 'production_composition_recovers_a_genuinely_persistent_validated_image' (172416889) panicked at tests/ic3_boundary.rs:54:10:
IC3B assembled open must supply its session: Unavailable
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace
test production_composition_recovers_a_genuinely_persistent_validated_image ... FAILED

failures:

failures:
    production_composition_recovers_a_genuinely_persistent_validated_image

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 5 filtered out; finished in 0.01s

error: test failed, to rerun pass `--test ic3_boundary`

```

## B2 actual configured NodeAssembly genuine physical open GREEN plus unchanged default refusers
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--test', 'ic3_boundary']
Exit: 101; wall: 1.342s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
error[E0603]: enum `Fault` is private
   --> src/assembly.rs:326:96
    |
326 |     ) -> Result<crate::independent::ConfiguredIndependentAdapters<P>, glade_crdt_recovery_api::Fault> {
    |                                                                                                ^^^^^ private enum
    |
note: the enum `Fault` is defined here
   --> /Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-api/src/lib.rs:2:5
    |
  2 | use glade_crdt_admission_data::*;
    |     ^^^^^^^^^^^^^^^^^^^^^^^^^
help: import `Fault` directly
    |
326 -     ) -> Result<crate::independent::ConfiguredIndependentAdapters<P>, glade_crdt_recovery_api::Fault> {
326 +     ) -> Result<crate::independent::ConfiguredIndependentAdapters<P>, glade_crdt_storage_attempt_api::Fault> {
    |

error[E0603]: enum `Fault` is private
  --> src/independent/mod.rs:35:122
   |
35 |     pub(crate) fn new(config: EvidenceConfig, source: P, roots: DiskRootConfig) -> Result<Self, glade_crdt_recovery_api::Fault> {
   |                                                                                                                          ^^^^^ private enum
   |
note: the enum `Fault` is defined here
  --> /Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-api/src/lib.rs:2:5
   |
 2 | use glade_crdt_admission_data::*;
   |     ^^^^^^^^^^^^^^^^^^^^^^^^^
help: import `Fault` directly
   |
35 -     pub(crate) fn new(config: EvidenceConfig, source: P, roots: DiskRootConfig) -> Result<Self, glade_crdt_recovery_api::Fault> {
35 +     pub(crate) fn new(config: EvidenceConfig, source: P, roots: DiskRootConfig) -> Result<Self, glade_crdt_storage_attempt_api::Fault> {
   |

For more information about this error, try `rustc --explain E0603`.
error: could not compile `glade-node` (lib) due to 2 previous errors

```

## B2 actual Reserved fence winner and authentic late/contrary terminal control
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'actual_reserved_fence_wins', '--', '--nocapture']
Exit: 101; wall: 3.962s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
error[E0603]: enum `Fault` is private
   --> src/assembly.rs:326:96
    |
326 |     ) -> Result<crate::independent::ConfiguredIndependentAdapters<P>, glade_crdt_recovery_api::Fault> {
    |                                                                                                ^^^^^ private enum
    |
note: the enum `Fault` is defined here
   --> /Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-api/src/lib.rs:2:5
    |
  2 | use glade_crdt_admission_data::*;
    |     ^^^^^^^^^^^^^^^^^^^^^^^^^
help: import `Fault` directly
    |
326 -     ) -> Result<crate::independent::ConfiguredIndependentAdapters<P>, glade_crdt_recovery_api::Fault> {
326 +     ) -> Result<crate::independent::ConfiguredIndependentAdapters<P>, glade_crdt_storage_attempt_api::Fault> {
    |

error[E0603]: enum `Fault` is private
  --> src/independent/mod.rs:35:122
   |
35 |     pub(crate) fn new(config: EvidenceConfig, source: P, roots: DiskRootConfig) -> Result<Self, glade_crdt_recovery_api::Fault> {
   |                                                                                                                          ^^^^^ private enum
   |
note: the enum `Fault` is defined here
  --> /Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-api/src/lib.rs:2:5
   |
 2 | use glade_crdt_admission_data::*;
   |     ^^^^^^^^^^^^^^^^^^^^^^^^^
help: import `Fault` directly
   |
35 -     pub(crate) fn new(config: EvidenceConfig, source: P, roots: DiskRootConfig) -> Result<Self, glade_crdt_recovery_api::Fault> {
35 +     pub(crate) fn new(config: EvidenceConfig, source: P, roots: DiskRootConfig) -> Result<Self, glade_crdt_storage_attempt_api::Fault> {
   |

For more information about this error, try `rustc --explain E0603`.
error: could not compile `glade-node` (lib test) due to 2 previous errors

```

## B2 actual configured NodeAssembly physical path corrected public Fault import GREEN
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--test', 'ic3_boundary']
Exit: 0; wall: 5.497s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 4.52s
     Running tests/ic3_boundary.rs (glade/node/target/debug/deps/ic3_boundary-330d971e6f6496b5)

running 6 tests
test standalone_refuser_has_no_fabricated_validated_image ... ok
test standalone_refuser_never_issues_a_consume_permit ... ok
test standalone_refuser_rejects_caller_created_permit_before_callback ... ok
test consumer_detects_recovery_selection_mutant_instead_of_discarding_host ... ok
test actual_assembled_evidence_verify_seal_and_observe_refuse ... ok
test production_composition_recovers_a_genuinely_persistent_validated_image ... ok

test result: ok. 6 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.06s


```

## B2 actual Reserved fence winner late and contrary callbacks
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'actual_reserved_fence_wins', '--', '--nocapture']
Exit: 0; wall: 7.662s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 6.29s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test
test independent::records::tests::fences::actual_reserved_fence_wins_and_late_exact_or_contrary_callbacks_never_reopen_terminal ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 399 filtered out; finished in 0.40s


```

## B2 physical guard write failure must not return permit compiling behavioral RED
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'failed_guard_establishment', '--', '--nocapture']
Exit: 101; wall: 4.372s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 3.34s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test

thread 'independent::records::tests::ingress::failed_guard_establishment_never_returns_a_consumable_owned_permit' (172423110) panicked at src/independent/records/tests/ingress.rs:84:5:
a failed real guard write supplies no consume capability
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace
test independent::records::tests::ingress::failed_guard_establishment_never_returns_a_consumable_owned_permit ... FAILED

failures:

failures:
    independent::records::tests::ingress::failed_guard_establishment_never_returns_a_consumable_owned_permit

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 400 filtered out; finished in 0.06s

error: test failed, to rerun pass `--lib`

```

## B2 physical guard write failure no permit GREEN
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'failed_guard_establishment', '--', '--nocapture']
Exit: 0; wall: 3.953s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 2.94s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test
test independent::records::tests::ingress::failed_guard_establishment_never_returns_a_consumable_owned_permit ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 400 filtered out; finished in 0.06s


```

## B2 actual 65 OS guard begin/settle/abandon/loss/consumed-prefix crash cuts
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'actual_process_kill_guard_begin', '--', '--nocapture']
Exit: 101; wall: 0.877s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
error[E0382]: use of partially moved value: `inventory`
  --> src/independent/records/tests/ingress_cuts.rs:14:151
   |
14 | ...e: inventory.instance, source: guard.source, channel: guard.channel, guard: guard.id.clone(), bytes: encode(&(header, inventory), ...
   |       ------------------ value partially moved here                                                                      ^^^^^^^^^ value used here after partial move
   |
   = note: partial move occurs because `inventory.instance` has type `glade_crdt_admission_data::Instance`, which does not implement the `Copy` trait

For more information about this error, try `rustc --explain E0382`.
error: could not compile `glade-node` (lib test) due to 1 previous error

```

## B2 actual65 OS ingress cuts corrected moved fixture
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'actual_process_kill_guard_begin', '--', '--nocapture']
Exit: 0; wall: 13.750s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 4.24s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test
test independent::records::tests::ingress_cuts::actual_process_kill_guard_begin_settle_abandon_loss_and_consumed_prefix_reopen_honestly ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 402 filtered out; finished in 8.50s


```

## B2 full authenticated pending-next validation before selection compiling behavioral RED
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'structurally_valid_pending_next', '--', '--nocapture']
Exit: 101; wall: 4.119s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 2.68s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test

thread 'independent::records::tests::controls::structurally_valid_pending_next_with_bad_authenticated_state_refuses_before_floor_selection' (172430681) panicked at src/independent/records/tests/controls.rs:151:5:
assertion `left == right` failed: invalid-but-structural next must never be selected before full validation
  left: [103, 108, 97, 100, 101, 46, 99, 114, 100, 116, 46, 114, 101, 99, 111, 118, 101, 114, 121, 0, 1, 130, 111, 73, 99, 51, 68, 105, 115, 107, 70, 108, 111, 111, 114, 47, 118, 49, 164, 0, 173, 0, 167, 0, 72, 0, 0, 0, 0, 0, 0, 0, 20, 1, 72, 0, 0, 0, 0, 0, 0, 0, 0, 2, 88, 32, 227, 94, 96, 62, 17, 89, 224, 77, 234, 134, 177, 2, 7, 19, 173, 158, 70, 248, 105, 23, 59, 219, 17, 154, 45, 60, 143, 174, 241, 241, 79, 21, 3, 88, 32, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 4, 88, 32, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 5, 72, 0, 0, 0, 0, 0, 0, 0, 5, 6, 128, 1, 72, 0, 0, 0, 0, 0, 0, 0, 1, 2, 162, 0, 88, 32, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 1, 72, 0, 0, 0, 0, 0, 0, 0, 1, 3, 88, 32, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 4, 88, 32, 169, 53, 241, 176, 86, 7, 250, 2, 70, 238, 194, 196, 85, 46, 215, 93, 157, 202, 255, 78, 123, 93, 248, 42, 127, 184, 28, 90, 202, 244, 78, 33, 5, 72, 0, 0, 0, 0, 0, 0, 0, 1, 6, 72, 0, 0, 0, 0, 0, 0, 0, 26, 7, 163, 0, 1, 1, 72, 0, 0, 0, 0, 0, 0, 0, 13, 2, 88, 32, 227, 68, 82, 242, 222, 166, 173, 233, 196, 226, 74, 59, 125, 184, 94, 46, 83, 22, 97, 255, 49, 143, 24, 218, 109, 20, 236, 136, 94, 100, 176, 190, 8, 72, 0, 0, 0, 0, 0, 0, 0, 2, 9, 72, 0, 0, 0, 0, 0, 0, 0, 5, 10, 72, 0, 0, 0, 0, 0, 0, 0, 0, 11, 128, 12, 246, 1, 246, 2, 246, 3, 128]
 right: [103, 108, 97, 100, 101, 46, 99, 114, 100, 116, 46, 114, 101, 99, 111, 118, 101, 114, 121, 0, 1, 130, 111, 73, 99, 51, 68, 105, 115, 107, 70, 108, 111, 111, 114, 47, 118, 49, 164, 0, 173, 0, 167, 0, 72, 0, 0, 0, 0, 0, 0, 0, 20, 1, 72, 0, 0, 0, 0, 0, 0, 0, 0, 2, 88, 32, 227, 94, 96, 62, 17, 89, 224, 77, 234, 134, 177, 2, 7, 19, 173, 158, 70, 248, 105, 23, 59, 219, 17, 154, 45, 60, 143, 174, 241, 241, 79, 21, 3, 88, 32, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 4, 88, 32, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 5, 72, 0, 0, 0, 0, 0, 0, 0, 5, 6, 128, 1, 72, 0, 0, 0, 0, 0, 0, 0, 1, 2, 162, 0, 88, 32, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 1, 72, 0, 0, 0, 0, 0, 0, 0, 1, 3, 88, 32, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 4, 88, 32, 169, 53, 241, 176, 86, 7, 250, 2, 70, 238, 194, 196, 85, 46, 215, 93, 157, 202, 255, 78, 123, 93, 248, 42, 127, 184, 28, 90, 202, 244, 78, 33, 5, 72, 0, 0, 0, 0, 0, 0, 0, 1, 6, 72, 0, 0, 0, 0, 0, 0, 0, 25, 7, 163, 0, 0, 1, 72, 0, 0, 0, 0, 0, 0, 0, 12, 2, 88, 32, 120, 111, 189, 193, 63, 27, 160, 103, 108, 186, 83, 40, 168, 64, 224, 20, 187, 82, 253, 133, 15, 247, 128, 58, 199, 164, 176, 56, 175, 212, 159, 44, 8, 72, 0, 0, 0, 0, 0, 0, 0, 2, 9, 72, 0, 0, 0, 0, 0, 0, 0, 5, 10, 72, 0, 0, 0, 0, 0, 0, 0, 0, 11, 128, 12, 129, 167, 0, 167, 0, 72, 0, 0, 0, 0, 0, 0, 0, 20, 1, 72, 0, 0, 0, 0, 0, 0, 0, 0, 2, 88, 32, 227, 94, 96, 62, 17, 89, 224, 77, 234, 134, 177, 2, 7, 19, 173, 158, 70, 248, 105, 23, 59, 219, 17, 154, 45, 60, 143, 174, 241, 241, 79, 21, 3, 88, 32, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 4, 88, 32, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 5, 72, 0, 0, 0, 0, 0, 0, 0, 5, 6, 128, 1, 163, 0, 0, 1, 72, 0, 0, 0, 0, 0, 0, 0, 12, 2, 88, 32, 120, 111, 189, 193, 63, 27, 160, 103, 108, 186, 83, 40, 168, 64, 224, 20, 187, 82, 253, 133, 15, 247, 128, 58, 199, 164, 176, 56, 175, 212, 159, 44, 2, 163, 0, 1, 1, 72, 0, 0, 0, 0, 0, 0, 0, 13, 2, 88, 32, 227, 68, 82, 242, 222, 166, 173, 233, 196, 226, 74, 59, 125, 184, 94, 46, 83, 22, 97, 255, 49, 143, 24, 218, 109, 20, 236, 136, 94, 100, 176, 190, 3, 72, 0, 0, 0, 0, 0, 0, 0, 2, 4, 72, 0, 0, 0, 0, 0, 0, 0, 5, 5, 72, 0, 0, 0, 0, 0, 0, 0, 0, 6, 128, 1, 129, 164, 0, 0, 1, 88, 32, 189, 164, 69, 83, 216, 30, 180, 176, 248, 42, 119, 188, 200, 93, 205, 238, 36, 59, 117, 89, 226, 147, 99, 142, 198, 95, 160, 54, 199, 231, 166, 111, 2, 163, 0, 0, 1, 72, 0, 0, 0, 0, 0, 0, 0, 12, 2, 88, 32, 120, 111, 189, 193, 63, 27, 160, 103, 108, 186, 83, 40, 168, 64, 224, 20, 187, 82, 253, 133, 15, 247, 128, 58, 199, 164, 176, 56, 175, 212, 159, 44, 3, 163, 0, 1, 1, 72, 0, 0, 0, 0, 0, 0, 0, 13, 2, 88, 32, 227, 68, 82, 242, 222, 166, 173, 233, 196, 226, 74, 59, 125, 184, 94, 46, 83, 22, 97, 255, 49, 143, 24, 218, 109, 20, 236, 136, 94, 100, 176, 190, 2, 129, 173, 0, 167, 0, 72, 0, 0, 0, 0, 0, 0, 0, 20, 1, 72, 0, 0, 0, 0, 0, 0, 0, 0, 2, 88, 32, 227, 94, 96, 62, 17, 89, 224, 77, 234, 134, 177, 2, 7, 19, 173, 158, 70, 248, 105, 23, 59, 219, 17, 154, 45, 60, 143, 174, 241, 241, 79, 21, 3, 88, 32, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 4, 88, 32, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 5, 72, 0, 0, 0, 0, 0, 0, 0, 5, 6, 128, 1, 72, 0, 0, 0, 0, 0, 0, 0, 1, 2, 162, 0, 88, 32, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 1, 72, 0, 0, 0, 0, 0, 0, 0, 1, 3, 88, 32, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 4, 88, 32, 169, 53, 241, 176, 86, 7, 250, 2, 70, 238, 194, 196, 85, 46, 215, 93, 157, 202, 255, 78, 123, 93, 248, 42, 127, 184, 28, 90, 202, 244, 78, 33, 5, 72, 0, 0, 0, 0, 0, 0, 0, 1, 6, 72, 0, 0, 0, 0, 0, 0, 0, 26, 7, 163, 0, 1, 1, 72, 0, 0, 0, 0, 0, 0, 0, 13, 2, 88, 32, 227, 68, 82, 242, 222, 166, 173, 233, 196, 226, 74, 59, 125, 184, 94, 46, 83, 22, 97, 255, 49, 143, 24, 218, 109, 20, 236, 136, 94, 100, 176, 190, 8, 72, 0, 0, 0, 0, 0, 0, 0, 2, 9, 72, 0, 0, 0, 0, 0, 0, 0, 5, 10, 72, 0, 0, 0, 0, 0, 0, 0, 0, 11, 128, 12, 246, 3, 128]
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace
test independent::records::tests::controls::structurally_valid_pending_next_with_bad_authenticated_state_refuses_before_floor_selection ... FAILED

failures:

failures:
    independent::records::tests::controls::structurally_valid_pending_next_with_bad_authenticated_state_refuses_before_floor_selection

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 403 filtered out; finished in 0.44s

error: test failed, to rerun pass `--lib`

```

## B2 full authenticated pending-next validation before selection GREEN
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'structurally_valid_pending_next', '--', '--nocapture']
Exit: 0; wall: 4.321s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 2.97s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test
test independent::records::tests::controls::structurally_valid_pending_next_with_bad_authenticated_state_refuses_before_floor_selection ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 403 filtered out; finished in 0.37s


```

## B2 full owned-host controls after validated recovery selection boundary
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'independent::records::tests', '--', '--nocapture']
Exit: 0; wall: 30.775s
```text
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.13s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 22 tests
test independent::records::tests::controls::genuine_ordinary_policy_observation_cannot_consume_preallocated_critical_region ... ok
test independent::records::tests::ingress::failed_guard_establishment_never_returns_a_consumable_owned_permit ... ok
test independent::records::tests::ingress_cuts::ingress_cut_child ... ignored, owned real guard process child
test independent::records::tests::ingress::exact_selected_permanent_ingress_loss_is_validated_but_never_complete ... ok
test independent::records::tests::ingress::unknown_abandon_retains_unretired_owned_permit_until_durable_selection ... ok
test independent::records::tests::native_cuts::native_cut_child ... ignored, owned child of authenticated native cut qualification
test independent::records::tests::ingress::drained_partial_receive_can_retain_loss_and_close_without_false_complete_on_restart ... ok
test independent::records::tests::observation_restart::observation_floor_child ... ignored, owned child of genuine observation floor-ahead witness
test independent::records::tests::controls::original_verified_continuation_rejects_mutated_facts_before_load ... ok
test independent::records::tests::controls::unavailable_verification_retains_provider_observed_floor_before_reply ... ok
test independent::records::tests::restart::terminal_before_callback_child ... ignored, owned child of genuine native terminal restart witness
test independent::records::tests::fences::close_retains_actual_reserved_plan_and_stops_new_input_until_original_callback_drains ... ok
test independent::records::tests::fences::actual_reserved_fence_wins_and_late_exact_or_contrary_callbacks_never_reopen_terminal ... ok
test independent::records::tests::controls::structurally_valid_pending_next_with_bad_authenticated_state_refuses_before_floor_selection ... ok
test independent::records::tests::controls::full_selected_state_refuses_omitted_terminal_request_and_mutated_projection ... ok
test independent::records::tests::controls::durable_current_expiry_floor_preserves_historical_original_receipt_and_projection ... ok
test independent::records::tests::observation_restart::actual_process_kill_keeps_new_observed_floor_and_recovers_old_valid_pending_image ... ok
test independent::records::tests::restart::actual_process_kill_recovers_original_owned_seal_continuation_without_new_link_authority ... ok
test independent::records::tests::restart::actual_process_kill_recovers_selected_terminal_through_original_core_callback_before_load ... ok
test independent::records::tests::kinds::all_four_genuine_native_kinds_couple_original_custody_and_reopen_projection ... ok
test independent::records::tests::ingress_cuts::actual_process_kill_guard_begin_settle_abandon_loss_and_consumed_prefix_reopen_honestly ... ok
test independent::records::tests::native_cuts::actual_signed_host_process_kill_reopens_prepare_started_and_terminal_cuts ... ok

test result: ok. 18 passed; 0 failed; 4 ignored; 0 measured; 382 filtered out; finished in 30.60s


```

## B2 original qualified fork with zero new acceptances compiling behavioral RED
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'genuine_already_accepted_fork_proof', '--', '--nocapture']
Exit: 101; wall: 5.233s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 3.72s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test

thread 'independent::records::tests::kinds::genuine_already_accepted_fork_proof_keeps_original_zero_new_receipt_batch_shape' (172436017) panicked at src/independent/records/tests/kinds.rs:66:63:
original full fork proof batch
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace
test independent::records::tests::kinds::genuine_already_accepted_fork_proof_keeps_original_zero_new_receipt_batch_shape ... FAILED

failures:

failures:
    independent::records::tests::kinds::genuine_already_accepted_fork_proof_keeps_original_zero_new_receipt_batch_shape

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 404 filtered out; finished in 0.51s

error: test failed, to rerun pass `--lib`

```

## B2 original qualified fork zero-new-receipt batch GREEN
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'genuine_already_accepted_fork_proof', '--', '--nocapture']
Exit: 0; wall: 3.933s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 2.33s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test
test independent::records::tests::kinds::genuine_already_accepted_fork_proof_keeps_original_zero_new_receipt_batch_shape ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 404 filtered out; finished in 0.63s


```

## B2 actual SIGKILL protected Started winner under genuine current revocation
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'actual_killed_protected_started', '--', '--nocapture']
Exit: 0; wall: 5.375s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 3.89s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test
test independent::records::tests::fences::actual_killed_protected_started_cut_commits_original_receipt_despite_current_revocation ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 405 filtered out; finished in 0.49s


```

## B2 actual171 SIGKILL Candidate/Security/Fork native transaction cuts
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'actual_signed_candidate_security_and_fork', '--', '--nocapture']
Exit: 0; wall: 81.754s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 3.54s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test
test independent::records::tests::native_cuts::actual_signed_candidate_security_and_fork_native_kinds_171_os_cuts has been running for over 60 seconds
test independent::records::tests::native_cuts::actual_signed_candidate_security_and_fork_native_kinds_171_os_cuts ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 406 filtered out; finished in 77.23s


```

## B2 actual owned cancellation/join/close plus X-Y separate namespace progress
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'owned_cancel_is_joined', '--', '--nocapture']
Exit: 0; wall: 5.876s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 4.40s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test
test independent::records::tests::ingress::owned_cancel_is_joined_before_loss_close_and_x_cannot_block_independent_y ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 407 filtered out; finished in 0.48s


```

## B2 utility eligibility not-drained/cancelled controls
Command: ['cargo', 'test', '--manifest-path', 'glade/contracts/Cargo.toml', '--locked', '--offline', '-p', 'glade-crdt-recovery-api']
Exit: 0; wall: 2.705s
```text
   Compiling glade-crdt-recovery-api v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-api)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.62s
     Running unittests src/lib.rs (glade/contracts/target/debug/deps/glade_crdt_recovery_api-86172c5c56e8b27f)

running 1 test
test ingress::tests::live_started_unjoined_receive_refuses_both_retirement_eligibility_queries ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/public_contract.rs (glade/contracts/target/debug/deps/public_contract-5bc6e82aa5aa7537)

running 8 tests
test issuer_capacity_is_finite_and_retirement_does_not_reissue_history ... ok
test another_authority_refuses_before_constructing_or_consuming_future ... ok
test cancelled_started_async_receive_does_not_imply_drain_or_abandon ... ok
test issued_guard_identity_is_not_reissued_by_same_session ... ok
test abandoned_capability_cannot_start_work_again ... ok
test eligibility_queries_preserve_owned_lifecycle_and_refuse_foreign_closed_or_started ... ok
test live_never_started_owned_guard_can_abandon_only_once ... ok
test owned_receive_drains_before_settlement_and_close ... ok

test result: ok. 8 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/source_boundaries.rs (glade/contracts/target/debug/deps/source_boundaries-d87c63d050de1dbe)

running 4 tests
test checks_disabled_branch_instead_of_skipping_cfg ... ok
test disabled_associated_foreign_and_field_declarations_are_checked ... ok
test tranche_sources_have_explicit_conditional_boundaries ... ok
test actual_node_independent_subtree_and_disabled_branches_are_checked ... ok

test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.15s

   Doc-tests glade_crdt_recovery_api

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s


```

## B2 exact by-value unknown settlement and all failed writes restart controls
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'unknown_settlement_keeps', '--', '--nocapture']
Exit: 0; wall: 4.865s
```text
   Compiling glade-crdt-recovery-api v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-api)
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 3.73s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test
test independent::records::tests::ingress::unknown_settlement_keeps_exact_owned_observation_and_failed_loss_write_keeps_floor_guard ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 409 filtered out; finished in 0.08s


```

## B2 finite retired guard history and pre-consumption critical reservation controls
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'guard_history_and_critical', '--', '--nocapture']
Exit: 101; wall: 0.165s
```text
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.12s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test

thread 'independent::records::tests::ingress::guard_history_and_critical_discharge_reservation_refuse_before_new_consumption' (172451256) panicked at src/independent/records/tests.rs:35:6:
called `Result::unwrap()` on an `Err` value: Capacity
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace
test independent::records::tests::ingress::guard_history_and_critical_discharge_reservation_refuse_before_new_consumption ... FAILED

failures:

failures:
    independent::records::tests::ingress::guard_history_and_critical_discharge_reservation_refuse_before_new_consumption

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 409 filtered out; finished in 0.00s

error: test failed, to rerun pass `--lib`

```

## B2 finite guard history corrected explicit session capacity and critical reserve controls
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'guard_history_and_critical', '--', '--nocapture']
Exit: 0; wall: 3.104s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 1.96s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test
test independent::records::tests::ingress::guard_history_and_critical_discharge_reservation_refuse_before_new_consumption ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 409 filtered out; finished in 0.16s


```

## B2 actual physical allocated backing blocks plus critical ordinary refusal
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'genuine_ordinary_policy_observation', '--', '--nocapture']
Exit: 0; wall: 3.999s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 2.96s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test
test independent::records::tests::controls::genuine_ordinary_policy_observation_cannot_consume_preallocated_critical_region ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 409 filtered out; finished in 0.06s


```

## B2 record_observation exact owned refused continuation compiling behavioral RED
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'record_observation_resumes_only_exact', '--', '--nocapture']
Exit: 101; wall: 4.775s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 3.71s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test

thread 'independent::records::tests::ingress::record_observation_resumes_only_exact_owned_drained_refused_continuation' (172456918) panicked at src/independent/records/tests/ingress.rs:169:5:
the exact retained owned continuation can settle after correcting a pre-I/O checkpoint refusal
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace
test independent::records::tests::ingress::record_observation_resumes_only_exact_owned_drained_refused_continuation ... FAILED

failures:

failures:
    independent::records::tests::ingress::record_observation_resumes_only_exact_owned_drained_refused_continuation

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 410 filtered out; finished in 0.06s

error: test failed, to rerun pass `--lib`

```

## B2 record_observation exact owned refused continuation GREEN plus dedup/foreign refusal
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'record_observation_resumes_only_exact', '--', '--nocapture']
Exit: 0; wall: 4.129s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 3.03s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test
test independent::records::tests::ingress::record_observation_resumes_only_exact_owned_drained_refused_continuation ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 410 filtered out; finished in 0.13s


```

## B2 guard critical discharge cannot be refused by ordinary ceiling compiling behavioral RED
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'admitted_guard_critical_loss', '--', '--nocapture']
Exit: 101; wall: 5.076s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 3.93s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test

thread 'independent::records::tests::ingress::admitted_guard_critical_loss_can_settle_when_ordinary_image_region_is_full' (172462959) panicked at src/independent/records/tests/ingress.rs:196:5:
discharging a reserved receive must use its critical region even when ordinary admission has reached its ceiling
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace
test independent::records::tests::ingress::admitted_guard_critical_loss_can_settle_when_ordinary_image_region_is_full ... FAILED

failures:

failures:
    independent::records::tests::ingress::admitted_guard_critical_loss_can_settle_when_ordinary_image_region_is_full

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 411 filtered out; finished in 0.14s

error: test failed, to rerun pass `--lib`

```

## B2 reserved ingress critical discharge beyond ordinary ceiling GREEN
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'admitted_guard_critical_loss', '--', '--nocapture']
Exit: 0; wall: 4.176s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 3.03s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test
test independent::records::tests::ingress::admitted_guard_critical_loss_can_settle_when_ordinary_image_region_is_full ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 411 filtered out; finished in 0.15s


```

## B2 complete owned-host matrix after combined native and ingress critical reservation enforcement
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'independent::records::tests', '--', '--nocapture']
Exit: 0; wall: 100.681s
```text
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.12s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 30 tests
test independent::records::tests::controls::genuine_ordinary_policy_observation_cannot_consume_preallocated_critical_region ... ok
test independent::records::tests::ingress::admitted_guard_critical_loss_can_settle_when_ordinary_image_region_is_full ... ok
test independent::records::tests::ingress::exact_selected_permanent_ingress_loss_is_validated_but_never_complete ... ok
test independent::records::tests::ingress::failed_guard_establishment_never_returns_a_consumable_owned_permit ... ok
test independent::records::tests::ingress::drained_partial_receive_can_retain_loss_and_close_without_false_complete_on_restart ... ok
test independent::records::tests::ingress::unknown_abandon_retains_unretired_owned_permit_until_durable_selection ... ok
test independent::records::tests::ingress::record_observation_resumes_only_exact_owned_drained_refused_continuation ... ok
test independent::records::tests::controls::original_verified_continuation_rejects_mutated_facts_before_load ... ok
test independent::records::tests::ingress_cuts::ingress_cut_child ... ignored, owned real guard process child
test independent::records::tests::controls::unavailable_verification_retains_provider_observed_floor_before_reply ... ok
test independent::records::tests::ingress::unknown_settlement_keeps_exact_owned_observation_and_failed_loss_write_keeps_floor_guard ... ok
test independent::records::tests::fences::actual_reserved_fence_wins_and_late_exact_or_contrary_callbacks_never_reopen_terminal ... ok
test independent::records::tests::fences::close_retains_actual_reserved_plan_and_stops_new_input_until_original_callback_drains ... ok
test independent::records::tests::native_cuts::native_cut_child ... ignored, owned child of authenticated native cut qualification
test independent::records::tests::controls::full_selected_state_refuses_omitted_terminal_request_and_mutated_projection ... ok
test independent::records::tests::observation_restart::observation_floor_child ... ignored, owned child of genuine observation floor-ahead witness
test independent::records::tests::controls::structurally_valid_pending_next_with_bad_authenticated_state_refuses_before_floor_selection ... ok
test independent::records::tests::controls::durable_current_expiry_floor_preserves_historical_original_receipt_and_projection ... ok
test independent::records::tests::restart::terminal_before_callback_child ... ignored, owned child of genuine native terminal restart witness
test independent::records::tests::fences::actual_killed_protected_started_cut_commits_original_receipt_despite_current_revocation ... ok
test independent::records::tests::ingress::guard_history_and_critical_discharge_reservation_refuse_before_new_consumption ... ok
test independent::records::tests::observation_restart::actual_process_kill_keeps_new_observed_floor_and_recovers_old_valid_pending_image ... ok
test independent::records::tests::ingress::owned_cancel_is_joined_before_loss_close_and_x_cannot_block_independent_y ... ok
test independent::records::tests::restart::actual_process_kill_recovers_original_owned_seal_continuation_without_new_link_authority ... ok
test independent::records::tests::kinds::genuine_already_accepted_fork_proof_keeps_original_zero_new_receipt_batch_shape ... ok
test independent::records::tests::restart::actual_process_kill_recovers_selected_terminal_through_original_core_callback_before_load ... ok
test independent::records::tests::kinds::all_four_genuine_native_kinds_couple_original_custody_and_reopen_projection ... ok
test independent::records::tests::ingress_cuts::actual_process_kill_guard_begin_settle_abandon_loss_and_consumed_prefix_reopen_honestly ... ok
test independent::records::tests::native_cuts::actual_signed_host_process_kill_reopens_prepare_started_and_terminal_cuts ... ok
test independent::records::tests::native_cuts::actual_signed_candidate_security_and_fork_native_kinds_171_os_cuts has been running for over 60 seconds
test independent::records::tests::native_cuts::actual_signed_candidate_security_and_fork_native_kinds_171_os_cuts ... ok

test result: ok. 26 passed; 0 failed; 4 ignored; 0 measured; 382 filtered out; finished in 100.52s


```

## B2 syntax-owned cohesion move ingress lifecycle capacity and cancellation controls
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'independent::records::tests::ingress', '--', '--skip', 'ingress_cuts', '--nocapture']
Exit: 0; wall: 6.778s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 4.82s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 9 tests
test independent::records::tests::ingress::failed_guard_establishment_never_returns_a_consumable_owned_permit ... ok
test independent::records::tests::ingress::unknown_abandon_retains_unretired_owned_permit_until_durable_selection ... ok
test independent::records::tests::ingress::exact_selected_permanent_ingress_loss_is_validated_but_never_complete ... ok
test independent::records::tests::ingress_capacity::admitted_guard_critical_loss_can_settle_when_ordinary_image_region_is_full ... ok
test independent::records::tests::ingress::unknown_settlement_keeps_exact_owned_observation_and_failed_loss_write_keeps_floor_guard ... ok
test independent::records::tests::ingress::record_observation_resumes_only_exact_owned_drained_refused_continuation ... ok
test independent::records::tests::ingress::drained_partial_receive_can_retain_loss_and_close_without_false_complete_on_restart ... ok
test independent::records::tests::ingress_capacity::guard_history_and_critical_discharge_reservation_refuse_before_new_consumption ... ok
test independent::records::tests::ingress_cancellation::owned_cancel_is_joined_before_loss_close_and_x_cannot_block_independent_y ... ok

test result: ok. 9 passed; 0 failed; 0 ignored; 0 measured; 403 filtered out; finished in 0.94s


```

## B2 process globals unchanged permanent debt
Command: ['python3', 'glade/scripts/checks/check_process_globals.py', '--repo', 'glade']
Exit: 1; wall: 0.697s
```text
process-global state guard failed for /Volumes/projects/limbo/glade-wz/glade (allowlist: /Volumes/projects/limbo/glade-wz/glade/scripts/checks/process_globals_allowlist.json):
  NEW   env env::var at node/src/independent/disk/paired/tests/process.rs:59
  NEW   env env::var_os at node/src/independent/disk/paired/tests/process.rs:58
  NEW   process Command::new at node/src/independent/disk/paired/tests/process.rs:93
  NEW   process Command::new at node/src/independent/records/tests/fences.rs:153
  NEW   env env::var at node/src/independent/records/tests/ingress_cuts.rs:73, node/src/independent/records/tests/ingress_cuts.rs:77
  NEW   env env::var_os at node/src/independent/records/tests/ingress_cuts.rs:72
  NEW   process Command::new at node/src/independent/records/tests/ingress_cuts.rs:146
  NEW   env env::var at node/src/independent/records/tests/native_cuts.rs:50, node/src/independent/records/tests/native_cuts.rs:54
  NEW   env env::var_os at node/src/independent/records/tests/native_cuts.rs:49
  NEW   process Command::new at node/src/independent/records/tests/native_cuts.rs:124
  NEW   env env::var_os at node/src/independent/records/tests/observation_restart.rs:8
  NEW   process Command::new at node/src/independent/records/tests/observation_restart.rs:52
  NEW   env env::var at node/src/independent/records/tests/restart.rs:8
  NEW   env env::var_os at node/src/independent/records/tests/restart.rs:9
  NEW   process Command::new at node/src/independent/records/tests/restart.rs:83, node/src/independent/records/tests/restart.rs:157
Pass state through the operation/session context instead of the process, and spawn child processes with env_clear() plus the session's environment snapshot. A genuinely process-wide item needs an allowlist entry with a disposition and reason (GwzCoreSessionDesign O9).
note: node/src/independent/disk/paired/tests/process.rs is not reached from a crate root; scanned as production
note: node/src/independent/disk/paired/tests.rs is not reached from a crate root; scanned as production
note: node/src/independent/records/tests/controls.rs is not reached from a crate root; scanned as production
note: node/src/independent/records/tests/fences.rs is not reached from a crate root; scanned as production
note: node/src/independent/records/tests/ingress.rs is not reached from a crate root; scanned as production
note: node/src/independent/records/tests/ingress_cancellation.rs is not reached from a crate root; scanned as production
note: node/src/independent/records/tests/ingress_capacity.rs is not reached from a crate root; scanned as production
note: node/src/independent/records/tests/ingress_cuts.rs is not reached from a crate root; scanned as production
note: node/src/independent/records/tests/kinds.rs is not reached from a crate root; scanned as production
note: node/src/independent/records/tests/native_cuts.rs is not reached from a crate root; scanned as production
note: node/src/independent/records/tests/observation_restart.rs is not reached from a crate root; scanned as production
note: node/src/independent/records/tests/restart.rs is not reached from a crate root; scanned as production
note: node/src/independent/records/tests.rs is not reached from a crate root; scanned as production

```

## B2 node architecture adoption normal and target edges
Command: ['cargo', 'run', '--quiet', '--locked', '--offline', '--manifest-path', 'glade-discover/tools/architecture-check/Cargo.toml', '--', 'glade/node']
Exit: 1; wall: 1.049s
```text
ARCH-005 glade-node: missing/non-executable conformance target ic3_disk

```

## B2 final node genuine auth configured assembly physical consumer and unchanged default controls
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--test', 'ic3_auth', '--test', 'ic3_boundary', '--test', 'ic3_disk', '--test', 'assembly']
Exit: 0; wall: 9.618s
```text
    Blocking waiting for file lock on package cache
    Blocking waiting for file lock on package cache
    Blocking waiting for file lock on package cache
    Blocking waiting for file lock on package cache
   Compiling glade-crdt-recovery-api v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-api)
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
warning: associated functions `open` and `open_with` are never used
   --> src/independent/disk/paired.rs:116:19
    |
 23 | impl PairStore {
    | -------------- associated functions in this implementation
...
116 |     pub(crate) fn open(layout: DiskLayout, bounds: DecodeLimits) -> Result<Self, Fault> {
    |                   ^^^^
...
119 |     pub(crate) fn open_with(
    |                   ^^^^^^^^^
    |
    = note: `#[warn(dead_code)]` (part of `#[warn(unused)]`) on by default

warning: `glade-node` (lib) generated 1 warning
    Finished `test` profile [unoptimized + debuginfo] target(s) in 4.20s
     Running tests/assembly/main.rs (glade/node/target/debug/deps/assembly-3721822e7bd6d1d9)

running 30 tests
test conformance::cl_002_the_fake_clock_reads_epoch_milliseconds ... ok
test conformance::cl_002_the_system_clock_reads_epoch_milliseconds ... ok
test conformance::cl_001_the_fake_clock_is_one_instant_behind_every_handle ... ok
test conformance::gr_001_the_in_memory_fold_matches_exactly ... ok
test conformance::gr_002_in_the_in_memory_fold_revocation_wins_in_either_order ... ok
test conformance::gr_003_an_unreadable_in_memory_fold_is_unavailable ... ok
test conformance::ca_001_the_fake_network_carries_frames_whole_once_and_in_order ... ok
test conformance::ca_006_the_fake_network_binds_each_link_to_its_session ... ok
test conformance::ca_005_the_fake_network_names_each_far_end ... ok
test conformance::ca_004_a_fake_port_gives_its_endpoint_up_by_value ... ok
test a_test_composition_constructs_no_real_provider ... ok
test conformance::gr_003_the_grant_fold_the_module_builds_is_unavailable ... ok
test conformance::ca_003_the_fake_networks_futures_are_lazy_and_recv_is_cancel_safe ... ok
test conformance::si_001_the_keyed_test_signer_round_trips_every_purpose ... ok
test conformance::ca_002_the_fake_network_holds_the_frame_limit_both_ways ... ok
test conformance::si_002_the_keyed_test_signer_binds_bytes_purpose_and_signer ... ok
test conformance::si_003_the_keyed_test_signer_refuses_without_key_material ... ok
test conformance::si_003_the_node_signer_without_a_key_refuses_both_ways ... ok
test each_carrier_role_is_its_own_occurrence_and_the_record_transport_rides_the_peer_one ... ok
test conformance::gr_001_to_003_the_nodes_grant_fold_keeps_the_grant_contract ... ok
test one_clock_substitution_reaches_the_directory_and_admission ... ok
test one_grant_selection_reaches_admission ... ok
test conformance::si_002_the_node_signer_binds_bytes_purpose_and_signer ... ok
test one_scope_hands_out_one_occurrence_of_every_binding ... ok
test one_record_host_selection_reaches_the_directory ... ok
test conformance::si_001_the_node_signer_round_trips_every_purpose ... ok
test records_refuse_an_op_outside_the_directory_profile_before_verifying_it ... ok
test the_directory_profile_hosts_every_directory_record_kind_and_nothing_else ... ok
test sibling_scopes_share_nothing_and_meet_only_through_the_network ... ok
test a_concurrent_first_access_of_a_lazy_binding_constructs_once_per_scope ... ok

test result: ok. 30 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/ic3_auth.rs (glade/node/target/debug/deps/ic3_auth-e1bc2d4362c83d32)

running 16 tests
test ic3_auth_extra::strict_ed25519_refuses_small_order_writer_and_changed_domain ... ok
test provider_observation_is_genuine_current_signed_policy_and_owned_clock ... ok
test genuine_overlimit_operation_is_refused_before_payload_interpretation ... ok
test genuine_historical_admission_verifies_exact_scoped_signed_records ... ok
test ic3_auth_extra::distinct_fresh_origin_qualifies_but_reused_origin_epoch_or_issuance_refuses ... ok
test root_signature_does_not_authorize_an_unsupported_merge_corpus ... ok
test bad_signature_wrong_domain_or_altered_namespace_are_invalid ... ok
test signed_invalid_payload_is_authenticated_security_data_not_qualified_admission ... ok
test released_payload_duplicate_properties_remain_supported ... ok
test trusted_source_cannot_regress_observed_clock_or_policy_floor ... ok
test every_local_verification_requires_new_possession_not_operation_cache_reuse ... ok
test ic3_auth_extra::all_evidence_layers_reject_validly_signed_changed_bindings_or_wrong_keys ... ok
test ic3_auth_extra::bare_signed_rival_does_not_convict_but_original_signed_admission_qualifies ... ok
test local_possession_seal_and_foreign_or_replayed_session_controls ... ok
test uncertain_expired_or_revoked_current_cut_does_not_change_historical_validity ... ok
test genuine_provider_matches_shared_released_text_syntax_rows ... ok

test result: ok. 16 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.03s

     Running tests/ic3_boundary.rs (glade/node/target/debug/deps/ic3_boundary-330d971e6f6496b5)

running 6 tests
test standalone_refuser_has_no_fabricated_validated_image ... ok
test standalone_refuser_never_issues_a_consume_permit ... ok
test standalone_refuser_rejects_caller_created_permit_before_callback ... ok
test consumer_detects_recovery_selection_mutant_instead_of_discarding_host ... ok
test actual_assembled_evidence_verify_seal_and_observe_refuse ... ok
test production_composition_recovers_a_genuinely_persistent_validated_image ... ok

test result: ok. 6 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.05s

     Running tests/ic3_disk.rs (glade/node/target/debug/deps/ic3_disk-79b05533cd314114)

running 7 tests
test genuine_fresh_replica_opens_owned_validated_genesis_and_reopens_same_identity ... ok
test actual_owned_begin_precedes_factory_and_active_guard_suppresses_complete_cut ... ok
test genuine_challenge_response_custody_and_consumption_survive_owned_reopen ... ok
test finite_authenticated_empty_round_settles_exact_observation_and_never_started_abandons ... ok
test actual_storage_attempt_host_narrow_open_preserves_replica_created_namespace_and_owner ... ok
test actual_native_attempt_provider_recovers_and_returns_immutable_terminal_for_exact_request ... ok
test actual_genuine_local_commit_persists_owned_callback_history_and_exact_original_receipt ... ok

test result: ok. 7 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.88s


```

## B2 node clippy ratchet
Command: ['cargo', 'clippy', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '-p', 'glade-node', '--all-targets', '--all-features']
Exit: 0; wall: 11.134s
```text
    Blocking waiting for file lock on package cache
    Blocking waiting for file lock on build directory
    Checking glade-crdt-recovery-api v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-api)
    Checking glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
warning: associated functions `open` and `open_with` are never used
   --> src/independent/disk/paired.rs:116:19
    |
 23 | impl PairStore {
    | -------------- associated functions in this implementation
...
116 |     pub(crate) fn open(layout: DiskLayout, bounds: DecodeLimits) -> Result<Self, Fault> {
    |                   ^^^^
...
119 |     pub(crate) fn open_with(
    |                   ^^^^^^^^^
    |
    = note: `#[warn(dead_code)]` (part of `#[warn(unused)]`) on by default

warning: this can be `std::io::Error::other(_)`
   --> src/claims.rs:138:5
    |
138 |     io::Error::new(io::ErrorKind::Other, e)
    |     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    |
    = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
    = note: `#[warn(clippy::io_other_error)]` on by default
help: use `std::io::Error::other`
    |
138 -     io::Error::new(io::ErrorKind::Other, e)
138 +     io::Error::other(e)
    |

warning: this can be `std::io::Error::other(_)`
  --> src/exchange.rs:53:5
   |
53 |     io::Error::new(io::ErrorKind::Other, e)
   |     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
   |
   = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
help: use `std::io::Error::other`
   |
53 -     io::Error::new(io::ErrorKind::Other, e)
53 +     io::Error::other(e)
   |

warning: this can be `std::io::Error::other(_)`
  --> src/iroh_carrier.rs:68:5
   |
68 |     io::Error::new(io::ErrorKind::Other, e)
   |     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
   |
   = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
help: use `std::io::Error::other`
   |
68 -     io::Error::new(io::ErrorKind::Other, e)
68 +     io::Error::other(e)
   |

warning: large size difference between variants
  --> src/independent/records/persist.rs:3:1
   |
 3 | /   pub(super) enum PendingIngress {
 4 | | /     Settle {
 5 | | |         permit: IngressPermit,
 6 | | |         observation: Observation,
 7 | | |         checkpoint: Checkpoint,
 8 | | |     },
   | | |_____- the largest variant contains at least 2984 bytes
...  |
12 | | /     Loss {
13 | | |         permit: IngressPermit,
14 | | |         observed: Bytes,
15 | | |     },
   | | |_____- the second-largest variant contains at least 368 bytes
16 | |   }
   | |___^ the entire enum is at least 2984 bytes
   |
   = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#large_enum_variant
   = note: `#[warn(clippy::large_enum_variant)]` on by default
help: consider boxing the large fields or introducing indirection in some other way to reduce the total size of the enum
   |
 5 ~         permit: Box<IngressPermit>,
 6 |         observation: Observation,
 7 ~         checkpoint: Box<Checkpoint>,
   |

warning: this can be `std::io::Error::other(_)`
  --> src/mesh.rs:63:5
   |
63 |     io::Error::new(io::ErrorKind::Other, e)
   |     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
   |
   = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
help: use `std::io::Error::other`
   |
63 -     io::Error::new(io::ErrorKind::Other, e)
63 +     io::Error::other(e)
   |

warning: this can be `std::io::Error::other(_)`
   --> src/server.rs:458:18
    |
458 |         other => std::io::Error::new(std::io::ErrorKind::Other, format!("{other:?}")),
    |                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    |
    = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
help: use `std::io::Error::other`
    |
458 -         other => std::io::Error::new(std::io::ErrorKind::Other, format!("{other:?}")),
458 +         other => std::io::Error::other(format!("{other:?}")),
    |

warning: doc list item without indentation
 --> src/ws.rs:3:5
  |
3 | //! (which is text-only) for **binary** frames: glade carries CBOR, not text.
  |     ^
  |
  = help: if this is supposed to be its own paragraph, add a blank line
  = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#doc_lazy_continuation
  = note: `#[warn(clippy::doc_lazy_continuation)]` on by default
help: indent this line
  |
3 | //!   (which is text-only) for **binary** frames: glade carries CBOR, not text.
  |     ++

warning: doc list item without indentation
 --> src/ws.rs:4:5
  |
4 | //! Enough to talk to a browser/Node WebSocket: the upgrade handshake, masked
  |     ^
  |
  = help: if this is supposed to be its own paragraph, add a blank line
  = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#doc_lazy_continuation
help: indent this line
  |
4 | //!   Enough to talk to a browser/Node WebSocket: the upgrade handshake, masked
  |     ++

warning: doc list item without indentation
 --> src/ws.rs:5:5
  |
5 | //! client->server and unmasked server->client binary frames; close surfaced;
  |     ^
  |
  = help: if this is supposed to be its own paragraph, add a blank line
  = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#doc_lazy_continuation
help: indent this line
  |
5 | //!   client->server and unmasked server->client binary frames; close surfaced;
  |     ++

warning: doc list item without indentation
 --> src/ws.rs:6:5
  |
6 | //! ping/pong skipped (trusted localhost).
  |     ^
  |
  = help: if this is supposed to be its own paragraph, add a blank line
  = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#doc_lazy_continuation
help: indent this line
  |
6 | //!   ping/pong skipped (trusted localhost).
  |     ++

warning: `glade-node` (lib) generated 11 warnings (run `cargo clippy --fix --lib -p glade-node -- ` to apply 5 suggestions)
warning: items after a test module
   --> src/independent/records.rs:393:1
    |
393 | mod tests {
    | ^^^^^^^^^
...
396 | impl<P: PolicyClock> StorageAttemptHost for DiskHost<P> {
    | ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
...
403 | impl<P: PolicyClock> ReplicaRecoveryHost for DiskHost<P> {
    | ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    |
    = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#items_after_test_module
    = note: `#[warn(clippy::items_after_test_module)]` on by default
    = help: move the items to before the test module was defined

warning: `glade-node` (lib test) generated 11 warnings (10 duplicates) (run `cargo clippy --fix --lib -p glade-node --tests -- ` to apply 1 suggestion)
    Finished `dev` profile [unoptimized + debuginfo] target(s) in 11.06s

```

## B2 final contracts adopter production selector retained core STA data evidence recovery codec
Command: ['sh', 'glade/contracts/check.sh', 'crdt-production']
Exit: 1; wall: 12.901s
```text
Architecture boundaries: PASS (workspace libraries, declared dependencies, traits and conformance targets)
   Compiling glade-crdt-recovery-api v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-api)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.48s
     Running unittests src/lib.rs (glade/contracts/target/debug/deps/glade_crdt_admission_core-932f6277b6041d9c)

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/encoder_complete.rs (glade/contracts/target/debug/deps/encoder_complete-0c61aeec9660768e)

running 10 tests
test fork::fork_pairs_have_complete_candidate_identity_and_evidence ... ok
test stage::all_staged_candidate_seal_and_receipt_fields ... ok
test plan::namespaces_issuance_owner_and_storage_promise_are_part_of_bytes ... ok
test plan::complete_plan_header_and_optional_local_cut ... ok
test candidate::all_candidate_evidence_and_inner_op_bytes ... ok
test descriptor::all_descriptor_parsed_fields_and_bounds ... ok
test seal_scope::full_seal_descriptor_and_evidence ... ok
test facts::all_staged_facts_and_certificate_fields ... ok
test seal::full_sealing_query_continuations ... ok
test verify::full_verification_query_continuations ... ok

test result: ok. 10 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

     Running tests/fixture_composition.rs (glade/contracts/target/debug/deps/fixture_composition-65d2eb16df52c7d1)

running 7 tests
test mandatory_text_replica_journeys_do_not_construct_fresh_host_per_drive_call ... ok
test historical_prior_cut_fixture_registers_multiline_inspect_through_full_helper ... ok
test lookup_fixture_owns_full_request_and_bounded_history_not_only_secondary_index ... ok
test trusted_seed_retains_reservations_outcomes_and_rejects_inconsistent_history ... ok
test configured_provider_matches_core_cut_and_changes_independently ... ok
test seeded_terminal_requires_original_custody_and_accounting ... ok
test seeded_custody_is_explicit_and_consecutive_port_publications_keep_history ... ok

test result: ok. 7 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/kernel_edges.rs (glade/contracts/target/debug/deps/kernel_edges-0e6067bcb16c3e14)

running 21 tests
test admission::oversized_proof_cannot_allocate_a_verification_continuation ... ok
test admission::pending_origins_reserve_the_origin_limit_before_verification ... ok
test admission::restored_fork_cut_derives_one_coherent_quarantine_and_eligible_set ... ok
test admission::retained_candidates_and_verifications_share_pending_capacity ... ok
test encoder::storage_batch_limit_refuses_before_any_prepare_or_invocation ... ok
test admission::outstanding_verification_prevents_complete_local_and_is_bounded ... ok
test frontier::already_retained_exact_frontier_hash_preserves_complete_local ... ok
test frontier::empty_peer_frontier_offers_all_local_history ... ok
test frontier::frontier_union_cannot_exceed_pending_items_or_clear_previous_observation ... ok
test admission::signed_historical_rival_outside_permit_sequence_is_security_not_conviction ... ok
test admission::committed_local_custody_retains_the_actual_seal_named_by_original_receipt ... ok
test admission::signed_invalid_payload_is_security_custody_without_conviction ... ok
test encoder::full_encoded_continuation_footprint_consumes_edit_quota ... ok
test storage::prepared_reply_cannot_replace_original_attempt_mapping ... ok
test encoder::unretained_historical_batch_due_to_encoder_limit_is_sticky_incomplete ... ok
test storage::lost_prepare_ack_can_recover_original_plan_while_original_invocation_is_live ... ok
test frontier::different_arriving_hash_cannot_complete_an_announced_missing_slot ... ok
test storage::prepare_request_from_retained_old_owner_has_no_current_callback_authority ... ok
test admission::no_prior_admission_local_intent_keeps_real_seal_for_historical_replay ... ok
test frontier::announced_missing_frontier_survives_unrelated_publication ... ok
test encoder::encoder_is_deterministic_and_binds_descriptor_facts_and_seal_continuations ... ok

test result: ok. 21 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/records_host_contract.rs (glade/contracts/target/debug/deps/records_host_contract-377bbaa390d43bf2)

running 22 tests
test icd003_legacy_and_strong_descriptors_do_not_activate_independent_admission ... ok
test icd007_zero_base_prev_refs_and_exact_safe_numbers ... ok
test icd006_stale_verification_after_policy_change_cannot_seal_or_commit ... ok
test icd005_evidence_reply_binds_mode_bytes_scope_and_candidate ... ok
test icd006_delayed_prior_cut_committed_callback_retains_historical_admission ... ok
test icd002_partitioned_admission_commits_without_a_holder ... ok
test icd004_same_display_names_do_not_share_instance_rights_or_callbacks ... ok
test icd006_historical_authorization_is_separate_from_current_revocation ... ok
test icd006_offline_window_and_clock_uncertainty_refuse_new_intent ... ok
test icd007_reused_canonical_origin_and_numeric_overflow_refuse ... ok
test icd010_old_receipt_retry_does_not_reauthorize_or_reappend ... ok
test icd010_lookup_recovery_binds_request_and_restores_original_receipt ... ok
test icd010_unknown_commit_retains_reservation_and_foreign_callback_cannot_accept ... ok
test icd013_edit_capacity_preserves_recovery_reserves ... ok
test icd008_successor_requests_predecessor_without_advancing_head ... ok
test icd010_commit_callbacks_bind_batch_revision_and_have_three_distinct_outcomes ... ok
test icd007_new_epoch_uses_new_origin_and_old_retries_stay_old ... ok
test icd013_recovery_exhaustion_is_explicit_and_cannot_spend_edit_budget ... ok
test prior_cut_inspect40_distinguishes_issued_authority_from_identical_unissued_reply ... ok
test icd009_qualified_dependent_custody_survives_quarantined_support_but_local_intent_refuses ... ok
test icd009_two_qualified_rivals_quarantine_both_and_dependents_in_either_order ... ok
test icd006_revoked_expired_unadmitted_rival_preserves_ad_and_receipts ... ok

test result: ok. 22 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

     Running tests/recovery_contract.rs (glade/contracts/target/debug/deps/recovery_contract-8cab13edcccedff2)

running 6 tests
test lookup_invocation_counter_exhaustion_refuses_without_wrap_or_reservation_loss ... ok
test trusted_restoration_invalidates_live_lookup_and_preserves_identity_high_water ... ok
test retention_committed_lookup_binds_batch_storage_revision_and_empty_receipts ... ok
test repeated_unknown_lookup_retires_invocation_and_old_replies_preserve_new_lookup ... ok
test genuine_e0_fork_then_fresh_e1_local_recovery_keeps_ab_and_old_receipts_both_orders ... ok
test every_atomic_kind_recovers_committed_absent_and_unknown_without_fake_admission ... ok

test result: ok. 6 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.02s

     Running tests/remediation1.rs (glade/contracts/target/debug/deps/remediation1-be8535f3fccf7f31)

running 16 tests
test frontier::frontier_names_empty_exact_limit_over_limit_and_huge_are_bounded ... ok
test integrity::already_qualified_fork_cannot_stage_new_work_after_stop ... ok
test pending::multiple_candidates_and_frontier_slots_share_deduplicated_prospective_cap ... ok
test frontier::frontier_bytes_include_existing_candidate_charge_and_parked_verification ... ok
test frontier::frontier_retained_slot_aggregate_bytes_exact_boundary_and_one_over ... ok
test exhaustion::local_intent_counter_refusal_alone_does_not_taint_known_history ... ok
test pending::frontier_cannot_steal_slots_reserved_by_an_unpublished_candidate_plan ... ok
test exhaustion::historical_plan_exhaustion_remains_sticky_through_resume_restore ... ok
test pending::predecessor_and_ref_to_the_same_missing_slot_emit_one_request ... ok
test pending::prospective_two_missing_slots_refuse_before_emission_or_candidate_staging ... ok
test exhaustion::historical_query_exhaustion_remains_sticky_through_resume_restore ... ok
test integrity::integrity_stop_preserves_owned_started_attempt_and_genuine_late_commit ... ok
test terminal::late_pending_and_refused_never_reopen_an_authentic_terminal ... ok
test integrity::parked_verification_and_seal_cannot_create_new_work_after_authenticated_stop ... ok
test pending::exact_slot_limit_and_overlap_union_commit_without_duplicate_reservations ... ok
test terminal::held_started_and_terminal_inspect_both_orders_all_four_kinds_and_outcomes ... ok

test result: ok. 16 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

     Running tests/remediation2.rs (glade/contracts/target/debug/deps/remediation2-c6ddfa10c99b9612)

running 3 tests
test two_issued_queries_verified_historical_b_during_held_started_a_is_explicitly_incomplete ... ok
test fresh_historical_offer_during_held_started_a_is_explicitly_incomplete ... ok
test local_intent_only_busy_refusal_does_not_taint_known_history ... ok

test result: ok. 3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

     Running tests/representation.rs (glade/contracts/target/debug/deps/representation-b4c77cef7d79e0fa)

running 2 tests
test operation_bytes_and_digest_are_derived_and_owned ... ok
test pure_step_is_deterministic_preserves_caller_input_and_read_only_state ... ok

test result: ok. 2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/source_boundaries.rs (glade/contracts/target/debug/deps/source_boundaries-cfcb6000711a5cc4)

running 4 tests
test ic3_data_boundary_is_independent_of_the_pure_algorithm ... ok
test checks_disabled_branch_instead_of_skipping_cfg ... ok
test disabled_associated_foreign_and_field_declarations_are_checked ... ok
test tranche_sources_have_explicit_conditional_boundaries ... ok

test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.15s

     Running tests/storage_attempt_contract.rs (glade/contracts/target/debug/deps/storage_attempt_contract-a98f1e5df7b04b9e)

running 15 tests
test sta008_critical_pending_does_not_release_semantic_reservation ... ok
test sta009_restored_attempt_and_invocation_floors_preserve_pending ... ok
test sta006_current_prestart_observation_emits_fence_without_erasing_plan ... ok
test sta005_contradictory_terminal_stops_instance_after_once_only_installation ... ok
test identical_unissued_lookup_reply_cannot_acquire_callback_authority ... ok
test issued_lookup_retains_full_request_on_consumption ... ok
test sta001_callback_complete_binding_and_finite_invocation_namespace ... ok
test sta005_unissued_foreign_or_changed_retired_callback_cannot_create_integrity_stop ... ok
test sta003_pending_lookup_retains_started_write_until_late_commit_all_kinds ... ok
test sta002_kernel_prepare_keeps_exact_plan_after_lost_ack ... ok
test sta007_all_kinds_install_original_terminal_without_double_charge ... ok
test sta004_noncommit_retains_tombstone_and_rescheduling_uses_fresh_plan ... ok
test sta010_overflow_is_sticky_distinct_from_charges_and_partial_repair ... ok
test sta011_existing_twenty_seven_and_text_consumers_keep_actual_port_path ... ok
test sta011_driver_uses_caller_owned_session_across_continuations ... ok

test result: ok. 15 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running unittests src/lib.rs (glade/contracts/target/debug/deps/glade_crdt_admission_data-829261682f5780f4)

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/representation.rs (glade/contracts/target/debug/deps/representation-a11dd961075c09ca)

running 1 test
test canonical_operation_owns_bytes_and_recomputes_digest ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/source_boundaries.rs (glade/contracts/target/debug/deps/source_boundaries-15d7213681b61363)

running 3 tests
test checks_disabled_branch_instead_of_skipping_cfg ... ok
test disabled_associated_foreign_and_field_declarations_are_checked ... ok
test tranche_sources_have_explicit_conditional_boundaries ... ok

test result: ok. 3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

     Running unittests src/lib.rs (glade/contracts/target/debug/deps/glade_crdt_evidence_api-0ab689c801ef5981)

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/public_contract.rs (glade/contracts/target/debug/deps/public_contract-a450847ecdbb9cfb)

running 2 tests
test concrete_provider_must_supply_all_three_trusted_operations ... ok
test required_evidence_methods_have_no_default_provider ... ok

test result: ok. 2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/source_boundaries.rs (glade/contracts/target/debug/deps/source_boundaries-d9ef5b5c6b238cc5)

running 3 tests
test checks_disabled_branch_instead_of_skipping_cfg ... ok
test disabled_associated_foreign_and_field_declarations_are_checked ... ok
test tranche_sources_have_explicit_conditional_boundaries ... ok

test result: ok. 3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running unittests src/lib.rs (glade/contracts/target/debug/deps/glade_crdt_recovery_api-86172c5c56e8b27f)

running 1 test
test ingress::tests::live_started_unjoined_receive_refuses_both_retirement_eligibility_queries ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/public_contract.rs (glade/contracts/target/debug/deps/public_contract-5bc6e82aa5aa7537)

running 8 tests
test abandoned_capability_cannot_start_work_again ... ok
test another_authority_refuses_before_constructing_or_consuming_future ... ok
test cancelled_started_async_receive_does_not_imply_drain_or_abandon ... ok
test issued_guard_identity_is_not_reissued_by_same_session ... ok
test issuer_capacity_is_finite_and_retirement_does_not_reissue_history ... ok
test eligibility_queries_preserve_owned_lifecycle_and_refuse_foreign_closed_or_started ... ok
test live_never_started_owned_guard_can_abandon_only_once ... ok
test owned_receive_drains_before_settlement_and_close ... ok

test result: ok. 8 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/source_boundaries.rs (glade/contracts/target/debug/deps/source_boundaries-d87c63d050de1dbe)

running 4 tests
test checks_disabled_branch_instead_of_skipping_cfg ... ok
test disabled_associated_foreign_and_field_declarations_are_checked ... ok
test tranche_sources_have_explicit_conditional_boundaries ... ok
test actual_node_independent_subtree_and_disabled_branches_are_checked ... ok

test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.25s

     Running unittests src/lib.rs (glade/contracts/target/debug/deps/glade_crdt_recovery_codec-249926a6c91406e4)

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/batch_decode.rs (glade/contracts/target/debug/deps/batch_decode-c338073ef4bd3146)

running 3 tests
test unchanged_private_encoder_has_a_complete_bounded_decoder ... ok
test batch_operations_share_the_existing_aggregate_item_budget ... ok
test interned_blob_references_cannot_amplify_owned_decoding_past_budget ... ok

test result: ok. 3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/image.rs (glade/contracts/target/debug/deps/image-ff97efb1b877942d)

running 4 tests
test interrupted_intent_preserves_issuance_and_guard_floors_without_next_image ... ok
test full_image_retains_all_kernel_callbacks_attempts_guards_issuance_and_loss ... ok
test image_hash_and_external_selection_do_not_require_a_hash_fixed_point ... ok
test corrupt_truncated_trailing_unknown_versions_and_capacity_fail_closed ... ok

test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.29s

     Running tests/remediation1.rs (glade/contracts/target/debug/deps/remediation1-4606bedf9a4f1344)

running 6 tests
test root_operation_name_limit_applies_inside_opaque_canonical_bytes ... ok
test root_operation_depth_includes_the_embedded_interpretation_boundary ... ok
test root_operation_item_budget_includes_interpreted_refs_cumulatively ... ok
test nested_candidate_and_remote_transfer_cannot_hide_operation_name ... ok
test repeated_nested_operations_share_one_budget_not_one_budget_each ... ok
test concrete_container_roots_cannot_substitute_plan_for_guard ... ok

test result: ok. 6 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/roundtrip.rs (glade/contracts/target/debug/deps/roundtrip-afbf6185948b82a4)

running 6 tests
test accepted_signature_domains_are_full_and_zero_terminated ... ok
test type_domain_cannot_substitute_plan_identity_for_receive_guard ... ok
test remote_profile_is_exact_canonical_integer_key_map_without_recovery_magic ... ok
test inventory_empty_is_exact_observation_not_a_completeness_claim ... ok
test proof_body_requires_exact_purpose_version_signature_shape_and_type ... ok
test identity_roundtrip_preserves_full_namespaces_and_unsigned_floor ... ok

test result: ok. 6 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/source_boundaries.rs (glade/contracts/target/debug/deps/source_boundaries-b49e6bf7138dd73f)

running 3 tests
test checks_disabled_branch_instead_of_skipping_cfg ... ok
test disabled_associated_foreign_and_field_declarations_are_checked ... ok
test tranche_sources_have_explicit_conditional_boundaries ... ok

test result: ok. 3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.05s

     Running tests/vectors.rs (glade/contracts/target/debug/deps/vectors-e6054aa97de7077a)

running 4 tests
test closed_maps_reject_unknown_duplicate_reordered_or_wrong_context_fields ... ok
test bounded_malformed_canonical_vectors_fail_closed ... ok
test malformed_signature_length_and_wrong_exact_domain_refuse_signed_envelope_shape ... ok
test all_remote_profile_categories_derive_exact_bytes_and_digests_from_semantic_inputs ... ok

test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running unittests src/lib.rs (glade/contracts/target/debug/deps/glade_crdt_storage_attempt_api-183ed550d5084400)

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/conformance_mutants.rs (glade/contracts/target/debug/deps/conformance_mutants-62cbd41425c44fca)

running 1 test
test shared_public_port_probe_accepts_fixture_and_rejects_six_semantic_mutants ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/public_contract.rs (glade/contracts/target/debug/deps/public_contract-5dd65e92533e6d9b)

running 28 tests
test finite_attempt_invocation_and_name_bounds_refuse_without_wrap ... ok
test historical_accepted_batch_keeps_original_receipt_without_local_prestart ... ok
test host_serialized_observation_cannot_be_replaced_by_caller_current_claim ... ok
test restoration_rejects_corrupt_cardinality_floor_and_history_limit ... ok
test restored_capacity_and_binding_phase_consistency_are_validated ... ok
test restored_started_and_committed_cuts_must_fit_their_immutable_windows ... ok
test restored_noncommit_must_retain_its_bindings_unchanged_revision ... ok
test lost_prepare_ack_and_queued_late_prepare_recover_exactly_one_attempt ... ok
test authentic_two_commit_recovery_rejects_distinct_duplicate_revision ... ok
test full_retained_commit_history_rejects_missing_head_gaps_and_unbacked_current_revision ... ok
test sta001_exact_binding_exhaustion_and_invocation_identity ... ok
test sta002_exact_plan_dedup_no_overlap_and_independent_instances ... ok
test restoration_rejects_identity_and_unresolved_overlap_but_keeps_history_and_y ... ok
test sta004_fence_excludes_late_begin_and_reprepare_uses_new_identity ... ok
test sequential_commits_repeated_noncommit_and_independent_revision_spaces_restore ... ok
test sta003_absent_terminal_is_pending_for_all_kinds ... ok
test sta005_commit_wins_fence_race_and_receipts_are_original ... ok
test sta007_retention_receipts_cannot_be_synthetic ... ok
test sta006_prestart_checks_entire_window_and_historical_has_no_current_admit_check ... ok
test sta009_exclusive_recovery_and_close_keep_issuance_floors ... ok
test started_cut_is_not_rechecked_after_revocation_or_delayed_begin_ack ... ok
test started_absent_lookup_late_publication_and_fence_use_same_predicate ... ok
test sta008_critical_reserve_exhaustion_cannot_manufacture_negative_finality ... ok
test trusted_observation_injection_has_finite_instance_and_name_bounds ... ok
test validated_restore_retains_all_attempts_and_invocation_namespace_without_auto_commit ... ok
test reopen_validates_retained_consumption_before_changing_owner_or_floors ... ok
test sparse_invocation_restore_preserves_actual_remaining_capacity ... ok
test fresh_revision_mismatch_refuses_before_reserved_or_queued_for_every_kind ... ok

test result: ok. 28 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/source_boundaries.rs (glade/contracts/target/debug/deps/source_boundaries-625bf4e5641d0a44)

running 5 tests
test checks_disabled_branch_instead_of_skipping_cfg ... ok
test disabled_associated_foreign_and_field_declarations_are_checked ... ok
test rejects_missing_identity_callback_ownership_and_terminality_fields ... ok
test actual_port_preserves_required_boundary_shape ... ok
test tranche_sources_have_explicit_conditional_boundaries ... ok

test result: ok. 5 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.05s

   Doc-tests glade_crdt_admission_core

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

   Doc-tests glade_crdt_admission_data

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

   Doc-tests glade_crdt_evidence_api

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

   Doc-tests glade_crdt_recovery_api

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

   Doc-tests glade_crdt_recovery_codec

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

   Doc-tests glade_crdt_storage_attempt_api

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

Diff in /Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-api/tests/public_contract.rs:26:
     }
 }
 use std::{
-    future::{ready, Future},
+    future::{Future, ready},
     pin::Pin,
     task::{Context, Poll, Waker},
 };

```

## B2 scoped adopter module reachability compiling control
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'independent::records::tests', '--', '--skip', 'ingress_cuts', '--skip', 'native_cuts', '--skip', 'fences', '--skip', 'observation_restart', '--skip', 'restart', '--nocapture']
Exit: 101; wall: 2.140s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
error[E0308]: mismatched types
   --> src/independent/records/tests/../tests/ingress.rs:239:22
    |
239 |     assert_eq!(kept, observation);
    |                      ^^^^^^^^^^^ expected `Box<Observation>`, found `Observation`
    |
    = note: expected struct `Box<glade_crdt_admission_data::Observation>`
               found struct `glade_crdt_admission_data::Observation`
    = note: for more on the distinction between the stack and the heap, read https://doc.rust-lang.org/book/ch15-01-box.html, https://doc.rust-lang.org/rust-by-example/std/box.html, and https://doc.rust-lang.org/std/boxed/index.html
help: store this in the heap by calling `Box::new`
    |
239 |     assert_eq!(kept, Box::new(observation));
    |                      +++++++++           +

error[E0308]: mismatched types
   --> src/independent/records/tests/../tests/ingress.rs:240:28
    |
240 |     assert_eq!(checkpoint, expected);
    |                            ^^^^^^^^ expected `Box<Checkpoint>`, found `Checkpoint`
    |
    = note: expected struct `Box<glade_crdt_admission_data::Checkpoint>`
               found struct `glade_crdt_admission_data::Checkpoint`
    = note: for more on the distinction between the stack and the heap, read https://doc.rust-lang.org/book/ch15-01-box.html, https://doc.rust-lang.org/rust-by-example/std/box.html, and https://doc.rust-lang.org/std/boxed/index.html
help: store this in the heap by calling `Box::new`
    |
240 |     assert_eq!(checkpoint, Box::new(expected));
    |                            +++++++++        +

For more information about this error, try `rustc --explain E0308`.
error: could not compile `glade-node` (lib test) due to 2 previous errors

```

## B2 canonical independent three-language candidate vectors
Command: ['sh', 'glade/contracts/crdt-recovery-codec/check-vectors.sh']
Exit: 0; wall: 0.832s
```text
Candidate content representation PASS; unqualified for remote use until committed pin and accepted B1 crypto
......
----------------------------------------------------------------------
Ran 6 tests in 0.567s

OK
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.01s
     Running tests/vectors.rs (glade/contracts/target/debug/deps/vectors-e6054aa97de7077a)

running 4 tests
test closed_maps_reject_unknown_duplicate_reordered_or_wrong_context_fields ... ok
test malformed_signature_length_and_wrong_exact_domain_refuse_signed_envelope_shape ... ok
test bounded_malformed_canonical_vectors_fail_closed ... ok
test all_remote_profile_categories_derive_exact_bytes_and_digests_from_semantic_inputs ... ok

test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

Python independent profile vectors: 21 positive + negative controls PASS
(node:37366) ExperimentalWarning: Transform Types is an experimental feature and might change at any time
(Use `node --trace-warnings ...` to show where the warning was created)
TypeScript independent profile vectors: 21 positive + 18 negative controls PASS

```

## B2 final explicit test-boundary reachability source guard
Command: ['python3', 'glade/scripts/checks/check_process_globals.py', '--repo', 'glade']
Exit: 0; wall: 0.637s
```text
process-global state guard: 148 files, 3 allowlisted items (0 debt, 3 permanent); nothing new

```

## B2 final node adopted conformance scanner normal fixture module
Command: ['cargo', 'run', '--quiet', '--locked', '--offline', '--manifest-path', 'glade-discover/tools/architecture-check/Cargo.toml', '--', 'glade/node']
Exit: 0; wall: 0.779s
```text
Architecture boundaries: PASS (workspace libraries, declared dependencies, traits and conformance targets)

```

## B2 final retained contracts production gate edition formatting corrected
Command: ['sh', 'glade/contracts/check.sh', 'crdt-production']
Exit: 0; wall: 3.754s
```text
Architecture boundaries: PASS (workspace libraries, declared dependencies, traits and conformance targets)
   Compiling glade-crdt-recovery-api v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-api)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.23s
     Running unittests src/lib.rs (glade/contracts/target/debug/deps/glade_crdt_admission_core-932f6277b6041d9c)

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/encoder_complete.rs (glade/contracts/target/debug/deps/encoder_complete-0c61aeec9660768e)

running 10 tests
test plan::namespaces_issuance_owner_and_storage_promise_are_part_of_bytes ... ok
test stage::all_staged_candidate_seal_and_receipt_fields ... ok
test fork::fork_pairs_have_complete_candidate_identity_and_evidence ... ok
test candidate::all_candidate_evidence_and_inner_op_bytes ... ok
test plan::complete_plan_header_and_optional_local_cut ... ok
test facts::all_staged_facts_and_certificate_fields ... ok
test descriptor::all_descriptor_parsed_fields_and_bounds ... ok
test verify::full_verification_query_continuations ... ok
test seal_scope::full_seal_descriptor_and_evidence ... ok
test seal::full_sealing_query_continuations ... ok

test result: ok. 10 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

     Running tests/fixture_composition.rs (glade/contracts/target/debug/deps/fixture_composition-65d2eb16df52c7d1)

running 7 tests
test historical_prior_cut_fixture_registers_multiline_inspect_through_full_helper ... ok
test mandatory_text_replica_journeys_do_not_construct_fresh_host_per_drive_call ... ok
test lookup_fixture_owns_full_request_and_bounded_history_not_only_secondary_index ... ok
test trusted_seed_retains_reservations_outcomes_and_rejects_inconsistent_history ... ok
test configured_provider_matches_core_cut_and_changes_independently ... ok
test seeded_terminal_requires_original_custody_and_accounting ... ok
test seeded_custody_is_explicit_and_consecutive_port_publications_keep_history ... ok

test result: ok. 7 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/kernel_edges.rs (glade/contracts/target/debug/deps/kernel_edges-0e6067bcb16c3e14)

running 21 tests
test admission::oversized_proof_cannot_allocate_a_verification_continuation ... ok
test admission::outstanding_verification_prevents_complete_local_and_is_bounded ... ok
test admission::retained_candidates_and_verifications_share_pending_capacity ... ok
test encoder::storage_batch_limit_refuses_before_any_prepare_or_invocation ... ok
test admission::pending_origins_reserve_the_origin_limit_before_verification ... ok
test admission::restored_fork_cut_derives_one_coherent_quarantine_and_eligible_set ... ok
test frontier::already_retained_exact_frontier_hash_preserves_complete_local ... ok
test encoder::full_encoded_continuation_footprint_consumes_edit_quota ... ok
test frontier::frontier_union_cannot_exceed_pending_items_or_clear_previous_observation ... ok
test frontier::empty_peer_frontier_offers_all_local_history ... ok
test admission::committed_local_custody_retains_the_actual_seal_named_by_original_receipt ... ok
test storage::prepared_reply_cannot_replace_original_attempt_mapping ... ok
test storage::lost_prepare_ack_can_recover_original_plan_while_original_invocation_is_live ... ok
test frontier::announced_missing_frontier_survives_unrelated_publication ... ok
test storage::prepare_request_from_retained_old_owner_has_no_current_callback_authority ... ok
test admission::no_prior_admission_local_intent_keeps_real_seal_for_historical_replay ... ok
test encoder::unretained_historical_batch_due_to_encoder_limit_is_sticky_incomplete ... ok
test frontier::different_arriving_hash_cannot_complete_an_announced_missing_slot ... ok
test admission::signed_invalid_payload_is_security_custody_without_conviction ... ok
test admission::signed_historical_rival_outside_permit_sequence_is_security_not_conviction ... ok
test encoder::encoder_is_deterministic_and_binds_descriptor_facts_and_seal_continuations ... ok

test result: ok. 21 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/records_host_contract.rs (glade/contracts/target/debug/deps/records_host_contract-377bbaa390d43bf2)

running 22 tests
test icd003_legacy_and_strong_descriptors_do_not_activate_independent_admission ... ok
test icd005_evidence_reply_binds_mode_bytes_scope_and_candidate ... ok
test icd004_same_display_names_do_not_share_instance_rights_or_callbacks ... ok
test icd006_stale_verification_after_policy_change_cannot_seal_or_commit ... ok
test icd002_partitioned_admission_commits_without_a_holder ... ok
test icd006_historical_authorization_is_separate_from_current_revocation ... ok
test icd007_zero_base_prev_refs_and_exact_safe_numbers ... ok
test icd007_reused_canonical_origin_and_numeric_overflow_refuse ... ok
test icd006_offline_window_and_clock_uncertainty_refuse_new_intent ... ok
test icd007_new_epoch_uses_new_origin_and_old_retries_stay_old ... ok
test icd006_delayed_prior_cut_committed_callback_retains_historical_admission ... ok
test icd010_lookup_recovery_binds_request_and_restores_original_receipt ... ok
test icd010_commit_callbacks_bind_batch_revision_and_have_three_distinct_outcomes ... ok
test icd010_old_receipt_retry_does_not_reauthorize_or_reappend ... ok
test icd010_unknown_commit_retains_reservation_and_foreign_callback_cannot_accept ... ok
test icd013_recovery_exhaustion_is_explicit_and_cannot_spend_edit_budget ... ok
test icd008_successor_requests_predecessor_without_advancing_head ... ok
test icd013_edit_capacity_preserves_recovery_reserves ... ok
test prior_cut_inspect40_distinguishes_issued_authority_from_identical_unissued_reply ... ok
test icd009_qualified_dependent_custody_survives_quarantined_support_but_local_intent_refuses ... ok
test icd009_two_qualified_rivals_quarantine_both_and_dependents_in_either_order ... ok
test icd006_revoked_expired_unadmitted_rival_preserves_ad_and_receipts ... ok

test result: ok. 22 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/recovery_contract.rs (glade/contracts/target/debug/deps/recovery_contract-8cab13edcccedff2)

running 6 tests
test lookup_invocation_counter_exhaustion_refuses_without_wrap_or_reservation_loss ... ok
test trusted_restoration_invalidates_live_lookup_and_preserves_identity_high_water ... ok
test repeated_unknown_lookup_retires_invocation_and_old_replies_preserve_new_lookup ... ok
test retention_committed_lookup_binds_batch_storage_revision_and_empty_receipts ... ok
test genuine_e0_fork_then_fresh_e1_local_recovery_keeps_ab_and_old_receipts_both_orders ... ok
test every_atomic_kind_recovers_committed_absent_and_unknown_without_fake_admission ... ok

test result: ok. 6 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

     Running tests/remediation1.rs (glade/contracts/target/debug/deps/remediation1-be8535f3fccf7f31)

running 16 tests
test frontier::frontier_bytes_include_existing_candidate_charge_and_parked_verification ... ok
test frontier::frontier_retained_slot_aggregate_bytes_exact_boundary_and_one_over ... ok
test exhaustion::local_intent_counter_refusal_alone_does_not_taint_known_history ... ok
test exhaustion::historical_query_exhaustion_remains_sticky_through_resume_restore ... ok
test exhaustion::historical_plan_exhaustion_remains_sticky_through_resume_restore ... ok
test frontier::frontier_names_empty_exact_limit_over_limit_and_huge_are_bounded ... ok
test pending::prospective_two_missing_slots_refuse_before_emission_or_candidate_staging ... ok
test pending::frontier_cannot_steal_slots_reserved_by_an_unpublished_candidate_plan ... ok
test pending::multiple_candidates_and_frontier_slots_share_deduplicated_prospective_cap ... ok
test pending::predecessor_and_ref_to_the_same_missing_slot_emit_one_request ... ok
test terminal::late_pending_and_refused_never_reopen_an_authentic_terminal ... ok
test integrity::already_qualified_fork_cannot_stage_new_work_after_stop ... ok
test pending::exact_slot_limit_and_overlap_union_commit_without_duplicate_reservations ... ok
test integrity::integrity_stop_preserves_owned_started_attempt_and_genuine_late_commit ... ok
test integrity::parked_verification_and_seal_cannot_create_new_work_after_authenticated_stop ... ok
test terminal::held_started_and_terminal_inspect_both_orders_all_four_kinds_and_outcomes ... ok

test result: ok. 16 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

     Running tests/remediation2.rs (glade/contracts/target/debug/deps/remediation2-c6ddfa10c99b9612)

running 3 tests
test fresh_historical_offer_during_held_started_a_is_explicitly_incomplete ... ok
test two_issued_queries_verified_historical_b_during_held_started_a_is_explicitly_incomplete ... ok
test local_intent_only_busy_refusal_does_not_taint_known_history ... ok

test result: ok. 3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/representation.rs (glade/contracts/target/debug/deps/representation-b4c77cef7d79e0fa)

running 2 tests
test operation_bytes_and_digest_are_derived_and_owned ... ok
test pure_step_is_deterministic_preserves_caller_input_and_read_only_state ... ok

test result: ok. 2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/source_boundaries.rs (glade/contracts/target/debug/deps/source_boundaries-cfcb6000711a5cc4)

running 4 tests
test ic3_data_boundary_is_independent_of_the_pure_algorithm ... ok
test checks_disabled_branch_instead_of_skipping_cfg ... ok
test disabled_associated_foreign_and_field_declarations_are_checked ... ok
test tranche_sources_have_explicit_conditional_boundaries ... ok

test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.10s

     Running tests/storage_attempt_contract.rs (glade/contracts/target/debug/deps/storage_attempt_contract-a98f1e5df7b04b9e)

running 15 tests
test sta006_current_prestart_observation_emits_fence_without_erasing_plan ... ok
test identical_unissued_lookup_reply_cannot_acquire_callback_authority ... ok
test issued_lookup_retains_full_request_on_consumption ... ok
test sta008_critical_pending_does_not_release_semantic_reservation ... ok
test sta001_callback_complete_binding_and_finite_invocation_namespace ... ok
test sta005_contradictory_terminal_stops_instance_after_once_only_installation ... ok
test sta005_unissued_foreign_or_changed_retired_callback_cannot_create_integrity_stop ... ok
test sta010_overflow_is_sticky_distinct_from_charges_and_partial_repair ... ok
test sta009_restored_attempt_and_invocation_floors_preserve_pending ... ok
test sta003_pending_lookup_retains_started_write_until_late_commit_all_kinds ... ok
test sta007_all_kinds_install_original_terminal_without_double_charge ... ok
test sta011_existing_twenty_seven_and_text_consumers_keep_actual_port_path ... ok
test sta002_kernel_prepare_keeps_exact_plan_after_lost_ack ... ok
test sta004_noncommit_retains_tombstone_and_rescheduling_uses_fresh_plan ... ok
test sta011_driver_uses_caller_owned_session_across_continuations ... ok

test result: ok. 15 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running unittests src/lib.rs (glade/contracts/target/debug/deps/glade_crdt_admission_data-829261682f5780f4)

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/representation.rs (glade/contracts/target/debug/deps/representation-a11dd961075c09ca)

running 1 test
test canonical_operation_owns_bytes_and_recomputes_digest ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/source_boundaries.rs (glade/contracts/target/debug/deps/source_boundaries-15d7213681b61363)

running 3 tests
test checks_disabled_branch_instead_of_skipping_cfg ... ok
test disabled_associated_foreign_and_field_declarations_are_checked ... ok
test tranche_sources_have_explicit_conditional_boundaries ... ok

test result: ok. 3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

     Running unittests src/lib.rs (glade/contracts/target/debug/deps/glade_crdt_evidence_api-0ab689c801ef5981)

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/public_contract.rs (glade/contracts/target/debug/deps/public_contract-a450847ecdbb9cfb)

running 2 tests
test concrete_provider_must_supply_all_three_trusted_operations ... ok
test required_evidence_methods_have_no_default_provider ... ok

test result: ok. 2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/source_boundaries.rs (glade/contracts/target/debug/deps/source_boundaries-d9ef5b5c6b238cc5)

running 3 tests
test checks_disabled_branch_instead_of_skipping_cfg ... ok
test disabled_associated_foreign_and_field_declarations_are_checked ... ok
test tranche_sources_have_explicit_conditional_boundaries ... ok

test result: ok. 3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running unittests src/lib.rs (glade/contracts/target/debug/deps/glade_crdt_recovery_api-86172c5c56e8b27f)

running 1 test
test ingress::tests::live_started_unjoined_receive_refuses_both_retirement_eligibility_queries ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/public_contract.rs (glade/contracts/target/debug/deps/public_contract-5bc6e82aa5aa7537)

running 8 tests
test abandoned_capability_cannot_start_work_again ... ok
test another_authority_refuses_before_constructing_or_consuming_future ... ok
test cancelled_started_async_receive_does_not_imply_drain_or_abandon ... ok
test issued_guard_identity_is_not_reissued_by_same_session ... ok
test live_never_started_owned_guard_can_abandon_only_once ... ok
test eligibility_queries_preserve_owned_lifecycle_and_refuse_foreign_closed_or_started ... ok
test owned_receive_drains_before_settlement_and_close ... ok
test issuer_capacity_is_finite_and_retirement_does_not_reissue_history ... ok

test result: ok. 8 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/source_boundaries.rs (glade/contracts/target/debug/deps/source_boundaries-d87c63d050de1dbe)

running 4 tests
test checks_disabled_branch_instead_of_skipping_cfg ... ok
test disabled_associated_foreign_and_field_declarations_are_checked ... ok
test tranche_sources_have_explicit_conditional_boundaries ... ok
test actual_node_independent_subtree_and_disabled_branches_are_checked ... ok

test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.12s

     Running unittests src/lib.rs (glade/contracts/target/debug/deps/glade_crdt_recovery_codec-249926a6c91406e4)

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/batch_decode.rs (glade/contracts/target/debug/deps/batch_decode-c338073ef4bd3146)

running 3 tests
test unchanged_private_encoder_has_a_complete_bounded_decoder ... ok
test batch_operations_share_the_existing_aggregate_item_budget ... ok
test interned_blob_references_cannot_amplify_owned_decoding_past_budget ... ok

test result: ok. 3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/image.rs (glade/contracts/target/debug/deps/image-ff97efb1b877942d)

running 4 tests
test interrupted_intent_preserves_issuance_and_guard_floors_without_next_image ... ok
test full_image_retains_all_kernel_callbacks_attempts_guards_issuance_and_loss ... ok
test image_hash_and_external_selection_do_not_require_a_hash_fixed_point ... ok
test corrupt_truncated_trailing_unknown_versions_and_capacity_fail_closed ... ok

test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.16s

     Running tests/remediation1.rs (glade/contracts/target/debug/deps/remediation1-4606bedf9a4f1344)

running 6 tests
test root_operation_item_budget_includes_interpreted_refs_cumulatively ... ok
test nested_candidate_and_remote_transfer_cannot_hide_operation_name ... ok
test root_operation_depth_includes_the_embedded_interpretation_boundary ... ok
test root_operation_name_limit_applies_inside_opaque_canonical_bytes ... ok
test concrete_container_roots_cannot_substitute_plan_for_guard ... ok
test repeated_nested_operations_share_one_budget_not_one_budget_each ... ok

test result: ok. 6 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/roundtrip.rs (glade/contracts/target/debug/deps/roundtrip-afbf6185948b82a4)

running 6 tests
test accepted_signature_domains_are_full_and_zero_terminated ... ok
test remote_profile_is_exact_canonical_integer_key_map_without_recovery_magic ... ok
test type_domain_cannot_substitute_plan_identity_for_receive_guard ... ok
test inventory_empty_is_exact_observation_not_a_completeness_claim ... ok
test identity_roundtrip_preserves_full_namespaces_and_unsigned_floor ... ok
test proof_body_requires_exact_purpose_version_signature_shape_and_type ... ok

test result: ok. 6 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/source_boundaries.rs (glade/contracts/target/debug/deps/source_boundaries-b49e6bf7138dd73f)

running 3 tests
test checks_disabled_branch_instead_of_skipping_cfg ... ok
test disabled_associated_foreign_and_field_declarations_are_checked ... ok
test tranche_sources_have_explicit_conditional_boundaries ... ok

test result: ok. 3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.05s

     Running tests/vectors.rs (glade/contracts/target/debug/deps/vectors-e6054aa97de7077a)

running 4 tests
test malformed_signature_length_and_wrong_exact_domain_refuse_signed_envelope_shape ... ok
test closed_maps_reject_unknown_duplicate_reordered_or_wrong_context_fields ... ok
test bounded_malformed_canonical_vectors_fail_closed ... ok
test all_remote_profile_categories_derive_exact_bytes_and_digests_from_semantic_inputs ... ok

test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running unittests src/lib.rs (glade/contracts/target/debug/deps/glade_crdt_storage_attempt_api-183ed550d5084400)

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/conformance_mutants.rs (glade/contracts/target/debug/deps/conformance_mutants-62cbd41425c44fca)

running 1 test
test shared_public_port_probe_accepts_fixture_and_rejects_six_semantic_mutants ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/public_contract.rs (glade/contracts/target/debug/deps/public_contract-5dd65e92533e6d9b)

running 28 tests
test finite_attempt_invocation_and_name_bounds_refuse_without_wrap ... ok
test historical_accepted_batch_keeps_original_receipt_without_local_prestart ... ok
test authentic_two_commit_recovery_rejects_distinct_duplicate_revision ... ok
test host_serialized_observation_cannot_be_replaced_by_caller_current_claim ... ok
test lost_prepare_ack_and_queued_late_prepare_recover_exactly_one_attempt ... ok
test restoration_rejects_corrupt_cardinality_floor_and_history_limit ... ok
test restored_capacity_and_binding_phase_consistency_are_validated ... ok
test full_retained_commit_history_rejects_missing_head_gaps_and_unbacked_current_revision ... ok
test restored_noncommit_must_retain_its_bindings_unchanged_revision ... ok
test restored_started_and_committed_cuts_must_fit_their_immutable_windows ... ok
test restoration_rejects_identity_and_unresolved_overlap_but_keeps_history_and_y ... ok
test sta001_exact_binding_exhaustion_and_invocation_identity ... ok
test sta005_commit_wins_fence_race_and_receipts_are_original ... ok
test sequential_commits_repeated_noncommit_and_independent_revision_spaces_restore ... ok
test sta002_exact_plan_dedup_no_overlap_and_independent_instances ... ok
test sta004_fence_excludes_late_begin_and_reprepare_uses_new_identity ... ok
test sta008_critical_reserve_exhaustion_cannot_manufacture_negative_finality ... ok
test sta007_retention_receipts_cannot_be_synthetic ... ok
test sta006_prestart_checks_entire_window_and_historical_has_no_current_admit_check ... ok
test sta003_absent_terminal_is_pending_for_all_kinds ... ok
test sta009_exclusive_recovery_and_close_keep_issuance_floors ... ok
test started_cut_is_not_rechecked_after_revocation_or_delayed_begin_ack ... ok
test trusted_observation_injection_has_finite_instance_and_name_bounds ... ok
test validated_restore_retains_all_attempts_and_invocation_namespace_without_auto_commit ... ok
test started_absent_lookup_late_publication_and_fence_use_same_predicate ... ok
test sparse_invocation_restore_preserves_actual_remaining_capacity ... ok
test reopen_validates_retained_consumption_before_changing_owner_or_floors ... ok
test fresh_revision_mismatch_refuses_before_reserved_or_queued_for_every_kind ... ok

test result: ok. 28 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/source_boundaries.rs (glade/contracts/target/debug/deps/source_boundaries-625bf4e5641d0a44)

running 5 tests
test checks_disabled_branch_instead_of_skipping_cfg ... ok
test disabled_associated_foreign_and_field_declarations_are_checked ... ok
test rejects_missing_identity_callback_ownership_and_terminality_fields ... ok
test actual_port_preserves_required_boundary_shape ... ok
test tranche_sources_have_explicit_conditional_boundaries ... ok

test result: ok. 5 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.03s

   Doc-tests glade_crdt_admission_core

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

   Doc-tests glade_crdt_admission_data

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

   Doc-tests glade_crdt_evidence_api

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

   Doc-tests glade_crdt_recovery_api

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

   Doc-tests glade_crdt_recovery_codec

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

   Doc-tests glade_crdt_storage_attempt_api

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

    Checking glade-crdt-recovery-api v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-api)
    Finished `dev` profile [unoptimized + debuginfo] target(s) in 0.27s

```

## B2 final physical paired cuts after source module path correction
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'independent::disk', '--', '--nocapture']
Exit: 0; wall: 11.668s
```text
    Blocking waiting for file lock on build directory
    Finished `test` profile [unoptimized + debuginfo] target(s) in 6.00s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 18 tests
test independent::disk::floors::tests::floor_cut_child ... ignored, owned helper process invoked only by its kill-cut parent
test independent::disk::paired::tests::content::process::pair_cut_child ... ignored, owned child of paired process-kill schedule
test independent::disk::floors::tests::atomic_floor_exposes_each_exact_creation_partial_write_and_sync_cut ... ok
test independent::disk::slots::tests::actual_reserved_slot_roundtrips_exact_bounded_bytes_and_rejects_torn_or_extra_data ... ok
test independent::disk::tests::actual_committed_legacy_executable_refuses_the_disposable_ic3_root ... ignored, B2 qualification requires the preserved exact committed legacy executable fixture
test independent::disk::metadata::tests::private_pending_kind_survives_missing_image_and_rejects_other_root_identity ... ok
test independent::disk::floors::tests::bounded_floor_replacement_retains_installed_bytes_after_lost_rename_reply ... ok
test independent::disk::slots::tests::slot_reopens_and_exposes_exact_header_partial_body_and_sync_cuts ... ok
test independent::disk::tests::fresh_layout_has_stable_exclusive_custody_and_legacy_refusal_marker ... ok
test independent::disk::tests::registered_roots_reopen_but_live_lock_wrong_registration_and_data_clone_refuse ... ok
test independent::disk::paired::tests::content::malformed_next_image_is_refused_before_any_intent_or_slot_write ... ok
test independent::disk::paired::tests::content::nonrecursive_pair_selection_and_exact_pending_fallback_retain_all_floors ... ok
test independent::disk::paired::tests::content::installed_next_image_finishes_lost_selection_reply_without_hash_recursion ... ok
test independent::disk::paired::tests::content::completed_next_image_installs_exact_guard_settlement_after_missing_selection ... ok
test independent::disk::paired::tests::content::failed_recovery_resync_keeps_original_pending_floor_and_does_not_select ... ok
test independent::disk::floors::tests::actual_process_kill_at_every_floor_cut_reopens_exact_old_or_installed_bytes ... ok
test independent::disk::paired::tests::content::live_root_substitution_refuses_before_touching_trusted_selection ... ok
test independent::disk::paired::tests::content::process::actual_process_kill_reopens_every_intent_image_selection_cut ... ok

test result: ok. 15 passed; 0 failed; 3 ignored; 0 measured; 394 filtered out; finished in 4.70s


```

## B2 strict pre-remote remains refused until actual genuine acceptance record
Command: ['sh', 'glade/contracts/crdt-recovery-codec/check-vectors.sh', '--pre-remote']
Exit: 1; wall: 0.709s
```text
Traceback (most recent call last):
  File "/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-codec/compat/gate.py", line 106, in <module>
    validate(Path(sys.argv[1]), strict=strict)
  File "/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-codec/compat/gate.py", line 53, in validate
    validate_remote(root, pins)
  File "/Volumes/projects/limbo/glade-wz/glade/contracts/crdt-recovery-codec/compat/gate.py", line 84, in validate_remote
    raise ValueError("genuine B1 crypto qualification absent")
ValueError: genuine B1 crypto qualification absent

```

## B2 scoped node format ratchet
Command: cargo fmt --manifest-path glade/node/Cargo.toml -p glade-node -- --check
Exit: 1; counted hunks 253 / retained baseline252
```text
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/bin/glade-node.rs:410:
                 eprintln!("{line}");
             }
             let reg = glade_node::appdecl::register(&decl, &mut node.registry, &registrant)
-                .map_err(|e| std::io::Error::new(std::io::ErrorKind::InvalidData, format!("{e:?}")))?;
+                .map_err(|e| {
+                    std::io::Error::new(std::io::ErrorKind::InvalidData, format!("{e:?}"))
+                })?;
             node.store.save(&node.registry.snapshot())?;
-            println!("app {} registered (+{} record(s), {} unchanged)", decl.app, reg.appended, reg.unchanged);
-            workspaces.extend(decl.workspaces.iter().map(|w| (w.share.clone(), w.name.clone())));
+            println!(
+                "app {} registered (+{} record(s), {} unchanged)",
+                decl.app, reg.appended, reg.unchanged
+            );
+            workspaces.extend(
+                decl.workspaces
+                    .iter()
+                    .map(|w| (w.share.clone(), w.name.clone())),
+            );
         }
         Some((node, workspaces, network, leases))
     } else {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl/tail.rs:36:
 const PROFILE_REQUIRED: [&str; 1] = ["crdt"];
 
 /// The units `ttl=` takes, each in milliseconds.
-const UNITS: [(&str, i64); 5] =
-    [("ms", 1), ("s", 1_000), ("m", 60_000), ("h", 3_600_000), ("d", 86_400_000)];
+const UNITS: [(&str, i64); 5] = [
+    ("ms", 1),
+    ("s", 1_000),
+    ("m", 60_000),
+    ("h", 3_600_000),
+    ("d", 86_400_000),
+];
 
 /// Parse binding line `n`'s tail — `toks`, the tokens after the five
 /// positional ones — against the line's shape, zone and retention, in a file
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl/tail.rs:64:
             }
         }
     }
-    let mut tail = BindingTail { glade_id: glade_id.into(), ..BindingTail::default() };
+    let mut tail = BindingTail {
+        glade_id: glade_id.into(),
+        ..BindingTail::default()
+    };
     let mut seen: Vec<&str> = Vec::new();
     for tok in toks {
         let Some((key, value)) = tok.split_once('=').filter(|(key, _)| !key.is_empty()) else {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl/tail.rs:71:
-            return Err(format!("line {n}: `{tok}` is not a key=value entry ({})", keys()));
+            return Err(format!(
+                "line {n}: `{tok}` is not a key=value entry ({})",
+                keys()
+            ));
         };
         if !KEYS.contains(&key) {
-            return Err(format!("line {n}: unknown binding key `{key}` ({})", keys()));
+            return Err(format!(
+                "line {n}: unknown binding key `{key}` ({})",
+                keys()
+            ));
         }
         if seen.contains(&key) {
             return Err(format!("line {n}: repeated binding key `{key}`"));
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl/tail.rs:84:
         }
     }
     if tail.ttl_ms.is_some() && retention != "ttl" {
-        return Err(format!("line {n}: `ttl=` needs the retention `ttl` (this line's is `{retention}`)"));
+        return Err(format!(
+            "line {n}: `ttl=` needs the retention `ttl` (this line's is `{retention}`)"
+        ));
     }
     fits_shape(n, shape, tail.shape_profile.as_deref())?;
     if seen.is_empty() {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl/tail.rs:108:
 
 /// GDL-041's profiles, as a diagnostic lists them.
 fn profiles() -> String {
-    let each: Vec<String> = PROFILES.iter().map(|(p, core)| format!("`{p}` over `{core}`")).collect();
+    let each: Vec<String> = PROFILES
+        .iter()
+        .map(|(p, core)| format!("`{p}` over `{core}`"))
+        .collect();
     format!("profiles: {}", each.join(", "))
 }
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl/tail.rs:140:
 fn profile(n: usize, value: &str) -> Result<&'static str, String> {
     match PROFILES.iter().find(|(p, _)| *p == value) {
         Some((p, _)) => Ok(p),
-        None => Err(format!("line {n}: unknown profile `{value}` ({})", profiles())),
+        None => Err(format!(
+            "line {n}: unknown profile `{value}` ({})",
+            profiles()
+        )),
     }
 }
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl/tail.rs:148:
 /// over one core engine; a shape no profile runs over takes none; a shape in
 /// [`PROFILE_REQUIRED`] must name one.
 fn fits_shape(n: usize, shape: &str, profile: Option<&str>) -> Result<(), String> {
-    let over_shape: Vec<&str> = PROFILES.iter().filter(|(_, core)| *core == shape).map(|(p, _)| *p).collect();
+    let over_shape: Vec<&str> = PROFILES
+        .iter()
+        .filter(|(_, core)| *core == shape)
+        .map(|(p, _)| *p)
+        .collect();
     match profile {
         Some(p) => {
             if over_shape.is_empty() {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl/tail.rs:155:
-                return Err(format!("line {n}: shape `{shape}` takes no `shape-profile` ({})", profiles()));
+                return Err(format!(
+                    "line {n}: shape `{shape}` takes no `shape-profile` ({})",
+                    profiles()
+                ));
             }
             if !over_shape.contains(&p) {
-                let core = PROFILES.iter().find(|(name, _)| *name == p).map(|(_, core)| *core).unwrap_or("");
-                return Err(format!("line {n}: profile `{p}` is over `{core}`, not `{shape}`"));
+                let core = PROFILES
+                    .iter()
+                    .find(|(name, _)| *name == p)
+                    .map(|(_, core)| *core)
+                    .unwrap_or("");
+                return Err(format!(
+                    "line {n}: profile `{p}` is over `{core}`, not `{shape}`"
+                ));
             }
             Ok(())
         }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl/tail.rs:163:
         None => {
             if PROFILE_REQUIRED.contains(&shape) {
-                let needs: Vec<String> = over_shape.iter().map(|p| format!("`shape-profile={p}`")).collect();
+                let needs: Vec<String> = over_shape
+                    .iter()
+                    .map(|p| format!("`shape-profile={p}`"))
+                    .collect();
                 return Err(format!(
                     "line {n}: shape `{shape}` needs {} (a `{shape}` line must name its profile)",
                     needs.join(" or ")
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl/tail.rs:235:
     #[test]
     fn an_unknown_key_is_refused_by_name_with_its_line() {
         assert_eq!(
-            parse("glade-app v0\napp x\n\nbinding g value share commons latest colour=red\n").unwrap_err(),
+            parse("glade-app v0\napp x\n\nbinding g value share commons latest colour=red\n")
+                .unwrap_err(),
             "line 4: unknown binding key `colour` (binding keys: `ttl`, `shape-profile`)"
         );
         assert_eq!(
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl/tail.rs:335:
     /// `ms`, `s`, `m`, `h` or `d` — nothing else.
     #[test]
     fn a_bad_duration_is_refused() {
-        for bad in ["", "10", "m", "0m", "00s", "1.5h", "1h30m", "10M", "-1m", "+1m", "1w", "10mss", "1 m"] {
+        for bad in [
+            "", "10", "m", "0m", "00s", "1.5h", "1h30m", "10M", "-1m", "+1m", "1w", "10mss", "1 m",
+        ] {
             let text = format!("binding g value share commons ttl ttl={bad}");
             // A space ends the token, so `ttl=1 m` offers the duration `1`.
             let tok = bad.split_whitespace().next().unwrap_or("");
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl/tail.rs:376:
         let profiles = "(profiles: `snapshot_delta` over `swmr`, `text_crdt` over `crdt`)";
         for shape in ["value", "log"] {
             assert_eq!(
-                line(&format!("binding g {shape} share commons latest shape-profile=snapshot_delta")).unwrap_err(),
+                line(&format!(
+                    "binding g {shape} share commons latest shape-profile=snapshot_delta"
+                ))
+                .unwrap_err(),
                 format!("line 3: shape `{shape}` takes no `shape-profile` {profiles}")
             );
         }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl/tail.rs:385:
             "line 3: profile `text_crdt` is over `crdt`, not `swmr`"
         );
         assert_eq!(
-            line("binding g crdt share commons from-cursor shape-profile=snapshot_delta").unwrap_err(),
+            line("binding g crdt share commons from-cursor shape-profile=snapshot_delta")
+                .unwrap_err(),
             "line 3: profile `snapshot_delta` is over `swmr`, not `crdt`"
         );
         for unknown in ["text-crdt", "blob", ""] {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl/tail.rs:392:
             assert_eq!(
-                line(&format!("binding g swmr share commons from-cursor shape-profile={unknown}")).unwrap_err(),
+                line(&format!(
+                    "binding g swmr share commons from-cursor shape-profile={unknown}"
+                ))
+                .unwrap_err(),
                 format!("line 3: unknown profile `{unknown}` {profiles}")
             );
         }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:94:
 /// must name; `atom` (a GDL-041 engine), `message` and `window` are
 /// recognised and reserved ([`RESERVED_SHAPES`]); `stream` is recognised and
 /// not bindable; an exchange is authored by a `service` line.
-const KNOWN_SHAPES: [&str; 9] =
-    ["value", "log", "message", "stream", "exchange", "window", "swmr", "crdt", "atom"];
+const KNOWN_SHAPES: [&str; 9] = [
+    "value", "log", "message", "stream", "exchange", "window", "swmr", "crdt", "atom",
+];
 const BINDING_SHAPES: [&str; 4] = ["value", "log", "swmr", "crdt"];
 /// Recognised shapes with nothing to bind and nothing to redirect to: the
 /// refusal says they are reserved rather than only listing what binds.
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:130:
 ];
 /// What a `glade-app v0` header is told (R10(a)): the file loads as it always
 /// did, and learns the header that names the validated grammar.
-const V0_HEADER_WARNING: &str = "header `glade-app v0` names the old language; write `glade-app v1`";
+const V0_HEADER_WARNING: &str =
+    "header `glade-app v0` names the old language; write `glade-app v1`";
 /// What a file whose first declaration line is not a header is told: the
 /// header to write, and the one an old file may still carry.
 const HEADER_TO_WRITE: &str = "write `glade-app v1` (`glade-app v0` is accepted for old files)";
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:389:
             }
             "binding" => {
                 if decl.app.is_empty() {
-                    return Err(format!("line {n}: `app` must be declared before any binding"));
+                    return Err(format!(
+                        "line {n}: `app` must be declared before any binding"
+                    ));
                 }
                 // A minimum: five positional tokens, then the optional tail.
                 if toks.len() < 6 {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:397:
                 }
                 let (glade_id, shape, retention) = (toks[1], toks[2], toks[5]);
                 if !KNOWN_SHAPES.contains(&shape) {
-                    return Err(format!("line {n}: unknown shape `{shape}` (known: {KNOWN_SHAPES:?})"));
+                    return Err(format!(
+                        "line {n}: unknown shape `{shape}` (known: {KNOWN_SHAPES:?})"
+                    ));
                 }
                 if !BINDING_SHAPES.contains(&shape) {
                     return Err(unbindable(n, shape));
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:452:
             }
             "service" => {
                 if decl.app.is_empty() {
-                    return Err(format!("line {n}: `app` must be declared before any service"));
+                    return Err(format!(
+                        "line {n}: `app` must be declared before any service"
+                    ));
                 }
                 if toks.len() != 3 {
                     return Err(format!("line {n}: `service <name> <exchange-glade-id>`"));
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:469:
                     return Err(format!("line {n}: `app` must be declared before any seed"));
                 }
                 if toks.len() != 4 {
-                    return Err(format!("line {n}: `seed <principal> <share> <verb[,verb...]>`"));
+                    return Err(format!(
+                        "line {n}: `seed <principal> <share> <verb[,verb...]>`"
+                    ));
                 }
                 let seed = CapabilityGrant {
                     principal: toks[1].into(),
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:517:
             }
             "workspace" => {
                 if decl.app.is_empty() {
-                    return Err(format!("line {n}: `app` must be declared before any workspace"));
+                    return Err(format!(
+                        "line {n}: `app` must be declared before any workspace"
+                    ));
                 }
                 if toks.len() != 3 {
                     return Err(format!("line {n}: `workspace <share> <name>`"));
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:525:
                 if decl.workspaces.iter().any(|w| w.share == toks[1]) {
                     return Err(format!("line {n}: duplicate workspace share `{}`", toks[1]));
                 }
-                decl.workspaces.push(WorkspaceDecl { share: toks[1].into(), name: toks[2].into() });
+                decl.workspaces.push(WorkspaceDecl {
+                    share: toks[1].into(),
+                    name: toks[2].into(),
+                });
             }
             other => return Err(format!("line {n}: unknown declaration `{other}`")),
         }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:569:
 /// The message a `glade-app v1` file is told for `token`, if it is one of the
 /// retention tokens a file may not write ([`REFUSED_RETENTIONS`]).
 pub fn refused_retention(token: &str) -> Option<&'static str> {
-    REFUSED_RETENTIONS.iter().find(|(t, _, _)| *t == token).map(|(_, v1, _)| *v1)
+    REFUSED_RETENTIONS
+        .iter()
+        .find(|(t, _, _)| *t == token)
+        .map(|(_, v1, _)| *v1)
 }
 
 /// A zone or retention that `glade-app v1` does not accept, as a file in each
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:602:
     if retention.contains('=') {
         out.push(misplaced("retention", retention));
     } else if let Some(&(_, v1, v0)) = REFUSED_RETENTIONS.iter().find(|(t, _, _)| *t == retention) {
-        out.push(Unaccepted { v1: v1.into(), v0: v0.into() });
+        out.push(Unaccepted {
+            v1: v1.into(),
+            v0: v0.into(),
+        });
     } else if !RETENTIONS.contains(&retention) {
         out.push(Unaccepted {
             v1: format!("unknown retention `{retention}` (one of {RETENTIONS:?})"),
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:800:
     }
     for glade_id in live.keys() {
         if !decl.bindings.iter().any(|b| &b.glade_id == glade_id) {
-            let retraction = BindingRetraction { app: decl.app.clone(), glade_id: glade_id.clone() };
+            let retraction = BindingRetraction {
+                app: decl.app.clone(),
+                glade_id: glade_id.clone(),
+            };
             reg.append(Record::Retract(retraction), origin)?;
             out.appended += 1;
         }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:832:
 
     for rec in records {
         let (glade_id, payload) = (rec.glade_id().to_string(), rec.encode());
-        if existing.iter().any(|(g, p)| *g == glade_id && *p == payload) {
+        if existing
+            .iter()
+            .any(|(g, p)| *g == glade_id && *p == payload)
+        {
             out.unchanged += 1;
         } else {
             reg.append(rec, origin)?;
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:852:
     use glade_wire::generated::Shape;
 
     use crate::registry::{
-        BindingFold, Record, Registry, RegistryApi, G_BINDINGS, G_BINDING_RETRACTIONS, G_GRANTS, G_REVOCATIONS,
-        G_SERVICES, HOME,
+        BindingFold, Record, Registry, RegistryApi, G_BINDINGS, G_BINDING_RETRACTIONS, G_GRANTS,
+        G_REVOCATIONS, G_SERVICES, HOME,
     };
     use crate::sysdata::CapabilityRevocation;
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:887:
     fn grazel_file_matches_the_trace_shape() {
         let decl = parse(&grazel_file()).unwrap();
         assert_eq!(decl.app, "grazel");
-        assert_eq!(decl.bindings.len(), 7, "4 workspace + 3 composed-supplier surfaces");
+        assert_eq!(
+            decl.bindings.len(),
+            7,
+            "4 workspace + 3 composed-supplier surfaces"
+        );
         assert_eq!(decl.services.len(), 1, "1 service (grazel)");
         assert_eq!(decl.seeds.len(), 2, "2 ACL seeds");
         for g in &decl.seeds {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:899:
             share: "grazel".into(),
         };
         assert_eq!(decl.revocations, [old_pair]);
-        assert_eq!(decl.workspaces, vec![WorkspaceDecl { share: "ws-razel".into(), name: "razel".into() }]);
+        assert_eq!(
+            decl.workspaces,
+            vec![WorkspaceDecl {
+                share: "ws-razel".into(),
+                name: "razel".into()
+            }]
+        );
         // the directed surface the service answers (discovery.ts phase D):
         assert_eq!(decl.services[0].glade_id, "gwz.ops");
         // key surface names ride as data — the workspace tree + the composed
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:906:
         // gwz.output long-op stream + the chat group-keyed log:
-        assert!(decl.bindings.iter().any(|b| b.glade_id == "ws.tree" && b.shape == "value"));
-        assert!(decl.bindings.iter().any(|b| b.glade_id == "ws.files" && b.shape == "swmr"));
-        assert!(decl.bindings.iter().any(|b| b.glade_id == "gwz.output" && b.shape == "log"));
-        assert!(decl.bindings.iter().any(|b| b.glade_id == "chat.msgs" && b.shape == "log"));
-        assert!(decl.bindings.iter().any(|b| b.glade_id == "chat.groups" && b.shape == "value"));
+        assert!(decl
+            .bindings
+            .iter()
+            .any(|b| b.glade_id == "ws.tree" && b.shape == "value"));
+        assert!(decl
+            .bindings
+            .iter()
+            .any(|b| b.glade_id == "ws.files" && b.shape == "swmr"));
+        assert!(decl
+            .bindings
+            .iter()
+            .any(|b| b.glade_id == "gwz.output" && b.shape == "log"));
+        assert!(decl
+            .bindings
+            .iter()
+            .any(|b| b.glade_id == "chat.msgs" && b.shape == "log"));
+        assert!(decl
+            .bindings
+            .iter()
+            .any(|b| b.glade_id == "chat.groups" && b.shape == "value"));
         assert!(decl.bindings.iter().all(|b| b.app == "grazel"));
     }
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:925:
         // Known legacy/future enum values remain decodable on the wire but are
         // not authorable bindings until an exact runtime adapter exists.
         for shape in ["message", "stream", "exchange", "window"] {
-            let text = format!(
-                "glade-app v0\napp x\nbinding g {shape} share commons latest\n"
-            );
+            let text = format!("glade-app v0\napp x\nbinding g {shape} share commons latest\n");
             let e = parse(&text).unwrap_err();
-            assert!(e.contains("line 3") && e.contains("unsupported binding shape") && e.contains(shape), "{e}");
+            assert!(
+                e.contains("line 3")
+                    && e.contains("unsupported binding shape")
+                    && e.contains(shape),
+                "{e}"
+            );
         }
         // duplicate glade id (frozen-once-shared, GQ-6)
         let e = parse(
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:936:
             "glade-app v0\napp x\nbinding g value share commons latest\nbinding g log share commons latest\n",
         )
         .unwrap_err();
-        assert!(e.contains("line 4") && e.contains("duplicate glade id"), "{e}");
+        assert!(
+            e.contains("line 4") && e.contains("duplicate glade id"),
+            "{e}"
+        );
         // declarations before `app`
         let e = parse("glade-app v0\nbinding g value share commons latest\n").unwrap_err();
-        assert!(e.contains("line 2") && e.contains("`app` must be declared"), "{e}");
+        assert!(
+            e.contains("line 2") && e.contains("`app` must be declared"),
+            "{e}"
+        );
         // missing app entirely
-        assert!(parse("glade-app v0\n").unwrap_err().contains("missing `app"));
+        assert!(parse("glade-app v0\n")
+            .unwrap_err()
+            .contains("missing `app"));
         // workspace: arity + duplicate share
         let e = parse("glade-app v0\napp x\nworkspace ws-a\n").unwrap_err();
-        assert!(e.contains("line 3") && e.contains("workspace <share> <name>"), "{e}");
+        assert!(
+            e.contains("line 3") && e.contains("workspace <share> <name>"),
+            "{e}"
+        );
         let e = parse("glade-app v0\napp x\nworkspace ws-a a\nworkspace ws-a b\n").unwrap_err();
-        assert!(e.contains("line 4") && e.contains("duplicate workspace share"), "{e}");
+        assert!(
+            e.contains("line 4") && e.contains("duplicate workspace share"),
+            "{e}"
+        );
     }
 
     #[test]
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:953:
     fn swmr_is_an_exact_authorable_binding_shape() {
-        let decl = parse(
-            "glade-app v0\napp demo\nbinding ws.files swmr share commons from_cursor\n",
-        )
-        .unwrap();
+        let decl =
+            parse("glade-app v0\napp demo\nbinding ws.files swmr share commons from_cursor\n")
+                .unwrap();
         assert_eq!(decl.bindings[0].shape, "swmr");
     }
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:966:
         let decl = parse("glade-app v0\napp demo\nworkspace ws-d demo-ws\n").unwrap();
         let mut reg = Registry::new();
         let out = register(&decl, &mut reg, "node-1").unwrap();
-        assert_eq!(out, Registered { appended: 1, unchanged: 0 });
+        assert_eq!(
+            out,
+            Registered {
+                appended: 1,
+                unchanged: 0
+            }
+        );
         assert_eq!(reg.replicas_of("ws-d"), vec!["node-1"]);
         // re-registration diffs away (same registrant, same bytes).
         let again = register(&decl, &mut reg, "node-1").unwrap();
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:973:
-        assert_eq!(again, Registered { appended: 0, unchanged: 1 });
+        assert_eq!(
+            again,
+            Registered {
+                appended: 0,
+                unchanged: 1
+            }
+        );
     }
 
     /// Registration = ordinary record appends: home-share wire Ops, origin-
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:986:
         .unwrap();
         let mut reg = Registry::new();
         let out = register(&decl, &mut reg, "node-1").unwrap();
-        assert_eq!(out, Registered { appended: 3, unchanged: 0 });
+        assert_eq!(
+            out,
+            Registered {
+                appended: 3,
+                unchanged: 0
+            }
+        );
 
         let snap = reg.snapshot();
-        let ops: Vec<Op> = snap.records.iter().map(|b| Op::decode(b).unwrap()).collect();
+        let ops: Vec<Op> = snap
+            .records
+            .iter()
+            .map(|b| Op::decode(b).unwrap())
+            .collect();
         assert_eq!(ops.len(), 3);
         for op in &ops {
             assert_eq!(op.share, HOME);
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:1008:
         let decl = parse(&grazel_file()).unwrap();
         let mut reg = Registry::new();
         let first = register(&decl, &mut reg, "node-1").unwrap();
-        assert_eq!(first, Registered { appended: 12, unchanged: 0 }); // 7 bindings +1 service +2 seeds +1 revocation +1 workspace
+        assert_eq!(
+            first,
+            Registered {
+                appended: 12,
+                unchanged: 0
+            }
+        ); // 7 bindings +1 service +2 seeds +1 revocation +1 workspace
         let snap1 = reg.snapshot();
         let second = register(&decl, &mut reg, "node-1").unwrap();
-        assert_eq!(second, Registered { appended: 0, unchanged: 12 });
-        assert_eq!(reg.snapshot(), snap1, "re-registration is a byte-identical no-op");
+        assert_eq!(
+            second,
+            Registered {
+                appended: 0,
+                unchanged: 12
+            }
+        );
+        assert_eq!(
+            reg.snapshot(),
+            snap1,
+            "re-registration is a byte-identical no-op"
+        );
     }
 
     /// The fold is the only authority: a runtime revocation lands AFTER the
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:1033:
         // the file seeds once; the fold rules forever.
         let again = register(&decl, &mut reg, "node-1").unwrap();
         assert_eq!(again.appended, 0, "identical seeds diff away on re-load");
-        assert_eq!(reg.grants_for("owner", "ws-razel"), Vec::<String>::new(), "revocation stays");
+        assert_eq!(
+            reg.grants_for("owner", "ws-razel"),
+            Vec::<String>::new(),
+            "revocation stays"
+        );
     }
 
     /// §4.7 row 17 (R10(a)): the regression that pins plan Step 2.3 ahead of
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:1157:
     /// profile, which the tail makes mandatory for it (bullet 4).
     #[test]
     fn crdt_is_a_binding_shape() {
-        let decl = binding_line("binding doc.body crdt share commons from-cursor shape-profile=text_crdt").unwrap();
+        let decl =
+            binding_line("binding doc.body crdt share commons from-cursor shape-profile=text_crdt")
+                .unwrap();
         assert_eq!(decl.bindings[0].shape, "crdt");
     }
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:1185:
             format!("line 3: unsupported binding shape `stream` (implemented: {implemented})")
         );
         let e = binding_line("binding g blob share commons latest").unwrap_err();
-        assert!(e.starts_with("line 3: unknown shape `blob`") && e.contains("\"crdt\", \"atom\""), "{e}");
+        assert!(
+            e.starts_with("line 3: unknown shape `blob`") && e.contains("\"crdt\", \"atom\""),
+            "{e}"
+        );
     }
 
     /// R11(a), §4.4 bullet 4: the arity check is a MINIMUM of five tokens
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:1214:
         );
         assert_eq!(
             refused_retention("from_cursor"),
-            Some("retention `from_cursor` is the contract's spelling (use `from-cursor` in a file)")
+            Some(
+                "retention `from_cursor` is the contract's spelling (use `from-cursor` in a file)"
+            )
         );
         for token in ["latest", "from-cursor", "ttl", "frobnicate"] {
             assert_eq!(refused_retention(token), None, "{token}");
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:1221:
         }
         for token in ["windowed", "from_cursor"] {
             let told = v1_reports(&v1_file(&format!("binding g log share commons {token}")));
-            assert_eq!(told, [format!("line 3: {}", refused_retention(token).unwrap())], "{token}");
+            assert_eq!(
+                told,
+                [format!("line 3: {}", refused_retention(token).unwrap())],
+                "{token}"
+            );
         }
     }
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:1231:
     /// same bytes.
     #[test]
     fn the_tail_reaches_no_record() {
-        let with = binding_line("binding g swmr share commons ttl ttl=10m shape-profile=snapshot_delta").unwrap();
+        let with =
+            binding_line("binding g swmr share commons ttl ttl=10m shape-profile=snapshot_delta")
+                .unwrap();
         let without = binding_line("binding g swmr share commons ttl").unwrap();
         assert_eq!(with.bindings, without.bindings);
         let (mut a, mut b) = (Registry::new(), Registry::new());
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:1242:
 
     /// The live bindings as (glade_id, stored retention).
     fn live(reg: &Registry) -> Vec<(String, String)> {
-        reg.bindings_of().into_iter().map(|b| (b.glade_id, b.retention)).collect()
+        reg.bindings_of()
+            .into_iter()
+            .map(|b| (b.glade_id, b.retention))
+            .collect()
     }
     fn pair(glade_id: &str, retention: &str) -> (String, String) {
         (glade_id.into(), retention.into())
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:1249:
     }
     fn ops_of(reg: &Registry) -> Vec<Op> {
-        reg.snapshot().records.iter().map(|b| Op::decode(b).unwrap()).collect()
+        reg.snapshot()
+            .records
+            .iter()
+            .map(|b| Op::decode(b).unwrap())
+            .collect()
     }
 
     /// R9(a): `register` diffs a file's bindings against the FOLD, per
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:1260:
     #[test]
     fn register_diffs_bindings_per_app_against_the_fold() {
         let file = |bindings: &str| parse(&format!("glade-app v0\napp x\n{bindings}")).unwrap();
-        let v1 = file("binding a value share commons latest\nbinding b log share commons from-cursor\n");
-        let v2 = file("binding a value share commons ttl\nbinding c log share commons from-cursor\n");
+        let v1 =
+            file("binding a value share commons latest\nbinding b log share commons from-cursor\n");
+        let v2 =
+            file("binding a value share commons ttl\nbinding c log share commons from-cursor\n");
         let mut reg = Registry::new();
-        assert_eq!(register(&v1, &mut reg, "node-1").unwrap(), Registered { appended: 2, unchanged: 0 });
+        assert_eq!(
+            register(&v1, &mut reg, "node-1").unwrap(),
+            Registered {
+                appended: 2,
+                unchanged: 0
+            }
+        );
         // a changed, b deleted, c added: a's new declaration, c's, and b's retraction.
-        assert_eq!(register(&v2, &mut reg, "node-1").unwrap(), Registered { appended: 3, unchanged: 0 });
+        assert_eq!(
+            register(&v2, &mut reg, "node-1").unwrap(),
+            Registered {
+                appended: 3,
+                unchanged: 0
+            }
+        );
         assert_eq!(live(&reg), vec![pair("a", "ttl"), pair("c", "from_cursor")]);
-        assert_eq!(BindingFold::over(&ops_of(&reg)).retracted(), vec![("x".to_string(), "b".to_string())]);
+        assert_eq!(
+            BindingFold::over(&ops_of(&reg)).retracted(),
+            vec![("x".to_string(), "b".to_string())]
+        );
         // back to v1: a changes back, b is declared again, c is retracted.
-        assert_eq!(register(&v1, &mut reg, "node-1").unwrap(), Registered { appended: 3, unchanged: 0 });
-        assert_eq!(live(&reg), vec![pair("a", "latest"), pair("b", "from_cursor")]);
-        assert_eq!(BindingFold::over(&ops_of(&reg)).retracted(), vec![("x".to_string(), "c".to_string())]);
-        assert_eq!(register(&v1, &mut reg, "node-1").unwrap(), Registered { appended: 0, unchanged: 2 });
-        let retractions = ops_of(&reg).iter().filter(|o| o.glade_id == G_BINDING_RETRACTIONS).count();
+        assert_eq!(
+            register(&v1, &mut reg, "node-1").unwrap(),
+            Registered {
+                appended: 3,
+                unchanged: 0
+            }
+        );
+        assert_eq!(
+            live(&reg),
+            vec![pair("a", "latest"), pair("b", "from_cursor")]
+        );
+        assert_eq!(
+            BindingFold::over(&ops_of(&reg)).retracted(),
+            vec![("x".to_string(), "c".to_string())]
+        );
+        assert_eq!(
+            register(&v1, &mut reg, "node-1").unwrap(),
+            Registered {
+                appended: 0,
+                unchanged: 2
+            }
+        );
+        let retractions = ops_of(&reg)
+            .iter()
+            .filter(|o| o.glade_id == G_BINDING_RETRACTIONS)
+            .count();
         assert_eq!(retractions, 2, "b's and c's, each once");
     }
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:1282:
     #[test]
     fn another_apps_declarations_are_never_in_scope() {
         let a = parse("glade-app v0\napp a\nbinding a.one value share commons latest\nbinding a.two value share commons latest\n").unwrap();
-        let b = parse("glade-app v0\napp b\nbinding b.one log share commons from-cursor\n").unwrap();
-        let a_without_two = parse("glade-app v0\napp a\nbinding a.one value share commons latest\n").unwrap();
+        let b =
+            parse("glade-app v0\napp b\nbinding b.one log share commons from-cursor\n").unwrap();
+        let a_without_two =
+            parse("glade-app v0\napp a\nbinding a.one value share commons latest\n").unwrap();
         let mut reg = Registry::new();
-        assert_eq!(register(&a, &mut reg, "node-1").unwrap(), Registered { appended: 2, unchanged: 0 });
-        assert_eq!(register(&b, &mut reg, "node-1").unwrap(), Registered { appended: 1, unchanged: 0 });
-        assert_eq!(register(&a_without_two, &mut reg, "node-1").unwrap(), Registered { appended: 1, unchanged: 1 });
+        assert_eq!(
+            register(&a, &mut reg, "node-1").unwrap(),
+            Registered {
+                appended: 2,
+                unchanged: 0
+            }
+        );
+        assert_eq!(
+            register(&b, &mut reg, "node-1").unwrap(),
+            Registered {
+                appended: 1,
+                unchanged: 0
+            }
+        );
+        assert_eq!(
+            register(&a_without_two, &mut reg, "node-1").unwrap(),
+            Registered {
+                appended: 1,
+                unchanged: 1
+            }
+        );
         let ids: Vec<String> = live(&reg).into_iter().map(|(id, _)| id).collect();
         assert_eq!(ids, ["a.one", "b.one"]);
-        assert_eq!(BindingFold::over(&ops_of(&reg)).retracted(), vec![("a".to_string(), "a.two".to_string())]);
+        assert_eq!(
+            BindingFold::over(&ops_of(&reg)).retracted(),
+            vec![("a".to_string(), "a.two".to_string())]
+        );
     }
 
     /// What the PRE-amendment `register` appended for `decl` on a fresh store,
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:1349:
         let decl = parse(&grazel_file()).unwrap();
         let mut reg = Registry::new();
         register(&decl, &mut reg, "node-1").unwrap();
-        assert_eq!(reg.snapshot().records, pre_amendment_records(&decl, "node-1"));
+        assert_eq!(
+            reg.snapshot().records,
+            pre_amendment_records(&decl, "node-1")
+        );
     }
 
     /// R9(b2): the file writes `from-cursor` and the stored record holds the
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:1369:
         )
         .unwrap();
         let stored: Vec<&str> = decl.bindings.iter().map(|b| b.retention.as_str()).collect();
-        assert_eq!(stored, ["from_cursor", "from_cursor", "latest", "ttl", "windowed"]);
-        assert_eq!(decl.warnings.len(), 3, "the header, `from_cursor` and `windowed`: {:?}", decl.warnings);
+        assert_eq!(
+            stored,
+            ["from_cursor", "from_cursor", "latest", "ttl", "windowed"]
+        );
+        assert_eq!(
+            decl.warnings.len(),
+            3,
+            "the header, `from_cursor` and `windowed`: {:?}",
+            decl.warnings
+        );
         // The shipped file's five `from-cursor` lines all store the contract's spelling.
         let shipped = parse(&grazel_file()).unwrap();
-        let cursor = shipped.bindings.iter().filter(|b| b.retention == "from_cursor").count();
+        let cursor = shipped
+            .bindings
+            .iter()
+            .filter(|b| b.retention == "from_cursor")
+            .count();
         assert_eq!(cursor, 5);
-        assert!(shipped.bindings.iter().all(|b| b.retention != "from-cursor"));
+        assert!(shipped
+            .bindings
+            .iter()
+            .all(|b| b.retention != "from-cursor"));
     }
 
     // ---- Step 2.6: the zone and retention checks (§4.7 row 7) -------------
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:1382:
 
     /// The `v0` header's warning, for a header on line 1.
-    const V0_HEADER_AT_1: &str = "line 1: header `glade-app v0` names the old language; write `glade-app v1`";
+    const V0_HEADER_AT_1: &str =
+        "line 1: header `glade-app v0` names the old language; write `glade-app v1`";
 
     /// A `v1` file holding `lines` after its `app` line; the first is line 3.
     fn v1_file(lines: &str) -> String {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:1420:
     /// line, with the header to write instead. A `v1` header is not warned.
     #[test]
     fn a_v0_header_is_warned_naming_the_header_to_write() {
-        assert_eq!(parse("glade-app v0\napp x\n").unwrap().warnings, [V0_HEADER_AT_1]);
         assert_eq!(
-            parse("# c\n\n  glade-app   v0  # the header\napp x\n").unwrap().warnings,
+            parse("glade-app v0\napp x\n").unwrap().warnings,
+            [V0_HEADER_AT_1]
+        );
+        assert_eq!(
+            parse("# c\n\n  glade-app   v0  # the header\napp x\n")
+                .unwrap()
+                .warnings,
             ["line 3: header `glade-app v0` names the old language; write `glade-app v1`"]
         );
-        assert_eq!(parse("glade-app v1\napp x\n").unwrap().warnings, Vec::<String>::new());
+        assert_eq!(
+            parse("glade-app v1\napp x\n").unwrap().warnings,
+            Vec::<String>::new()
+        );
     }
 
     /// §4.7 row 7, an unknown zone (R1, row 31b (ii)): told on its line with
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:1437:
             let line = format!("binding g value share {zone} latest");
             assert_eq!(
                 v1_reports(&v1_file(&line)),
-                [format!(r#"line 3: unknown zone `{zone}` (one of ["commons", "private"])"#)]
+                [format!(
+                    r#"line 3: unknown zone `{zone}` (one of ["commons", "private"])"#
+                )]
             );
             assert_eq!(
                 v0_warnings(&line),
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:1444:
                 [
                     V0_HEADER_AT_1.to_string(),
-                    format!(r#"line 3: zone `{zone}` is not in `glade-app v1` (one of ["commons", "private"])"#)
+                    format!(
+                        r#"line 3: zone `{zone}` is not in `glade-app v1` (one of ["commons", "private"])"#
+                    )
                 ]
             );
         }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:1461:
         );
         assert_eq!(
             v0_warnings(line),
-            [V0_HEADER_AT_1, "line 3: retention `windowed` was removed in `glade-app v1` (use `from-cursor`)"]
+            [
+                V0_HEADER_AT_1,
+                "line 3: retention `windowed` was removed in `glade-app v1` (use `from-cursor`)"
+            ]
         );
     }
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:1492:
             let line = format!("binding g value share commons {retention}");
             assert_eq!(
                 v1_reports(&v1_file(&line)),
-                [format!(r#"line 3: unknown retention `{retention}` (one of ["latest", "from-cursor", "ttl"])"#)]
+                [format!(
+                    r#"line 3: unknown retention `{retention}` (one of ["latest", "from-cursor", "ttl"])"#
+                )]
             );
             assert_eq!(
                 v0_warnings(&line),
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:1518:
                      binding d value share private ttl ttl=10m\n\
                      binding e value share commons ttl\n\
                      binding f crdt  share commons from-cursor shape-profile=text_crdt";
-        assert_eq!(parse(&v1_file(lines)).unwrap().warnings, Vec::<String>::new());
-        assert_eq!(parse(&format!("glade-app v0\napp x\n{lines}\n")).unwrap().warnings, [V0_HEADER_AT_1]);
+        assert_eq!(
+            parse(&v1_file(lines)).unwrap().warnings,
+            Vec::<String>::new()
+        );
+        assert_eq!(
+            parse(&format!("glade-app v0\napp x\n{lines}\n"))
+                .unwrap()
+                .warnings,
+            [V0_HEADER_AT_1]
+        );
     }
 
     /// In this release a `v1` file's violations are warnings: the file loads,
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:1546:
             let decl = parse(&text).unwrap();
             let warned = told.map(|t| format!("{t}; a later node release refuses the line"));
             assert_eq!(decl.warnings, warned);
-            let stored: Vec<(&str, &str)> =
-                decl.bindings.iter().map(|b| (b.zone.as_str(), b.retention.as_str())).collect();
-            assert_eq!(stored, [("commons", "latest"), ("shared", "windowed"), ("commons", "from_cursor")]);
+            let stored: Vec<(&str, &str)> = decl
+                .bindings
+                .iter()
+                .map(|b| (b.zone.as_str(), b.retention.as_str()))
+                .collect();
+            assert_eq!(
+                stored,
+                [
+                    ("commons", "latest"),
+                    ("shared", "windowed"),
+                    ("commons", "from_cursor")
+                ]
+            );
         }
     }
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:1576:
                 r#"line 6: retention `hourly` is not in `glade-app v1` (one of ["latest", "from-cursor", "ttl"])"#,
             ]
         );
-        let stored: Vec<(&str, &str)> = decl.bindings.iter().map(|b| (b.zone.as_str(), b.retention.as_str())).collect();
+        let stored: Vec<(&str, &str)> = decl
+            .bindings
+            .iter()
+            .map(|b| (b.zone.as_str(), b.retention.as_str()))
+            .collect();
         assert_eq!(
             stored,
-            [("commons", "latest"), ("shared", "windowed"), ("commons", "from_cursor"), ("private", "hourly")]
+            [
+                ("commons", "latest"),
+                ("shared", "windowed"),
+                ("commons", "from_cursor"),
+                ("private", "hourly")
+            ]
         );
     }
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:1603:
             "line 3: `ttl=` needs the retention `ttl` (this line's is `windowed`)"
         );
         assert_eq!(
-            parse(&v1_file("binding g value share commons latest\nbinding g log share shared windowed")).unwrap_err(),
+            parse(&v1_file(
+                "binding g value share commons latest\nbinding g log share shared windowed"
+            ))
+            .unwrap_err(),
             "line 4: duplicate glade id `g`"
         );
     }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/assembly.rs:323:
         evidence: crate::independent::EvidenceConfig,
         source: P,
         roots: crate::independent::DiskRootConfig,
-    ) -> Result<crate::independent::ConfiguredIndependentAdapters<P>, glade_crdt_admission_data::Fault> {
+    ) -> Result<
+        crate::independent::ConfiguredIndependentAdapters<P>,
+        glade_crdt_admission_data::Fault,
+    > {
         crate::independent::ConfiguredIndependentAdapters::new(evidence, source, roots)
     }
 }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/claims.rs:53:
 use crate::registry::{Record, Registry, RegistryApi, G_CLAIMS, G_PRINCIPALS, HOME};
 use crate::server::{refresh_policy, Server, Shared};
 use crate::store::Store;
-use crate::sysdata::{PrincipalRecord, ServeClaim, WorkspaceCreateReq, WorkspaceCreateRes, WorkspaceEntry};
+use crate::sysdata::{
+    PrincipalRecord, ServeClaim, WorkspaceCreateReq, WorkspaceCreateRes, WorkspaceEntry,
+};
 use crate::sysdir::Boot;
 use crate::tasks::Site;
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/claims.rs:295:
 /// The mint itself, callable from the create ceremony (`exchange.rs`) as well
 /// as [`Server::serve_workspace`]. Returns whether anything NEW was minted —
 /// false = already configured locally, or a known remote owner is retained.
-pub(crate) async fn serve_workspace_on(shared: &Arc<Shared>, share: &str, name: &str) -> io::Result<bool> {
+pub(crate) async fn serve_workspace_on(
+    shared: &Arc<Shared>,
+    share: &str,
+    name: &str,
+) -> io::Result<bool> {
     let Some(state) = shared.dir.get() else {
         return Err(other("no directory authority (adopt_boot first)"));
     };
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/claims.rs:353:
 /// around this ceremony (the app-owned-storage seam); the ceremony creates the
 /// glade-side records only. Idempotent by diff: re-creating a workspace this
 /// node already serves appends nothing and answers `created: false`.
-pub(crate) async fn create_workspace(shared: &Arc<Shared>, req: &WorkspaceCreateReq) -> io::Result<WorkspaceCreateRes> {
+pub(crate) async fn create_workspace(
+    shared: &Arc<Shared>,
+    req: &WorkspaceCreateReq,
+) -> io::Result<WorkspaceCreateRes> {
     let Some(state) = shared.dir.get() else {
         return Err(other("no directory authority at the create target"));
     };
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/claims.rs:360:
-    let name = if req.name.is_empty() { req.workspace.clone() } else { req.name.clone() };
+    let name = if req.name.is_empty() {
+        req.workspace.clone()
+    } else {
+        req.name.clone()
+    };
     let created = serve_workspace_on(shared, &req.workspace, &name).await?;
     if !state.inner.lock().await.served.contains_key(&req.workspace) {
         return Err(io::Error::new(
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/claims.rs:382:
 /// and on a store-only node (no directory authority to attribute the append
 /// to — such sessions keep origin-as-identity, byte-for-byte).
 pub(crate) async fn note_principal(shared: &Arc<Shared>, principal: &str) {
-    let Some(state) = shared.dir.get() else { return };
+    let Some(state) = shared.dir.get() else {
+        return;
+    };
     {
         let st = shared.store.lock().await;
         if knows_principal(&st, principal) {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/claims.rs:467:
 /// claims chain into a checkpoint (plan Step 4.5c, `checkpoint::tick`), and
 /// says so through the root's reporter.
 async fn renew_leases(shared: &Arc<Shared>) {
-    let Some(state) = shared.dir.get() else { return };
+    let Some(state) = shared.dir.get() else {
+        return;
+    };
     let (node, leases) = (state.node_id.clone(), state.leases);
     let mut dir = state.inner.lock().await;
     if dir.served.is_empty() {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/claims.rs:1468:
         let (a_shared, b_shared) = (a.shared.clone(), b.shared.clone());
         {
             let bid = b_id.clone();
-            wait_store(&a_shared, move |st| who_serves(st, "ws-live", now_ms()) == Some(bid.clone()), "A to route ws-live to B").await;
+            wait_store(
+                &a_shared,
+                move |st| who_serves(st, "ws-live", now_ms()) == Some(bid.clone()),
+                "A to route ws-live to B",
+            )
+            .await;
         }
         {
             let st = a_shared.store.lock().await;
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/claims.rs:1495:
         };
         {
             let bid = b_id.clone();
-            wait_store(&a_shared, move |st| max_lease(st, "ws-live", &bid) > first, "a renewed lease to reach A").await;
+            wait_store(
+                &a_shared,
+                move |st| max_lease(st, "ws-live", &bid) > first,
+                "a renewed lease to reach A",
+            )
+            .await;
         }
         {
             let bid = b_id.clone();
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/claims.rs:1502:
             let st = b_shared.store.lock().await;
-            assert!(max_lease(&st, "ws-live", &bid) >= first, "the holder renews its own replica");
+            assert!(
+                max_lease(&st, "ws-live", &bid) >= first,
+                "the holder renews its own replica"
+            );
         }
 
         // (c) judged at a reader clock PAST the original horizon, the renewed
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/claims.rs:1511:
         }
 
         // in-process idempotence: re-serving mints nothing new.
-        assert!(!serve_workspace_on(&b.shared, "ws-live", "live").await.unwrap());
+        assert!(!serve_workspace_on(&b.shared, "ws-live", "live")
+            .await
+            .unwrap());
     }
 
     /// Principals minimal (P0.S7), end to end on a booted node: a session
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/claims.rs:1546:
             })
             .to_bytes()
         };
-        let sub = Frame::Subscribe(Subscribe { share: HOME.into(), glade_id: G_PRINCIPALS.into(), key: None, from: None }).to_bytes();
+        let sub = Frame::Subscribe(Subscribe {
+            share: HOME.into(),
+            glade_id: G_PRINCIPALS.into(),
+            key: None,
+            from: None,
+        })
+        .to_bytes();
         async fn next(r: &mut ws::WsReader, what: &str) -> Frame {
             let msg = tokio::time::timeout(Duration::from_secs(5), r.read())
                 .await
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/claims.rs:1574:
         let (mut r1, w1) = ws::connect("127.0.0.1", port).await.unwrap();
         w1.send_binary(&hello(Some("alice"))).await.unwrap();
         assert!(matches!(next(&mut r1, "welcome").await, Frame::Welcome(_)));
-        assert_eq!(shared.principals.lock().await.values().filter(|p| p.as_str() == "alice").count(), 1, "the session is BOUND");
+        assert_eq!(
+            shared
+                .principals
+                .lock()
+                .await
+                .values()
+                .filter(|p| p.as_str() == "alice")
+                .count(),
+            1,
+            "the session is BOUND"
+        );
 
         // (b) served via the ORDINARY subscribe path, origin-attributed.
         let (mut r2, w2) = ws::connect("127.0.0.1", port).await.unwrap();
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/claims.rs:1581:
         w2.send_binary(&sub).await.unwrap();
-        assert!(matches!(next(&mut r2, "dir.principals ack").await, Frame::Heads(_)));
+        assert!(matches!(
+            next(&mut r2, "dir.principals ack").await,
+            Frame::Heads(_)
+        ));
         match next(&mut r2, "the alice record").await {
             Frame::Ops(ops) => {
                 assert_eq!(ops.ops.len(), 1);
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/claims.rs:1586:
-                assert_eq!(ops.ops[0].origin, node_id, "attributed to the witnessing node's chain");
+                assert_eq!(
+                    ops.ops[0].origin, node_id,
+                    "attributed to the witnessing node's chain"
+                );
                 let record = envelope::record(&ops.ops[0], PrincipalRecord::from_cbor).unwrap();
                 assert_eq!(record.principal, "alice");
             }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/claims.rs:1593:
         // (c) a second Hello for the SAME principal appends nothing new...
         let (mut r3, w3) = ws::connect("127.0.0.1", port).await.unwrap();
         w3.send_binary(&hello(Some("alice"))).await.unwrap();
-        assert!(matches!(next(&mut r3, "second welcome").await, Frame::Welcome(_)));
+        assert!(matches!(
+            next(&mut r3, "second welcome").await,
+            Frame::Welcome(_)
+        ));
         // ...but a NEW principal lands (and reaches the live subscriber).
         let (mut r4, w4) = ws::connect("127.0.0.1", port).await.unwrap();
         w4.send_binary(&hello(Some("bob"))).await.unwrap();
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/claims.rs:1600:
-        assert!(matches!(next(&mut r4, "bob welcome").await, Frame::Welcome(_)));
+        assert!(matches!(
+            next(&mut r4, "bob welcome").await,
+            Frame::Welcome(_)
+        ));
         match next(&mut r2, "the bob record, live").await {
             Frame::Ops(ops) => {
                 let record = envelope::record(&ops.ops[0], PrincipalRecord::from_cbor).unwrap();
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/claims.rs:1607:
         }
         {
             let st = shared.store.lock().await;
-            assert_eq!(principal_count(&st, "alice"), 1, "no duplicate for a known principal");
+            assert_eq!(
+                principal_count(&st, "alice"),
+                1,
+                "no duplicate for a known principal"
+            );
             assert_eq!(principal_count(&st, "bob"), 1);
         }
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/claims.rs:1615:
         // nothing minted — the back-compat contract.
         let (mut r5, w5) = ws::connect("127.0.0.1", port).await.unwrap();
         w5.send_binary(&hello(None)).await.unwrap();
-        assert!(matches!(next(&mut r5, "plain welcome").await, Frame::Welcome(_)));
+        assert!(matches!(
+            next(&mut r5, "plain welcome").await,
+            Frame::Welcome(_)
+        ));
         {
             let st = shared.store.lock().await;
-            let total: usize = st.heads(HOME, G_PRINCIPALS, &[]).iter().map(|(o, s)| { let _ = o; (*s + 1) as usize }).sum();
-            assert_eq!(total, 2, "exactly alice + bob — plain sessions mint nothing");
+            let total: usize = st
+                .heads(HOME, G_PRINCIPALS, &[])
+                .iter()
+                .map(|(o, s)| {
+                    let _ = o;
+                    (*s + 1) as usize
+                })
+                .sum();
+            assert_eq!(
+                total, 2,
+                "exactly alice + bob — plain sessions mint nothing"
+            );
         }
     }
 }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/echo.rs:80:
         let mut e = Echo::new();
         let ch = || "ch1".to_string();
         // data before open: ignored
-        assert!(e.handle(&Frame::ChannelData(ChannelData { channel: ch(), data: b"x".to_vec() })).is_empty());
+        assert!(e
+            .handle(&Frame::ChannelData(ChannelData {
+                channel: ch(),
+                data: b"x".to_vec()
+            }))
+            .is_empty());
         // open, then data echoes
         e.handle(&Frame::ChannelOpen(ChannelOpen {
             share: "sh".into(),
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/echo.rs:88:
             channel: ch(),
             key: None,
         }));
-        match e.handle(&Frame::ChannelData(ChannelData { channel: ch(), data: b"abc".to_vec() })).as_slice() {
+        match e
+            .handle(&Frame::ChannelData(ChannelData {
+                channel: ch(),
+                data: b"abc".to_vec(),
+            }))
+            .as_slice()
+        {
             [Frame::ChannelData(d)] => assert_eq!(d.data, b"abc"),
             other => panic!("expected echoed ChannelData, got {other:?}"),
         }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/echo.rs:95:
         // close propagates once...
-        match e.handle(&Frame::ChannelClose(ChannelClose { channel: ch(), reason: None })).as_slice() {
+        match e
+            .handle(&Frame::ChannelClose(ChannelClose {
+                channel: ch(),
+                reason: None,
+            }))
+            .as_slice()
+        {
             [Frame::ChannelClose(c)] => assert_eq!(c.channel, "ch1"),
             other => panic!("expected ChannelClose, got {other:?}"),
         }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/echo.rs:100:
         // ...and data after close is ignored
-        assert!(e.handle(&Frame::ChannelData(ChannelData { channel: ch(), data: b"y".to_vec() })).is_empty());
+        assert!(e
+            .handle(&Frame::ChannelData(ChannelData {
+                channel: ch(),
+                data: b"y".to_vec()
+            }))
+            .is_empty());
     }
 }
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:90:
             family.extend(store.scan(HOME, stream, &[], &origin, i64::MIN));
         }
     }
-    BindingFold::over(&family).live().iter().any(|b| b.glade_id == glade_id && b.shape == "exchange")
+    BindingFold::over(&family)
+        .live()
+        .iter()
+        .any(|b| b.glade_id == glade_id && b.shape == "exchange")
 }
 
 /// An authority provider attaches: a SUBSCRIBE to a declared exchange surface
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:97:
 /// registers the session as THE provider for `(share, glade_id)` and acks with
 /// empty `Heads` (exchanges are never replicated — there is no gap to ship).
 /// The keyed entry map IS the routing table, applied to the directed leg.
-pub(crate) async fn attach_provider(shared: &Arc<Shared>, sid: SessionId, share: &str, glade_id: &str, key: Vec<u8>) {
-    shared.providers.lock().await.insert((share.into(), glade_id.into()), sid);
+pub(crate) async fn attach_provider(
+    shared: &Arc<Shared>,
+    sid: SessionId,
+    share: &str,
+    glade_id: &str,
+    key: Vec<u8>,
+) {
+    shared
+        .providers
+        .lock()
+        .await
+        .insert((share.into(), glade_id.into()), sid);
     let ack = Frame::Heads(Heads {
-        streams: vec![StreamHeads { share: share.into(), glade_id: glade_id.into(), key, heads: vec![] }],
+        streams: vec![StreamHeads {
+            share: share.into(),
+            glade_id: glade_id.into(),
+            key,
+            heads: vec![],
+        }],
     });
     send(shared, sid, &ack).await;
 }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:296:
 /// reason — an unlinked target fails as DATA, never a hang.
 async fn handle_create(shared: &Arc<Shared>, sid: SessionId, req: ExchangeReq) {
     if req.payload.is_empty() {
-        send(shared, sid, &res_err(&req.corr, "workspace.create needs a WorkspaceCreateReq payload")).await;
+        send(
+            shared,
+            sid,
+            &res_err(
+                &req.corr,
+                "workspace.create needs a WorkspaceCreateReq payload",
+            ),
+        )
+        .await;
         return;
     }
     let Some(create) = create_request(shared, sid, &req).await else {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:303:
         return;
     };
     if create.workspace.is_empty() || create.target.is_empty() {
-        send(shared, sid, &res_err(&req.corr, "workspace.create needs {workspace, target}")).await;
+        send(
+            shared,
+            sid,
+            &res_err(&req.corr, "workspace.create needs {workspace, target}"),
+        )
+        .await;
         return;
     }
     let Some(mesh) = shared.mesh.get() else {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:310:
-        send(shared, sid, &res_err(&req.corr, "workspace.create requires a booted node (no mesh)")).await;
+        send(
+            shared,
+            sid,
+            &res_err(
+                &req.corr,
+                "workspace.create requires a booted node (no mesh)",
+            ),
+        )
+        .await;
         return;
     };
     if create.target == mesh.self_id {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:329:
             forward_exchange(&forward, peer, req, sid).await;
         });
     } else {
-        let reason = format!("create target {} is not self or a linked peer", create.target);
+        let reason = format!(
+            "create target {} is not self or a linked peer",
+            create.target
+        );
         send(shared, sid, &res_err(&req.corr, &reason)).await;
     }
 }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:369:
 /// The requesting node's Forward arm: one conversation on the claim holder's
 /// link carries exactly one exchange; the response (or the bounded failure)
 /// is delivered to the requester as an `ExchangeRes`.
-async fn forward_exchange(shared: &Arc<Shared>, peer: String, req: ExchangeReq, requester: SessionId) {
+async fn forward_exchange(
+    shared: &Arc<Shared>,
+    peer: String,
+    req: ExchangeReq,
+    requester: SessionId,
+) {
     let corr = req.corr.clone();
     let frame = match try_forward(shared, &peer, req).await {
         Ok(res) => Frame::ExchangeRes(res),
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:378:
     send(shared, requester, &frame).await;
 }
 
-async fn try_forward(shared: &Arc<Shared>, peer: &str, req: ExchangeReq) -> io::Result<ExchangeRes> {
-    let mesh = shared.mesh.get().cloned().ok_or_else(|| other("mesh not enabled"))?;
+async fn try_forward(
+    shared: &Arc<Shared>,
+    peer: &str,
+    req: ExchangeReq,
+) -> io::Result<ExchangeRes> {
+    let mesh = shared
+        .mesh
+        .get()
+        .cloned()
+        .ok_or_else(|| other("mesh not enabled"))?;
     let linked = mesh.linked(peer).await;
     let linked = linked.ok_or_else(|| other("no live peer link"))?;
     let glade_id = req.glade_id.clone();
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:493:
     }
 
     fn sub(share: &str, glade_id: &str) -> Vec<u8> {
-        Frame::Subscribe(Subscribe { share: share.into(), glade_id: glade_id.into(), key: None, from: None })
-            .to_bytes()
+        Frame::Subscribe(Subscribe {
+            share: share.into(),
+            glade_id: glade_id.into(),
+            key: None,
+            from: None,
+        })
+        .to_bytes()
     }
 
     fn xreq(share: &str, glade_id: &str, corr: &str, payload: &[u8]) -> Vec<u8> {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:528:
     #[tokio::test]
     async fn local_provider_round_trip_absence_and_echo_fallback() {
         // a non-grazel app: the routing is app-agnostic.
-        let decl = appdecl::parse(
-            "glade-app v0\napp demo\nservice demo d.ops\n",
-        )
-        .unwrap();
+        let decl = appdecl::parse("glade-app v0\napp demo\nservice demo d.ops\n").unwrap();
         let (mut reg, n1) = sealed();
         appdecl::register(&decl, &mut reg, &n1).unwrap();
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:544:
         let (mut rc, wc) = ws::connect("127.0.0.1", port).await.unwrap(); // requester
 
         // (1) declared surface, nobody attached -> failure as data, bounded.
-        wc.send_binary(&xreq("s", "d.ops", "c0", b"status")).await.unwrap();
+        wc.send_binary(&xreq("s", "d.ops", "c0", b"status"))
+            .await
+            .unwrap();
         match next_frame(&mut rc, "no-provider answer").await {
             Frame::ExchangeRes(res) => {
                 assert_eq!(res.corr, "c0");
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:551:
                 assert!(!res.ok);
-                assert!(res.error.unwrap().contains("no authority provider"), "reason rides the response");
+                assert!(
+                    res.error.unwrap().contains("no authority provider"),
+                    "reason rides the response"
+                );
             }
             other => panic!("expected ExchangeRes, got {other:?}"),
         }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:557:
         // (2) the authority provider attaches: SUBSCRIBE to the declared surface.
         let (mut rp, wp) = ws::connect("127.0.0.1", port).await.unwrap();
         wp.send_binary(&sub("s", "d.ops")).await.unwrap();
-        assert!(matches!(next_frame(&mut rp, "provider attach ack").await, Frame::Heads(_)));
+        assert!(matches!(
+            next_frame(&mut rp, "provider attach ack").await,
+            Frame::Heads(_)
+        ));
 
         // (3) request -> provider (on the node's corr, F16) -> response -> requester (on its own).
-        wc.send_binary(&xreq("s", "d.ops", "c1", b"workspace.status")).await.unwrap();
+        wc.send_binary(&xreq("s", "d.ops", "c1", b"workspace.status"))
+            .await
+            .unwrap();
         let corr = match next_frame(&mut rp, "provider receives the request").await {
             Frame::ExchangeReq(req) => {
                 assert_eq!(req.payload, b"workspace.status");
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:589:
         }
 
         // (4) an UNDECLARED glade id still gets the legacy echo answer.
-        wc.send_binary(&xreq("s", "echo", "c2", b"ping")).await.unwrap();
+        wc.send_binary(&xreq("s", "echo", "c2", b"ping"))
+            .await
+            .unwrap();
         match next_frame(&mut rc, "echo fallback").await {
             Frame::ExchangeRes(res) => {
                 assert!(res.ok);
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:650:
         reg.append(binding("demo", "d.x", "exchange"), &n1).unwrap();
         assert!(declared_exchange(&store_of(&reg, "fold-1"), "d.x"));
         reg.append(binding("demo", "d.x", "value"), &n1).unwrap();
-        assert!(!declared_exchange(&store_of(&reg, "fold-2"), "d.x"), "the newest declaration is not an exchange");
+        assert!(
+            !declared_exchange(&store_of(&reg, "fold-2"), "d.x"),
+            "the newest declaration is not an exchange"
+        );
         reg.append(binding("demo", "d.x", "exchange"), &n1).unwrap();
         assert!(declared_exchange(&store_of(&reg, "fold-3"), "d.x"));
-        let retract = BindingRetraction { app: "demo".into(), glade_id: "d.x".into() };
+        let retract = BindingRetraction {
+            app: "demo".into(),
+            glade_id: "d.x".into(),
+        };
         reg.append(Record::Retract(retract), &n1).unwrap();
-        assert!(!declared_exchange(&store_of(&reg, "fold-4"), "d.x"), "a newest retraction takes it down");
+        assert!(
+            !declared_exchange(&store_of(&reg, "fold-4"), "d.x"),
+            "a newest retraction takes it down"
+        );
     }
 
     /// STA-P3-1: the served store holds several nodes' records, and a
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:707:
 
     fn create_payload(workspace: &str, name: &str, target: &str) -> Vec<u8> {
         glade_wire::cbor::encode(
-            &crate::sysdata::WorkspaceCreateReq { workspace: workspace.into(), name: name.into(), target: target.into() }.to_cbor(),
+            &crate::sysdata::WorkspaceCreateReq {
+                workspace: workspace.into(),
+                name: name.into(),
+                target: target.into(),
+            }
+            .to_cbor(),
         )
     }
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:776:
         let (a_shared, b_shared) = (a.shared.clone(), b.shared.clone());
         let lis_a = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
         let lis_b = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
-        let (port_a, port_b) = (lis_a.local_addr().unwrap().port(), lis_b.local_addr().unwrap().port());
+        let (port_a, port_b) = (
+            lis_a.local_addr().unwrap().port(),
+            lis_b.local_addr().unwrap().port(),
+        );
         tokio::spawn(a.run(lis_a));
         tokio::spawn(b.run(lis_b));
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:783:
         let (mut rc, wc) = ws::connect("127.0.0.1", port_a).await.unwrap();
 
         // ---- (a) create at B, asked from A ----------------------------------
-        wc.send_binary(&xreq(HOME, WORKSPACE_CREATE, "cr-1", &create_payload("ws-new", "new", &b_id))).await.unwrap();
+        wc.send_binary(&xreq(
+            HOME,
+            WORKSPACE_CREATE,
+            "cr-1",
+            &create_payload("ws-new", "new", &b_id),
+        ))
+        .await
+        .unwrap();
         match next_frame(&mut rc, "create response").await {
             Frame::ExchangeRes(res) => {
                 assert!(res.ok, "create succeeded, corr intact: {:?}", res.error);
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:790:
                 assert_eq!(res.corr, "cr-1");
-                let out = crate::sysdata::WorkspaceCreateRes::decode(&res.payload.unwrap()).unwrap();
-                assert_eq!((out.workspace.as_str(), out.node.as_str(), out.created), ("ws-new", b_id.as_str(), true), "the TARGET performed the creation under its own origin");
+                let out =
+                    crate::sysdata::WorkspaceCreateRes::decode(&res.payload.unwrap()).unwrap();
+                assert_eq!(
+                    (out.workspace.as_str(), out.node.as_str(), out.created),
+                    ("ws-new", b_id.as_str(), true),
+                    "the TARGET performed the creation under its own origin"
+                );
             }
             other => panic!("expected ExchangeRes, got {other:?}"),
         }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:797:
         // ---- (b) the minted records reached A (B9 push): routing follows ----
         {
             let bid = b_id.clone();
-            wait_store(&a_shared, move |st| crate::mesh::who_serves(st, "ws-new", now_ms()) == Some(bid.clone()), "A's fold to route ws-new to B").await;
+            wait_store(
+                &a_shared,
+                move |st| crate::mesh::who_serves(st, "ws-new", now_ms()) == Some(bid.clone()),
+                "A's fold to route ws-new to B",
+            )
+            .await;
         }
         wc.send_binary(&sub("ws-new", "ws.tree")).await.unwrap();
-        assert!(matches!(next_frame(&mut rc, "ws-new subscribe ack (routed, not absent)").await, Frame::Heads(_)));
+        assert!(matches!(
+            next_frame(&mut rc, "ws-new subscribe ack (routed, not absent)").await,
+            Frame::Heads(_)
+        ));
         // B's authority session writes; the op reaches the A-side client live.
         let (_rp, wp) = ws::connect("127.0.0.1", port_b).await.unwrap();
         let op = Op {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:815:
             shape: Shape::Value,
             payload: b"new-tree-v0".to_vec(),
         };
-        wp.send_binary(&Frame::Ops(Ops { ops: vec![op], pri: None }).to_bytes()).await.unwrap();
+        wp.send_binary(
+            &Frame::Ops(Ops {
+                ops: vec![op],
+                pri: None,
+            })
+            .to_bytes(),
+        )
+        .await
+        .unwrap();
         loop {
             if let Frame::Ops(ops) = next_frame(&mut rc, "content through the new claim").await {
                 if ops.ops.iter().any(|o| o.payload == b"new-tree-v0") {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:827:
         // ---- (c) re-create is idempotent: the records diff -------------------
         let (entry_heads, epoch_before) = {
             let st = b_shared.store.lock().await;
-            (st.heads(HOME, crate::registry::G_WORKSPACES, &[]), max_claim_epoch_for(&st, "ws-new"))
+            (
+                st.heads(HOME, crate::registry::G_WORKSPACES, &[]),
+                max_claim_epoch_for(&st, "ws-new"),
+            )
         };
-        wc.send_binary(&xreq(HOME, WORKSPACE_CREATE, "cr-2", &create_payload("ws-new", "new", &b_id))).await.unwrap();
+        wc.send_binary(&xreq(
+            HOME,
+            WORKSPACE_CREATE,
+            "cr-2",
+            &create_payload("ws-new", "new", &b_id),
+        ))
+        .await
+        .unwrap();
         match next_frame(&mut rc, "re-create response").await {
             Frame::ExchangeRes(res) => {
                 assert!(res.ok);
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:836:
-                let out = crate::sysdata::WorkspaceCreateRes::decode(&res.payload.unwrap()).unwrap();
+                let out =
+                    crate::sysdata::WorkspaceCreateRes::decode(&res.payload.unwrap()).unwrap();
                 assert!(!out.created, "already served: nothing new minted");
             }
             other => panic!("expected ExchangeRes, got {other:?}"),
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:840:
         }
         {
             let st = b_shared.store.lock().await;
-            assert_eq!(st.heads(HOME, crate::registry::G_WORKSPACES, &[]), entry_heads, "no duplicate WorkspaceEntry");
-            assert_eq!(max_claim_epoch_for(&st, "ws-new"), epoch_before, "no re-claim: the epoch is stable");
+            assert_eq!(
+                st.heads(HOME, crate::registry::G_WORKSPACES, &[]),
+                entry_heads,
+                "no duplicate WorkspaceEntry"
+            );
+            assert_eq!(
+                max_claim_epoch_for(&st, "ws-new"),
+                epoch_before,
+                "no re-claim: the epoch is stable"
+            );
         }
 
         // ---- (d) an unlinked target fails as data ----------------------------
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:848:
-        wc.send_binary(&xreq(HOME, WORKSPACE_CREATE, "cr-3", &create_payload("ws-nope", "nope", "deadbeef"))).await.unwrap();
+        wc.send_binary(&xreq(
+            HOME,
+            WORKSPACE_CREATE,
+            "cr-3",
+            &create_payload("ws-nope", "nope", "deadbeef"),
+        ))
+        .await
+        .unwrap();
         match next_frame(&mut rc, "unlinked-target failure data").await {
             Frame::ExchangeRes(res) => {
                 assert_eq!(res.corr, "cr-3");
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:852:
                 assert!(!res.ok);
-                assert!(res.error.unwrap().contains("not self or a linked peer"), "the reason rides the response");
+                assert!(
+                    res.error.unwrap().contains("not self or a linked peer"),
+                    "the reason rides the response"
+                );
             }
             other => panic!("expected ExchangeRes failure data, got {other:?}"),
         }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:857:
         // failure is data, not a dead session: the next ask still answers.
-        wc.send_binary(&sub(HOME, crate::registry::G_WORKSPACES)).await.unwrap();
-        assert!(matches!(next_frame(&mut rc, "post-failure ack").await, Frame::Heads(_)));
+        wc.send_binary(&sub(HOME, crate::registry::G_WORKSPACES))
+            .await
+            .unwrap();
+        assert!(matches!(
+            next_frame(&mut rc, "post-failure ack").await,
+            Frame::Heads(_)
+        ));
 
         // ---- (e) target == self performs locally -----------------------------
-        wc.send_binary(&xreq(HOME, WORKSPACE_CREATE, "cr-4", &create_payload("ws-mine", "mine", &a_id))).await.unwrap();
+        wc.send_binary(&xreq(
+            HOME,
+            WORKSPACE_CREATE,
+            "cr-4",
+            &create_payload("ws-mine", "mine", &a_id),
+        ))
+        .await
+        .unwrap();
         {
             let res = next_exchange_res(&mut rc, "self-target create response").await;
             assert!(res.ok, "{:?}", res.error);
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:869:
         }
         {
             let st = a_shared.store.lock().await;
-            assert_eq!(crate::mesh::who_serves(&st, "ws-mine", now_ms()), Some(a_id.clone()));
+            assert_eq!(
+                crate::mesh::who_serves(&st, "ws-mine", now_ms()),
+                Some(a_id.clone())
+            );
         }
     }
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:907:
         boot_b
             .registry
             .append(
-                Record::Serve(ServeClaim { node: b_id.clone(), share: "ws-razel".into(), lease_expiry_ms: now_ms() + 30_000, epoch: 1 }),
+                Record::Serve(ServeClaim {
+                    node: b_id.clone(),
+                    share: "ws-razel".into(),
+                    lease_expiry_ms: now_ms() + 30_000,
+                    epoch: 1,
+                }),
                 &b_id,
             )
             .unwrap();
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:915:
         boot_b
             .registry
             .append(
-                Record::Serve(ServeClaim { node: "attic-mini".into(), share: "ws-attic".into(), lease_expiry_ms: now_ms() - 1_000, epoch: 1 }),
+                Record::Serve(ServeClaim {
+                    node: "attic-mini".into(),
+                    share: "ws-attic".into(),
+                    lease_expiry_ms: now_ms() - 1_000,
+                    epoch: 1,
+                }),
                 &b_id,
             )
             .unwrap();
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:933:
         let a_shared = a.shared.clone();
         let lis_a = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
         let lis_b = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
-        let (port_a, port_b) = (lis_a.local_addr().unwrap().port(), lis_b.local_addr().unwrap().port());
+        let (port_a, port_b) = (
+            lis_a.local_addr().unwrap().port(),
+            lis_b.local_addr().unwrap().port(),
+        );
         tokio::spawn(a.run(lis_a));
         tokio::spawn(b.run(lis_b));
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:941:
         // attaches as gwz.ops provider AND appends the ws.tree binding content.
         let (mut rp, wp) = ws::connect("127.0.0.1", port_b).await.unwrap();
         wp.send_binary(&sub("ws-razel", "gwz.ops")).await.unwrap();
-        assert!(matches!(next_frame(&mut rp, "grazel attach ack").await, Frame::Heads(_)));
+        assert!(matches!(
+            next_frame(&mut rp, "grazel attach ack").await,
+            Frame::Heads(_)
+        ));
         let o0 = tree_op(0, None, b"tree-v0");
         let o1 = tree_op(1, Some(crate::chain::op_hash(&o0).to_vec()), b"tree-v1");
-        wp.send_binary(&Frame::Ops(Ops { ops: vec![o0.clone(), o1.clone()], pri: None }).to_bytes()).await.unwrap();
+        wp.send_binary(
+            &Frame::Ops(Ops {
+                ops: vec![o0.clone(), o1.clone()],
+                pri: None,
+            })
+            .to_bytes(),
+        )
+        .await
+        .unwrap();
         // each op is answered on the provider's session, by its hash (R1).
         for o in [&o0, &o1] {
             match next_frame(&mut rp, "the provider's op status").await {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:1004:
         // ---- (a) registered surfaces appear at A as ordinary records --------
         let (mut rc, wc) = ws::connect("127.0.0.1", port_a).await.unwrap();
         wc.send_binary(&sub(HOME, G_BINDINGS)).await.unwrap();
-        assert!(matches!(next_frame(&mut rc, "dir.bindings ack").await, Frame::Heads(_)));
+        assert!(matches!(
+            next_frame(&mut rc, "dir.bindings ack").await,
+            Frame::Heads(_)
+        ));
         let mut bindings = Vec::new();
         while bindings.len() < 7 {
             if let Frame::Ops(ops) = next_frame(&mut rc, "BindingDecl records").await {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:1020:
         // (gwz.output, chat.msgs, chat.groups) — P1.S3.
         assert_eq!(
             bindings,
-            vec!["chat.groups", "chat.msgs", "gwz.output", "term.log", "ws.diff", "ws.files", "ws.tree"]
+            vec![
+                "chat.groups",
+                "chat.msgs",
+                "gwz.output",
+                "term.log",
+                "ws.diff",
+                "ws.files",
+                "ws.tree"
+            ]
         );
         // the ACL seeds compiled to ORDINARY grant records (s-app-register A5).
         wc.send_binary(&sub(HOME, G_GRANTS)).await.unwrap();
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:1027:
-        assert!(matches!(next_frame(&mut rc, "dir.grants ack").await, Frame::Heads(_)));
+        assert!(matches!(
+            next_frame(&mut rc, "dir.grants ack").await,
+            Frame::Heads(_)
+        ));
         let mut grants = Vec::new();
         while grants.len() < 3 {
             if let Frame::Ops(ops) = next_frame(&mut rc, "seeded grant records").await {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:1058:
 
         // ---- (b) the declared binding is served end to end ------------------
         wc.send_binary(&sub("ws-razel", "ws.tree")).await.unwrap();
-        assert!(matches!(next_frame(&mut rc, "ws.tree ack").await, Frame::Heads(_)));
+        assert!(matches!(
+            next_frame(&mut rc, "ws.tree ack").await,
+            Frame::Heads(_)
+        ));
         let mut payloads = Vec::new();
         while payloads.len() < 2 {
             if let Frame::Ops(ops) = next_frame(&mut rc, "routed tree ops").await {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:1065:
                 payloads.extend(ops.ops.into_iter().map(|o| o.payload));
             }
         }
-        assert_eq!(payloads, vec![b"tree-v0".to_vec(), b"tree-v1".to_vec()], "authority content converges in order");
+        assert_eq!(
+            payloads,
+            vec![b"tree-v0".to_vec(), b"tree-v1".to_vec()],
+            "authority content converges in order"
+        );
 
         // ---- (c) the gwz exchange round-trips through the authority ---------
-        wc.send_binary(&xreq("ws-razel", "gwz.ops", "x-42", b"workspace.status")).await.unwrap();
+        wc.send_binary(&xreq("ws-razel", "gwz.ops", "x-42", b"workspace.status"))
+            .await
+            .unwrap();
         let corr = match next_frame(&mut rp, "grazel receives the forwarded exchange").await {
             Frame::ExchangeReq(req) => {
                 assert_ne!(req.corr, "x-42", "the handler sees B's correlation");
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:1092:
             Frame::ExchangeRes(res) => {
                 assert!(res.ok);
                 assert_eq!(res.corr, "x-42");
-                assert_eq!(res.payload.as_deref(), Some(b"12 clean, 1 dirty".as_slice()));
+                assert_eq!(
+                    res.payload.as_deref(),
+                    Some(b"12 clean, 1 dirty".as_slice())
+                );
             }
             other => panic!("requester expected ExchangeRes, got {other:?}"),
         }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:1099:
 
         // ---- (d) missing/unclaimed target: bounded failure as data ----------
-        wc.send_binary(&xreq("ws-attic", "gwz.ops", "x-43", b"workspace.status")).await.unwrap();
+        wc.send_binary(&xreq("ws-attic", "gwz.ops", "x-43", b"workspace.status"))
+            .await
+            .unwrap();
         match next_frame(&mut rc, "ws-attic exchange status").await {
             Frame::ExchangeRes(res) => {
                 assert_eq!(res.corr, "x-43");
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:1105:
                 assert!(!res.ok);
-                assert!(res.error.unwrap().contains("no live ServeClaim"), "the reason rides the response");
+                assert!(
+                    res.error.unwrap().contains("no live ServeClaim"),
+                    "the reason rides the response"
+                );
             }
             other => panic!("expected ExchangeRes failure data, got {other:?}"),
         }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:1110:
         // failure is data, not a dead session: the next ask still answers.
-        wc.send_binary(&sub(HOME, crate::registry::G_CLAIMS)).await.unwrap();
-        assert!(matches!(next_frame(&mut rc, "post-failure ack").await, Frame::Heads(_)));
+        wc.send_binary(&sub(HOME, crate::registry::G_CLAIMS))
+            .await
+            .unwrap();
+        assert!(matches!(
+            next_frame(&mut rc, "post-failure ack").await,
+            Frame::Heads(_)
+        ));
     }
 
     /// `grazel_attach_end_to_end`, turned round (plan Step 4.3): B's fold
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/frame.rs:119:
             seq: 1,
             prev: None,
             lamport: 1,
-            refs: vec![Head { origin: "b".into(), seq: 2, hash: None }],
+            refs: vec![Head {
+                origin: "b".into(),
+                seq: 2,
+                hash: None,
+            }],
             shape: Shape::Value,
             payload: b"hi".to_vec(),
         };
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/frame.rs:133:
                     share: "sh".into(),
                     glade_id: "".into(),
                     key: vec![],
-                    heads: vec![Head { origin: "a".into(), seq: 1, hash: None }],
+                    heads: vec![Head {
+                        origin: "a".into(),
+                        seq: 1,
+                        hash: None,
+                    }],
                 }],
             }),
-            Frame::Ops(Ops { ops: vec![op], pri: None }),
-            Frame::Welcome(Welcome { session: "s1".into(), protocol: 1, heads: vec![] }),
+            Frame::Ops(Ops {
+                ops: vec![op],
+                pri: None,
+            }),
+            Frame::Welcome(Welcome {
+                session: "s1".into(),
+                protocol: 1,
+                heads: vec![],
+            }),
         ];
         for f in frames {
             let round = Frame::from_bytes(&f.to_bytes()).unwrap();
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/lib.rs:20:
 pub mod exchange;
 pub mod frame;
 pub mod grants;
-pub mod iroh_carrier;
 pub mod independent;
+pub mod iroh_carrier;
 pub mod lifecycle;
 pub mod mesh;
 pub mod netconf;
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/home.rs:29:
 /// conversation per link, its one `Ops` frame then END, only queued (plan
 /// Step 4.5b); one over the frame limit is not sent, with a line.
 pub(crate) async fn push_home(shared: &Arc<Shared>, ops: Vec<Op>) {
-    let Some(mesh) = shared.mesh.get() else { return };
+    let Some(mesh) = shared.mesh.get() else {
+        return;
+    };
     let Some(first) = ops.first() else { return };
     let zone = (first.share.clone(), first.glade_id.clone());
     let links: Vec<Arc<Linked>> = {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/home.rs:65:
 ) -> io::Result<SyncOutcome> {
     let ours: Vec<StreamHeads> = {
         let st = shared.store.lock().await;
-        st.all_heads().into_iter().filter(|sh| sh.share == HOME).collect()
+        st.all_heads()
+            .into_iter()
+            .filter(|sh| sh.share == HOME)
+            .collect()
     };
     conversation.send(&Frame::Heads(Heads { streams: ours }))?;
     let mut round = Round::new(shared, mesh, peer);
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/home.rs:339:
         if let Some((mesh, pair)) = revoked {
             close_revoked(mesh, pair).await;
         }
-        let targets = shared.router.lock().await.route(from, &share, &glade_id, &key);
+        let targets = shared
+            .router
+            .lock()
+            .await
+            .route(from, &share, &glade_id, &key);
         if !targets.is_empty() {
-            let frame = Frame::Ops(Ops { ops: vec![op], pri: None });
+            let frame = Frame::Ops(Ops {
+                ops: vec![op],
+                pri: None,
+            });
             for t in targets {
                 send(shared, t, &frame).await;
             }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/link.rs:96:
     /// (a pull each way rides the link). Returns the peer's directory node id
     /// (hex).
     pub async fn connect_peer(&self, target: impl Into<PeerEntry>) -> io::Result<String> {
-        let mesh = self.shared.mesh.get().cloned().ok_or_else(|| other("mesh not enabled"))?;
+        let mesh = self
+            .shared
+            .mesh
+            .get()
+            .cloned()
+            .ok_or_else(|| other("mesh not enabled"))?;
         let entry = target.into();
         let at = carrier_addr(&entry).ok_or_else(|| other("the peer names no address to dial"))?;
         let link: Arc<dyn CarrierLink> = Arc::from(mesh.port.dial(&at).await.map_err(carried)?);
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/route.rs:45:
 /// share → absent (lease lapsed at the reader's clock — trace E2); a share the
 /// directory has never heard of → local (plain app-share serving).
 pub(crate) async fn route_subscribe(shared: &Arc<Shared>, share: &str) -> Route {
-    let Some(mesh) = shared.mesh.get() else { return Route::Local };
+    let Some(mesh) = shared.mesh.get() else {
+        return Route::Local;
+    };
     if share == HOME {
         return Route::Local;
     }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/route.rs:52:
     let (holder, known) = {
         let st = shared.store.lock().await;
-        (who_serves(&st, share, now_ms()), directory_knows(&st, share))
+        (
+            who_serves(&st, share, now_ms()),
+            directory_knows(&st, share),
+        )
     };
     match holder {
         Some(id) if id == mesh.self_id => Route::Local,
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/route.rs:244:
     let mut conversation = linked.open();
     let from: Vec<Head> = {
         let st = shared.store.lock().await;
-        st.heads(share, glade_id, key).into_iter().map(|(origin, seq)| Head { origin, seq, hash: None }).collect()
+        st.heads(share, glade_id, key)
+            .into_iter()
+            .map(|(origin, seq)| Head {
+                origin,
+                seq,
+                hash: None,
+            })
+            .collect()
     };
     let sub = Subscribe {
         share: share.into(),
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/route.rs:251:
         glade_id: glade_id.into(),
-        key: if key.is_empty() { None } else { Some(key.to_vec()) },
+        key: if key.is_empty() {
+            None
+        } else {
+            Some(key.to_vec())
+        },
         from: Some(from),
     };
     conversation.send(&Frame::Subscribe(sub))?;
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/serve.rs:121:
     let sid = shared.next.fetch_add(1, Ordering::SeqCst);
     let (tx, mut rx) = tokio::sync::mpsc::unbounded_channel::<Vec<u8>>();
     shared.out.lock().await.insert(sid, tx.clone());
-    shared.router.lock().await.subscribe(sid, &s.share, &s.glade_id, &key);
+    shared
+        .router
+        .lock()
+        .await
+        .subscribe(sid, &s.share, &s.glade_id, &key);
     shared.admitted.lock().await.insert(sid, node);
 
     // Ack + gap ride the SAME outbound channel as live fan-out, so a live op
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/serve.rs:128:
     // can never overtake the resume gap on the conversation. The gap goes in
     // chunks under the link's frame limit (plan Step 4.5b).
-    let their: crate::session::Heads =
-        s.from.clone().unwrap_or_default().into_iter().map(|h| (h.origin, h.seq)).collect();
+    let their: crate::session::Heads = s
+        .from
+        .clone()
+        .unwrap_or_default()
+        .into_iter()
+        .map(|h| (h.origin, h.seq))
+        .collect();
     let (acked, gap) = {
         let st = shared.store.lock().await;
         let gap = missing_for(&st, &s.share, &s.glade_id, &key, &their);
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/serve.rs:202:
 ) -> io::Result<()> {
     let mut by_zone: BTreeMap<(String, String, Vec<u8>), BTreeMap<String, i64>> = BTreeMap::new();
     for sh in their.streams {
-        let m = by_zone.entry((sh.share.clone(), sh.glade_id.clone(), sh.key.clone())).or_default();
+        let m = by_zone
+            .entry((sh.share.clone(), sh.glade_id.clone(), sh.key.clone()))
+            .or_default();
         for hd in sh.heads {
             m.insert(hd.origin, hd.seq);
         }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/serve.rs:215:
             if share != HOME {
                 continue;
             }
-            let their_v = by_zone.get(&(share.clone(), glade_id.clone(), key.clone())).cloned().unwrap_or_default();
+            let their_v = by_zone
+                .get(&(share.clone(), glade_id.clone(), key.clone()))
+                .cloned()
+                .unwrap_or_default();
             gap.extend(missing_for(&st, &share, &glade_id, &key, &their_v));
         }
         gap
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/tests/forward.rs:39:
 
     // ---- (a) phase A: list the directory from A's LOCAL replica ---------
     let (mut rc, wc) = crate::ws::connect("127.0.0.1", port_a).await.unwrap();
-    wc.send_binary(&sub(HOME, crate::registry::G_WORKSPACES)).await.unwrap();
-    assert!(matches!(next_frame(&mut rc, "dir.workspaces ack").await, Frame::Heads(_)));
+    wc.send_binary(&sub(HOME, crate::registry::G_WORKSPACES))
+        .await
+        .unwrap();
+    assert!(matches!(
+        next_frame(&mut rc, "dir.workspaces ack").await,
+        Frame::Heads(_)
+    ));
     let mut names = Vec::new();
     while names.len() < 2 {
         if let Frame::Ops(ops) = next_frame(&mut rc, "workspace entries").await {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/tests/forward.rs:52:
         }
     }
     names.sort();
-    assert_eq!(names, vec!["ws-attic".to_string(), "ws-razel".to_string()], "the list from the local replica");
+    assert_eq!(
+        names,
+        vec!["ws-attic".to_string(), "ws-razel".to_string()],
+        "the list from the local replica"
+    );
 
     // ---- (b) phase C: the claim routes the workspace share to B ---------
     wc.send_binary(&sub("ws-razel", "ws.tree")).await.unwrap();
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/tests/forward.rs:59:
-    assert!(matches!(next_frame(&mut rc, "ws.tree ack").await, Frame::Heads(_)));
+    assert!(matches!(
+        next_frame(&mut rc, "ws.tree ack").await,
+        Frame::Heads(_)
+    ));
     let mut payloads = Vec::new();
     while payloads.len() < 2 {
         if let Frame::Ops(ops) = next_frame(&mut rc, "routed tree ops").await {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/tests/forward.rs:63:
             payloads.extend(ops.ops.into_iter().map(|o| o.payload));
         }
     }
-    assert_eq!(payloads, vec![b"tree-v0".to_vec(), b"tree-v1".to_vec()], "the routed gap converges in order");
+    assert_eq!(
+        payloads,
+        vec![b"tree-v0".to_vec(), b"tree-v1".to_vec()],
+        "the routed gap converges in order"
+    );
     // ...and INTO A's replica — the replica served the read (C5).
-    wait_store(&a_shared, |st| st.scan("ws-razel", "ws.tree", &[], "prov-b", i64::MIN).len() == 2, "A's replica to hold the routed zone").await;
+    wait_store(
+        &a_shared,
+        |st| {
+            st.scan("ws-razel", "ws.tree", &[], "prov-b", i64::MIN)
+                .len()
+                == 2
+        },
+        "A's replica to hold the routed zone",
+    )
+    .await;
 
     // live: the provider writes v2 on B; it reaches the A-side client with
     // no re-request (the C5→C6 stream keeps flowing).
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/tests/forward.rs:72:
     let o2 = tree_op(2, Some(crate::chain::op_hash(&o1).to_vec()), b"tree-v2");
-    wp.send_binary(&Frame::Ops(Ops { ops: vec![o2], pri: None }).to_bytes()).await.unwrap();
+    wp.send_binary(
+        &Frame::Ops(Ops {
+            ops: vec![o2],
+            pri: None,
+        })
+        .to_bytes(),
+    )
+    .await
+    .unwrap();
     loop {
         if let Frame::Ops(ops) = next_frame(&mut rc, "live tree op").await {
             if ops.ops.iter().any(|o| o.payload == b"tree-v2") {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/tests/forward.rs:97:
             assert_eq!(e.share.as_deref(), Some("ws-attic"));
             assert_eq!(e.glade_id.as_deref(), Some("ws.tree"));
             assert_eq!(e.corr, None, "a refused subscribe names no op");
-            assert!(e.message.contains("no live ServeClaim"), "the reason rides the status: {}", e.message);
+            assert!(
+                e.message.contains("no live ServeClaim"),
+                "the reason rides the status: {}",
+                e.message
+            );
         }
         other => panic!("expected STATUS (Error frame), got {other:?}"),
     }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/tests/forward.rs:104:
     // absence is data, not a dead session: the next ask still answers,
     // with an ack that names its zone.
-    wc.send_binary(&sub(HOME, crate::registry::G_CLAIMS)).await.unwrap();
+    wc.send_binary(&sub(HOME, crate::registry::G_CLAIMS))
+        .await
+        .unwrap();
     match next_frame(&mut rc, "post-absence ack").await {
         Frame::Heads(h) => {
             assert_eq!(h.streams.len(), 1, "an accepted ack names its zone: {h:?}")
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/tests/home.rs:63:
     let (b_id, a_id) = (boot_b.node_id.clone(), boot_a.node_id.clone());
     {
         let bid = b_id.clone();
-        wait_for(&a, move |st| !st.scan(HOME, crate::registry::G_NODES, &[], &bid, i64::MIN).is_empty(), "A to hold B's presence").await;
+        wait_for(
+            &a,
+            move |st| {
+                !st.scan(HOME, crate::registry::G_NODES, &[], &bid, i64::MIN)
+                    .is_empty()
+            },
+            "A to hold B's presence",
+        )
+        .await;
     }
     {
         let st = a.shared.store.lock().await;
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/tests/home.rs:70:
-        assert!(!st.scan(HOME, crate::registry::G_WORKSPACES, &[], &b_id, i64::MIN).is_empty(), "A holds B's WorkspaceEntry");
+        assert!(
+            !st.scan(HOME, crate::registry::G_WORKSPACES, &[], &b_id, i64::MIN)
+                .is_empty(),
+            "A holds B's WorkspaceEntry"
+        );
         // ...and A's LOCAL fold routes ws-razel to B, judged at A's clock.
         assert_eq!(who_serves(&st, "ws-razel", now_ms()), Some(b_id.clone()));
-        assert_eq!(who_serves(&st, "ws-razel", now_ms() + 60_000), None, "lapsed at a later reader clock");
+        assert_eq!(
+            who_serves(&st, "ws-razel", now_ms() + 60_000),
+            None,
+            "lapsed at a later reader clock"
+        );
     }
 
     // ...and B pulled A (the reverse direction of the same connection).
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/tests/home.rs:77:
     {
         let aid = a_id.clone();
-        wait_for(&b, move |st| !st.scan(HOME, crate::registry::G_NODES, &[], &aid, i64::MIN).is_empty(), "B to hold A's presence").await;
+        wait_for(
+            &b,
+            move |st| {
+                !st.scan(HOME, crate::registry::G_NODES, &[], &aid, i64::MIN)
+                    .is_empty()
+            },
+            "B to hold A's presence",
+        )
+        .await;
     }
 }
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/tests/two_nodes.rs:15:
 use std::time::Duration;
 
 pub(super) fn sub(share: &str, glade_id: &str) -> Vec<u8> {
-    Frame::Subscribe(Subscribe { share: share.into(), glade_id: glade_id.into(), key: None, from: None })
-        .to_bytes()
+    Frame::Subscribe(Subscribe {
+        share: share.into(),
+        glade_id: glade_id.into(),
+        key: None,
+        from: None,
+    })
+    .to_bytes()
 }
 
 pub(super) fn tree_op(seq: i64, prev: Option<Vec<u8>>, payload: &[u8]) -> Op {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/tests/two_nodes.rs:122:
     let (a_shared, b_shared) = (a.shared.clone(), b.shared.clone());
     let lis_a = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
     let lis_b = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
-    let (port_a, port_b) = (lis_a.local_addr().unwrap().port(), lis_b.local_addr().unwrap().port());
+    let (port_a, port_b) = (
+        lis_a.local_addr().unwrap().port(),
+        lis_b.local_addr().unwrap().port(),
+    );
     tokio::spawn(a.run(lis_a));
     tokio::spawn(b.run(lis_b));
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/peer.rs:373:
 pub type ChainKey = (String, String, Vec<u8>, String);
 
 fn chain_key(op: &Op) -> ChainKey {
-    (op.share.clone(), op.glade_id.clone(), op.key.clone(), op.origin.clone())
+    (
+        op.share.clone(),
+        op.glade_id.clone(),
+        op.key.clone(),
+        op.origin.clone(),
+    )
 }
 
 /// What a pull produced.
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/peer.rs:417:
 {
     let their = match read_frame(r).await? {
         Frame::Heads(h) => h.streams,
-        other => return Err(io::Error::new(io::ErrorKind::InvalidData, format!("expected Heads, got {other:?}"))),
+        other => {
+            return Err(io::Error::new(
+                io::ErrorKind::InvalidData,
+                format!("expected Heads, got {other:?}"),
+            ))
+        }
     };
     // Index the peer's vectors by zone -> origin -> seq.
-    let mut their_by_zone: BTreeMap<(String, String, Vec<u8>), BTreeMap<String, i64>> = BTreeMap::new();
+    let mut their_by_zone: BTreeMap<(String, String, Vec<u8>), BTreeMap<String, i64>> =
+        BTreeMap::new();
     for sh in their {
-        let m = their_by_zone.entry((sh.share.clone(), sh.glade_id.clone(), sh.key.clone())).or_default();
+        let m = their_by_zone
+            .entry((sh.share.clone(), sh.glade_id.clone(), sh.key.clone()))
+            .or_default();
         for hd in sh.heads {
             m.insert(hd.origin, hd.seq);
         }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/peer.rs:432:
         if share != HOME && grants.check(holder, READ_SUBSCRIBE, &share).is_err() {
             continue;
         }
-        let their_v = their_by_zone.get(&(share.clone(), glade_id.clone(), key.clone())).cloned().unwrap_or_default();
+        let their_v = their_by_zone
+            .get(&(share.clone(), glade_id.clone(), key.clone()))
+            .cloned()
+            .unwrap_or_default();
         let gap = missing_for(store, &share, &glade_id, &key, &their_v);
         for chunk in gap.chunks(OPS_PER_CHUNK) {
-            write_frame(w, &Frame::Ops(Ops { ops: chunk.to_vec(), pri: Some(Priority::Bulk) })).await?;
+            write_frame(
+                w,
+                &Frame::Ops(Ops {
+                    ops: chunk.to_vec(),
+                    pri: Some(Priority::Bulk),
+                }),
+            )
+            .await?;
             sent += chunk.len();
         }
     }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/peer.rs:461:
     R: AsyncRead + Unpin,
     W: AsyncWrite + Unpin,
 {
-    write_frame(w, &Frame::Heads(Heads { streams: store.all_heads() })).await?;
+    write_frame(
+        w,
+        &Frame::Heads(Heads {
+            streams: store.all_heads(),
+        }),
+    )
+    .await?;
     let before = store.equivocation_proofs().len();
     let mut out = SyncOutcome::default();
     loop {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/peer.rs:1088:
         let mut prev = None;
         let mut ops = Vec::new();
         for seq in 0..n {
-            let o = op(origin, seq, key, prev.clone(), format!("{origin}{seq}").as_bytes());
+            let o = op(
+                origin,
+                seq,
+                key,
+                prev.clone(),
+                format!("{origin}{seq}").as_bytes(),
+            );
             store.append(o.clone()).unwrap();
             prev = Some(crate::chain::op_hash(&o).to_vec());
             ops.push(o);
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/peer.rs:1253:
         // Malicious peer: ops 0,1,2 valid, op 3 with a tampered prev, then op 4.
         let mut bad3 = ops[3].clone();
         bad3.prev = Some(vec![0u8; 32]); // != hash(op2) -> chain break at seq 3
-        let malicious = vec![ops[0].clone(), ops[1].clone(), ops[2].clone(), bad3, ops[4].clone()];
+        let malicious = vec![
+            ops[0].clone(),
+            ops[1].clone(),
+            ops[2].clone(),
+            bad3,
+            ops[4].clone(),
+        ];
 
         let (ca, cb) = tokio::io::duplex(64 * 1024);
         let (mut ar, mut aw) = split(ca);
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/peer.rs:1260:
         let (mut br, mut bw) = split(cb);
         let carrier = tokio::spawn(async move {
             read_frame(&mut br).await.unwrap(); // client HEADS
-            write_frame(&mut bw, &Frame::Ops(Ops { ops: malicious, pri: Some(Priority::Bulk) })).await.unwrap();
+            write_frame(
+                &mut bw,
+                &Frame::Ops(Ops {
+                    ops: malicious,
+                    pri: Some(Priority::Bulk),
+                }),
+            )
+            .await
+            .unwrap();
             bw.shutdown().await.unwrap();
         });
         let out = pull_sync(&mut ar, &mut aw, &mut client, &anyone)
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/peer.rs:1269:
         carrier.await.unwrap();
 
         assert_eq!(out.applied, 3); // 0,1,2 landed; 3 broke, 4 (suffix) dropped
-        assert_eq!(out.rejected, vec![("sh".into(), "g".into(), vec![], "a".into())]);
+        assert_eq!(
+            out.rejected,
+            vec![("sh".into(), "g".into(), vec![], "a".into())]
+        );
         assert_eq!(client.scan("sh", "g", b"", "a", -1).len(), 3);
 
         // Re-fetch from the honest replica: resume from head 2, gain 3 and 4.
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/peer.rs:1302:
         let (mut br, mut bw) = split(cb);
         let carrier = tokio::spawn(async move {
             read_frame(&mut br).await.unwrap();
-            write_frame(&mut bw, &Frame::Ops(Ops { ops: vec![conflict], pri: Some(Priority::Bulk) })).await.unwrap();
+            write_frame(
+                &mut bw,
+                &Frame::Ops(Ops {
+                    ops: vec![conflict],
+                    pri: Some(Priority::Bulk),
+                }),
+            )
+            .await
+            .unwrap();
             bw.shutdown().await.unwrap();
         });
         let out = pull_sync(&mut ar, &mut aw, &mut client, &anyone)
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/registry.rs:546:
                 if self.holds(&op) {
                     return Ok(Ingested::Duplicate);
                 }
-                return Err(RegistryError::Equivocation { origin: op.origin, seq: op.seq });
+                return Err(RegistryError::Equivocation {
+                    origin: op.origin,
+                    seq: op.seq,
+                });
             }
             if op.seq != last_seq + 1 {
-                return Err(RegistryError::Gap { expected: last_seq + 1, got: op.seq });
+                return Err(RegistryError::Gap {
+                    expected: last_seq + 1,
+                    got: op.seq,
+                });
             }
             match &op.prev {
                 Some(prev) if prev.as_slice() != last_hash => {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/registry.rs:556:
-                    return Err(RegistryError::ChainBreak { origin: op.origin, seq: op.seq });
+                    return Err(RegistryError::ChainBreak {
+                        origin: op.origin,
+                        seq: op.seq,
+                    });
                 }
                 _ => {}
             }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/registry.rs:560:
         } else if op.seq != 0 {
-            return Err(RegistryError::Gap { expected: 0, got: op.seq });
+            return Err(RegistryError::Gap {
+                expected: 0,
+                got: op.seq,
+            });
         }
         let hash = op_hash(&op);
         self.tips.insert(chain, (op.seq, hash));
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/registry.rs:664:
         // The binding family folds newest-wins ACROSS its two streams, so its
         // lamport is one clock over both (see `next_binding_lamport`); every
         // other kind keeps its chain seq.
-        let lamport = if Record::is_binding_family(glade_id) { self.next_binding_lamport() } else { seq };
+        let lamport = if Record::is_binding_family(glade_id) {
+            self.next_binding_lamport()
+        } else {
+            seq
+        };
         let mut op = Op {
             share: HOME.into(),
             glade_id: glade_id.into(),
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/registry.rs:857:
             .map(|(glade_id, mut hs)| {
                 hs.sort_by(|a, b| a.origin.cmp(&b.origin));
                 cbor::encode(
-                    &StreamHeads { share: HOME.into(), glade_id, key: vec![], heads: hs }.to_cbor(),
+                    &StreamHeads {
+                        share: HOME.into(),
+                        glade_id,
+                        key: vec![],
+                        heads: hs,
+                    }
+                    .to_cbor(),
                 )
             })
             .collect();
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/registry.rs:940:
                 }
                 _ => continue,
             };
-            let stamp =
-                Stamp { lamport: op.lamport, origin: op.origin.clone(), retraction: decl.is_none(), seq: op.seq };
+            let stamp = Stamp {
+                lamport: op.lamport,
+                origin: op.origin.clone(),
+                retraction: decl.is_none(),
+                seq: op.seq,
+            };
             let candidate = Newest { stamp, decl };
             let origins = newest.entry((app, glade_id)).or_default();
             match origins.entry(op.origin.clone()) {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/registry.rs:1016:
         })
     }
     fn claim(node: &str, share: &str, expiry: i64, epoch: i64) -> Record {
-        Record::Serve(ServeClaim { node: node.into(), share: share.into(), lease_expiry_ms: expiry, epoch })
+        Record::Serve(ServeClaim {
+            node: node.into(),
+            share: share.into(),
+            lease_expiry_ms: expiry,
+            epoch,
+        })
     }
 
     /// A scripted directory used by several tests + the conformance gate.
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/registry.rs:1023:
     fn scripted() -> Registry {
         let mut r = Registry::new();
-        r.append(Record::Node(NodeRecord { node_id: "glade-local".into(), operator: "gianni".into() }), "glade-local").unwrap();
-        r.append(Record::Node(NodeRecord { node_id: "peer1".into(), operator: "gianni".into() }), "glade-local").unwrap();
-        r.append(ws("ws-razel", &["peer1", "peer2"]), "glade-local").unwrap();
-        r.append(ws("ws-attic", &["attic-mini"]), "glade-local").unwrap();
-        r.append(ws("home", &["glade-local"]), "glade-local").unwrap();
-        r.append(claim("peer1", "ws-razel", 30_000, 1), "peer1").unwrap();
-        r.append(claim("peer2", "ws-razel", 30_000, 2), "peer2").unwrap(); // higher epoch
-        r.append(Record::Grant(CapabilityGrant { principal: "gianni".into(), share: "ws-razel".into(), verbs: vec!["read".into(), "write".into()] }), "glade-local").unwrap();
-        r.append(Record::Grant(CapabilityGrant { principal: "eve".into(), share: "ws-razel".into(), verbs: vec!["read".into()] }), "glade-local").unwrap();
-        r.append(Record::Revoke(CapabilityRevocation { principal: "eve".into(), share: "ws-razel".into() }), "glade-local").unwrap();
+        r.append(
+            Record::Node(NodeRecord {
+                node_id: "glade-local".into(),
+                operator: "gianni".into(),
+            }),
+            "glade-local",
+        )
+        .unwrap();
+        r.append(
+            Record::Node(NodeRecord {
+                node_id: "peer1".into(),
+                operator: "gianni".into(),
+            }),
+            "glade-local",
+        )
+        .unwrap();
+        r.append(ws("ws-razel", &["peer1", "peer2"]), "glade-local")
+            .unwrap();
+        r.append(ws("ws-attic", &["attic-mini"]), "glade-local")
+            .unwrap();
+        r.append(ws("home", &["glade-local"]), "glade-local")
+            .unwrap();
+        r.append(claim("peer1", "ws-razel", 30_000, 1), "peer1")
+            .unwrap();
+        r.append(claim("peer2", "ws-razel", 30_000, 2), "peer2")
+            .unwrap(); // higher epoch
+        r.append(
+            Record::Grant(CapabilityGrant {
+                principal: "gianni".into(),
+                share: "ws-razel".into(),
+                verbs: vec!["read".into(), "write".into()],
+            }),
+            "glade-local",
+        )
+        .unwrap();
+        r.append(
+            Record::Grant(CapabilityGrant {
+                principal: "eve".into(),
+                share: "ws-razel".into(),
+                verbs: vec!["read".into()],
+            }),
+            "glade-local",
+        )
+        .unwrap();
+        r.append(
+            Record::Revoke(CapabilityRevocation {
+                principal: "eve".into(),
+                share: "ws-razel".into(),
+            }),
+            "glade-local",
+        )
+        .unwrap();
         r
     }
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/registry.rs:1045:
             let op = Op::decode(bytes).unwrap();
             assert!(!op.origin.is_empty(), "record missing origin attribution");
         }
-        assert!(!snap.heads.is_empty(), "snapshot carries heads (cached fold + heads)");
+        assert!(
+            !snap.heads.is_empty(),
+            "snapshot carries heads (cached fold + heads)"
+        );
     }
 
     #[test]
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/registry.rs:1131:
         mem.save(&snap).unwrap();
         let (from_mem, rej_m) = Registry::from_snapshot(&mem.load().unwrap());
 
-        assert_eq!((rej_b, rej_m), (0, 0), "clean snapshot ingests with no rejects");
-        for (p, s, now) in [("ws-razel", "ws-razel", 0i64), ("ws-attic", "ws-attic", 100_000)] {
+        assert_eq!(
+            (rej_b, rej_m),
+            (0, 0),
+            "clean snapshot ingests with no rejects"
+        );
+        for (p, s, now) in [
+            ("ws-razel", "ws-razel", 0i64),
+            ("ws-attic", "ws-attic", 100_000),
+        ] {
             assert_eq!(live.who_serves(p, now), from_blob.who_serves(p, now));
             assert_eq!(from_blob.who_serves(p, now), from_mem.who_serves(p, now));
             assert_eq!(live.replicas_of(s), from_blob.replicas_of(s));
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/registry.rs:1139:
             assert_eq!(from_blob.replicas_of(s), from_mem.replicas_of(s));
         }
         assert_eq!(live.nodes_of("gianni"), from_mem.nodes_of("gianni"));
-        assert_eq!(live.grants_for("gianni", "ws-razel"), from_blob.grants_for("gianni", "ws-razel"));
-        assert_eq!(live.grants_for("eve", "ws-razel"), from_mem.grants_for("eve", "ws-razel"));
+        assert_eq!(
+            live.grants_for("gianni", "ws-razel"),
+            from_blob.grants_for("gianni", "ws-razel")
+        );
+        assert_eq!(
+            live.grants_for("eve", "ws-razel"),
+            from_mem.grants_for("eve", "ws-razel")
+        );
         // a snapshot is a cached fold + heads: round-trip is byte-identical.
         assert_eq!(live.snapshot(), from_blob.snapshot());
         assert_eq!(from_blob.snapshot(), from_mem.snapshot());
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/registry.rs:1150:
     fn verify_as_ingest_rejects_a_tampered_chain() {
         let mut r = scripted();
         // a valid appended chain of two claims on origin "peerX"
-        r.append(claim("peerX", "ws-x", 30_000, 1), "peerX").unwrap();
-        r.append(claim("peerX", "ws-x", 30_000, 2), "peerX").unwrap();
+        r.append(claim("peerX", "ws-x", 30_000, 1), "peerX")
+            .unwrap();
+        r.append(claim("peerX", "ws-x", 30_000, 2), "peerX")
+            .unwrap();
         let mut snap = r.snapshot();
         // tamper: corrupt one claim record's payload -> its op-hash changes, so
         // the NEXT op's prev no longer matches -> chain break -> suffix dropped.
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/registry.rs:1158:
-        let target = snap.records.iter().position(|b| {
-            let op = Op::decode(b).unwrap();
-            op.origin == "peerX" && op.seq == 0
-        }).unwrap();
+        let target = snap
+            .records
+            .iter()
+            .position(|b| {
+                let op = Op::decode(b).unwrap();
+                op.origin == "peerX" && op.seq == 0
+            })
+            .unwrap();
         let mut op = Op::decode(&snap.records[target]).unwrap();
         op.payload.push(0xff); // malicious edit — indistinguishable from a bad sync chunk
         snap.records[target] = cbor::encode(&op.to_cbor());
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/registry.rs:1165:
         let (reg, rejected) = Registry::from_snapshot(&snap);
-        assert!(rejected >= 1, "the tampered op (and its suffix) is quarantined");
+        assert!(
+            rejected >= 1,
+            "the tampered op (and its suffix) is quarantined"
+        );
         // the honest records still fold.
         assert_eq!(reg.nodes_of("gianni"), vec!["glade-local", "peer1"]);
     }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/registry.rs:1460:
         })
     }
     fn retract(app: &str, glade_id: &str) -> Record {
-        Record::Retract(BindingRetraction { app: app.into(), glade_id: glade_id.into() })
+        Record::Retract(BindingRetraction {
+            app: app.into(),
+            glade_id: glade_id.into(),
+        })
     }
     /// The live bindings as (app, glade_id, shape).
     fn live(r: &Registry) -> Vec<(String, String, String)> {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/registry.rs:1467:
-        r.bindings_of().into_iter().map(|b| (b.app, b.glade_id, b.shape)).collect()
+        r.bindings_of()
+            .into_iter()
+            .map(|b| (b.app, b.glade_id, b.shape))
+            .collect()
     }
     fn row(app: &str, glade_id: &str, shape: &str) -> (String, String, String) {
         (app.into(), glade_id.into(), shape.into())
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/registry.rs:1471:
     }
     fn ops_of(r: &Registry) -> Vec<Op> {
-        r.snapshot().records.iter().map(|b| Op::decode(b).unwrap()).collect()
+        r.snapshot()
+            .records
+            .iter()
+            .map(|b| Op::decode(b).unwrap())
+            .collect()
     }
 
     /// R9(a): `dir.bindings` folds by glade id and the newest declaration is
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/registry.rs:1495:
             r.append(decl("a", id, "value"), "n1").unwrap();
         }
         r.append(retract("a", "g"), "n1").unwrap();
-        assert_eq!(live(&r), vec![row("a", "h", "value"), row("a", "k", "value")]);
-        assert_eq!(BindingFold::over(&ops_of(&r)).retracted(), vec![("a".to_string(), "g".to_string())]);
+        assert_eq!(
+            live(&r),
+            vec![row("a", "h", "value"), row("a", "k", "value")]
+        );
+        assert_eq!(
+            BindingFold::over(&ops_of(&r)).retracted(),
+            vec![("a".to_string(), "g".to_string())]
+        );
         r.append(decl("a", "g", "log"), "n1").unwrap();
-        assert_eq!(live(&r), vec![row("a", "g", "log"), row("a", "h", "value"), row("a", "k", "value")]);
-        assert_eq!(BindingFold::over(&ops_of(&r)).retracted(), Vec::<(String, String)>::new());
+        assert_eq!(
+            live(&r),
+            vec![
+                row("a", "g", "log"),
+                row("a", "h", "value"),
+                row("a", "k", "value")
+            ]
+        );
+        assert_eq!(
+            BindingFold::over(&ops_of(&r)).retracted(),
+            Vec::<(String, String)>::new()
+        );
     }
 
     /// R9(a)'s scope: a retraction retracts its own app's declaration and no
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/registry.rs:1512:
         r.append(decl("b", "g", "log"), "n1").unwrap();
         assert_eq!(live(&r), vec![row("b", "g", "log")]);
         r.append(retract("b", "g"), "n1").unwrap();
-        assert_eq!(live(&r), vec![row("a", "g", "value")], "a's declaration was never in scope");
+        assert_eq!(
+            live(&r),
+            vec![row("a", "g", "value")],
+            "a's declaration was never in scope"
+        );
         r.append(retract("a", "g"), "n1").unwrap();
         assert_eq!(live(&r), vec![]);
     }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/registry.rs:1531:
         assert_eq!(at(decl("a", "g", "value"), "n1"), (G_BINDINGS.into(), 0, 0));
         assert_eq!(at(decl("a", "h", "value"), "n1"), (G_BINDINGS.into(), 1, 1));
         assert_eq!(at(claim("n1", "ws", 1, 1), "n1"), (G_CLAIMS.into(), 0, 0));
-        assert_eq!(at(retract("a", "g"), "n1"), (G_BINDING_RETRACTIONS.into(), 0, 2));
+        assert_eq!(
+            at(retract("a", "g"), "n1"),
+            (G_BINDING_RETRACTIONS.into(), 0, 2)
+        );
         assert_eq!(at(decl("a", "g", "log"), "n1"), (G_BINDINGS.into(), 2, 3));
-        assert_eq!(at(retract("a", "h"), "n1"), (G_BINDING_RETRACTIONS.into(), 1, 4));
+        assert_eq!(
+            at(retract("a", "h"), "n1"),
+            (G_BINDING_RETRACTIONS.into(), 1, 4)
+        );
         // a second origin's first record is still the newest
         assert_eq!(at(decl("a", "k", "value"), "n2"), (G_BINDINGS.into(), 0, 5));
         assert_eq!(at(claim("n1", "ws", 1, 2), "n1"), (G_CLAIMS.into(), 1, 1));
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/registry.rs:1637:
     #[test]
     fn a_stored_binding_decl_round_trips_byte_identically() {
         let pinned = "a601666772617a656c02687465726d2e6c6f6703636c6f67046573686172650567636f6d6d6f6e73066b66726f6d5f637572736f72";
-        let payload: Vec<u8> =
-            (0..pinned.len()).step_by(2).map(|i| u8::from_str_radix(&pinned[i..i + 2], 16).unwrap()).collect();
+        let payload: Vec<u8> = (0..pinned.len())
+            .step_by(2)
+            .map(|i| u8::from_str_radix(&pinned[i..i + 2], 16).unwrap())
+            .collect();
         let b = BindingDecl {
             app: "grazel".into(),
             glade_id: "term.log".into(),
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/registry.rs:1653:
         r.append(Record::Binding(b), "n1").unwrap();
         let snap = r.snapshot();
         let op = Op::decode(&snap.records[0]).unwrap();
-        assert_eq!((op.payload.as_slice(), op.seq, op.lamport), (payload.as_slice(), 0, 0));
+        assert_eq!(
+            (op.payload.as_slice(), op.seq, op.lamport),
+            (payload.as_slice(), 0, 0)
+        );
         let (back, rejected) = Registry::from_snapshot(&snap);
         assert_eq!(rejected, 0);
         assert_eq!(back.snapshot(), snap);
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/router.rs:30:
     }
 
     pub fn subscribe(&mut self, session: SessionId, share: &str, glade_id: &str, key: &[u8]) {
-        self.subs.entry((share.into(), glade_id.into(), key.to_vec())).or_default().insert(session);
+        self.subs
+            .entry((share.into(), glade_id.into(), key.to_vec()))
+            .or_default()
+            .insert(session);
     }
 
     pub fn unsubscribe(&mut self, session: SessionId, share: &str, glade_id: &str, key: &[u8]) {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/router.rs:37:
-        if let Some(set) = self.subs.get_mut(&(share.into(), glade_id.into(), key.to_vec())) {
+        if let Some(set) = self
+            .subs
+            .get_mut(&(share.into(), glade_id.into(), key.to_vec()))
+        {
             set.remove(&session);
         }
     }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/router.rs:57:
 
     /// Sessions subscribed to `(share, glade_id, key)` except `from` — the
     /// fan-out targets for an op originating at `from` (never echoed to itself).
-    pub fn route(&self, from: SessionId, share: &str, glade_id: &str, key: &[u8]) -> Vec<SessionId> {
+    pub fn route(
+        &self,
+        from: SessionId,
+        share: &str,
+        glade_id: &str,
+        key: &[u8],
+    ) -> Vec<SessionId> {
         self.subs
             .get(&(share.to_string(), glade_id.to_string(), key.to_vec()))
             .map(|set| set.iter().copied().filter(|&s| s != from).collect())
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/router.rs:171:
         // session 1 (origin "a") submits an op: node stores it, fans out to others
         let o = op("a", 0, b"hello");
         store.append(o.clone()).unwrap();
-        let frame = Frame::Ops(Ops { ops: vec![o.clone()], pri: None }).to_bytes();
+        let frame = Frame::Ops(Ops {
+            ops: vec![o.clone()],
+            pri: None,
+        })
+        .to_bytes();
         for target in router.route(1, "sh", "g", &[]) {
-            out.get_mut(&target).unwrap().push(Priority::Interactive, frame.clone());
+            out.get_mut(&target)
+                .unwrap()
+                .push(Priority::Interactive, frame.clone());
         }
         // session 2 receives the op; session 1 (origin) gets nothing
-        let got = out.get_mut(&2).unwrap().pop().expect("session 2 should receive");
+        let got = out
+            .get_mut(&2)
+            .unwrap()
+            .pop()
+            .expect("session 2 should receive");
         match Frame::from_bytes(&got).unwrap() {
             Frame::Ops(ops) => assert_eq!(ops.ops[0].payload, b"hello"),
             other => panic!("expected Ops, got {other:?}"),
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/server.rs:344:
                     shared.principals.lock().await.insert(sid, p.to_string());
                     crate::claims::note_principal(&shared, p).await;
                 }
-                send(&shared, sid, &Frame::Welcome(Welcome { session: h.session, protocol: 1, heads: vec![] })).await;
+                send(
+                    &shared,
+                    sid,
+                    &Frame::Welcome(Welcome {
+                        session: h.session,
+                        protocol: 1,
+                        heads: vec![],
+                    }),
+                )
+                .await;
             }
             Frame::Subscribe(s) => {
                 // A subscription is to one zone-surface (share, glade_id, key);
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/server.rs:359:
                     crate::exchange::declared_exchange(&st, &s.glade_id)
                 };
                 if declared {
-                    crate::exchange::attach_provider(&shared, sid, &s.share, &s.glade_id, key).await;
+                    crate::exchange::attach_provider(&shared, sid, &s.share, &s.glade_id, key)
+                        .await;
                     continue;
                 }
                 match crate::mesh::route_subscribe(&shared, &s.share).await {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/server.rs:418:
                         }
                         drop(cut);
                         if let crate::mesh::Route::Forward(peer) = route {
-                            crate::mesh::forward_interest(&shared, peer, s.share.clone(), s.glade_id.clone(), key.clone()).await;
+                            crate::mesh::forward_interest(
+                                &shared,
+                                peer,
+                                s.share.clone(),
+                                s.glade_id.clone(),
+                                key.clone(),
+                            )
+                            .await;
                         }
                     }
                 }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/server.rs:484:
         }
     }
     fn subscribe() -> Vec<u8> {
-        Frame::Subscribe(Subscribe { share: "sh".into(), glade_id: "g".into(), key: None, from: None }).to_bytes()
+        Frame::Subscribe(Subscribe {
+            share: "sh".into(),
+            glade_id: "g".into(),
+            key: None,
+            from: None,
+        })
+        .to_bytes()
     }
     fn subscribe_key(key: Option<Vec<u8>>) -> Vec<u8> {
-        Frame::Subscribe(Subscribe { share: "sh".into(), glade_id: "g".into(), key, from: None }).to_bytes()
+        Frame::Subscribe(Subscribe {
+            share: "sh".into(),
+            glade_id: "g".into(),
+            key,
+            from: None,
+        })
+        .to_bytes()
     }
     fn keyed_op(origin: &str, seq: i64, key: &[u8], payload: &[u8]) -> Op {
-        Op { key: key.to_vec(), ..op(origin, seq, payload) }
+        Op {
+            key: key.to_vec(),
+            ..op(origin, seq, payload)
+        }
     }
     fn ops_frame(o: Op) -> Vec<u8> {
-        Frame::Ops(Ops { ops: vec![o], pri: None }).to_bytes()
+        Frame::Ops(Ops {
+            ops: vec![o],
+            pri: None,
+        })
+        .to_bytes()
     }
     async fn recv(r: &mut ws::WsReader) -> Frame {
         match r.read().await.unwrap() {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/server.rs:619:
 
         wc.send_binary(&subscribe_key(None)).await.unwrap(); // commons
         assert!(matches!(recv(&mut rc).await, Frame::Heads(_)));
-        wp.send_binary(&subscribe_key(Some(b"self:p".to_vec()))).await.unwrap();
+        wp.send_binary(&subscribe_key(Some(b"self:p".to_vec())))
+            .await
+            .unwrap();
         assert!(matches!(recv(&mut rp).await, Frame::Heads(_)));
 
         // writer emits a private op then a commons op (independent chains, both seq 0)
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/server.rs:626:
-        ww.send_binary(&ops_frame(keyed_op("w", 0, b"self:p", b"secret"))).await.unwrap();
-        ww.send_binary(&ops_frame(keyed_op("w", 0, b"", b"public"))).await.unwrap();
+        ww.send_binary(&ops_frame(keyed_op("w", 0, b"self:p", b"secret")))
+            .await
+            .unwrap();
+        ww.send_binary(&ops_frame(keyed_op("w", 0, b"", b"public")))
+            .await
+            .unwrap();
 
         // the private subscriber sees the secret; the commons subscriber's only
         // delivered op is the public one — the secret never crosses the zone.
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/session.rs:26:
 /// `their` heads is missing: for each origin, everything above the peer's head
 /// (or the whole chain if the peer has never seen that origin). Scoped to the
 /// zone so a subscriber never receives another zone's (e.g. private) ops.
-pub fn missing_for(store: &Store, share: &str, glade_id: &str, key: &[u8], their: &Heads) -> Vec<Op> {
+pub fn missing_for(
+    store: &Store,
+    share: &str,
+    glade_id: &str,
+    key: &[u8],
+    their: &Heads,
+) -> Vec<Op> {
     let mut out = Vec::new();
     for (origin, _head) in store.heads(share, glade_id, key) {
         let from = their.get(&origin).copied().unwrap_or(i64::MIN);
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/session.rs:98:
 /// surfaced, never propagated or silently dropped. It is the op's status (R1).
 pub fn error_frame(err: &StoreError, op: &Op) -> Frame {
     let (code, message) = match err {
-        StoreError::Equivocation { origin, seq } => {
-            (ErrorCode::Equivocation, format!("forked chain at ({origin},{seq})"))
-        }
-        StoreError::ChainBreak { origin, seq } => {
-            (ErrorCode::Protocol, format!("chain break at ({origin},{seq})"))
-        }
-        StoreError::Gap { expected, got } => {
-            (ErrorCode::Protocol, format!("gap: expected {expected}, got {got}"))
-        }
-        StoreError::InvalidSwmrPayload { error } => {
-            (ErrorCode::Protocol, format!("invalid SWMR action envelope: {error:?}"))
-        }
-        StoreError::SwmrWriterConflict { expected, got } => {
-            (ErrorCode::Protocol, format!("SWMR writer conflict: expected {expected:?}, got {got:?}"))
-        }
-        StoreError::ShapeConflict { expected, got } => {
-            (ErrorCode::Protocol, format!("shape conflict: expected {expected:?}, got {got:?}"))
-        }
-        StoreError::Unverified { origin, seq, why } => {
-            (ErrorCode::Unauthorized, format!("({origin},{seq}) does not verify: {why}"))
-        }
+        StoreError::Equivocation { origin, seq } => (
+            ErrorCode::Equivocation,
+            format!("forked chain at ({origin},{seq})"),
+        ),
+        StoreError::ChainBreak { origin, seq } => (
+            ErrorCode::Protocol,
+            format!("chain break at ({origin},{seq})"),
+        ),
+        StoreError::Gap { expected, got } => (
+            ErrorCode::Protocol,
+            format!("gap: expected {expected}, got {got}"),
+        ),
+        StoreError::InvalidSwmrPayload { error } => (
+            ErrorCode::Protocol,
+            format!("invalid SWMR action envelope: {error:?}"),
+        ),
+        StoreError::SwmrWriterConflict { expected, got } => (
+            ErrorCode::Protocol,
+            format!("SWMR writer conflict: expected {expected:?}, got {got:?}"),
+        ),
+        StoreError::ShapeConflict { expected, got } => (
+            ErrorCode::Protocol,
+            format!("shape conflict: expected {expected:?}, got {got:?}"),
+        ),
+        StoreError::Unverified { origin, seq, why } => (
+            ErrorCode::Unauthorized,
+            format!("({origin},{seq}) does not verify: {why}"),
+        ),
         StoreError::Rewrite { origin, seq } => (
             ErrorCode::Equivocation,
             format!("rewritten chain at ({origin},{seq})"),
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/session.rs:223:
             other => panic!("expected Error frame, got {other:?}"),
         }
         // and it survives the wire
-        assert!(matches!(Frame::from_bytes(&frame.to_bytes()).unwrap(), Frame::Error(_)));
+        assert!(matches!(
+            Frame::from_bytes(&frame.to_bytes()).unwrap(),
+            Frame::Error(_)
+        ));
     }
 
     #[test]
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/session.rs:233:
         client.append(op("a", 1, b"a1")).unwrap();
         ship(&client, &mut server);
         // second sync ships nothing
-        assert!(missing_for(&server, "sh", "g", &[], &heads_map(&client, "sh", "g", &[])).is_empty());
-        assert!(missing_for(&client, "sh", "g", &[], &heads_map(&server, "sh", "g", &[])).is_empty());
+        assert!(
+            missing_for(&server, "sh", "g", &[], &heads_map(&client, "sh", "g", &[])).is_empty()
+        );
+        assert!(
+            missing_for(&client, "sh", "g", &[], &heads_map(&server, "sh", "g", &[])).is_empty()
+        );
     }
 }
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/store.rs:65:
 impl EquivProof {
     /// The forked `(share, glade_id, key, origin, seq)` slot.
     pub fn slot(&self) -> (String, String, Vec<u8>, String, i64) {
-        (self.a.share.clone(), self.a.glade_id.clone(), self.a.key.clone(), self.a.origin.clone(), self.a.seq)
+        (
+            self.a.share.clone(),
+            self.a.glade_id.clone(),
+            self.a.key.clone(),
+            self.a.origin.clone(),
+            self.a.seq,
+        )
     }
 }
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/store.rs:72:
 #[derive(Debug)]
 pub enum StoreError {
     /// Non-contiguous: an origin's log must advance by exactly one.
-    Gap { expected: i64, got: i64 },
+    Gap {
+        expected: i64,
+        got: i64,
+    },
     /// A second op at an existing `(origin, seq)` with a *different* hash — a
     /// forked per-origin chain (GQ-9). Rejected, never folded.
-    Equivocation { origin: String, seq: i64 },
+    Equivocation {
+        origin: String,
+        seq: i64,
+    },
     /// A new op's `prev` does not match its predecessor's hash.
-    ChainBreak { origin: String, seq: i64 },
+    ChainBreak {
+        origin: String,
+        seq: i64,
+    },
     /// The SWMR action envelope is not `glade.swmr.adapter/v1`.
-    InvalidSwmrPayload { error: SwmrPayloadError },
+    InvalidSwmrPayload {
+        error: SwmrPayloadError,
+    },
     /// A SWMR surface already has a different authenticated writer origin.
-    SwmrWriterConflict { expected: String, got: String },
+    SwmrWriterConflict {
+        expected: String,
+        got: String,
+    },
     /// SWMR and a multi-writer fold MUST NOT share one zone-surface.
-    ShapeConflict { expected: Shape, got: Shape },
+    ShapeConflict {
+        expected: Shape,
+        got: Shape,
+    },
     /// A `home` op that does not verify (plan Step 4.1b): unsigned, forged,
     /// or not the directory's form or kind.
-    Unverified { origin: String, seq: i64, why: Refused },
+    Unverified {
+        origin: String,
+        seq: i64,
+        why: Refused,
+    },
     /// A checkpoint whose base moves back from the one held, or that names
     /// another hash there (plan Step 4.5c): refused, the pair kept as its
     /// proof.
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/store.rs:139:
 type ChainId = (String, String, Vec<u8>, String);
 
 fn chain_of(op: &Op) -> ChainId {
-    (op.share.clone(), op.glade_id.clone(), op.key.clone(), op.origin.clone())
+    (
+        op.share.clone(),
+        op.glade_id.clone(),
+        op.key.clone(),
+        op.origin.clone(),
+    )
 }
 
 /// Each chain's ops, in order.
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/store.rs:322:
             Verdict::Duplicate => Ok(Append::Duplicate),
             Verdict::BelowRetained => Ok(Append::BelowRetained),
             Verdict::Gap { expected, got } => Err(StoreError::Gap { expected, got }),
-            Verdict::ChainBreak => Err(StoreError::ChainBreak { origin: op.origin, seq: op.seq }),
+            Verdict::ChainBreak => Err(StoreError::ChainBreak {
+                origin: op.origin,
+                seq: op.seq,
+            }),
             Verdict::Equivocation(stored) => {
                 // Two signed ops, one slot — persist the fork proof, then reject.
-                self.record_equivocation(EquivProof { a: stored, b: op.clone() })?;
-                Err(StoreError::Equivocation { origin: op.origin, seq: op.seq })
+                self.record_equivocation(EquivProof {
+                    a: stored,
+                    b: op.clone(),
+                })?;
+                Err(StoreError::Equivocation {
+                    origin: op.origin,
+                    seq: op.seq,
+                })
             }
             Verdict::Rewrite(stored) => {
                 let proof = EquivProof {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/store.rs:390:
                 || existing_shape == Shape::Crdt)
                 && existing_shape != op.shape
             {
-                return Err(StoreError::ShapeConflict { expected: existing_shape, got: op.shape });
+                return Err(StoreError::ShapeConflict {
+                    expected: existing_shape,
+                    got: op.shape,
+                });
             }
             if op.shape == Shape::Swmr && origin != &op.origin {
                 return Err(StoreError::SwmrWriterConflict {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/store.rs:463:
 
     /// Ops for a chain `(share, glade_id, key, origin)` with `seq > from_seq`, in
     /// order (the resume tail for one origin within a zone).
-    pub fn scan(&self, share: &str, glade_id: &str, key: &[u8], origin: &str, from_seq: i64) -> Vec<Op> {
+    pub fn scan(
+        &self,
+        share: &str,
+        glade_id: &str,
+        key: &[u8],
+        origin: &str,
+        from_seq: i64,
+    ) -> Vec<Op> {
         self.logs
-            .get(&(share.to_string(), glade_id.to_string(), key.to_vec(), origin.to_string()))
+            .get(&(
+                share.to_string(),
+                glade_id.to_string(),
+                key.to_vec(),
+                origin.to_string(),
+            ))
             .map(|log| log.iter().filter(|o| o.seq > from_seq).cloned().collect())
             .unwrap_or_default()
     }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/store.rs:511:
     Appended,
     Duplicate,
     BelowRetained,
-    Gap { expected: i64, got: i64 },
+    Gap {
+        expected: i64,
+        got: i64,
+    },
     ChainBreak,
     /// An op already sits at this `(origin, seq)` with a different hash — a fork.
     /// Carries the stored op so the proof can be assembled. At a chain's base
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/store.rs:636:
 }
 
 fn classify(log: Option<&Vec<Op>>, op: &Op) -> Verdict {
-    let Some(last) = log.and_then(|l| l.last()) else { return Verdict::Appended };
+    let Some(last) = log.and_then(|l| l.last()) else {
+        return Verdict::Appended;
+    };
     if op.seq <= last.seq {
         // Safe to unwrap the log: we found `last` in it.
         return match log.unwrap().iter().find(|o| o.seq == op.seq) {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/store.rs:980:
     fn append_and_scan_from_seq() {
         let mut s = Store::open(fresh("scan")).unwrap();
         for n in 1..=3 {
-            assert_eq!(s.append(op("sh", "a", n, &[n as u8])).unwrap(), Append::Appended);
+            assert_eq!(
+                s.append(op("sh", "a", n, &[n as u8])).unwrap(),
+                Append::Appended
+            );
         }
         assert_eq!(s.scan("sh", "g", &[], "a", 0).len(), 3); // all
         assert_eq!(s.scan("sh", "g", &[], "a", 1).len(), 2); // seq > 1
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/store.rs:1006:
     fn keys_are_independent_chains() {
         let mut s = Store::open(fresh("zones")).unwrap();
         let commons = |seq, p: &[u8]| op("sh", "a", seq, p); // key = []
-        let private = |seq, p: &[u8]| Op { key: b"self:a".to_vec(), ..op("sh", "a", seq, p) };
+        let private = |seq, p: &[u8]| Op {
+            key: b"self:a".to_vec(),
+            ..op("sh", "a", seq, p)
+        };
         // both chains start at seq 0 — independent, no equivocation across keys
         s.append(commons(0, b"c0")).unwrap();
         s.append(private(0, b"p0")).unwrap();
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/store.rs:1039:
     fn swmr_accepts_one_writer_snapshot_delta_and_empty_reset() {
         let mut s = Store::open(fresh("swmr-one-writer")).unwrap();
         assert_eq!(
-            s.append(swmr_op("writer-a", 0, SwmrAction::Snapshot, b"whole-0")).unwrap(),
+            s.append(swmr_op("writer-a", 0, SwmrAction::Snapshot, b"whole-0"))
+                .unwrap(),
             Append::Appended,
         );
         assert_eq!(
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/store.rs:1046:
-            s.append(swmr_op("writer-a", 1, SwmrAction::Delta, b"whole-1")).unwrap(),
+            s.append(swmr_op("writer-a", 1, SwmrAction::Delta, b"whole-1"))
+                .unwrap(),
             Append::Appended,
         );
         assert_eq!(
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/store.rs:1050:
-            s.append(swmr_op("writer-a", 2, SwmrAction::Reset, b"")).unwrap(),
+            s.append(swmr_op("writer-a", 2, SwmrAction::Reset, b""))
+                .unwrap(),
             Append::Appended,
         );
         assert_eq!(s.scan("sh", "g", &[], "writer-a", -1).len(), 3);
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/store.rs:1056:
     #[test]
     fn swmr_rejects_malformed_action_before_store_mutation() {
         let mut s = Store::open(fresh("swmr-malformed")).unwrap();
-        let malformed = Op { shape: Shape::Swmr, payload: vec![1, 99], ..op("sh", "writer-a", 0, b"") };
+        let malformed = Op {
+            shape: Shape::Swmr,
+            payload: vec![1, 99],
+            ..op("sh", "writer-a", 0, b"")
+        };
 
         assert!(matches!(
             s.append(malformed),
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/store.rs:1068:
     #[test]
     fn swmr_rejects_second_writer_and_shape_mixing_before_mutation() {
         let mut s = Store::open(fresh("swmr-conflicts")).unwrap();
-        s.append(swmr_op("writer-a", 0, SwmrAction::Snapshot, b"whole")).unwrap();
+        s.append(swmr_op("writer-a", 0, SwmrAction::Snapshot, b"whole"))
+            .unwrap();
 
         assert!(matches!(
             s.append(swmr_op("writer-b", 0, SwmrAction::Snapshot, b"other")),
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/store.rs:1077:
         ));
         assert!(matches!(
             s.append(op("sh", "writer-b", 0, b"value")),
-            Err(StoreError::ShapeConflict { expected: Shape::Swmr, got: Shape::Value })
+            Err(StoreError::ShapeConflict {
+                expected: Shape::Swmr,
+                got: Shape::Value
+            })
         ));
         assert!(s.scan("sh", "g", &[], "writer-b", -1).is_empty());
         assert_eq!(s.scan("sh", "g", &[], "writer-a", -1).len(), 1);
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/store.rs:1086:
     #[test]
     fn crdt_accepts_multiple_writers_but_rejects_shape_mixing() {
         let mut s = Store::open(fresh("crdt-multi-writer")).unwrap();
-        let alice = Op { shape: Shape::Crdt, ..op("sh", "alice", 0, b"A") };
-        let bob = Op { shape: Shape::Crdt, ..op("sh", "bob", 0, b"B") };
+        let alice = Op {
+            shape: Shape::Crdt,
+            ..op("sh", "alice", 0, b"A")
+        };
+        let bob = Op {
+            shape: Shape::Crdt,
+            ..op("sh", "bob", 0, b"B")
+        };
         assert_eq!(s.append(alice).unwrap(), Append::Appended);
         assert_eq!(s.append(bob).unwrap(), Append::Appended);
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/store.rs:1094:
         assert!(matches!(
             s.append(op("sh", "legacy", 0, b"whole-value")),
-            Err(StoreError::ShapeConflict { expected: Shape::Crdt, got: Shape::Value })
+            Err(StoreError::ShapeConflict {
+                expected: Shape::Crdt,
+                got: Shape::Value
+            })
         ));
         assert_eq!(s.scan("sh", "g", &[], "alice", -1).len(), 1);
         assert_eq!(s.scan("sh", "g", &[], "bob", -1).len(), 1);
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/store.rs:1119:
         s.append(op("sh", "a", 0, b"p0")).unwrap();
         // same (origin, seq), different payload -> forked chain, rejected
         match s.append(op("sh", "a", 0, b"p0-fork")) {
-            Err(StoreError::Equivocation { origin, seq }) => assert_eq!((origin.as_str(), seq), ("a", 0)),
+            Err(StoreError::Equivocation { origin, seq }) => {
+                assert_eq!((origin.as_str(), seq), ("a", 0))
+            }
             other => panic!("expected Equivocation, got {other:?}"),
         }
         // exact re-delivery of the real op is still idempotent
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/store.rs:1126:
-        assert_eq!(s.append(op("sh", "a", 0, b"p0")).unwrap(), Append::Duplicate);
+        assert_eq!(
+            s.append(op("sh", "a", 0, b"p0")).unwrap(),
+            Append::Duplicate
+        );
     }
 
     #[test]
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/store.rs:1133:
         let mut a1 = op("sh", "a", 1, b"p1");
         a1.prev = Some(vec![0xde, 0xad, 0xbe, 0xef]); // does not match hash(a0)
         match s.append(a1) {
-            Err(StoreError::ChainBreak { origin, seq }) => assert_eq!((origin.as_str(), seq), ("a", 1)),
+            Err(StoreError::ChainBreak { origin, seq }) => {
+                assert_eq!((origin.as_str(), seq), ("a", 1))
+            }
             other => panic!("expected ChainBreak, got {other:?}"),
         }
     }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/store.rs:1167:
     fn all_heads_are_per_zone_with_chain_hash() {
         let mut s = Store::open(fresh("all-heads")).unwrap();
         s.append(op("sh", "a", 0, b"x")).unwrap(); // commons zone
-        s.append(Op { key: b"self:a".to_vec(), ..op("sh", "a", 0, b"y") }).unwrap(); // private zone
+        s.append(Op {
+            key: b"self:a".to_vec(),
+            ..op("sh", "a", 0, b"y")
+        })
+        .unwrap(); // private zone
         let ah = s.all_heads();
         assert_eq!(ah.len(), 2); // two zones, independent
         for sh in &ah {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/sysdir.rs:339:
     let mut recovery = None;
     if !registry.has_node(&node_id) {
         registry
-            .append(Record::Node(NodeRecord { node_id: node_id.clone(), operator: operator.into() }), &node_id)
+            .append(
+                Record::Node(NodeRecord {
+                    node_id: node_id.clone(),
+                    operator: operator.into(),
+                }),
+                &node_id,
+            )
             .map_err(reg_io)?;
         registry
             .append(
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/sysdir.rs:480:
 /// expiry); never consulted inside the fold.
 pub fn now_ms() -> i64 {
     use std::time::{SystemTime, UNIX_EPOCH};
-    SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_millis() as i64).unwrap_or(0)
+    SystemTime::now()
+        .duration_since(UNIX_EPOCH)
+        .map(|d| d.as_millis() as i64)
+        .unwrap_or(0)
 }
 
 /// NodeId = hex of the node key's Ed25519 public key (plan Step 4.1a, D2): the
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/sysdir.rs:563:
 }
 
 fn reg_io(e: crate::registry::RegistryError) -> io::Error {
-    io::Error::new(io::ErrorKind::InvalidData, format!("registry append rejected: {e:?}"))
+    io::Error::new(
+        io::ErrorKind::InvalidData,
+        format!("registry append rejected: {e:?}"),
+    )
 }
 
 #[cfg(test)]
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/sysdir.rs:588:
         assert!(dir.join("records.json").exists()); // class-2 snapshot written
         assert!(dir.join("cache").is_dir());
         assert!(dir.join("instance.lock").exists()); // held while `boot` lives
-        // presence: our node is in the fold, attributed to our own id.
+                                                     // presence: our node is in the fold, attributed to our own id.
         assert!(boot.registry.has_node(&boot.node_id));
         assert_eq!(boot.registry.nodes_of("gianni"), vec![boot.node_id.clone()]);
         // the node served itself its own home before any client: whoServes(home).
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/sysdir.rs:595:
-        assert_eq!(boot.registry.who_serves(HOME, 0), Some(boot.node_id.clone()));
+        assert_eq!(
+            boot.registry.who_serves(HOME, 0),
+            Some(boot.node_id.clone())
+        );
     }
 
     #[test]
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/ws.rs:28:
     for chunk in msg.chunks(64) {
         let mut w = [0u32; 80];
         for i in 0..16 {
-            w[i] = u32::from_be_bytes([chunk[i * 4], chunk[i * 4 + 1], chunk[i * 4 + 2], chunk[i * 4 + 3]]);
+            w[i] = u32::from_be_bytes([
+                chunk[i * 4],
+                chunk[i * 4 + 1],
+                chunk[i * 4 + 2],
+                chunk[i * 4 + 3],
+            ]);
         }
         for i in 16..80 {
             w[i] = (w[i - 3] ^ w[i - 8] ^ w[i - 14] ^ w[i - 16]).rotate_left(1);
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/ws.rs:41:
                 40..=59 => ((b & c) | (b & d) | (c & d), 0x8F1BBCDC),
                 _ => (b ^ c ^ d, 0xCA62C1D6),
             };
-            let tmp = a.rotate_left(5).wrapping_add(f).wrapping_add(e).wrapping_add(k).wrapping_add(*wi);
+            let tmp = a
+                .rotate_left(5)
+                .wrapping_add(f)
+                .wrapping_add(e)
+                .wrapping_add(k)
+                .wrapping_add(*wi);
             e = d;
             d = c;
             c = b.rotate_left(30);
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/ws.rs:62:
 }
 
 pub fn accept_key(key: &str) -> String {
-    b64_encode(&sha1(format!("{}258EAFA5-E914-47DA-95CA-C5AB0DC85B11", key).as_bytes()))
+    b64_encode(&sha1(
+        format!("{}258EAFA5-E914-47DA-95CA-C5AB0DC85B11", key).as_bytes(),
+    ))
 }
 
 const B64: &[u8] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/ws.rs:70:
 pub fn b64_encode(data: &[u8]) -> String {
     let mut s = String::new();
     for chunk in data.chunks(3) {
-        let b = [chunk[0], *chunk.get(1).unwrap_or(&0), *chunk.get(2).unwrap_or(&0)];
+        let b = [
+            chunk[0],
+            *chunk.get(1).unwrap_or(&0),
+            *chunk.get(2).unwrap_or(&0),
+        ];
         let n = ((b[0] as u32) << 16) | ((b[1] as u32) << 8) | (b[2] as u32);
         s.push(B64[((n >> 18) & 63) as usize] as char);
         s.push(B64[((n >> 12) & 63) as usize] as char);
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/ws.rs:77:
-        s.push(if chunk.len() > 1 { B64[((n >> 6) & 63) as usize] as char } else { '=' });
-        s.push(if chunk.len() > 2 { B64[(n & 63) as usize] as char } else { '=' });
+        s.push(if chunk.len() > 1 {
+            B64[((n >> 6) & 63) as usize] as char
+        } else {
+            '='
+        });
+        s.push(if chunk.len() > 2 {
+            B64[(n & 63) as usize] as char
+        } else {
+            '='
+        });
     }
     s
 }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/ws.rs:177:
         .lines()
         .find_map(|l| {
             let (name, val) = l.split_once(':')?;
-            name.trim().eq_ignore_ascii_case("sec-websocket-key").then(|| val.trim().to_string())
+            name.trim()
+                .eq_ignore_ascii_case("sec-websocket-key")
+                .then(|| val.trim().to_string())
         })
         .ok_or_else(|| std::io::Error::new(std::io::ErrorKind::InvalidData, "no ws key"))?;
     let resp = format!(
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/ws.rs:185:
         accept_key(&key)
     );
     write.write_all(resp.as_bytes()).await?;
-    Ok((WsReader { inner: read }, WsWriter { inner: Arc::new(Mutex::new(write)), mask: false }))
+    Ok((
+        WsReader { inner: read },
+        WsWriter {
+            inner: Arc::new(Mutex::new(write)),
+            mask: false,
+        },
+    ))
 }
 
 /// Client side: send the upgrade request (frames will be masked).
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/ws.rs:206:
         buf.push(byte[0]);
     }
     if !String::from_utf8_lossy(&buf).contains("101") {
-        return Err(std::io::Error::new(std::io::ErrorKind::InvalidData, "no 101 upgrade"));
+        return Err(std::io::Error::new(
+            std::io::ErrorKind::InvalidData,
+            "no 101 upgrade",
+        ));
     }
-    Ok((WsReader { inner: read }, WsWriter { inner: Arc::new(Mutex::new(write)), mask: true }))
+    Ok((
+        WsReader { inner: read },
+        WsWriter {
+            inner: Arc::new(Mutex::new(write)),
+            mask: true,
+        },
+    ))
 }
 
 fn eof() -> std::io::Error {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/tests/binding_census.rs:34:
 /// every other record unchanged. The later session-desk declaration adds one
 /// fresh binding to Gyld; the pre-amendment reconstruction excludes it.
 const CENSUS: [(&str, Registered); 5] = [
-    (GRAZEL, Registered { appended: 5, unchanged: 7 }),
-    ("../apps/grazel-app.glade", Registered { appended: 5, unchanged: 7 }),
-    (GYLD, Registered { appended: 3, unchanged: 10 }),
-    ("../../glade-gyld/tests/fixtures/gyld-test-app.glade", Registered { appended: 2, unchanged: 7 }),
-    ("../../glade-gwz/tests/fixtures/gwz-test-app.glade", Registered { appended: 1, unchanged: 3 }),
+    (
+        GRAZEL,
+        Registered {
+            appended: 5,
+            unchanged: 7,
+        },
+    ),
+    (
+        "../apps/grazel-app.glade",
+        Registered {
+            appended: 5,
+            unchanged: 7,
+        },
+    ),
+    (
+        GYLD,
+        Registered {
+            appended: 3,
+            unchanged: 10,
+        },
+    ),
+    (
+        "../../glade-gyld/tests/fixtures/gyld-test-app.glade",
+        Registered {
+            appended: 2,
+            unchanged: 7,
+        },
+    ),
+    (
+        "../../glade-gwz/tests/fixtures/gwz-test-app.glade",
+        Registered {
+            appended: 1,
+            unchanged: 3,
+        },
+    ),
 ];
 
 fn path(rel: &str) -> PathBuf {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/tests/binding_census.rs:48:
 /// Read app files by their path from this crate, failing — with every
 /// missing path named — when this checkout is not inside the workspace.
 fn read_all<const N: usize>(rels: [&str; N]) -> [String; N] {
-    let missing: Vec<String> =
-        rels.iter().map(|rel| path(rel)).filter(|p| !p.is_file()).map(|p| p.display().to_string()).collect();
+    let missing: Vec<String> = rels
+        .iter()
+        .map(|rel| path(rel))
+        .filter(|p| !p.is_file())
+        .map(|p| p.display().to_string())
+        .collect();
     assert!(
         missing.is_empty(),
         "these tests read the census's app files from four repositories of the glade-wz workspace, \
Diff in /Volumes/projects/limbo/glade-wz/glade/node/tests/binding_census.rs:79:
         .filter(|line| !line.split_whitespace().take(2).eq(["binding", "gyld.desk"]))
         .map(|line| {
             let toks: Vec<&str> = line.split_whitespace().collect();
-            if toks == ["binding", "term.log", "log", "share", "commons", "from-cursor"] {
+            if toks
+                == [
+                    "binding",
+                    "term.log",
+                    "log",
+                    "share",
+                    "commons",
+                    "from-cursor",
+                ]
+            {
                 changed += 1;
                 line.replacen("from-cursor", "windowed", 1)
             } else if toks == ["glade-app", "v1"] {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/tests/binding_census.rs:105:
 /// release's flip, which refuses it in a `v1` file.
 fn pre_amendment(text: &str) -> AppDecl {
     let mut decl = parse(text).unwrap();
-    assert_eq!(decl.version, AppFileVersion::V0, "the text as it was before Step 2.4");
+    assert_eq!(
+        decl.version,
+        AppFileVersion::V0,
+        "the text as it was before Step 2.4"
+    );
     let lines: Vec<Vec<&str>> = text
         .lines()
-        .map(|line| line.split('#').next().unwrap_or("").split_whitespace().collect::<Vec<&str>>())
+        .map(|line| {
+            line.split('#')
+                .next()
+                .unwrap_or("")
+                .split_whitespace()
+                .collect::<Vec<&str>>()
+        })
         .filter(|toks| toks.first() == Some(&"binding"))
         .collect();
     assert_eq!(lines.len(), decl.bindings.len());
Diff in /Volumes/projects/limbo/glade-wz/glade/node/tests/binding_census.rs:115:
     for (b, toks) in decl.bindings.iter_mut().zip(&lines) {
-        assert_eq!(toks.len(), 6, "a pre-amendment binding line has no tail: {toks:?}");
+        assert_eq!(
+            toks.len(),
+            6,
+            "a pre-amendment binding line has no tail: {toks:?}"
+        );
         b.retention = toks[5].to_string();
-        let stored = [b.glade_id.as_str(), b.shape.as_str(), b.authority.as_str(), b.zone.as_str(), &b.retention];
+        let stored = [
+            b.glade_id.as_str(),
+            b.shape.as_str(),
+            b.authority.as_str(),
+            b.zone.as_str(),
+            &b.retention,
+        ];
         assert_eq!(stored, toks[1..6], "every field raw");
         assert_eq!(b.app, decl.app);
     }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/tests/binding_census.rs:132:
 
 /// The declarations these parses make, as `bindings_of` orders them.
 fn declared(decls: &[&AppDecl]) -> Vec<BindingDecl> {
-    let mut all: Vec<BindingDecl> = decls.iter().flat_map(|d| d.bindings.iter().cloned()).collect();
+    let mut all: Vec<BindingDecl> = decls
+        .iter()
+        .flat_map(|d| d.bindings.iter().cloned())
+        .collect();
     all.sort_by(|a, b| a.glade_id.cmp(&b.glade_id));
     all
 }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/tests/binding_census.rs:139:
 
 fn ops_of(reg: &Registry) -> Vec<Op> {
-    reg.snapshot().records.iter().map(|b| Op::decode(b).unwrap()).collect()
+    reg.snapshot()
+        .records
+        .iter()
+        .map(|b| Op::decode(b).unwrap())
+        .collect()
 }
 
 fn retracted(reg: &Registry) -> Vec<(String, String)> {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/tests/binding_census.rs:163:
     let mut total = 0;
     for ((rel, want), text) in CENSUS.iter().zip(&texts) {
         let (old_text, reverted) = before_step_2_4(text);
-        assert_eq!(reverted, usize::from(rel.ends_with("grazel-app.glade")), "{rel}: Step 2.4's edit");
+        assert_eq!(
+            reverted,
+            usize::from(rel.ends_with("grazel-app.glade")),
+            "{rel}: Step 2.4's edit"
+        );
         let pre = pre_amendment(&old_text);
         let mut reg = Registry::new();
         let first = register(&pre, &mut reg, ORIGIN).unwrap();
Diff in /Volumes/projects/limbo/glade-wz/glade/node/tests/binding_census.rs:170:
-        assert_eq!(first, Registered { appended: records(&pre), unchanged: 0 }, "{rel}");
+        assert_eq!(
+            first,
+            Registered {
+                appended: records(&pre),
+                unchanged: 0
+            },
+            "{rel}"
+        );
 
         let mut reg = reboot(&reg);
         let post = parse(text).unwrap();
Diff in /Volumes/projects/limbo/glade-wz/glade/node/tests/binding_census.rs:174:
         let out = register(&post, &mut reg, ORIGIN).unwrap();
         assert_eq!(out, *want, "{rel}");
-        assert_eq!(reg.bindings_of(), declared(&[&post]), "{rel}: the post-amendment declarations are live");
+        assert_eq!(
+            reg.bindings_of(),
+            declared(&[&post]),
+            "{rel}: the post-amendment declarations are live"
+        );
         assert_eq!(retracted(&reg), vec![], "{rel}: no line was deleted");
         total += out.appended;
     }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/tests/binding_census.rs:180:
-    assert_eq!(total, 16, "binding lines appended, summed over one registry per census file");
+    assert_eq!(
+        total, 16,
+        "binding lines appended, summed over one registry per census file"
+    );
 }
 
 /// §4.7 row 9 in the owner's store: grazel's boot with its gyld leg on
Diff in /Volumes/projects/limbo/glade-wz/glade/node/tests/binding_census.rs:186:
 #[test]
 fn row9_the_owners_two_file_store_appends_8() {
     let [grazel, gyld] = read_all([GRAZEL, GYLD]);
-    let (pre_grazel, pre_gyld) =
-        (pre_amendment(&before_step_2_4(&grazel).0), pre_amendment(&before_step_2_4(&gyld).0));
+    let (pre_grazel, pre_gyld) = (
+        pre_amendment(&before_step_2_4(&grazel).0),
+        pre_amendment(&before_step_2_4(&gyld).0),
+    );
     let mut reg = Registry::new();
-    assert_eq!(register(&pre_grazel, &mut reg, ORIGIN).unwrap(), Registered { appended: 12, unchanged: 0 });
+    assert_eq!(
+        register(&pre_grazel, &mut reg, ORIGIN).unwrap(),
+        Registered {
+            appended: 12,
+            unchanged: 0
+        }
+    );
     // the `workspace ws-razel razel` entry and the `seed owner ws-razel read.*`
     // grant both files declare register once
-    assert_eq!(register(&pre_gyld, &mut reg, ORIGIN).unwrap(), Registered { appended: 10, unchanged: 2 });
+    assert_eq!(
+        register(&pre_gyld, &mut reg, ORIGIN).unwrap(),
+        Registered {
+            appended: 10,
+            unchanged: 2
+        }
+    );
 
     let mut reg = reboot(&reg);
     let (post_grazel, post_gyld) = (parse(&grazel).unwrap(), parse(&gyld).unwrap());
Diff in /Volumes/projects/limbo/glade-wz/glade/node/tests/binding_census.rs:199:
     let a = register(&post_grazel, &mut reg, ORIGIN).unwrap();
     let b = register(&post_gyld, &mut reg, ORIGIN).unwrap();
-    assert_eq!((a, b), (Registered { appended: 5, unchanged: 7 }, Registered { appended: 3, unchanged: 10 }));
+    assert_eq!(
+        (a, b),
+        (
+            Registered {
+                appended: 5,
+                unchanged: 7
+            },
+            Registered {
+                appended: 3,
+                unchanged: 10
+            }
+        )
+    );
     assert_eq!(reg.bindings_of(), declared(&[&post_grazel, &post_gyld]));
     assert_eq!(reg.bindings_of().len(), 16);
     assert_eq!(retracted(&reg), vec![]);
Diff in /Volumes/projects/limbo/glade-wz/glade/node/tests/binding_census.rs:208:
 /// with the gyld leg on does.
 fn both_registered(grazel: &AppDecl, gyld: &AppDecl) -> Registry {
     let mut reg = Registry::new();
-    assert_eq!(register(grazel, &mut reg, ORIGIN).unwrap(), Registered { appended: 12, unchanged: 0 });
-    assert_eq!(register(gyld, &mut reg, ORIGIN).unwrap(), Registered { appended: 11, unchanged: 2 });
+    assert_eq!(
+        register(grazel, &mut reg, ORIGIN).unwrap(),
+        Registered {
+            appended: 12,
+            unchanged: 0
+        }
+    );
+    assert_eq!(
+        register(gyld, &mut reg, ORIGIN).unwrap(),
+        Registered {
+            appended: 11,
+            unchanged: 2
+        }
+    );
     reg
 }
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/tests/binding_census.rs:224:
     assert_eq!(reg.bindings_of(), declared(&[&grazel, &gyld]));
     assert_eq!(reg.bindings_of().len(), 16);
     assert_eq!(retracted(&reg), vec![]);
-    assert!(ops_of(&reg).iter().all(|o| o.glade_id != G_BINDING_RETRACTIONS), "no retraction record");
+    assert!(
+        ops_of(&reg)
+            .iter()
+            .all(|o| o.glade_id != G_BINDING_RETRACTIONS),
+        "no retraction record"
+    );
 }
 
 /// §4.7 row 10, second test: the next boot loads grazel-app.glade alone
Diff in /Volumes/projects/limbo/glade-wz/glade/node/tests/binding_census.rs:236:
     let (grazel, gyld) = (parse(&grazel).unwrap(), parse(&gyld).unwrap());
     let before = both_registered(&grazel, &gyld).snapshot();
     let (mut reg, _) = Registry::from_snapshot(&before);
-    assert_eq!(register(&grazel, &mut reg, ORIGIN).unwrap(), Registered { appended: 0, unchanged: 12 });
+    assert_eq!(
+        register(&grazel, &mut reg, ORIGIN).unwrap(),
+        Registered {
+            appended: 0,
+            unchanged: 12
+        }
+    );
     assert_eq!(reg.snapshot(), before, "nothing appended");
-    let gyld_live: Vec<BindingDecl> = reg.bindings_of().into_iter().filter(|b| b.app == "gyld").collect();
+    let gyld_live: Vec<BindingDecl> = reg
+        .bindings_of()
+        .into_iter()
+        .filter(|b| b.app == "gyld")
+        .collect();
     assert_eq!(gyld_live, declared(&[&gyld]), "gyld's 9 untouched");
     assert_eq!(gyld_live.len(), 9);
     assert_eq!(retracted(&reg), vec![]);
Diff in /Volumes/projects/limbo/glade-wz/glade/node/tests/binding_census.rs:257:
         .lines()
         .filter(|line| !line.split_whitespace().take(2).eq(["binding", "gyld.file"]))
         .collect();
-    assert_eq!(edited.len(), gyld.lines().count() - 1, "exactly one line deleted");
+    assert_eq!(
+        edited.len(),
+        gyld.lines().count() - 1,
+        "exactly one line deleted"
+    );
     let edited = parse(&(edited.join("\n") + "\n")).unwrap();
 
     let mut reg = reboot(&reg);
Diff in /Volumes/projects/limbo/glade-wz/glade/node/tests/binding_census.rs:264:
-    assert_eq!(register(&grazel_decl, &mut reg, ORIGIN).unwrap(), Registered { appended: 0, unchanged: 12 });
+    assert_eq!(
+        register(&grazel_decl, &mut reg, ORIGIN).unwrap(),
+        Registered {
+            appended: 0,
+            unchanged: 12
+        }
+    );
     // the retraction is gyld's one append; its 8 bindings, service, 2 seeds
     // and workspace are unchanged
-    assert_eq!(register(&edited, &mut reg, ORIGIN).unwrap(), Registered { appended: 1, unchanged: 12 });
-    assert_eq!(retracted(&reg), vec![("gyld".to_string(), "gyld.file".to_string())]);
+    assert_eq!(
+        register(&edited, &mut reg, ORIGIN).unwrap(),
+        Registered {
+            appended: 1,
+            unchanged: 12
+        }
+    );
+    assert_eq!(
+        retracted(&reg),
+        vec![("gyld".to_string(), "gyld.file".to_string())]
+    );
     assert_eq!(reg.bindings_of(), declared(&[&grazel_decl, &edited]));
     assert_eq!(reg.bindings_of().len(), 15);
-    let retractions = ops_of(&reg).iter().filter(|o| o.glade_id == G_BINDING_RETRACTIONS).count();
+    let retractions = ops_of(&reg)
+        .iter()
+        .filter(|o| o.glade_id == G_BINDING_RETRACTIONS)
+        .count();
     assert_eq!(retractions, 1);
 }
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/tests/shipped_app_files.rs:38:
 /// The number of `text`'s header line: its first line that is not blank or
 /// a comment, as `parse` finds it.
 fn header_at(text: &str) -> usize {
-    let at = text.lines().position(|line| !line.split('#').next().unwrap_or("").trim().is_empty());
+    let at = text
+        .lines()
+        .position(|line| !line.split('#').next().unwrap_or("").trim().is_empty());
     at.expect("a header line") + 1
 }
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/tests/shipped_app_files.rs:49:
     let lines: Vec<&str> = text
         .lines()
         .enumerate()
-        .map(|(i, line)| {
-            if i + 1 == at {
-                header
-            } else {
-                line
-            }
-        })
+        .map(|(i, line)| if i + 1 == at { header } else { line })
         .collect();
     lines.join("\n") + "\n"
 }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/tests/shipped_app_files.rs:62:
 
 #[test]
 fn every_shipped_file_loads_with_no_warning() {
-    let missing: Vec<String> =
-        SHIPPED.iter().map(|rel| path(rel)).filter(|p| !p.is_file()).map(|p| p.display().to_string()).collect();
+    let missing: Vec<String> = SHIPPED
+        .iter()
+        .map(|rel| path(rel))
+        .filter(|p| !p.is_file())
+        .map(|p| p.display().to_string())
+        .collect();
     assert!(
         missing.is_empty(),
         "this test reads the census's app files from four repositories of the glade-wz workspace, \
Diff in /Volumes/projects/limbo/glade-wz/glade/node/tests/shipped_app_files.rs:87:
         // the header's, on its line.
         let v0 = parse(&headed(&text, "glade-app v0")).unwrap();
         assert_eq!(v0.version, AppFileVersion::V0, "{rel}");
-        let warning = format!("line {at}: header `glade-app v0` names the old language; write `glade-app v1`");
+        let warning = format!(
+            "line {at}: header `glade-app v0` names the old language; write `glade-app v1`"
+        );
         assert_eq!(v0.warnings, [warning], "{rel}");
-        assert_eq!(v0.bindings, decl.bindings, "{rel}: the header moves no declaration");
+        assert_eq!(
+            v0.bindings, decl.bindings,
+            "{rel}: the header moves no declaration"
+        );
     }
 }
 

```

## B2 final clippy no newly introduced node debt
Command: ['cargo', 'clippy', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '-p', 'glade-node', '--all-targets', '--all-features']
Exit: 0; wall: 4.027s
```text
    Checking glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
warning: this can be `std::io::Error::other(_)`
   --> src/claims.rs:138:5
    |
138 |     io::Error::new(io::ErrorKind::Other, e)
    |     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    |
    = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
    = note: `#[warn(clippy::io_other_error)]` on by default
help: use `std::io::Error::other`
    |
138 -     io::Error::new(io::ErrorKind::Other, e)
138 +     io::Error::other(e)
    |

warning: this can be `std::io::Error::other(_)`
  --> src/exchange.rs:53:5
   |
53 |     io::Error::new(io::ErrorKind::Other, e)
   |     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
   |
   = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
help: use `std::io::Error::other`
   |
53 -     io::Error::new(io::ErrorKind::Other, e)
53 +     io::Error::other(e)
   |

warning: this can be `std::io::Error::other(_)`
  --> src/iroh_carrier.rs:68:5
   |
68 |     io::Error::new(io::ErrorKind::Other, e)
   |     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
   |
   = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
help: use `std::io::Error::other`
   |
68 -     io::Error::new(io::ErrorKind::Other, e)
68 +     io::Error::other(e)
   |

warning: this can be `std::io::Error::other(_)`
  --> src/mesh.rs:63:5
   |
63 |     io::Error::new(io::ErrorKind::Other, e)
   |     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
   |
   = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
help: use `std::io::Error::other`
   |
63 -     io::Error::new(io::ErrorKind::Other, e)
63 +     io::Error::other(e)
   |

warning: this can be `std::io::Error::other(_)`
   --> src/server.rs:458:18
    |
458 |         other => std::io::Error::new(std::io::ErrorKind::Other, format!("{other:?}")),
    |                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    |
    = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
help: use `std::io::Error::other`
    |
458 -         other => std::io::Error::new(std::io::ErrorKind::Other, format!("{other:?}")),
458 +         other => std::io::Error::other(format!("{other:?}")),
    |

warning: doc list item without indentation
 --> src/ws.rs:3:5
  |
3 | //! (which is text-only) for **binary** frames: glade carries CBOR, not text.
  |     ^
  |
  = help: if this is supposed to be its own paragraph, add a blank line
  = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#doc_lazy_continuation
  = note: `#[warn(clippy::doc_lazy_continuation)]` on by default
help: indent this line
  |
3 | //!   (which is text-only) for **binary** frames: glade carries CBOR, not text.
  |     ++

warning: doc list item without indentation
 --> src/ws.rs:4:5
  |
4 | //! Enough to talk to a browser/Node WebSocket: the upgrade handshake, masked
  |     ^
  |
  = help: if this is supposed to be its own paragraph, add a blank line
  = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#doc_lazy_continuation
help: indent this line
  |
4 | //!   Enough to talk to a browser/Node WebSocket: the upgrade handshake, masked
  |     ++

warning: doc list item without indentation
 --> src/ws.rs:5:5
  |
5 | //! client->server and unmasked server->client binary frames; close surfaced;
  |     ^
  |
  = help: if this is supposed to be its own paragraph, add a blank line
  = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#doc_lazy_continuation
help: indent this line
  |
5 | //!   client->server and unmasked server->client binary frames; close surfaced;
  |     ++

warning: doc list item without indentation
 --> src/ws.rs:6:5
  |
6 | //! ping/pong skipped (trusted localhost).
  |     ^
  |
  = help: if this is supposed to be its own paragraph, add a blank line
  = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#doc_lazy_continuation
help: indent this line
  |
6 | //!   ping/pong skipped (trusted localhost).
  |     ++

warning: `glade-node` (lib) generated 9 warnings (run `cargo clippy --fix --lib -p glade-node -- ` to apply 5 suggestions)
warning: `glade-node` (lib test) generated 9 warnings (9 duplicates)
    Finished `dev` profile [unoptimized + debuginfo] target(s) in 3.94s

```

## B2 final node format ratchet unchanged debt
Command: cargo fmt --manifest-path glade/node/Cargo.toml -p glade-node -- --check
Exit: 1; counted hunks 251 / retained baseline252
```text
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/bin/glade-node.rs:410:
                 eprintln!("{line}");
             }
             let reg = glade_node::appdecl::register(&decl, &mut node.registry, &registrant)
-                .map_err(|e| std::io::Error::new(std::io::ErrorKind::InvalidData, format!("{e:?}")))?;
+                .map_err(|e| {
+                    std::io::Error::new(std::io::ErrorKind::InvalidData, format!("{e:?}"))
+                })?;
             node.store.save(&node.registry.snapshot())?;
-            println!("app {} registered (+{} record(s), {} unchanged)", decl.app, reg.appended, reg.unchanged);
-            workspaces.extend(decl.workspaces.iter().map(|w| (w.share.clone(), w.name.clone())));
+            println!(
+                "app {} registered (+{} record(s), {} unchanged)",
+                decl.app, reg.appended, reg.unchanged
+            );
+            workspaces.extend(
+                decl.workspaces
+                    .iter()
+                    .map(|w| (w.share.clone(), w.name.clone())),
+            );
         }
         Some((node, workspaces, network, leases))
     } else {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl/tail.rs:36:
 const PROFILE_REQUIRED: [&str; 1] = ["crdt"];
 
 /// The units `ttl=` takes, each in milliseconds.
-const UNITS: [(&str, i64); 5] =
-    [("ms", 1), ("s", 1_000), ("m", 60_000), ("h", 3_600_000), ("d", 86_400_000)];
+const UNITS: [(&str, i64); 5] = [
+    ("ms", 1),
+    ("s", 1_000),
+    ("m", 60_000),
+    ("h", 3_600_000),
+    ("d", 86_400_000),
+];
 
 /// Parse binding line `n`'s tail — `toks`, the tokens after the five
 /// positional ones — against the line's shape, zone and retention, in a file
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl/tail.rs:64:
             }
         }
     }
-    let mut tail = BindingTail { glade_id: glade_id.into(), ..BindingTail::default() };
+    let mut tail = BindingTail {
+        glade_id: glade_id.into(),
+        ..BindingTail::default()
+    };
     let mut seen: Vec<&str> = Vec::new();
     for tok in toks {
         let Some((key, value)) = tok.split_once('=').filter(|(key, _)| !key.is_empty()) else {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl/tail.rs:71:
-            return Err(format!("line {n}: `{tok}` is not a key=value entry ({})", keys()));
+            return Err(format!(
+                "line {n}: `{tok}` is not a key=value entry ({})",
+                keys()
+            ));
         };
         if !KEYS.contains(&key) {
-            return Err(format!("line {n}: unknown binding key `{key}` ({})", keys()));
+            return Err(format!(
+                "line {n}: unknown binding key `{key}` ({})",
+                keys()
+            ));
         }
         if seen.contains(&key) {
             return Err(format!("line {n}: repeated binding key `{key}`"));
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl/tail.rs:84:
         }
     }
     if tail.ttl_ms.is_some() && retention != "ttl" {
-        return Err(format!("line {n}: `ttl=` needs the retention `ttl` (this line's is `{retention}`)"));
+        return Err(format!(
+            "line {n}: `ttl=` needs the retention `ttl` (this line's is `{retention}`)"
+        ));
     }
     fits_shape(n, shape, tail.shape_profile.as_deref())?;
     if seen.is_empty() {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl/tail.rs:108:
 
 /// GDL-041's profiles, as a diagnostic lists them.
 fn profiles() -> String {
-    let each: Vec<String> = PROFILES.iter().map(|(p, core)| format!("`{p}` over `{core}`")).collect();
+    let each: Vec<String> = PROFILES
+        .iter()
+        .map(|(p, core)| format!("`{p}` over `{core}`"))
+        .collect();
     format!("profiles: {}", each.join(", "))
 }
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl/tail.rs:140:
 fn profile(n: usize, value: &str) -> Result<&'static str, String> {
     match PROFILES.iter().find(|(p, _)| *p == value) {
         Some((p, _)) => Ok(p),
-        None => Err(format!("line {n}: unknown profile `{value}` ({})", profiles())),
+        None => Err(format!(
+            "line {n}: unknown profile `{value}` ({})",
+            profiles()
+        )),
     }
 }
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl/tail.rs:148:
 /// over one core engine; a shape no profile runs over takes none; a shape in
 /// [`PROFILE_REQUIRED`] must name one.
 fn fits_shape(n: usize, shape: &str, profile: Option<&str>) -> Result<(), String> {
-    let over_shape: Vec<&str> = PROFILES.iter().filter(|(_, core)| *core == shape).map(|(p, _)| *p).collect();
+    let over_shape: Vec<&str> = PROFILES
+        .iter()
+        .filter(|(_, core)| *core == shape)
+        .map(|(p, _)| *p)
+        .collect();
     match profile {
         Some(p) => {
             if over_shape.is_empty() {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl/tail.rs:155:
-                return Err(format!("line {n}: shape `{shape}` takes no `shape-profile` ({})", profiles()));
+                return Err(format!(
+                    "line {n}: shape `{shape}` takes no `shape-profile` ({})",
+                    profiles()
+                ));
             }
             if !over_shape.contains(&p) {
-                let core = PROFILES.iter().find(|(name, _)| *name == p).map(|(_, core)| *core).unwrap_or("");
-                return Err(format!("line {n}: profile `{p}` is over `{core}`, not `{shape}`"));
+                let core = PROFILES
+                    .iter()
+                    .find(|(name, _)| *name == p)
+                    .map(|(_, core)| *core)
+                    .unwrap_or("");
+                return Err(format!(
+                    "line {n}: profile `{p}` is over `{core}`, not `{shape}`"
+                ));
             }
             Ok(())
         }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl/tail.rs:163:
         None => {
             if PROFILE_REQUIRED.contains(&shape) {
-                let needs: Vec<String> = over_shape.iter().map(|p| format!("`shape-profile={p}`")).collect();
+                let needs: Vec<String> = over_shape
+                    .iter()
+                    .map(|p| format!("`shape-profile={p}`"))
+                    .collect();
                 return Err(format!(
                     "line {n}: shape `{shape}` needs {} (a `{shape}` line must name its profile)",
                     needs.join(" or ")
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl/tail.rs:235:
     #[test]
     fn an_unknown_key_is_refused_by_name_with_its_line() {
         assert_eq!(
-            parse("glade-app v0\napp x\n\nbinding g value share commons latest colour=red\n").unwrap_err(),
+            parse("glade-app v0\napp x\n\nbinding g value share commons latest colour=red\n")
+                .unwrap_err(),
             "line 4: unknown binding key `colour` (binding keys: `ttl`, `shape-profile`)"
         );
         assert_eq!(
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl/tail.rs:335:
     /// `ms`, `s`, `m`, `h` or `d` — nothing else.
     #[test]
     fn a_bad_duration_is_refused() {
-        for bad in ["", "10", "m", "0m", "00s", "1.5h", "1h30m", "10M", "-1m", "+1m", "1w", "10mss", "1 m"] {
+        for bad in [
+            "", "10", "m", "0m", "00s", "1.5h", "1h30m", "10M", "-1m", "+1m", "1w", "10mss", "1 m",
+        ] {
             let text = format!("binding g value share commons ttl ttl={bad}");
             // A space ends the token, so `ttl=1 m` offers the duration `1`.
             let tok = bad.split_whitespace().next().unwrap_or("");
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl/tail.rs:376:
         let profiles = "(profiles: `snapshot_delta` over `swmr`, `text_crdt` over `crdt`)";
         for shape in ["value", "log"] {
             assert_eq!(
-                line(&format!("binding g {shape} share commons latest shape-profile=snapshot_delta")).unwrap_err(),
+                line(&format!(
+                    "binding g {shape} share commons latest shape-profile=snapshot_delta"
+                ))
+                .unwrap_err(),
                 format!("line 3: shape `{shape}` takes no `shape-profile` {profiles}")
             );
         }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl/tail.rs:385:
             "line 3: profile `text_crdt` is over `crdt`, not `swmr`"
         );
         assert_eq!(
-            line("binding g crdt share commons from-cursor shape-profile=snapshot_delta").unwrap_err(),
+            line("binding g crdt share commons from-cursor shape-profile=snapshot_delta")
+                .unwrap_err(),
             "line 3: profile `snapshot_delta` is over `swmr`, not `crdt`"
         );
         for unknown in ["text-crdt", "blob", ""] {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl/tail.rs:392:
             assert_eq!(
-                line(&format!("binding g swmr share commons from-cursor shape-profile={unknown}")).unwrap_err(),
+                line(&format!(
+                    "binding g swmr share commons from-cursor shape-profile={unknown}"
+                ))
+                .unwrap_err(),
                 format!("line 3: unknown profile `{unknown}` {profiles}")
             );
         }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:94:
 /// must name; `atom` (a GDL-041 engine), `message` and `window` are
 /// recognised and reserved ([`RESERVED_SHAPES`]); `stream` is recognised and
 /// not bindable; an exchange is authored by a `service` line.
-const KNOWN_SHAPES: [&str; 9] =
-    ["value", "log", "message", "stream", "exchange", "window", "swmr", "crdt", "atom"];
+const KNOWN_SHAPES: [&str; 9] = [
+    "value", "log", "message", "stream", "exchange", "window", "swmr", "crdt", "atom",
+];
 const BINDING_SHAPES: [&str; 4] = ["value", "log", "swmr", "crdt"];
 /// Recognised shapes with nothing to bind and nothing to redirect to: the
 /// refusal says they are reserved rather than only listing what binds.
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:130:
 ];
 /// What a `glade-app v0` header is told (R10(a)): the file loads as it always
 /// did, and learns the header that names the validated grammar.
-const V0_HEADER_WARNING: &str = "header `glade-app v0` names the old language; write `glade-app v1`";
+const V0_HEADER_WARNING: &str =
+    "header `glade-app v0` names the old language; write `glade-app v1`";
 /// What a file whose first declaration line is not a header is told: the
 /// header to write, and the one an old file may still carry.
 const HEADER_TO_WRITE: &str = "write `glade-app v1` (`glade-app v0` is accepted for old files)";
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:389:
             }
             "binding" => {
                 if decl.app.is_empty() {
-                    return Err(format!("line {n}: `app` must be declared before any binding"));
+                    return Err(format!(
+                        "line {n}: `app` must be declared before any binding"
+                    ));
                 }
                 // A minimum: five positional tokens, then the optional tail.
                 if toks.len() < 6 {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:397:
                 }
                 let (glade_id, shape, retention) = (toks[1], toks[2], toks[5]);
                 if !KNOWN_SHAPES.contains(&shape) {
-                    return Err(format!("line {n}: unknown shape `{shape}` (known: {KNOWN_SHAPES:?})"));
+                    return Err(format!(
+                        "line {n}: unknown shape `{shape}` (known: {KNOWN_SHAPES:?})"
+                    ));
                 }
                 if !BINDING_SHAPES.contains(&shape) {
                     return Err(unbindable(n, shape));
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:452:
             }
             "service" => {
                 if decl.app.is_empty() {
-                    return Err(format!("line {n}: `app` must be declared before any service"));
+                    return Err(format!(
+                        "line {n}: `app` must be declared before any service"
+                    ));
                 }
                 if toks.len() != 3 {
                     return Err(format!("line {n}: `service <name> <exchange-glade-id>`"));
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:469:
                     return Err(format!("line {n}: `app` must be declared before any seed"));
                 }
                 if toks.len() != 4 {
-                    return Err(format!("line {n}: `seed <principal> <share> <verb[,verb...]>`"));
+                    return Err(format!(
+                        "line {n}: `seed <principal> <share> <verb[,verb...]>`"
+                    ));
                 }
                 let seed = CapabilityGrant {
                     principal: toks[1].into(),
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:517:
             }
             "workspace" => {
                 if decl.app.is_empty() {
-                    return Err(format!("line {n}: `app` must be declared before any workspace"));
+                    return Err(format!(
+                        "line {n}: `app` must be declared before any workspace"
+                    ));
                 }
                 if toks.len() != 3 {
                     return Err(format!("line {n}: `workspace <share> <name>`"));
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:525:
                 if decl.workspaces.iter().any(|w| w.share == toks[1]) {
                     return Err(format!("line {n}: duplicate workspace share `{}`", toks[1]));
                 }
-                decl.workspaces.push(WorkspaceDecl { share: toks[1].into(), name: toks[2].into() });
+                decl.workspaces.push(WorkspaceDecl {
+                    share: toks[1].into(),
+                    name: toks[2].into(),
+                });
             }
             other => return Err(format!("line {n}: unknown declaration `{other}`")),
         }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:569:
 /// The message a `glade-app v1` file is told for `token`, if it is one of the
 /// retention tokens a file may not write ([`REFUSED_RETENTIONS`]).
 pub fn refused_retention(token: &str) -> Option<&'static str> {
-    REFUSED_RETENTIONS.iter().find(|(t, _, _)| *t == token).map(|(_, v1, _)| *v1)
+    REFUSED_RETENTIONS
+        .iter()
+        .find(|(t, _, _)| *t == token)
+        .map(|(_, v1, _)| *v1)
 }
 
 /// A zone or retention that `glade-app v1` does not accept, as a file in each
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:602:
     if retention.contains('=') {
         out.push(misplaced("retention", retention));
     } else if let Some(&(_, v1, v0)) = REFUSED_RETENTIONS.iter().find(|(t, _, _)| *t == retention) {
-        out.push(Unaccepted { v1: v1.into(), v0: v0.into() });
+        out.push(Unaccepted {
+            v1: v1.into(),
+            v0: v0.into(),
+        });
     } else if !RETENTIONS.contains(&retention) {
         out.push(Unaccepted {
             v1: format!("unknown retention `{retention}` (one of {RETENTIONS:?})"),
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:800:
     }
     for glade_id in live.keys() {
         if !decl.bindings.iter().any(|b| &b.glade_id == glade_id) {
-            let retraction = BindingRetraction { app: decl.app.clone(), glade_id: glade_id.clone() };
+            let retraction = BindingRetraction {
+                app: decl.app.clone(),
+                glade_id: glade_id.clone(),
+            };
             reg.append(Record::Retract(retraction), origin)?;
             out.appended += 1;
         }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:832:
 
     for rec in records {
         let (glade_id, payload) = (rec.glade_id().to_string(), rec.encode());
-        if existing.iter().any(|(g, p)| *g == glade_id && *p == payload) {
+        if existing
+            .iter()
+            .any(|(g, p)| *g == glade_id && *p == payload)
+        {
             out.unchanged += 1;
         } else {
             reg.append(rec, origin)?;
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:852:
     use glade_wire::generated::Shape;
 
     use crate::registry::{
-        BindingFold, Record, Registry, RegistryApi, G_BINDINGS, G_BINDING_RETRACTIONS, G_GRANTS, G_REVOCATIONS,
-        G_SERVICES, HOME,
+        BindingFold, Record, Registry, RegistryApi, G_BINDINGS, G_BINDING_RETRACTIONS, G_GRANTS,
+        G_REVOCATIONS, G_SERVICES, HOME,
     };
     use crate::sysdata::CapabilityRevocation;
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:887:
     fn grazel_file_matches_the_trace_shape() {
         let decl = parse(&grazel_file()).unwrap();
         assert_eq!(decl.app, "grazel");
-        assert_eq!(decl.bindings.len(), 7, "4 workspace + 3 composed-supplier surfaces");
+        assert_eq!(
+            decl.bindings.len(),
+            7,
+            "4 workspace + 3 composed-supplier surfaces"
+        );
         assert_eq!(decl.services.len(), 1, "1 service (grazel)");
         assert_eq!(decl.seeds.len(), 2, "2 ACL seeds");
         for g in &decl.seeds {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:899:
             share: "grazel".into(),
         };
         assert_eq!(decl.revocations, [old_pair]);
-        assert_eq!(decl.workspaces, vec![WorkspaceDecl { share: "ws-razel".into(), name: "razel".into() }]);
+        assert_eq!(
+            decl.workspaces,
+            vec![WorkspaceDecl {
+                share: "ws-razel".into(),
+                name: "razel".into()
+            }]
+        );
         // the directed surface the service answers (discovery.ts phase D):
         assert_eq!(decl.services[0].glade_id, "gwz.ops");
         // key surface names ride as data — the workspace tree + the composed
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:906:
         // gwz.output long-op stream + the chat group-keyed log:
-        assert!(decl.bindings.iter().any(|b| b.glade_id == "ws.tree" && b.shape == "value"));
-        assert!(decl.bindings.iter().any(|b| b.glade_id == "ws.files" && b.shape == "swmr"));
-        assert!(decl.bindings.iter().any(|b| b.glade_id == "gwz.output" && b.shape == "log"));
-        assert!(decl.bindings.iter().any(|b| b.glade_id == "chat.msgs" && b.shape == "log"));
-        assert!(decl.bindings.iter().any(|b| b.glade_id == "chat.groups" && b.shape == "value"));
+        assert!(decl
+            .bindings
+            .iter()
+            .any(|b| b.glade_id == "ws.tree" && b.shape == "value"));
+        assert!(decl
+            .bindings
+            .iter()
+            .any(|b| b.glade_id == "ws.files" && b.shape == "swmr"));
+        assert!(decl
+            .bindings
+            .iter()
+            .any(|b| b.glade_id == "gwz.output" && b.shape == "log"));
+        assert!(decl
+            .bindings
+            .iter()
+            .any(|b| b.glade_id == "chat.msgs" && b.shape == "log"));
+        assert!(decl
+            .bindings
+            .iter()
+            .any(|b| b.glade_id == "chat.groups" && b.shape == "value"));
         assert!(decl.bindings.iter().all(|b| b.app == "grazel"));
     }
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:925:
         // Known legacy/future enum values remain decodable on the wire but are
         // not authorable bindings until an exact runtime adapter exists.
         for shape in ["message", "stream", "exchange", "window"] {
-            let text = format!(
-                "glade-app v0\napp x\nbinding g {shape} share commons latest\n"
-            );
+            let text = format!("glade-app v0\napp x\nbinding g {shape} share commons latest\n");
             let e = parse(&text).unwrap_err();
-            assert!(e.contains("line 3") && e.contains("unsupported binding shape") && e.contains(shape), "{e}");
+            assert!(
+                e.contains("line 3")
+                    && e.contains("unsupported binding shape")
+                    && e.contains(shape),
+                "{e}"
+            );
         }
         // duplicate glade id (frozen-once-shared, GQ-6)
         let e = parse(
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:936:
             "glade-app v0\napp x\nbinding g value share commons latest\nbinding g log share commons latest\n",
         )
         .unwrap_err();
-        assert!(e.contains("line 4") && e.contains("duplicate glade id"), "{e}");
+        assert!(
+            e.contains("line 4") && e.contains("duplicate glade id"),
+            "{e}"
+        );
         // declarations before `app`
         let e = parse("glade-app v0\nbinding g value share commons latest\n").unwrap_err();
-        assert!(e.contains("line 2") && e.contains("`app` must be declared"), "{e}");
+        assert!(
+            e.contains("line 2") && e.contains("`app` must be declared"),
+            "{e}"
+        );
         // missing app entirely
-        assert!(parse("glade-app v0\n").unwrap_err().contains("missing `app"));
+        assert!(parse("glade-app v0\n")
+            .unwrap_err()
+            .contains("missing `app"));
         // workspace: arity + duplicate share
         let e = parse("glade-app v0\napp x\nworkspace ws-a\n").unwrap_err();
-        assert!(e.contains("line 3") && e.contains("workspace <share> <name>"), "{e}");
+        assert!(
+            e.contains("line 3") && e.contains("workspace <share> <name>"),
+            "{e}"
+        );
         let e = parse("glade-app v0\napp x\nworkspace ws-a a\nworkspace ws-a b\n").unwrap_err();
-        assert!(e.contains("line 4") && e.contains("duplicate workspace share"), "{e}");
+        assert!(
+            e.contains("line 4") && e.contains("duplicate workspace share"),
+            "{e}"
+        );
     }
 
     #[test]
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:953:
     fn swmr_is_an_exact_authorable_binding_shape() {
-        let decl = parse(
-            "glade-app v0\napp demo\nbinding ws.files swmr share commons from_cursor\n",
-        )
-        .unwrap();
+        let decl =
+            parse("glade-app v0\napp demo\nbinding ws.files swmr share commons from_cursor\n")
+                .unwrap();
         assert_eq!(decl.bindings[0].shape, "swmr");
     }
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:966:
         let decl = parse("glade-app v0\napp demo\nworkspace ws-d demo-ws\n").unwrap();
         let mut reg = Registry::new();
         let out = register(&decl, &mut reg, "node-1").unwrap();
-        assert_eq!(out, Registered { appended: 1, unchanged: 0 });
+        assert_eq!(
+            out,
+            Registered {
+                appended: 1,
+                unchanged: 0
+            }
+        );
         assert_eq!(reg.replicas_of("ws-d"), vec!["node-1"]);
         // re-registration diffs away (same registrant, same bytes).
         let again = register(&decl, &mut reg, "node-1").unwrap();
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:973:
-        assert_eq!(again, Registered { appended: 0, unchanged: 1 });
+        assert_eq!(
+            again,
+            Registered {
+                appended: 0,
+                unchanged: 1
+            }
+        );
     }
 
     /// Registration = ordinary record appends: home-share wire Ops, origin-
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:986:
         .unwrap();
         let mut reg = Registry::new();
         let out = register(&decl, &mut reg, "node-1").unwrap();
-        assert_eq!(out, Registered { appended: 3, unchanged: 0 });
+        assert_eq!(
+            out,
+            Registered {
+                appended: 3,
+                unchanged: 0
+            }
+        );
 
         let snap = reg.snapshot();
-        let ops: Vec<Op> = snap.records.iter().map(|b| Op::decode(b).unwrap()).collect();
+        let ops: Vec<Op> = snap
+            .records
+            .iter()
+            .map(|b| Op::decode(b).unwrap())
+            .collect();
         assert_eq!(ops.len(), 3);
         for op in &ops {
             assert_eq!(op.share, HOME);
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:1008:
         let decl = parse(&grazel_file()).unwrap();
         let mut reg = Registry::new();
         let first = register(&decl, &mut reg, "node-1").unwrap();
-        assert_eq!(first, Registered { appended: 12, unchanged: 0 }); // 7 bindings +1 service +2 seeds +1 revocation +1 workspace
+        assert_eq!(
+            first,
+            Registered {
+                appended: 12,
+                unchanged: 0
+            }
+        ); // 7 bindings +1 service +2 seeds +1 revocation +1 workspace
         let snap1 = reg.snapshot();
         let second = register(&decl, &mut reg, "node-1").unwrap();
-        assert_eq!(second, Registered { appended: 0, unchanged: 12 });
-        assert_eq!(reg.snapshot(), snap1, "re-registration is a byte-identical no-op");
+        assert_eq!(
+            second,
+            Registered {
+                appended: 0,
+                unchanged: 12
+            }
+        );
+        assert_eq!(
+            reg.snapshot(),
+            snap1,
+            "re-registration is a byte-identical no-op"
+        );
     }
 
     /// The fold is the only authority: a runtime revocation lands AFTER the
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:1033:
         // the file seeds once; the fold rules forever.
         let again = register(&decl, &mut reg, "node-1").unwrap();
         assert_eq!(again.appended, 0, "identical seeds diff away on re-load");
-        assert_eq!(reg.grants_for("owner", "ws-razel"), Vec::<String>::new(), "revocation stays");
+        assert_eq!(
+            reg.grants_for("owner", "ws-razel"),
+            Vec::<String>::new(),
+            "revocation stays"
+        );
     }
 
     /// §4.7 row 17 (R10(a)): the regression that pins plan Step 2.3 ahead of
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:1157:
     /// profile, which the tail makes mandatory for it (bullet 4).
     #[test]
     fn crdt_is_a_binding_shape() {
-        let decl = binding_line("binding doc.body crdt share commons from-cursor shape-profile=text_crdt").unwrap();
+        let decl =
+            binding_line("binding doc.body crdt share commons from-cursor shape-profile=text_crdt")
+                .unwrap();
         assert_eq!(decl.bindings[0].shape, "crdt");
     }
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:1185:
             format!("line 3: unsupported binding shape `stream` (implemented: {implemented})")
         );
         let e = binding_line("binding g blob share commons latest").unwrap_err();
-        assert!(e.starts_with("line 3: unknown shape `blob`") && e.contains("\"crdt\", \"atom\""), "{e}");
+        assert!(
+            e.starts_with("line 3: unknown shape `blob`") && e.contains("\"crdt\", \"atom\""),
+            "{e}"
+        );
     }
 
     /// R11(a), §4.4 bullet 4: the arity check is a MINIMUM of five tokens
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:1214:
         );
         assert_eq!(
             refused_retention("from_cursor"),
-            Some("retention `from_cursor` is the contract's spelling (use `from-cursor` in a file)")
+            Some(
+                "retention `from_cursor` is the contract's spelling (use `from-cursor` in a file)"
+            )
         );
         for token in ["latest", "from-cursor", "ttl", "frobnicate"] {
             assert_eq!(refused_retention(token), None, "{token}");
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:1221:
         }
         for token in ["windowed", "from_cursor"] {
             let told = v1_reports(&v1_file(&format!("binding g log share commons {token}")));
-            assert_eq!(told, [format!("line 3: {}", refused_retention(token).unwrap())], "{token}");
+            assert_eq!(
+                told,
+                [format!("line 3: {}", refused_retention(token).unwrap())],
+                "{token}"
+            );
         }
     }
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:1231:
     /// same bytes.
     #[test]
     fn the_tail_reaches_no_record() {
-        let with = binding_line("binding g swmr share commons ttl ttl=10m shape-profile=snapshot_delta").unwrap();
+        let with =
+            binding_line("binding g swmr share commons ttl ttl=10m shape-profile=snapshot_delta")
+                .unwrap();
         let without = binding_line("binding g swmr share commons ttl").unwrap();
         assert_eq!(with.bindings, without.bindings);
         let (mut a, mut b) = (Registry::new(), Registry::new());
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:1242:
 
     /// The live bindings as (glade_id, stored retention).
     fn live(reg: &Registry) -> Vec<(String, String)> {
-        reg.bindings_of().into_iter().map(|b| (b.glade_id, b.retention)).collect()
+        reg.bindings_of()
+            .into_iter()
+            .map(|b| (b.glade_id, b.retention))
+            .collect()
     }
     fn pair(glade_id: &str, retention: &str) -> (String, String) {
         (glade_id.into(), retention.into())
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:1249:
     }
     fn ops_of(reg: &Registry) -> Vec<Op> {
-        reg.snapshot().records.iter().map(|b| Op::decode(b).unwrap()).collect()
+        reg.snapshot()
+            .records
+            .iter()
+            .map(|b| Op::decode(b).unwrap())
+            .collect()
     }
 
     /// R9(a): `register` diffs a file's bindings against the FOLD, per
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:1260:
     #[test]
     fn register_diffs_bindings_per_app_against_the_fold() {
         let file = |bindings: &str| parse(&format!("glade-app v0\napp x\n{bindings}")).unwrap();
-        let v1 = file("binding a value share commons latest\nbinding b log share commons from-cursor\n");
-        let v2 = file("binding a value share commons ttl\nbinding c log share commons from-cursor\n");
+        let v1 =
+            file("binding a value share commons latest\nbinding b log share commons from-cursor\n");
+        let v2 =
+            file("binding a value share commons ttl\nbinding c log share commons from-cursor\n");
         let mut reg = Registry::new();
-        assert_eq!(register(&v1, &mut reg, "node-1").unwrap(), Registered { appended: 2, unchanged: 0 });
+        assert_eq!(
+            register(&v1, &mut reg, "node-1").unwrap(),
+            Registered {
+                appended: 2,
+                unchanged: 0
+            }
+        );
         // a changed, b deleted, c added: a's new declaration, c's, and b's retraction.
-        assert_eq!(register(&v2, &mut reg, "node-1").unwrap(), Registered { appended: 3, unchanged: 0 });
+        assert_eq!(
+            register(&v2, &mut reg, "node-1").unwrap(),
+            Registered {
+                appended: 3,
+                unchanged: 0
+            }
+        );
         assert_eq!(live(&reg), vec![pair("a", "ttl"), pair("c", "from_cursor")]);
-        assert_eq!(BindingFold::over(&ops_of(&reg)).retracted(), vec![("x".to_string(), "b".to_string())]);
+        assert_eq!(
+            BindingFold::over(&ops_of(&reg)).retracted(),
+            vec![("x".to_string(), "b".to_string())]
+        );
         // back to v1: a changes back, b is declared again, c is retracted.
-        assert_eq!(register(&v1, &mut reg, "node-1").unwrap(), Registered { appended: 3, unchanged: 0 });
-        assert_eq!(live(&reg), vec![pair("a", "latest"), pair("b", "from_cursor")]);
-        assert_eq!(BindingFold::over(&ops_of(&reg)).retracted(), vec![("x".to_string(), "c".to_string())]);
-        assert_eq!(register(&v1, &mut reg, "node-1").unwrap(), Registered { appended: 0, unchanged: 2 });
-        let retractions = ops_of(&reg).iter().filter(|o| o.glade_id == G_BINDING_RETRACTIONS).count();
+        assert_eq!(
+            register(&v1, &mut reg, "node-1").unwrap(),
+            Registered {
+                appended: 3,
+                unchanged: 0
+            }
+        );
+        assert_eq!(
+            live(&reg),
+            vec![pair("a", "latest"), pair("b", "from_cursor")]
+        );
+        assert_eq!(
+            BindingFold::over(&ops_of(&reg)).retracted(),
+            vec![("x".to_string(), "c".to_string())]
+        );
+        assert_eq!(
+            register(&v1, &mut reg, "node-1").unwrap(),
+            Registered {
+                appended: 0,
+                unchanged: 2
+            }
+        );
+        let retractions = ops_of(&reg)
+            .iter()
+            .filter(|o| o.glade_id == G_BINDING_RETRACTIONS)
+            .count();
         assert_eq!(retractions, 2, "b's and c's, each once");
     }
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:1282:
     #[test]
     fn another_apps_declarations_are_never_in_scope() {
         let a = parse("glade-app v0\napp a\nbinding a.one value share commons latest\nbinding a.two value share commons latest\n").unwrap();
-        let b = parse("glade-app v0\napp b\nbinding b.one log share commons from-cursor\n").unwrap();
-        let a_without_two = parse("glade-app v0\napp a\nbinding a.one value share commons latest\n").unwrap();
+        let b =
+            parse("glade-app v0\napp b\nbinding b.one log share commons from-cursor\n").unwrap();
+        let a_without_two =
+            parse("glade-app v0\napp a\nbinding a.one value share commons latest\n").unwrap();
         let mut reg = Registry::new();
-        assert_eq!(register(&a, &mut reg, "node-1").unwrap(), Registered { appended: 2, unchanged: 0 });
-        assert_eq!(register(&b, &mut reg, "node-1").unwrap(), Registered { appended: 1, unchanged: 0 });
-        assert_eq!(register(&a_without_two, &mut reg, "node-1").unwrap(), Registered { appended: 1, unchanged: 1 });
+        assert_eq!(
+            register(&a, &mut reg, "node-1").unwrap(),
+            Registered {
+                appended: 2,
+                unchanged: 0
+            }
+        );
+        assert_eq!(
+            register(&b, &mut reg, "node-1").unwrap(),
+            Registered {
+                appended: 1,
+                unchanged: 0
+            }
+        );
+        assert_eq!(
+            register(&a_without_two, &mut reg, "node-1").unwrap(),
+            Registered {
+                appended: 1,
+                unchanged: 1
+            }
+        );
         let ids: Vec<String> = live(&reg).into_iter().map(|(id, _)| id).collect();
         assert_eq!(ids, ["a.one", "b.one"]);
-        assert_eq!(BindingFold::over(&ops_of(&reg)).retracted(), vec![("a".to_string(), "a.two".to_string())]);
+        assert_eq!(
+            BindingFold::over(&ops_of(&reg)).retracted(),
+            vec![("a".to_string(), "a.two".to_string())]
+        );
     }
 
     /// What the PRE-amendment `register` appended for `decl` on a fresh store,
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:1349:
         let decl = parse(&grazel_file()).unwrap();
         let mut reg = Registry::new();
         register(&decl, &mut reg, "node-1").unwrap();
-        assert_eq!(reg.snapshot().records, pre_amendment_records(&decl, "node-1"));
+        assert_eq!(
+            reg.snapshot().records,
+            pre_amendment_records(&decl, "node-1")
+        );
     }
 
     /// R9(b2): the file writes `from-cursor` and the stored record holds the
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:1369:
         )
         .unwrap();
         let stored: Vec<&str> = decl.bindings.iter().map(|b| b.retention.as_str()).collect();
-        assert_eq!(stored, ["from_cursor", "from_cursor", "latest", "ttl", "windowed"]);
-        assert_eq!(decl.warnings.len(), 3, "the header, `from_cursor` and `windowed`: {:?}", decl.warnings);
+        assert_eq!(
+            stored,
+            ["from_cursor", "from_cursor", "latest", "ttl", "windowed"]
+        );
+        assert_eq!(
+            decl.warnings.len(),
+            3,
+            "the header, `from_cursor` and `windowed`: {:?}",
+            decl.warnings
+        );
         // The shipped file's five `from-cursor` lines all store the contract's spelling.
         let shipped = parse(&grazel_file()).unwrap();
-        let cursor = shipped.bindings.iter().filter(|b| b.retention == "from_cursor").count();
+        let cursor = shipped
+            .bindings
+            .iter()
+            .filter(|b| b.retention == "from_cursor")
+            .count();
         assert_eq!(cursor, 5);
-        assert!(shipped.bindings.iter().all(|b| b.retention != "from-cursor"));
+        assert!(shipped
+            .bindings
+            .iter()
+            .all(|b| b.retention != "from-cursor"));
     }
 
     // ---- Step 2.6: the zone and retention checks (§4.7 row 7) -------------
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:1382:
 
     /// The `v0` header's warning, for a header on line 1.
-    const V0_HEADER_AT_1: &str = "line 1: header `glade-app v0` names the old language; write `glade-app v1`";
+    const V0_HEADER_AT_1: &str =
+        "line 1: header `glade-app v0` names the old language; write `glade-app v1`";
 
     /// A `v1` file holding `lines` after its `app` line; the first is line 3.
     fn v1_file(lines: &str) -> String {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:1420:
     /// line, with the header to write instead. A `v1` header is not warned.
     #[test]
     fn a_v0_header_is_warned_naming_the_header_to_write() {
-        assert_eq!(parse("glade-app v0\napp x\n").unwrap().warnings, [V0_HEADER_AT_1]);
         assert_eq!(
-            parse("# c\n\n  glade-app   v0  # the header\napp x\n").unwrap().warnings,
+            parse("glade-app v0\napp x\n").unwrap().warnings,
+            [V0_HEADER_AT_1]
+        );
+        assert_eq!(
+            parse("# c\n\n  glade-app   v0  # the header\napp x\n")
+                .unwrap()
+                .warnings,
             ["line 3: header `glade-app v0` names the old language; write `glade-app v1`"]
         );
-        assert_eq!(parse("glade-app v1\napp x\n").unwrap().warnings, Vec::<String>::new());
+        assert_eq!(
+            parse("glade-app v1\napp x\n").unwrap().warnings,
+            Vec::<String>::new()
+        );
     }
 
     /// §4.7 row 7, an unknown zone (R1, row 31b (ii)): told on its line with
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:1437:
             let line = format!("binding g value share {zone} latest");
             assert_eq!(
                 v1_reports(&v1_file(&line)),
-                [format!(r#"line 3: unknown zone `{zone}` (one of ["commons", "private"])"#)]
+                [format!(
+                    r#"line 3: unknown zone `{zone}` (one of ["commons", "private"])"#
+                )]
             );
             assert_eq!(
                 v0_warnings(&line),
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:1444:
                 [
                     V0_HEADER_AT_1.to_string(),
-                    format!(r#"line 3: zone `{zone}` is not in `glade-app v1` (one of ["commons", "private"])"#)
+                    format!(
+                        r#"line 3: zone `{zone}` is not in `glade-app v1` (one of ["commons", "private"])"#
+                    )
                 ]
             );
         }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:1461:
         );
         assert_eq!(
             v0_warnings(line),
-            [V0_HEADER_AT_1, "line 3: retention `windowed` was removed in `glade-app v1` (use `from-cursor`)"]
+            [
+                V0_HEADER_AT_1,
+                "line 3: retention `windowed` was removed in `glade-app v1` (use `from-cursor`)"
+            ]
         );
     }
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:1492:
             let line = format!("binding g value share commons {retention}");
             assert_eq!(
                 v1_reports(&v1_file(&line)),
-                [format!(r#"line 3: unknown retention `{retention}` (one of ["latest", "from-cursor", "ttl"])"#)]
+                [format!(
+                    r#"line 3: unknown retention `{retention}` (one of ["latest", "from-cursor", "ttl"])"#
+                )]
             );
             assert_eq!(
                 v0_warnings(&line),
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:1518:
                      binding d value share private ttl ttl=10m\n\
                      binding e value share commons ttl\n\
                      binding f crdt  share commons from-cursor shape-profile=text_crdt";
-        assert_eq!(parse(&v1_file(lines)).unwrap().warnings, Vec::<String>::new());
-        assert_eq!(parse(&format!("glade-app v0\napp x\n{lines}\n")).unwrap().warnings, [V0_HEADER_AT_1]);
+        assert_eq!(
+            parse(&v1_file(lines)).unwrap().warnings,
+            Vec::<String>::new()
+        );
+        assert_eq!(
+            parse(&format!("glade-app v0\napp x\n{lines}\n"))
+                .unwrap()
+                .warnings,
+            [V0_HEADER_AT_1]
+        );
     }
 
     /// In this release a `v1` file's violations are warnings: the file loads,
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:1546:
             let decl = parse(&text).unwrap();
             let warned = told.map(|t| format!("{t}; a later node release refuses the line"));
             assert_eq!(decl.warnings, warned);
-            let stored: Vec<(&str, &str)> =
-                decl.bindings.iter().map(|b| (b.zone.as_str(), b.retention.as_str())).collect();
-            assert_eq!(stored, [("commons", "latest"), ("shared", "windowed"), ("commons", "from_cursor")]);
+            let stored: Vec<(&str, &str)> = decl
+                .bindings
+                .iter()
+                .map(|b| (b.zone.as_str(), b.retention.as_str()))
+                .collect();
+            assert_eq!(
+                stored,
+                [
+                    ("commons", "latest"),
+                    ("shared", "windowed"),
+                    ("commons", "from_cursor")
+                ]
+            );
         }
     }
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:1576:
                 r#"line 6: retention `hourly` is not in `glade-app v1` (one of ["latest", "from-cursor", "ttl"])"#,
             ]
         );
-        let stored: Vec<(&str, &str)> = decl.bindings.iter().map(|b| (b.zone.as_str(), b.retention.as_str())).collect();
+        let stored: Vec<(&str, &str)> = decl
+            .bindings
+            .iter()
+            .map(|b| (b.zone.as_str(), b.retention.as_str()))
+            .collect();
         assert_eq!(
             stored,
-            [("commons", "latest"), ("shared", "windowed"), ("commons", "from_cursor"), ("private", "hourly")]
+            [
+                ("commons", "latest"),
+                ("shared", "windowed"),
+                ("commons", "from_cursor"),
+                ("private", "hourly")
+            ]
         );
     }
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/appdecl.rs:1603:
             "line 3: `ttl=` needs the retention `ttl` (this line's is `windowed`)"
         );
         assert_eq!(
-            parse(&v1_file("binding g value share commons latest\nbinding g log share shared windowed")).unwrap_err(),
+            parse(&v1_file(
+                "binding g value share commons latest\nbinding g log share shared windowed"
+            ))
+            .unwrap_err(),
             "line 4: duplicate glade id `g`"
         );
     }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/claims.rs:53:
 use crate::registry::{Record, Registry, RegistryApi, G_CLAIMS, G_PRINCIPALS, HOME};
 use crate::server::{refresh_policy, Server, Shared};
 use crate::store::Store;
-use crate::sysdata::{PrincipalRecord, ServeClaim, WorkspaceCreateReq, WorkspaceCreateRes, WorkspaceEntry};
+use crate::sysdata::{
+    PrincipalRecord, ServeClaim, WorkspaceCreateReq, WorkspaceCreateRes, WorkspaceEntry,
+};
 use crate::sysdir::Boot;
 use crate::tasks::Site;
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/claims.rs:295:
 /// The mint itself, callable from the create ceremony (`exchange.rs`) as well
 /// as [`Server::serve_workspace`]. Returns whether anything NEW was minted —
 /// false = already configured locally, or a known remote owner is retained.
-pub(crate) async fn serve_workspace_on(shared: &Arc<Shared>, share: &str, name: &str) -> io::Result<bool> {
+pub(crate) async fn serve_workspace_on(
+    shared: &Arc<Shared>,
+    share: &str,
+    name: &str,
+) -> io::Result<bool> {
     let Some(state) = shared.dir.get() else {
         return Err(other("no directory authority (adopt_boot first)"));
     };
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/claims.rs:353:
 /// around this ceremony (the app-owned-storage seam); the ceremony creates the
 /// glade-side records only. Idempotent by diff: re-creating a workspace this
 /// node already serves appends nothing and answers `created: false`.
-pub(crate) async fn create_workspace(shared: &Arc<Shared>, req: &WorkspaceCreateReq) -> io::Result<WorkspaceCreateRes> {
+pub(crate) async fn create_workspace(
+    shared: &Arc<Shared>,
+    req: &WorkspaceCreateReq,
+) -> io::Result<WorkspaceCreateRes> {
     let Some(state) = shared.dir.get() else {
         return Err(other("no directory authority at the create target"));
     };
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/claims.rs:360:
-    let name = if req.name.is_empty() { req.workspace.clone() } else { req.name.clone() };
+    let name = if req.name.is_empty() {
+        req.workspace.clone()
+    } else {
+        req.name.clone()
+    };
     let created = serve_workspace_on(shared, &req.workspace, &name).await?;
     if !state.inner.lock().await.served.contains_key(&req.workspace) {
         return Err(io::Error::new(
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/claims.rs:382:
 /// and on a store-only node (no directory authority to attribute the append
 /// to — such sessions keep origin-as-identity, byte-for-byte).
 pub(crate) async fn note_principal(shared: &Arc<Shared>, principal: &str) {
-    let Some(state) = shared.dir.get() else { return };
+    let Some(state) = shared.dir.get() else {
+        return;
+    };
     {
         let st = shared.store.lock().await;
         if knows_principal(&st, principal) {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/claims.rs:467:
 /// claims chain into a checkpoint (plan Step 4.5c, `checkpoint::tick`), and
 /// says so through the root's reporter.
 async fn renew_leases(shared: &Arc<Shared>) {
-    let Some(state) = shared.dir.get() else { return };
+    let Some(state) = shared.dir.get() else {
+        return;
+    };
     let (node, leases) = (state.node_id.clone(), state.leases);
     let mut dir = state.inner.lock().await;
     if dir.served.is_empty() {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/claims.rs:1468:
         let (a_shared, b_shared) = (a.shared.clone(), b.shared.clone());
         {
             let bid = b_id.clone();
-            wait_store(&a_shared, move |st| who_serves(st, "ws-live", now_ms()) == Some(bid.clone()), "A to route ws-live to B").await;
+            wait_store(
+                &a_shared,
+                move |st| who_serves(st, "ws-live", now_ms()) == Some(bid.clone()),
+                "A to route ws-live to B",
+            )
+            .await;
         }
         {
             let st = a_shared.store.lock().await;
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/claims.rs:1495:
         };
         {
             let bid = b_id.clone();
-            wait_store(&a_shared, move |st| max_lease(st, "ws-live", &bid) > first, "a renewed lease to reach A").await;
+            wait_store(
+                &a_shared,
+                move |st| max_lease(st, "ws-live", &bid) > first,
+                "a renewed lease to reach A",
+            )
+            .await;
         }
         {
             let bid = b_id.clone();
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/claims.rs:1502:
             let st = b_shared.store.lock().await;
-            assert!(max_lease(&st, "ws-live", &bid) >= first, "the holder renews its own replica");
+            assert!(
+                max_lease(&st, "ws-live", &bid) >= first,
+                "the holder renews its own replica"
+            );
         }
 
         // (c) judged at a reader clock PAST the original horizon, the renewed
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/claims.rs:1511:
         }
 
         // in-process idempotence: re-serving mints nothing new.
-        assert!(!serve_workspace_on(&b.shared, "ws-live", "live").await.unwrap());
+        assert!(!serve_workspace_on(&b.shared, "ws-live", "live")
+            .await
+            .unwrap());
     }
 
     /// Principals minimal (P0.S7), end to end on a booted node: a session
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/claims.rs:1546:
             })
             .to_bytes()
         };
-        let sub = Frame::Subscribe(Subscribe { share: HOME.into(), glade_id: G_PRINCIPALS.into(), key: None, from: None }).to_bytes();
+        let sub = Frame::Subscribe(Subscribe {
+            share: HOME.into(),
+            glade_id: G_PRINCIPALS.into(),
+            key: None,
+            from: None,
+        })
+        .to_bytes();
         async fn next(r: &mut ws::WsReader, what: &str) -> Frame {
             let msg = tokio::time::timeout(Duration::from_secs(5), r.read())
                 .await
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/claims.rs:1574:
         let (mut r1, w1) = ws::connect("127.0.0.1", port).await.unwrap();
         w1.send_binary(&hello(Some("alice"))).await.unwrap();
         assert!(matches!(next(&mut r1, "welcome").await, Frame::Welcome(_)));
-        assert_eq!(shared.principals.lock().await.values().filter(|p| p.as_str() == "alice").count(), 1, "the session is BOUND");
+        assert_eq!(
+            shared
+                .principals
+                .lock()
+                .await
+                .values()
+                .filter(|p| p.as_str() == "alice")
+                .count(),
+            1,
+            "the session is BOUND"
+        );
 
         // (b) served via the ORDINARY subscribe path, origin-attributed.
         let (mut r2, w2) = ws::connect("127.0.0.1", port).await.unwrap();
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/claims.rs:1581:
         w2.send_binary(&sub).await.unwrap();
-        assert!(matches!(next(&mut r2, "dir.principals ack").await, Frame::Heads(_)));
+        assert!(matches!(
+            next(&mut r2, "dir.principals ack").await,
+            Frame::Heads(_)
+        ));
         match next(&mut r2, "the alice record").await {
             Frame::Ops(ops) => {
                 assert_eq!(ops.ops.len(), 1);
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/claims.rs:1586:
-                assert_eq!(ops.ops[0].origin, node_id, "attributed to the witnessing node's chain");
+                assert_eq!(
+                    ops.ops[0].origin, node_id,
+                    "attributed to the witnessing node's chain"
+                );
                 let record = envelope::record(&ops.ops[0], PrincipalRecord::from_cbor).unwrap();
                 assert_eq!(record.principal, "alice");
             }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/claims.rs:1593:
         // (c) a second Hello for the SAME principal appends nothing new...
         let (mut r3, w3) = ws::connect("127.0.0.1", port).await.unwrap();
         w3.send_binary(&hello(Some("alice"))).await.unwrap();
-        assert!(matches!(next(&mut r3, "second welcome").await, Frame::Welcome(_)));
+        assert!(matches!(
+            next(&mut r3, "second welcome").await,
+            Frame::Welcome(_)
+        ));
         // ...but a NEW principal lands (and reaches the live subscriber).
         let (mut r4, w4) = ws::connect("127.0.0.1", port).await.unwrap();
         w4.send_binary(&hello(Some("bob"))).await.unwrap();
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/claims.rs:1600:
-        assert!(matches!(next(&mut r4, "bob welcome").await, Frame::Welcome(_)));
+        assert!(matches!(
+            next(&mut r4, "bob welcome").await,
+            Frame::Welcome(_)
+        ));
         match next(&mut r2, "the bob record, live").await {
             Frame::Ops(ops) => {
                 let record = envelope::record(&ops.ops[0], PrincipalRecord::from_cbor).unwrap();
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/claims.rs:1607:
         }
         {
             let st = shared.store.lock().await;
-            assert_eq!(principal_count(&st, "alice"), 1, "no duplicate for a known principal");
+            assert_eq!(
+                principal_count(&st, "alice"),
+                1,
+                "no duplicate for a known principal"
+            );
             assert_eq!(principal_count(&st, "bob"), 1);
         }
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/claims.rs:1615:
         // nothing minted — the back-compat contract.
         let (mut r5, w5) = ws::connect("127.0.0.1", port).await.unwrap();
         w5.send_binary(&hello(None)).await.unwrap();
-        assert!(matches!(next(&mut r5, "plain welcome").await, Frame::Welcome(_)));
+        assert!(matches!(
+            next(&mut r5, "plain welcome").await,
+            Frame::Welcome(_)
+        ));
         {
             let st = shared.store.lock().await;
-            let total: usize = st.heads(HOME, G_PRINCIPALS, &[]).iter().map(|(o, s)| { let _ = o; (*s + 1) as usize }).sum();
-            assert_eq!(total, 2, "exactly alice + bob — plain sessions mint nothing");
+            let total: usize = st
+                .heads(HOME, G_PRINCIPALS, &[])
+                .iter()
+                .map(|(o, s)| {
+                    let _ = o;
+                    (*s + 1) as usize
+                })
+                .sum();
+            assert_eq!(
+                total, 2,
+                "exactly alice + bob — plain sessions mint nothing"
+            );
         }
     }
 }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/echo.rs:80:
         let mut e = Echo::new();
         let ch = || "ch1".to_string();
         // data before open: ignored
-        assert!(e.handle(&Frame::ChannelData(ChannelData { channel: ch(), data: b"x".to_vec() })).is_empty());
+        assert!(e
+            .handle(&Frame::ChannelData(ChannelData {
+                channel: ch(),
+                data: b"x".to_vec()
+            }))
+            .is_empty());
         // open, then data echoes
         e.handle(&Frame::ChannelOpen(ChannelOpen {
             share: "sh".into(),
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/echo.rs:88:
             channel: ch(),
             key: None,
         }));
-        match e.handle(&Frame::ChannelData(ChannelData { channel: ch(), data: b"abc".to_vec() })).as_slice() {
+        match e
+            .handle(&Frame::ChannelData(ChannelData {
+                channel: ch(),
+                data: b"abc".to_vec(),
+            }))
+            .as_slice()
+        {
             [Frame::ChannelData(d)] => assert_eq!(d.data, b"abc"),
             other => panic!("expected echoed ChannelData, got {other:?}"),
         }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/echo.rs:95:
         // close propagates once...
-        match e.handle(&Frame::ChannelClose(ChannelClose { channel: ch(), reason: None })).as_slice() {
+        match e
+            .handle(&Frame::ChannelClose(ChannelClose {
+                channel: ch(),
+                reason: None,
+            }))
+            .as_slice()
+        {
             [Frame::ChannelClose(c)] => assert_eq!(c.channel, "ch1"),
             other => panic!("expected ChannelClose, got {other:?}"),
         }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/echo.rs:100:
         // ...and data after close is ignored
-        assert!(e.handle(&Frame::ChannelData(ChannelData { channel: ch(), data: b"y".to_vec() })).is_empty());
+        assert!(e
+            .handle(&Frame::ChannelData(ChannelData {
+                channel: ch(),
+                data: b"y".to_vec()
+            }))
+            .is_empty());
     }
 }
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:90:
             family.extend(store.scan(HOME, stream, &[], &origin, i64::MIN));
         }
     }
-    BindingFold::over(&family).live().iter().any(|b| b.glade_id == glade_id && b.shape == "exchange")
+    BindingFold::over(&family)
+        .live()
+        .iter()
+        .any(|b| b.glade_id == glade_id && b.shape == "exchange")
 }
 
 /// An authority provider attaches: a SUBSCRIBE to a declared exchange surface
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:97:
 /// registers the session as THE provider for `(share, glade_id)` and acks with
 /// empty `Heads` (exchanges are never replicated — there is no gap to ship).
 /// The keyed entry map IS the routing table, applied to the directed leg.
-pub(crate) async fn attach_provider(shared: &Arc<Shared>, sid: SessionId, share: &str, glade_id: &str, key: Vec<u8>) {
-    shared.providers.lock().await.insert((share.into(), glade_id.into()), sid);
+pub(crate) async fn attach_provider(
+    shared: &Arc<Shared>,
+    sid: SessionId,
+    share: &str,
+    glade_id: &str,
+    key: Vec<u8>,
+) {
+    shared
+        .providers
+        .lock()
+        .await
+        .insert((share.into(), glade_id.into()), sid);
     let ack = Frame::Heads(Heads {
-        streams: vec![StreamHeads { share: share.into(), glade_id: glade_id.into(), key, heads: vec![] }],
+        streams: vec![StreamHeads {
+            share: share.into(),
+            glade_id: glade_id.into(),
+            key,
+            heads: vec![],
+        }],
     });
     send(shared, sid, &ack).await;
 }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:296:
 /// reason — an unlinked target fails as DATA, never a hang.
 async fn handle_create(shared: &Arc<Shared>, sid: SessionId, req: ExchangeReq) {
     if req.payload.is_empty() {
-        send(shared, sid, &res_err(&req.corr, "workspace.create needs a WorkspaceCreateReq payload")).await;
+        send(
+            shared,
+            sid,
+            &res_err(
+                &req.corr,
+                "workspace.create needs a WorkspaceCreateReq payload",
+            ),
+        )
+        .await;
         return;
     }
     let Some(create) = create_request(shared, sid, &req).await else {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:303:
         return;
     };
     if create.workspace.is_empty() || create.target.is_empty() {
-        send(shared, sid, &res_err(&req.corr, "workspace.create needs {workspace, target}")).await;
+        send(
+            shared,
+            sid,
+            &res_err(&req.corr, "workspace.create needs {workspace, target}"),
+        )
+        .await;
         return;
     }
     let Some(mesh) = shared.mesh.get() else {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:310:
-        send(shared, sid, &res_err(&req.corr, "workspace.create requires a booted node (no mesh)")).await;
+        send(
+            shared,
+            sid,
+            &res_err(
+                &req.corr,
+                "workspace.create requires a booted node (no mesh)",
+            ),
+        )
+        .await;
         return;
     };
     if create.target == mesh.self_id {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:329:
             forward_exchange(&forward, peer, req, sid).await;
         });
     } else {
-        let reason = format!("create target {} is not self or a linked peer", create.target);
+        let reason = format!(
+            "create target {} is not self or a linked peer",
+            create.target
+        );
         send(shared, sid, &res_err(&req.corr, &reason)).await;
     }
 }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:369:
 /// The requesting node's Forward arm: one conversation on the claim holder's
 /// link carries exactly one exchange; the response (or the bounded failure)
 /// is delivered to the requester as an `ExchangeRes`.
-async fn forward_exchange(shared: &Arc<Shared>, peer: String, req: ExchangeReq, requester: SessionId) {
+async fn forward_exchange(
+    shared: &Arc<Shared>,
+    peer: String,
+    req: ExchangeReq,
+    requester: SessionId,
+) {
     let corr = req.corr.clone();
     let frame = match try_forward(shared, &peer, req).await {
         Ok(res) => Frame::ExchangeRes(res),
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:378:
     send(shared, requester, &frame).await;
 }
 
-async fn try_forward(shared: &Arc<Shared>, peer: &str, req: ExchangeReq) -> io::Result<ExchangeRes> {
-    let mesh = shared.mesh.get().cloned().ok_or_else(|| other("mesh not enabled"))?;
+async fn try_forward(
+    shared: &Arc<Shared>,
+    peer: &str,
+    req: ExchangeReq,
+) -> io::Result<ExchangeRes> {
+    let mesh = shared
+        .mesh
+        .get()
+        .cloned()
+        .ok_or_else(|| other("mesh not enabled"))?;
     let linked = mesh.linked(peer).await;
     let linked = linked.ok_or_else(|| other("no live peer link"))?;
     let glade_id = req.glade_id.clone();
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:493:
     }
 
     fn sub(share: &str, glade_id: &str) -> Vec<u8> {
-        Frame::Subscribe(Subscribe { share: share.into(), glade_id: glade_id.into(), key: None, from: None })
-            .to_bytes()
+        Frame::Subscribe(Subscribe {
+            share: share.into(),
+            glade_id: glade_id.into(),
+            key: None,
+            from: None,
+        })
+        .to_bytes()
     }
 
     fn xreq(share: &str, glade_id: &str, corr: &str, payload: &[u8]) -> Vec<u8> {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:528:
     #[tokio::test]
     async fn local_provider_round_trip_absence_and_echo_fallback() {
         // a non-grazel app: the routing is app-agnostic.
-        let decl = appdecl::parse(
-            "glade-app v0\napp demo\nservice demo d.ops\n",
-        )
-        .unwrap();
+        let decl = appdecl::parse("glade-app v0\napp demo\nservice demo d.ops\n").unwrap();
         let (mut reg, n1) = sealed();
         appdecl::register(&decl, &mut reg, &n1).unwrap();
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:544:
         let (mut rc, wc) = ws::connect("127.0.0.1", port).await.unwrap(); // requester
 
         // (1) declared surface, nobody attached -> failure as data, bounded.
-        wc.send_binary(&xreq("s", "d.ops", "c0", b"status")).await.unwrap();
+        wc.send_binary(&xreq("s", "d.ops", "c0", b"status"))
+            .await
+            .unwrap();
         match next_frame(&mut rc, "no-provider answer").await {
             Frame::ExchangeRes(res) => {
                 assert_eq!(res.corr, "c0");
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:551:
                 assert!(!res.ok);
-                assert!(res.error.unwrap().contains("no authority provider"), "reason rides the response");
+                assert!(
+                    res.error.unwrap().contains("no authority provider"),
+                    "reason rides the response"
+                );
             }
             other => panic!("expected ExchangeRes, got {other:?}"),
         }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:557:
         // (2) the authority provider attaches: SUBSCRIBE to the declared surface.
         let (mut rp, wp) = ws::connect("127.0.0.1", port).await.unwrap();
         wp.send_binary(&sub("s", "d.ops")).await.unwrap();
-        assert!(matches!(next_frame(&mut rp, "provider attach ack").await, Frame::Heads(_)));
+        assert!(matches!(
+            next_frame(&mut rp, "provider attach ack").await,
+            Frame::Heads(_)
+        ));
 
         // (3) request -> provider (on the node's corr, F16) -> response -> requester (on its own).
-        wc.send_binary(&xreq("s", "d.ops", "c1", b"workspace.status")).await.unwrap();
+        wc.send_binary(&xreq("s", "d.ops", "c1", b"workspace.status"))
+            .await
+            .unwrap();
         let corr = match next_frame(&mut rp, "provider receives the request").await {
             Frame::ExchangeReq(req) => {
                 assert_eq!(req.payload, b"workspace.status");
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:589:
         }
 
         // (4) an UNDECLARED glade id still gets the legacy echo answer.
-        wc.send_binary(&xreq("s", "echo", "c2", b"ping")).await.unwrap();
+        wc.send_binary(&xreq("s", "echo", "c2", b"ping"))
+            .await
+            .unwrap();
         match next_frame(&mut rc, "echo fallback").await {
             Frame::ExchangeRes(res) => {
                 assert!(res.ok);
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:650:
         reg.append(binding("demo", "d.x", "exchange"), &n1).unwrap();
         assert!(declared_exchange(&store_of(&reg, "fold-1"), "d.x"));
         reg.append(binding("demo", "d.x", "value"), &n1).unwrap();
-        assert!(!declared_exchange(&store_of(&reg, "fold-2"), "d.x"), "the newest declaration is not an exchange");
+        assert!(
+            !declared_exchange(&store_of(&reg, "fold-2"), "d.x"),
+            "the newest declaration is not an exchange"
+        );
         reg.append(binding("demo", "d.x", "exchange"), &n1).unwrap();
         assert!(declared_exchange(&store_of(&reg, "fold-3"), "d.x"));
-        let retract = BindingRetraction { app: "demo".into(), glade_id: "d.x".into() };
+        let retract = BindingRetraction {
+            app: "demo".into(),
+            glade_id: "d.x".into(),
+        };
         reg.append(Record::Retract(retract), &n1).unwrap();
-        assert!(!declared_exchange(&store_of(&reg, "fold-4"), "d.x"), "a newest retraction takes it down");
+        assert!(
+            !declared_exchange(&store_of(&reg, "fold-4"), "d.x"),
+            "a newest retraction takes it down"
+        );
     }
 
     /// STA-P3-1: the served store holds several nodes' records, and a
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:707:
 
     fn create_payload(workspace: &str, name: &str, target: &str) -> Vec<u8> {
         glade_wire::cbor::encode(
-            &crate::sysdata::WorkspaceCreateReq { workspace: workspace.into(), name: name.into(), target: target.into() }.to_cbor(),
+            &crate::sysdata::WorkspaceCreateReq {
+                workspace: workspace.into(),
+                name: name.into(),
+                target: target.into(),
+            }
+            .to_cbor(),
         )
     }
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:776:
         let (a_shared, b_shared) = (a.shared.clone(), b.shared.clone());
         let lis_a = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
         let lis_b = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
-        let (port_a, port_b) = (lis_a.local_addr().unwrap().port(), lis_b.local_addr().unwrap().port());
+        let (port_a, port_b) = (
+            lis_a.local_addr().unwrap().port(),
+            lis_b.local_addr().unwrap().port(),
+        );
         tokio::spawn(a.run(lis_a));
         tokio::spawn(b.run(lis_b));
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:783:
         let (mut rc, wc) = ws::connect("127.0.0.1", port_a).await.unwrap();
 
         // ---- (a) create at B, asked from A ----------------------------------
-        wc.send_binary(&xreq(HOME, WORKSPACE_CREATE, "cr-1", &create_payload("ws-new", "new", &b_id))).await.unwrap();
+        wc.send_binary(&xreq(
+            HOME,
+            WORKSPACE_CREATE,
+            "cr-1",
+            &create_payload("ws-new", "new", &b_id),
+        ))
+        .await
+        .unwrap();
         match next_frame(&mut rc, "create response").await {
             Frame::ExchangeRes(res) => {
                 assert!(res.ok, "create succeeded, corr intact: {:?}", res.error);
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:790:
                 assert_eq!(res.corr, "cr-1");
-                let out = crate::sysdata::WorkspaceCreateRes::decode(&res.payload.unwrap()).unwrap();
-                assert_eq!((out.workspace.as_str(), out.node.as_str(), out.created), ("ws-new", b_id.as_str(), true), "the TARGET performed the creation under its own origin");
+                let out =
+                    crate::sysdata::WorkspaceCreateRes::decode(&res.payload.unwrap()).unwrap();
+                assert_eq!(
+                    (out.workspace.as_str(), out.node.as_str(), out.created),
+                    ("ws-new", b_id.as_str(), true),
+                    "the TARGET performed the creation under its own origin"
+                );
             }
             other => panic!("expected ExchangeRes, got {other:?}"),
         }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:797:
         // ---- (b) the minted records reached A (B9 push): routing follows ----
         {
             let bid = b_id.clone();
-            wait_store(&a_shared, move |st| crate::mesh::who_serves(st, "ws-new", now_ms()) == Some(bid.clone()), "A's fold to route ws-new to B").await;
+            wait_store(
+                &a_shared,
+                move |st| crate::mesh::who_serves(st, "ws-new", now_ms()) == Some(bid.clone()),
+                "A's fold to route ws-new to B",
+            )
+            .await;
         }
         wc.send_binary(&sub("ws-new", "ws.tree")).await.unwrap();
-        assert!(matches!(next_frame(&mut rc, "ws-new subscribe ack (routed, not absent)").await, Frame::Heads(_)));
+        assert!(matches!(
+            next_frame(&mut rc, "ws-new subscribe ack (routed, not absent)").await,
+            Frame::Heads(_)
+        ));
         // B's authority session writes; the op reaches the A-side client live.
         let (_rp, wp) = ws::connect("127.0.0.1", port_b).await.unwrap();
         let op = Op {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:815:
             shape: Shape::Value,
             payload: b"new-tree-v0".to_vec(),
         };
-        wp.send_binary(&Frame::Ops(Ops { ops: vec![op], pri: None }).to_bytes()).await.unwrap();
+        wp.send_binary(
+            &Frame::Ops(Ops {
+                ops: vec![op],
+                pri: None,
+            })
+            .to_bytes(),
+        )
+        .await
+        .unwrap();
         loop {
             if let Frame::Ops(ops) = next_frame(&mut rc, "content through the new claim").await {
                 if ops.ops.iter().any(|o| o.payload == b"new-tree-v0") {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:827:
         // ---- (c) re-create is idempotent: the records diff -------------------
         let (entry_heads, epoch_before) = {
             let st = b_shared.store.lock().await;
-            (st.heads(HOME, crate::registry::G_WORKSPACES, &[]), max_claim_epoch_for(&st, "ws-new"))
+            (
+                st.heads(HOME, crate::registry::G_WORKSPACES, &[]),
+                max_claim_epoch_for(&st, "ws-new"),
+            )
         };
-        wc.send_binary(&xreq(HOME, WORKSPACE_CREATE, "cr-2", &create_payload("ws-new", "new", &b_id))).await.unwrap();
+        wc.send_binary(&xreq(
+            HOME,
+            WORKSPACE_CREATE,
+            "cr-2",
+            &create_payload("ws-new", "new", &b_id),
+        ))
+        .await
+        .unwrap();
         match next_frame(&mut rc, "re-create response").await {
             Frame::ExchangeRes(res) => {
                 assert!(res.ok);
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:836:
-                let out = crate::sysdata::WorkspaceCreateRes::decode(&res.payload.unwrap()).unwrap();
+                let out =
+                    crate::sysdata::WorkspaceCreateRes::decode(&res.payload.unwrap()).unwrap();
                 assert!(!out.created, "already served: nothing new minted");
             }
             other => panic!("expected ExchangeRes, got {other:?}"),
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:840:
         }
         {
             let st = b_shared.store.lock().await;
-            assert_eq!(st.heads(HOME, crate::registry::G_WORKSPACES, &[]), entry_heads, "no duplicate WorkspaceEntry");
-            assert_eq!(max_claim_epoch_for(&st, "ws-new"), epoch_before, "no re-claim: the epoch is stable");
+            assert_eq!(
+                st.heads(HOME, crate::registry::G_WORKSPACES, &[]),
+                entry_heads,
+                "no duplicate WorkspaceEntry"
+            );
+            assert_eq!(
+                max_claim_epoch_for(&st, "ws-new"),
+                epoch_before,
+                "no re-claim: the epoch is stable"
+            );
         }
 
         // ---- (d) an unlinked target fails as data ----------------------------
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:848:
-        wc.send_binary(&xreq(HOME, WORKSPACE_CREATE, "cr-3", &create_payload("ws-nope", "nope", "deadbeef"))).await.unwrap();
+        wc.send_binary(&xreq(
+            HOME,
+            WORKSPACE_CREATE,
+            "cr-3",
+            &create_payload("ws-nope", "nope", "deadbeef"),
+        ))
+        .await
+        .unwrap();
         match next_frame(&mut rc, "unlinked-target failure data").await {
             Frame::ExchangeRes(res) => {
                 assert_eq!(res.corr, "cr-3");
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:852:
                 assert!(!res.ok);
-                assert!(res.error.unwrap().contains("not self or a linked peer"), "the reason rides the response");
+                assert!(
+                    res.error.unwrap().contains("not self or a linked peer"),
+                    "the reason rides the response"
+                );
             }
             other => panic!("expected ExchangeRes failure data, got {other:?}"),
         }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:857:
         // failure is data, not a dead session: the next ask still answers.
-        wc.send_binary(&sub(HOME, crate::registry::G_WORKSPACES)).await.unwrap();
-        assert!(matches!(next_frame(&mut rc, "post-failure ack").await, Frame::Heads(_)));
+        wc.send_binary(&sub(HOME, crate::registry::G_WORKSPACES))
+            .await
+            .unwrap();
+        assert!(matches!(
+            next_frame(&mut rc, "post-failure ack").await,
+            Frame::Heads(_)
+        ));
 
         // ---- (e) target == self performs locally -----------------------------
-        wc.send_binary(&xreq(HOME, WORKSPACE_CREATE, "cr-4", &create_payload("ws-mine", "mine", &a_id))).await.unwrap();
+        wc.send_binary(&xreq(
+            HOME,
+            WORKSPACE_CREATE,
+            "cr-4",
+            &create_payload("ws-mine", "mine", &a_id),
+        ))
+        .await
+        .unwrap();
         {
             let res = next_exchange_res(&mut rc, "self-target create response").await;
             assert!(res.ok, "{:?}", res.error);
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:869:
         }
         {
             let st = a_shared.store.lock().await;
-            assert_eq!(crate::mesh::who_serves(&st, "ws-mine", now_ms()), Some(a_id.clone()));
+            assert_eq!(
+                crate::mesh::who_serves(&st, "ws-mine", now_ms()),
+                Some(a_id.clone())
+            );
         }
     }
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:907:
         boot_b
             .registry
             .append(
-                Record::Serve(ServeClaim { node: b_id.clone(), share: "ws-razel".into(), lease_expiry_ms: now_ms() + 30_000, epoch: 1 }),
+                Record::Serve(ServeClaim {
+                    node: b_id.clone(),
+                    share: "ws-razel".into(),
+                    lease_expiry_ms: now_ms() + 30_000,
+                    epoch: 1,
+                }),
                 &b_id,
             )
             .unwrap();
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:915:
         boot_b
             .registry
             .append(
-                Record::Serve(ServeClaim { node: "attic-mini".into(), share: "ws-attic".into(), lease_expiry_ms: now_ms() - 1_000, epoch: 1 }),
+                Record::Serve(ServeClaim {
+                    node: "attic-mini".into(),
+                    share: "ws-attic".into(),
+                    lease_expiry_ms: now_ms() - 1_000,
+                    epoch: 1,
+                }),
                 &b_id,
             )
             .unwrap();
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:933:
         let a_shared = a.shared.clone();
         let lis_a = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
         let lis_b = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
-        let (port_a, port_b) = (lis_a.local_addr().unwrap().port(), lis_b.local_addr().unwrap().port());
+        let (port_a, port_b) = (
+            lis_a.local_addr().unwrap().port(),
+            lis_b.local_addr().unwrap().port(),
+        );
         tokio::spawn(a.run(lis_a));
         tokio::spawn(b.run(lis_b));
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:941:
         // attaches as gwz.ops provider AND appends the ws.tree binding content.
         let (mut rp, wp) = ws::connect("127.0.0.1", port_b).await.unwrap();
         wp.send_binary(&sub("ws-razel", "gwz.ops")).await.unwrap();
-        assert!(matches!(next_frame(&mut rp, "grazel attach ack").await, Frame::Heads(_)));
+        assert!(matches!(
+            next_frame(&mut rp, "grazel attach ack").await,
+            Frame::Heads(_)
+        ));
         let o0 = tree_op(0, None, b"tree-v0");
         let o1 = tree_op(1, Some(crate::chain::op_hash(&o0).to_vec()), b"tree-v1");
-        wp.send_binary(&Frame::Ops(Ops { ops: vec![o0.clone(), o1.clone()], pri: None }).to_bytes()).await.unwrap();
+        wp.send_binary(
+            &Frame::Ops(Ops {
+                ops: vec![o0.clone(), o1.clone()],
+                pri: None,
+            })
+            .to_bytes(),
+        )
+        .await
+        .unwrap();
         // each op is answered on the provider's session, by its hash (R1).
         for o in [&o0, &o1] {
             match next_frame(&mut rp, "the provider's op status").await {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:1004:
         // ---- (a) registered surfaces appear at A as ordinary records --------
         let (mut rc, wc) = ws::connect("127.0.0.1", port_a).await.unwrap();
         wc.send_binary(&sub(HOME, G_BINDINGS)).await.unwrap();
-        assert!(matches!(next_frame(&mut rc, "dir.bindings ack").await, Frame::Heads(_)));
+        assert!(matches!(
+            next_frame(&mut rc, "dir.bindings ack").await,
+            Frame::Heads(_)
+        ));
         let mut bindings = Vec::new();
         while bindings.len() < 7 {
             if let Frame::Ops(ops) = next_frame(&mut rc, "BindingDecl records").await {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:1020:
         // (gwz.output, chat.msgs, chat.groups) — P1.S3.
         assert_eq!(
             bindings,
-            vec!["chat.groups", "chat.msgs", "gwz.output", "term.log", "ws.diff", "ws.files", "ws.tree"]
+            vec![
+                "chat.groups",
+                "chat.msgs",
+                "gwz.output",
+                "term.log",
+                "ws.diff",
+                "ws.files",
+                "ws.tree"
+            ]
         );
         // the ACL seeds compiled to ORDINARY grant records (s-app-register A5).
         wc.send_binary(&sub(HOME, G_GRANTS)).await.unwrap();
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:1027:
-        assert!(matches!(next_frame(&mut rc, "dir.grants ack").await, Frame::Heads(_)));
+        assert!(matches!(
+            next_frame(&mut rc, "dir.grants ack").await,
+            Frame::Heads(_)
+        ));
         let mut grants = Vec::new();
         while grants.len() < 3 {
             if let Frame::Ops(ops) = next_frame(&mut rc, "seeded grant records").await {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:1058:
 
         // ---- (b) the declared binding is served end to end ------------------
         wc.send_binary(&sub("ws-razel", "ws.tree")).await.unwrap();
-        assert!(matches!(next_frame(&mut rc, "ws.tree ack").await, Frame::Heads(_)));
+        assert!(matches!(
+            next_frame(&mut rc, "ws.tree ack").await,
+            Frame::Heads(_)
+        ));
         let mut payloads = Vec::new();
         while payloads.len() < 2 {
             if let Frame::Ops(ops) = next_frame(&mut rc, "routed tree ops").await {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:1065:
                 payloads.extend(ops.ops.into_iter().map(|o| o.payload));
             }
         }
-        assert_eq!(payloads, vec![b"tree-v0".to_vec(), b"tree-v1".to_vec()], "authority content converges in order");
+        assert_eq!(
+            payloads,
+            vec![b"tree-v0".to_vec(), b"tree-v1".to_vec()],
+            "authority content converges in order"
+        );
 
         // ---- (c) the gwz exchange round-trips through the authority ---------
-        wc.send_binary(&xreq("ws-razel", "gwz.ops", "x-42", b"workspace.status")).await.unwrap();
+        wc.send_binary(&xreq("ws-razel", "gwz.ops", "x-42", b"workspace.status"))
+            .await
+            .unwrap();
         let corr = match next_frame(&mut rp, "grazel receives the forwarded exchange").await {
             Frame::ExchangeReq(req) => {
                 assert_ne!(req.corr, "x-42", "the handler sees B's correlation");
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:1092:
             Frame::ExchangeRes(res) => {
                 assert!(res.ok);
                 assert_eq!(res.corr, "x-42");
-                assert_eq!(res.payload.as_deref(), Some(b"12 clean, 1 dirty".as_slice()));
+                assert_eq!(
+                    res.payload.as_deref(),
+                    Some(b"12 clean, 1 dirty".as_slice())
+                );
             }
             other => panic!("requester expected ExchangeRes, got {other:?}"),
         }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:1099:
 
         // ---- (d) missing/unclaimed target: bounded failure as data ----------
-        wc.send_binary(&xreq("ws-attic", "gwz.ops", "x-43", b"workspace.status")).await.unwrap();
+        wc.send_binary(&xreq("ws-attic", "gwz.ops", "x-43", b"workspace.status"))
+            .await
+            .unwrap();
         match next_frame(&mut rc, "ws-attic exchange status").await {
             Frame::ExchangeRes(res) => {
                 assert_eq!(res.corr, "x-43");
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:1105:
                 assert!(!res.ok);
-                assert!(res.error.unwrap().contains("no live ServeClaim"), "the reason rides the response");
+                assert!(
+                    res.error.unwrap().contains("no live ServeClaim"),
+                    "the reason rides the response"
+                );
             }
             other => panic!("expected ExchangeRes failure data, got {other:?}"),
         }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/exchange.rs:1110:
         // failure is data, not a dead session: the next ask still answers.
-        wc.send_binary(&sub(HOME, crate::registry::G_CLAIMS)).await.unwrap();
-        assert!(matches!(next_frame(&mut rc, "post-failure ack").await, Frame::Heads(_)));
+        wc.send_binary(&sub(HOME, crate::registry::G_CLAIMS))
+            .await
+            .unwrap();
+        assert!(matches!(
+            next_frame(&mut rc, "post-failure ack").await,
+            Frame::Heads(_)
+        ));
     }
 
     /// `grazel_attach_end_to_end`, turned round (plan Step 4.3): B's fold
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/frame.rs:119:
             seq: 1,
             prev: None,
             lamport: 1,
-            refs: vec![Head { origin: "b".into(), seq: 2, hash: None }],
+            refs: vec![Head {
+                origin: "b".into(),
+                seq: 2,
+                hash: None,
+            }],
             shape: Shape::Value,
             payload: b"hi".to_vec(),
         };
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/frame.rs:133:
                     share: "sh".into(),
                     glade_id: "".into(),
                     key: vec![],
-                    heads: vec![Head { origin: "a".into(), seq: 1, hash: None }],
+                    heads: vec![Head {
+                        origin: "a".into(),
+                        seq: 1,
+                        hash: None,
+                    }],
                 }],
             }),
-            Frame::Ops(Ops { ops: vec![op], pri: None }),
-            Frame::Welcome(Welcome { session: "s1".into(), protocol: 1, heads: vec![] }),
+            Frame::Ops(Ops {
+                ops: vec![op],
+                pri: None,
+            }),
+            Frame::Welcome(Welcome {
+                session: "s1".into(),
+                protocol: 1,
+                heads: vec![],
+            }),
         ];
         for f in frames {
             let round = Frame::from_bytes(&f.to_bytes()).unwrap();
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/home.rs:29:
 /// conversation per link, its one `Ops` frame then END, only queued (plan
 /// Step 4.5b); one over the frame limit is not sent, with a line.
 pub(crate) async fn push_home(shared: &Arc<Shared>, ops: Vec<Op>) {
-    let Some(mesh) = shared.mesh.get() else { return };
+    let Some(mesh) = shared.mesh.get() else {
+        return;
+    };
     let Some(first) = ops.first() else { return };
     let zone = (first.share.clone(), first.glade_id.clone());
     let links: Vec<Arc<Linked>> = {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/home.rs:65:
 ) -> io::Result<SyncOutcome> {
     let ours: Vec<StreamHeads> = {
         let st = shared.store.lock().await;
-        st.all_heads().into_iter().filter(|sh| sh.share == HOME).collect()
+        st.all_heads()
+            .into_iter()
+            .filter(|sh| sh.share == HOME)
+            .collect()
     };
     conversation.send(&Frame::Heads(Heads { streams: ours }))?;
     let mut round = Round::new(shared, mesh, peer);
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/home.rs:339:
         if let Some((mesh, pair)) = revoked {
             close_revoked(mesh, pair).await;
         }
-        let targets = shared.router.lock().await.route(from, &share, &glade_id, &key);
+        let targets = shared
+            .router
+            .lock()
+            .await
+            .route(from, &share, &glade_id, &key);
         if !targets.is_empty() {
-            let frame = Frame::Ops(Ops { ops: vec![op], pri: None });
+            let frame = Frame::Ops(Ops {
+                ops: vec![op],
+                pri: None,
+            });
             for t in targets {
                 send(shared, t, &frame).await;
             }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/link.rs:96:
     /// (a pull each way rides the link). Returns the peer's directory node id
     /// (hex).
     pub async fn connect_peer(&self, target: impl Into<PeerEntry>) -> io::Result<String> {
-        let mesh = self.shared.mesh.get().cloned().ok_or_else(|| other("mesh not enabled"))?;
+        let mesh = self
+            .shared
+            .mesh
+            .get()
+            .cloned()
+            .ok_or_else(|| other("mesh not enabled"))?;
         let entry = target.into();
         let at = carrier_addr(&entry).ok_or_else(|| other("the peer names no address to dial"))?;
         let link: Arc<dyn CarrierLink> = Arc::from(mesh.port.dial(&at).await.map_err(carried)?);
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/route.rs:45:
 /// share → absent (lease lapsed at the reader's clock — trace E2); a share the
 /// directory has never heard of → local (plain app-share serving).
 pub(crate) async fn route_subscribe(shared: &Arc<Shared>, share: &str) -> Route {
-    let Some(mesh) = shared.mesh.get() else { return Route::Local };
+    let Some(mesh) = shared.mesh.get() else {
+        return Route::Local;
+    };
     if share == HOME {
         return Route::Local;
     }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/route.rs:52:
     let (holder, known) = {
         let st = shared.store.lock().await;
-        (who_serves(&st, share, now_ms()), directory_knows(&st, share))
+        (
+            who_serves(&st, share, now_ms()),
+            directory_knows(&st, share),
+        )
     };
     match holder {
         Some(id) if id == mesh.self_id => Route::Local,
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/route.rs:244:
     let mut conversation = linked.open();
     let from: Vec<Head> = {
         let st = shared.store.lock().await;
-        st.heads(share, glade_id, key).into_iter().map(|(origin, seq)| Head { origin, seq, hash: None }).collect()
+        st.heads(share, glade_id, key)
+            .into_iter()
+            .map(|(origin, seq)| Head {
+                origin,
+                seq,
+                hash: None,
+            })
+            .collect()
     };
     let sub = Subscribe {
         share: share.into(),
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/route.rs:251:
         glade_id: glade_id.into(),
-        key: if key.is_empty() { None } else { Some(key.to_vec()) },
+        key: if key.is_empty() {
+            None
+        } else {
+            Some(key.to_vec())
+        },
         from: Some(from),
     };
     conversation.send(&Frame::Subscribe(sub))?;
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/serve.rs:121:
     let sid = shared.next.fetch_add(1, Ordering::SeqCst);
     let (tx, mut rx) = tokio::sync::mpsc::unbounded_channel::<Vec<u8>>();
     shared.out.lock().await.insert(sid, tx.clone());
-    shared.router.lock().await.subscribe(sid, &s.share, &s.glade_id, &key);
+    shared
+        .router
+        .lock()
+        .await
+        .subscribe(sid, &s.share, &s.glade_id, &key);
     shared.admitted.lock().await.insert(sid, node);
 
     // Ack + gap ride the SAME outbound channel as live fan-out, so a live op
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/serve.rs:128:
     // can never overtake the resume gap on the conversation. The gap goes in
     // chunks under the link's frame limit (plan Step 4.5b).
-    let their: crate::session::Heads =
-        s.from.clone().unwrap_or_default().into_iter().map(|h| (h.origin, h.seq)).collect();
+    let their: crate::session::Heads = s
+        .from
+        .clone()
+        .unwrap_or_default()
+        .into_iter()
+        .map(|h| (h.origin, h.seq))
+        .collect();
     let (acked, gap) = {
         let st = shared.store.lock().await;
         let gap = missing_for(&st, &s.share, &s.glade_id, &key, &their);
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/serve.rs:202:
 ) -> io::Result<()> {
     let mut by_zone: BTreeMap<(String, String, Vec<u8>), BTreeMap<String, i64>> = BTreeMap::new();
     for sh in their.streams {
-        let m = by_zone.entry((sh.share.clone(), sh.glade_id.clone(), sh.key.clone())).or_default();
+        let m = by_zone
+            .entry((sh.share.clone(), sh.glade_id.clone(), sh.key.clone()))
+            .or_default();
         for hd in sh.heads {
             m.insert(hd.origin, hd.seq);
         }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/serve.rs:215:
             if share != HOME {
                 continue;
             }
-            let their_v = by_zone.get(&(share.clone(), glade_id.clone(), key.clone())).cloned().unwrap_or_default();
+            let their_v = by_zone
+                .get(&(share.clone(), glade_id.clone(), key.clone()))
+                .cloned()
+                .unwrap_or_default();
             gap.extend(missing_for(&st, &share, &glade_id, &key, &their_v));
         }
         gap
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/tests/forward.rs:39:
 
     // ---- (a) phase A: list the directory from A's LOCAL replica ---------
     let (mut rc, wc) = crate::ws::connect("127.0.0.1", port_a).await.unwrap();
-    wc.send_binary(&sub(HOME, crate::registry::G_WORKSPACES)).await.unwrap();
-    assert!(matches!(next_frame(&mut rc, "dir.workspaces ack").await, Frame::Heads(_)));
+    wc.send_binary(&sub(HOME, crate::registry::G_WORKSPACES))
+        .await
+        .unwrap();
+    assert!(matches!(
+        next_frame(&mut rc, "dir.workspaces ack").await,
+        Frame::Heads(_)
+    ));
     let mut names = Vec::new();
     while names.len() < 2 {
         if let Frame::Ops(ops) = next_frame(&mut rc, "workspace entries").await {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/tests/forward.rs:52:
         }
     }
     names.sort();
-    assert_eq!(names, vec!["ws-attic".to_string(), "ws-razel".to_string()], "the list from the local replica");
+    assert_eq!(
+        names,
+        vec!["ws-attic".to_string(), "ws-razel".to_string()],
+        "the list from the local replica"
+    );
 
     // ---- (b) phase C: the claim routes the workspace share to B ---------
     wc.send_binary(&sub("ws-razel", "ws.tree")).await.unwrap();
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/tests/forward.rs:59:
-    assert!(matches!(next_frame(&mut rc, "ws.tree ack").await, Frame::Heads(_)));
+    assert!(matches!(
+        next_frame(&mut rc, "ws.tree ack").await,
+        Frame::Heads(_)
+    ));
     let mut payloads = Vec::new();
     while payloads.len() < 2 {
         if let Frame::Ops(ops) = next_frame(&mut rc, "routed tree ops").await {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/tests/forward.rs:63:
             payloads.extend(ops.ops.into_iter().map(|o| o.payload));
         }
     }
-    assert_eq!(payloads, vec![b"tree-v0".to_vec(), b"tree-v1".to_vec()], "the routed gap converges in order");
+    assert_eq!(
+        payloads,
+        vec![b"tree-v0".to_vec(), b"tree-v1".to_vec()],
+        "the routed gap converges in order"
+    );
     // ...and INTO A's replica — the replica served the read (C5).
-    wait_store(&a_shared, |st| st.scan("ws-razel", "ws.tree", &[], "prov-b", i64::MIN).len() == 2, "A's replica to hold the routed zone").await;
+    wait_store(
+        &a_shared,
+        |st| {
+            st.scan("ws-razel", "ws.tree", &[], "prov-b", i64::MIN)
+                .len()
+                == 2
+        },
+        "A's replica to hold the routed zone",
+    )
+    .await;
 
     // live: the provider writes v2 on B; it reaches the A-side client with
     // no re-request (the C5→C6 stream keeps flowing).
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/tests/forward.rs:72:
     let o2 = tree_op(2, Some(crate::chain::op_hash(&o1).to_vec()), b"tree-v2");
-    wp.send_binary(&Frame::Ops(Ops { ops: vec![o2], pri: None }).to_bytes()).await.unwrap();
+    wp.send_binary(
+        &Frame::Ops(Ops {
+            ops: vec![o2],
+            pri: None,
+        })
+        .to_bytes(),
+    )
+    .await
+    .unwrap();
     loop {
         if let Frame::Ops(ops) = next_frame(&mut rc, "live tree op").await {
             if ops.ops.iter().any(|o| o.payload == b"tree-v2") {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/tests/forward.rs:97:
             assert_eq!(e.share.as_deref(), Some("ws-attic"));
             assert_eq!(e.glade_id.as_deref(), Some("ws.tree"));
             assert_eq!(e.corr, None, "a refused subscribe names no op");
-            assert!(e.message.contains("no live ServeClaim"), "the reason rides the status: {}", e.message);
+            assert!(
+                e.message.contains("no live ServeClaim"),
+                "the reason rides the status: {}",
+                e.message
+            );
         }
         other => panic!("expected STATUS (Error frame), got {other:?}"),
     }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/tests/forward.rs:104:
     // absence is data, not a dead session: the next ask still answers,
     // with an ack that names its zone.
-    wc.send_binary(&sub(HOME, crate::registry::G_CLAIMS)).await.unwrap();
+    wc.send_binary(&sub(HOME, crate::registry::G_CLAIMS))
+        .await
+        .unwrap();
     match next_frame(&mut rc, "post-absence ack").await {
         Frame::Heads(h) => {
             assert_eq!(h.streams.len(), 1, "an accepted ack names its zone: {h:?}")
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/tests/home.rs:63:
     let (b_id, a_id) = (boot_b.node_id.clone(), boot_a.node_id.clone());
     {
         let bid = b_id.clone();
-        wait_for(&a, move |st| !st.scan(HOME, crate::registry::G_NODES, &[], &bid, i64::MIN).is_empty(), "A to hold B's presence").await;
+        wait_for(
+            &a,
+            move |st| {
+                !st.scan(HOME, crate::registry::G_NODES, &[], &bid, i64::MIN)
+                    .is_empty()
+            },
+            "A to hold B's presence",
+        )
+        .await;
     }
     {
         let st = a.shared.store.lock().await;
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/tests/home.rs:70:
-        assert!(!st.scan(HOME, crate::registry::G_WORKSPACES, &[], &b_id, i64::MIN).is_empty(), "A holds B's WorkspaceEntry");
+        assert!(
+            !st.scan(HOME, crate::registry::G_WORKSPACES, &[], &b_id, i64::MIN)
+                .is_empty(),
+            "A holds B's WorkspaceEntry"
+        );
         // ...and A's LOCAL fold routes ws-razel to B, judged at A's clock.
         assert_eq!(who_serves(&st, "ws-razel", now_ms()), Some(b_id.clone()));
-        assert_eq!(who_serves(&st, "ws-razel", now_ms() + 60_000), None, "lapsed at a later reader clock");
+        assert_eq!(
+            who_serves(&st, "ws-razel", now_ms() + 60_000),
+            None,
+            "lapsed at a later reader clock"
+        );
     }
 
     // ...and B pulled A (the reverse direction of the same connection).
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/tests/home.rs:77:
     {
         let aid = a_id.clone();
-        wait_for(&b, move |st| !st.scan(HOME, crate::registry::G_NODES, &[], &aid, i64::MIN).is_empty(), "B to hold A's presence").await;
+        wait_for(
+            &b,
+            move |st| {
+                !st.scan(HOME, crate::registry::G_NODES, &[], &aid, i64::MIN)
+                    .is_empty()
+            },
+            "B to hold A's presence",
+        )
+        .await;
     }
 }
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/tests/two_nodes.rs:15:
 use std::time::Duration;
 
 pub(super) fn sub(share: &str, glade_id: &str) -> Vec<u8> {
-    Frame::Subscribe(Subscribe { share: share.into(), glade_id: glade_id.into(), key: None, from: None })
-        .to_bytes()
+    Frame::Subscribe(Subscribe {
+        share: share.into(),
+        glade_id: glade_id.into(),
+        key: None,
+        from: None,
+    })
+    .to_bytes()
 }
 
 pub(super) fn tree_op(seq: i64, prev: Option<Vec<u8>>, payload: &[u8]) -> Op {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/mesh/tests/two_nodes.rs:122:
     let (a_shared, b_shared) = (a.shared.clone(), b.shared.clone());
     let lis_a = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
     let lis_b = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
-    let (port_a, port_b) = (lis_a.local_addr().unwrap().port(), lis_b.local_addr().unwrap().port());
+    let (port_a, port_b) = (
+        lis_a.local_addr().unwrap().port(),
+        lis_b.local_addr().unwrap().port(),
+    );
     tokio::spawn(a.run(lis_a));
     tokio::spawn(b.run(lis_b));
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/peer.rs:373:
 pub type ChainKey = (String, String, Vec<u8>, String);
 
 fn chain_key(op: &Op) -> ChainKey {
-    (op.share.clone(), op.glade_id.clone(), op.key.clone(), op.origin.clone())
+    (
+        op.share.clone(),
+        op.glade_id.clone(),
+        op.key.clone(),
+        op.origin.clone(),
+    )
 }
 
 /// What a pull produced.
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/peer.rs:417:
 {
     let their = match read_frame(r).await? {
         Frame::Heads(h) => h.streams,
-        other => return Err(io::Error::new(io::ErrorKind::InvalidData, format!("expected Heads, got {other:?}"))),
+        other => {
+            return Err(io::Error::new(
+                io::ErrorKind::InvalidData,
+                format!("expected Heads, got {other:?}"),
+            ))
+        }
     };
     // Index the peer's vectors by zone -> origin -> seq.
-    let mut their_by_zone: BTreeMap<(String, String, Vec<u8>), BTreeMap<String, i64>> = BTreeMap::new();
+    let mut their_by_zone: BTreeMap<(String, String, Vec<u8>), BTreeMap<String, i64>> =
+        BTreeMap::new();
     for sh in their {
-        let m = their_by_zone.entry((sh.share.clone(), sh.glade_id.clone(), sh.key.clone())).or_default();
+        let m = their_by_zone
+            .entry((sh.share.clone(), sh.glade_id.clone(), sh.key.clone()))
+            .or_default();
         for hd in sh.heads {
             m.insert(hd.origin, hd.seq);
         }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/peer.rs:432:
         if share != HOME && grants.check(holder, READ_SUBSCRIBE, &share).is_err() {
             continue;
         }
-        let their_v = their_by_zone.get(&(share.clone(), glade_id.clone(), key.clone())).cloned().unwrap_or_default();
+        let their_v = their_by_zone
+            .get(&(share.clone(), glade_id.clone(), key.clone()))
+            .cloned()
+            .unwrap_or_default();
         let gap = missing_for(store, &share, &glade_id, &key, &their_v);
         for chunk in gap.chunks(OPS_PER_CHUNK) {
-            write_frame(w, &Frame::Ops(Ops { ops: chunk.to_vec(), pri: Some(Priority::Bulk) })).await?;
+            write_frame(
+                w,
+                &Frame::Ops(Ops {
+                    ops: chunk.to_vec(),
+                    pri: Some(Priority::Bulk),
+                }),
+            )
+            .await?;
             sent += chunk.len();
         }
     }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/peer.rs:461:
     R: AsyncRead + Unpin,
     W: AsyncWrite + Unpin,
 {
-    write_frame(w, &Frame::Heads(Heads { streams: store.all_heads() })).await?;
+    write_frame(
+        w,
+        &Frame::Heads(Heads {
+            streams: store.all_heads(),
+        }),
+    )
+    .await?;
     let before = store.equivocation_proofs().len();
     let mut out = SyncOutcome::default();
     loop {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/peer.rs:1088:
         let mut prev = None;
         let mut ops = Vec::new();
         for seq in 0..n {
-            let o = op(origin, seq, key, prev.clone(), format!("{origin}{seq}").as_bytes());
+            let o = op(
+                origin,
+                seq,
+                key,
+                prev.clone(),
+                format!("{origin}{seq}").as_bytes(),
+            );
             store.append(o.clone()).unwrap();
             prev = Some(crate::chain::op_hash(&o).to_vec());
             ops.push(o);
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/peer.rs:1253:
         // Malicious peer: ops 0,1,2 valid, op 3 with a tampered prev, then op 4.
         let mut bad3 = ops[3].clone();
         bad3.prev = Some(vec![0u8; 32]); // != hash(op2) -> chain break at seq 3
-        let malicious = vec![ops[0].clone(), ops[1].clone(), ops[2].clone(), bad3, ops[4].clone()];
+        let malicious = vec![
+            ops[0].clone(),
+            ops[1].clone(),
+            ops[2].clone(),
+            bad3,
+            ops[4].clone(),
+        ];
 
         let (ca, cb) = tokio::io::duplex(64 * 1024);
         let (mut ar, mut aw) = split(ca);
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/peer.rs:1260:
         let (mut br, mut bw) = split(cb);
         let carrier = tokio::spawn(async move {
             read_frame(&mut br).await.unwrap(); // client HEADS
-            write_frame(&mut bw, &Frame::Ops(Ops { ops: malicious, pri: Some(Priority::Bulk) })).await.unwrap();
+            write_frame(
+                &mut bw,
+                &Frame::Ops(Ops {
+                    ops: malicious,
+                    pri: Some(Priority::Bulk),
+                }),
+            )
+            .await
+            .unwrap();
             bw.shutdown().await.unwrap();
         });
         let out = pull_sync(&mut ar, &mut aw, &mut client, &anyone)
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/peer.rs:1269:
         carrier.await.unwrap();
 
         assert_eq!(out.applied, 3); // 0,1,2 landed; 3 broke, 4 (suffix) dropped
-        assert_eq!(out.rejected, vec![("sh".into(), "g".into(), vec![], "a".into())]);
+        assert_eq!(
+            out.rejected,
+            vec![("sh".into(), "g".into(), vec![], "a".into())]
+        );
         assert_eq!(client.scan("sh", "g", b"", "a", -1).len(), 3);
 
         // Re-fetch from the honest replica: resume from head 2, gain 3 and 4.
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/peer.rs:1302:
         let (mut br, mut bw) = split(cb);
         let carrier = tokio::spawn(async move {
             read_frame(&mut br).await.unwrap();
-            write_frame(&mut bw, &Frame::Ops(Ops { ops: vec![conflict], pri: Some(Priority::Bulk) })).await.unwrap();
+            write_frame(
+                &mut bw,
+                &Frame::Ops(Ops {
+                    ops: vec![conflict],
+                    pri: Some(Priority::Bulk),
+                }),
+            )
+            .await
+            .unwrap();
             bw.shutdown().await.unwrap();
         });
         let out = pull_sync(&mut ar, &mut aw, &mut client, &anyone)
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/registry.rs:546:
                 if self.holds(&op) {
                     return Ok(Ingested::Duplicate);
                 }
-                return Err(RegistryError::Equivocation { origin: op.origin, seq: op.seq });
+                return Err(RegistryError::Equivocation {
+                    origin: op.origin,
+                    seq: op.seq,
+                });
             }
             if op.seq != last_seq + 1 {
-                return Err(RegistryError::Gap { expected: last_seq + 1, got: op.seq });
+                return Err(RegistryError::Gap {
+                    expected: last_seq + 1,
+                    got: op.seq,
+                });
             }
             match &op.prev {
                 Some(prev) if prev.as_slice() != last_hash => {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/registry.rs:556:
-                    return Err(RegistryError::ChainBreak { origin: op.origin, seq: op.seq });
+                    return Err(RegistryError::ChainBreak {
+                        origin: op.origin,
+                        seq: op.seq,
+                    });
                 }
                 _ => {}
             }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/registry.rs:560:
         } else if op.seq != 0 {
-            return Err(RegistryError::Gap { expected: 0, got: op.seq });
+            return Err(RegistryError::Gap {
+                expected: 0,
+                got: op.seq,
+            });
         }
         let hash = op_hash(&op);
         self.tips.insert(chain, (op.seq, hash));
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/registry.rs:664:
         // The binding family folds newest-wins ACROSS its two streams, so its
         // lamport is one clock over both (see `next_binding_lamport`); every
         // other kind keeps its chain seq.
-        let lamport = if Record::is_binding_family(glade_id) { self.next_binding_lamport() } else { seq };
+        let lamport = if Record::is_binding_family(glade_id) {
+            self.next_binding_lamport()
+        } else {
+            seq
+        };
         let mut op = Op {
             share: HOME.into(),
             glade_id: glade_id.into(),
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/registry.rs:857:
             .map(|(glade_id, mut hs)| {
                 hs.sort_by(|a, b| a.origin.cmp(&b.origin));
                 cbor::encode(
-                    &StreamHeads { share: HOME.into(), glade_id, key: vec![], heads: hs }.to_cbor(),
+                    &StreamHeads {
+                        share: HOME.into(),
+                        glade_id,
+                        key: vec![],
+                        heads: hs,
+                    }
+                    .to_cbor(),
                 )
             })
             .collect();
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/registry.rs:940:
                 }
                 _ => continue,
             };
-            let stamp =
-                Stamp { lamport: op.lamport, origin: op.origin.clone(), retraction: decl.is_none(), seq: op.seq };
+            let stamp = Stamp {
+                lamport: op.lamport,
+                origin: op.origin.clone(),
+                retraction: decl.is_none(),
+                seq: op.seq,
+            };
             let candidate = Newest { stamp, decl };
             let origins = newest.entry((app, glade_id)).or_default();
             match origins.entry(op.origin.clone()) {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/registry.rs:1016:
         })
     }
     fn claim(node: &str, share: &str, expiry: i64, epoch: i64) -> Record {
-        Record::Serve(ServeClaim { node: node.into(), share: share.into(), lease_expiry_ms: expiry, epoch })
+        Record::Serve(ServeClaim {
+            node: node.into(),
+            share: share.into(),
+            lease_expiry_ms: expiry,
+            epoch,
+        })
     }
 
     /// A scripted directory used by several tests + the conformance gate.
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/registry.rs:1023:
     fn scripted() -> Registry {
         let mut r = Registry::new();
-        r.append(Record::Node(NodeRecord { node_id: "glade-local".into(), operator: "gianni".into() }), "glade-local").unwrap();
-        r.append(Record::Node(NodeRecord { node_id: "peer1".into(), operator: "gianni".into() }), "glade-local").unwrap();
-        r.append(ws("ws-razel", &["peer1", "peer2"]), "glade-local").unwrap();
-        r.append(ws("ws-attic", &["attic-mini"]), "glade-local").unwrap();
-        r.append(ws("home", &["glade-local"]), "glade-local").unwrap();
-        r.append(claim("peer1", "ws-razel", 30_000, 1), "peer1").unwrap();
-        r.append(claim("peer2", "ws-razel", 30_000, 2), "peer2").unwrap(); // higher epoch
-        r.append(Record::Grant(CapabilityGrant { principal: "gianni".into(), share: "ws-razel".into(), verbs: vec!["read".into(), "write".into()] }), "glade-local").unwrap();
-        r.append(Record::Grant(CapabilityGrant { principal: "eve".into(), share: "ws-razel".into(), verbs: vec!["read".into()] }), "glade-local").unwrap();
-        r.append(Record::Revoke(CapabilityRevocation { principal: "eve".into(), share: "ws-razel".into() }), "glade-local").unwrap();
+        r.append(
+            Record::Node(NodeRecord {
+                node_id: "glade-local".into(),
+                operator: "gianni".into(),
+            }),
+            "glade-local",
+        )
+        .unwrap();
+        r.append(
+            Record::Node(NodeRecord {
+                node_id: "peer1".into(),
+                operator: "gianni".into(),
+            }),
+            "glade-local",
+        )
+        .unwrap();
+        r.append(ws("ws-razel", &["peer1", "peer2"]), "glade-local")
+            .unwrap();
+        r.append(ws("ws-attic", &["attic-mini"]), "glade-local")
+            .unwrap();
+        r.append(ws("home", &["glade-local"]), "glade-local")
+            .unwrap();
+        r.append(claim("peer1", "ws-razel", 30_000, 1), "peer1")
+            .unwrap();
+        r.append(claim("peer2", "ws-razel", 30_000, 2), "peer2")
+            .unwrap(); // higher epoch
+        r.append(
+            Record::Grant(CapabilityGrant {
+                principal: "gianni".into(),
+                share: "ws-razel".into(),
+                verbs: vec!["read".into(), "write".into()],
+            }),
+            "glade-local",
+        )
+        .unwrap();
+        r.append(
+            Record::Grant(CapabilityGrant {
+                principal: "eve".into(),
+                share: "ws-razel".into(),
+                verbs: vec!["read".into()],
+            }),
+            "glade-local",
+        )
+        .unwrap();
+        r.append(
+            Record::Revoke(CapabilityRevocation {
+                principal: "eve".into(),
+                share: "ws-razel".into(),
+            }),
+            "glade-local",
+        )
+        .unwrap();
         r
     }
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/registry.rs:1045:
             let op = Op::decode(bytes).unwrap();
             assert!(!op.origin.is_empty(), "record missing origin attribution");
         }
-        assert!(!snap.heads.is_empty(), "snapshot carries heads (cached fold + heads)");
+        assert!(
+            !snap.heads.is_empty(),
+            "snapshot carries heads (cached fold + heads)"
+        );
     }
 
     #[test]
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/registry.rs:1131:
         mem.save(&snap).unwrap();
         let (from_mem, rej_m) = Registry::from_snapshot(&mem.load().unwrap());
 
-        assert_eq!((rej_b, rej_m), (0, 0), "clean snapshot ingests with no rejects");
-        for (p, s, now) in [("ws-razel", "ws-razel", 0i64), ("ws-attic", "ws-attic", 100_000)] {
+        assert_eq!(
+            (rej_b, rej_m),
+            (0, 0),
+            "clean snapshot ingests with no rejects"
+        );
+        for (p, s, now) in [
+            ("ws-razel", "ws-razel", 0i64),
+            ("ws-attic", "ws-attic", 100_000),
+        ] {
             assert_eq!(live.who_serves(p, now), from_blob.who_serves(p, now));
             assert_eq!(from_blob.who_serves(p, now), from_mem.who_serves(p, now));
             assert_eq!(live.replicas_of(s), from_blob.replicas_of(s));
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/registry.rs:1139:
             assert_eq!(from_blob.replicas_of(s), from_mem.replicas_of(s));
         }
         assert_eq!(live.nodes_of("gianni"), from_mem.nodes_of("gianni"));
-        assert_eq!(live.grants_for("gianni", "ws-razel"), from_blob.grants_for("gianni", "ws-razel"));
-        assert_eq!(live.grants_for("eve", "ws-razel"), from_mem.grants_for("eve", "ws-razel"));
+        assert_eq!(
+            live.grants_for("gianni", "ws-razel"),
+            from_blob.grants_for("gianni", "ws-razel")
+        );
+        assert_eq!(
+            live.grants_for("eve", "ws-razel"),
+            from_mem.grants_for("eve", "ws-razel")
+        );
         // a snapshot is a cached fold + heads: round-trip is byte-identical.
         assert_eq!(live.snapshot(), from_blob.snapshot());
         assert_eq!(from_blob.snapshot(), from_mem.snapshot());
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/registry.rs:1150:
     fn verify_as_ingest_rejects_a_tampered_chain() {
         let mut r = scripted();
         // a valid appended chain of two claims on origin "peerX"
-        r.append(claim("peerX", "ws-x", 30_000, 1), "peerX").unwrap();
-        r.append(claim("peerX", "ws-x", 30_000, 2), "peerX").unwrap();
+        r.append(claim("peerX", "ws-x", 30_000, 1), "peerX")
+            .unwrap();
+        r.append(claim("peerX", "ws-x", 30_000, 2), "peerX")
+            .unwrap();
         let mut snap = r.snapshot();
         // tamper: corrupt one claim record's payload -> its op-hash changes, so
         // the NEXT op's prev no longer matches -> chain break -> suffix dropped.
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/registry.rs:1158:
-        let target = snap.records.iter().position(|b| {
-            let op = Op::decode(b).unwrap();
-            op.origin == "peerX" && op.seq == 0
-        }).unwrap();
+        let target = snap
+            .records
+            .iter()
+            .position(|b| {
+                let op = Op::decode(b).unwrap();
+                op.origin == "peerX" && op.seq == 0
+            })
+            .unwrap();
         let mut op = Op::decode(&snap.records[target]).unwrap();
         op.payload.push(0xff); // malicious edit — indistinguishable from a bad sync chunk
         snap.records[target] = cbor::encode(&op.to_cbor());
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/registry.rs:1165:
         let (reg, rejected) = Registry::from_snapshot(&snap);
-        assert!(rejected >= 1, "the tampered op (and its suffix) is quarantined");
+        assert!(
+            rejected >= 1,
+            "the tampered op (and its suffix) is quarantined"
+        );
         // the honest records still fold.
         assert_eq!(reg.nodes_of("gianni"), vec!["glade-local", "peer1"]);
     }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/registry.rs:1460:
         })
     }
     fn retract(app: &str, glade_id: &str) -> Record {
-        Record::Retract(BindingRetraction { app: app.into(), glade_id: glade_id.into() })
+        Record::Retract(BindingRetraction {
+            app: app.into(),
+            glade_id: glade_id.into(),
+        })
     }
     /// The live bindings as (app, glade_id, shape).
     fn live(r: &Registry) -> Vec<(String, String, String)> {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/registry.rs:1467:
-        r.bindings_of().into_iter().map(|b| (b.app, b.glade_id, b.shape)).collect()
+        r.bindings_of()
+            .into_iter()
+            .map(|b| (b.app, b.glade_id, b.shape))
+            .collect()
     }
     fn row(app: &str, glade_id: &str, shape: &str) -> (String, String, String) {
         (app.into(), glade_id.into(), shape.into())
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/registry.rs:1471:
     }
     fn ops_of(r: &Registry) -> Vec<Op> {
-        r.snapshot().records.iter().map(|b| Op::decode(b).unwrap()).collect()
+        r.snapshot()
+            .records
+            .iter()
+            .map(|b| Op::decode(b).unwrap())
+            .collect()
     }
 
     /// R9(a): `dir.bindings` folds by glade id and the newest declaration is
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/registry.rs:1495:
             r.append(decl("a", id, "value"), "n1").unwrap();
         }
         r.append(retract("a", "g"), "n1").unwrap();
-        assert_eq!(live(&r), vec![row("a", "h", "value"), row("a", "k", "value")]);
-        assert_eq!(BindingFold::over(&ops_of(&r)).retracted(), vec![("a".to_string(), "g".to_string())]);
+        assert_eq!(
+            live(&r),
+            vec![row("a", "h", "value"), row("a", "k", "value")]
+        );
+        assert_eq!(
+            BindingFold::over(&ops_of(&r)).retracted(),
+            vec![("a".to_string(), "g".to_string())]
+        );
         r.append(decl("a", "g", "log"), "n1").unwrap();
-        assert_eq!(live(&r), vec![row("a", "g", "log"), row("a", "h", "value"), row("a", "k", "value")]);
-        assert_eq!(BindingFold::over(&ops_of(&r)).retracted(), Vec::<(String, String)>::new());
+        assert_eq!(
+            live(&r),
+            vec![
+                row("a", "g", "log"),
+                row("a", "h", "value"),
+                row("a", "k", "value")
+            ]
+        );
+        assert_eq!(
+            BindingFold::over(&ops_of(&r)).retracted(),
+            Vec::<(String, String)>::new()
+        );
     }
 
     /// R9(a)'s scope: a retraction retracts its own app's declaration and no
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/registry.rs:1512:
         r.append(decl("b", "g", "log"), "n1").unwrap();
         assert_eq!(live(&r), vec![row("b", "g", "log")]);
         r.append(retract("b", "g"), "n1").unwrap();
-        assert_eq!(live(&r), vec![row("a", "g", "value")], "a's declaration was never in scope");
+        assert_eq!(
+            live(&r),
+            vec![row("a", "g", "value")],
+            "a's declaration was never in scope"
+        );
         r.append(retract("a", "g"), "n1").unwrap();
         assert_eq!(live(&r), vec![]);
     }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/registry.rs:1531:
         assert_eq!(at(decl("a", "g", "value"), "n1"), (G_BINDINGS.into(), 0, 0));
         assert_eq!(at(decl("a", "h", "value"), "n1"), (G_BINDINGS.into(), 1, 1));
         assert_eq!(at(claim("n1", "ws", 1, 1), "n1"), (G_CLAIMS.into(), 0, 0));
-        assert_eq!(at(retract("a", "g"), "n1"), (G_BINDING_RETRACTIONS.into(), 0, 2));
+        assert_eq!(
+            at(retract("a", "g"), "n1"),
+            (G_BINDING_RETRACTIONS.into(), 0, 2)
+        );
         assert_eq!(at(decl("a", "g", "log"), "n1"), (G_BINDINGS.into(), 2, 3));
-        assert_eq!(at(retract("a", "h"), "n1"), (G_BINDING_RETRACTIONS.into(), 1, 4));
+        assert_eq!(
+            at(retract("a", "h"), "n1"),
+            (G_BINDING_RETRACTIONS.into(), 1, 4)
+        );
         // a second origin's first record is still the newest
         assert_eq!(at(decl("a", "k", "value"), "n2"), (G_BINDINGS.into(), 0, 5));
         assert_eq!(at(claim("n1", "ws", 1, 2), "n1"), (G_CLAIMS.into(), 1, 1));
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/registry.rs:1637:
     #[test]
     fn a_stored_binding_decl_round_trips_byte_identically() {
         let pinned = "a601666772617a656c02687465726d2e6c6f6703636c6f67046573686172650567636f6d6d6f6e73066b66726f6d5f637572736f72";
-        let payload: Vec<u8> =
-            (0..pinned.len()).step_by(2).map(|i| u8::from_str_radix(&pinned[i..i + 2], 16).unwrap()).collect();
+        let payload: Vec<u8> = (0..pinned.len())
+            .step_by(2)
+            .map(|i| u8::from_str_radix(&pinned[i..i + 2], 16).unwrap())
+            .collect();
         let b = BindingDecl {
             app: "grazel".into(),
             glade_id: "term.log".into(),
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/registry.rs:1653:
         r.append(Record::Binding(b), "n1").unwrap();
         let snap = r.snapshot();
         let op = Op::decode(&snap.records[0]).unwrap();
-        assert_eq!((op.payload.as_slice(), op.seq, op.lamport), (payload.as_slice(), 0, 0));
+        assert_eq!(
+            (op.payload.as_slice(), op.seq, op.lamport),
+            (payload.as_slice(), 0, 0)
+        );
         let (back, rejected) = Registry::from_snapshot(&snap);
         assert_eq!(rejected, 0);
         assert_eq!(back.snapshot(), snap);
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/router.rs:30:
     }
 
     pub fn subscribe(&mut self, session: SessionId, share: &str, glade_id: &str, key: &[u8]) {
-        self.subs.entry((share.into(), glade_id.into(), key.to_vec())).or_default().insert(session);
+        self.subs
+            .entry((share.into(), glade_id.into(), key.to_vec()))
+            .or_default()
+            .insert(session);
     }
 
     pub fn unsubscribe(&mut self, session: SessionId, share: &str, glade_id: &str, key: &[u8]) {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/router.rs:37:
-        if let Some(set) = self.subs.get_mut(&(share.into(), glade_id.into(), key.to_vec())) {
+        if let Some(set) = self
+            .subs
+            .get_mut(&(share.into(), glade_id.into(), key.to_vec()))
+        {
             set.remove(&session);
         }
     }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/router.rs:57:
 
     /// Sessions subscribed to `(share, glade_id, key)` except `from` — the
     /// fan-out targets for an op originating at `from` (never echoed to itself).
-    pub fn route(&self, from: SessionId, share: &str, glade_id: &str, key: &[u8]) -> Vec<SessionId> {
+    pub fn route(
+        &self,
+        from: SessionId,
+        share: &str,
+        glade_id: &str,
+        key: &[u8],
+    ) -> Vec<SessionId> {
         self.subs
             .get(&(share.to_string(), glade_id.to_string(), key.to_vec()))
             .map(|set| set.iter().copied().filter(|&s| s != from).collect())
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/router.rs:171:
         // session 1 (origin "a") submits an op: node stores it, fans out to others
         let o = op("a", 0, b"hello");
         store.append(o.clone()).unwrap();
-        let frame = Frame::Ops(Ops { ops: vec![o.clone()], pri: None }).to_bytes();
+        let frame = Frame::Ops(Ops {
+            ops: vec![o.clone()],
+            pri: None,
+        })
+        .to_bytes();
         for target in router.route(1, "sh", "g", &[]) {
-            out.get_mut(&target).unwrap().push(Priority::Interactive, frame.clone());
+            out.get_mut(&target)
+                .unwrap()
+                .push(Priority::Interactive, frame.clone());
         }
         // session 2 receives the op; session 1 (origin) gets nothing
-        let got = out.get_mut(&2).unwrap().pop().expect("session 2 should receive");
+        let got = out
+            .get_mut(&2)
+            .unwrap()
+            .pop()
+            .expect("session 2 should receive");
         match Frame::from_bytes(&got).unwrap() {
             Frame::Ops(ops) => assert_eq!(ops.ops[0].payload, b"hello"),
             other => panic!("expected Ops, got {other:?}"),
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/server.rs:344:
                     shared.principals.lock().await.insert(sid, p.to_string());
                     crate::claims::note_principal(&shared, p).await;
                 }
-                send(&shared, sid, &Frame::Welcome(Welcome { session: h.session, protocol: 1, heads: vec![] })).await;
+                send(
+                    &shared,
+                    sid,
+                    &Frame::Welcome(Welcome {
+                        session: h.session,
+                        protocol: 1,
+                        heads: vec![],
+                    }),
+                )
+                .await;
             }
             Frame::Subscribe(s) => {
                 // A subscription is to one zone-surface (share, glade_id, key);
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/server.rs:359:
                     crate::exchange::declared_exchange(&st, &s.glade_id)
                 };
                 if declared {
-                    crate::exchange::attach_provider(&shared, sid, &s.share, &s.glade_id, key).await;
+                    crate::exchange::attach_provider(&shared, sid, &s.share, &s.glade_id, key)
+                        .await;
                     continue;
                 }
                 match crate::mesh::route_subscribe(&shared, &s.share).await {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/server.rs:418:
                         }
                         drop(cut);
                         if let crate::mesh::Route::Forward(peer) = route {
-                            crate::mesh::forward_interest(&shared, peer, s.share.clone(), s.glade_id.clone(), key.clone()).await;
+                            crate::mesh::forward_interest(
+                                &shared,
+                                peer,
+                                s.share.clone(),
+                                s.glade_id.clone(),
+                                key.clone(),
+                            )
+                            .await;
                         }
                     }
                 }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/server.rs:484:
         }
     }
     fn subscribe() -> Vec<u8> {
-        Frame::Subscribe(Subscribe { share: "sh".into(), glade_id: "g".into(), key: None, from: None }).to_bytes()
+        Frame::Subscribe(Subscribe {
+            share: "sh".into(),
+            glade_id: "g".into(),
+            key: None,
+            from: None,
+        })
+        .to_bytes()
     }
     fn subscribe_key(key: Option<Vec<u8>>) -> Vec<u8> {
-        Frame::Subscribe(Subscribe { share: "sh".into(), glade_id: "g".into(), key, from: None }).to_bytes()
+        Frame::Subscribe(Subscribe {
+            share: "sh".into(),
+            glade_id: "g".into(),
+            key,
+            from: None,
+        })
+        .to_bytes()
     }
     fn keyed_op(origin: &str, seq: i64, key: &[u8], payload: &[u8]) -> Op {
-        Op { key: key.to_vec(), ..op(origin, seq, payload) }
+        Op {
+            key: key.to_vec(),
+            ..op(origin, seq, payload)
+        }
     }
     fn ops_frame(o: Op) -> Vec<u8> {
-        Frame::Ops(Ops { ops: vec![o], pri: None }).to_bytes()
+        Frame::Ops(Ops {
+            ops: vec![o],
+            pri: None,
+        })
+        .to_bytes()
     }
     async fn recv(r: &mut ws::WsReader) -> Frame {
         match r.read().await.unwrap() {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/server.rs:619:
 
         wc.send_binary(&subscribe_key(None)).await.unwrap(); // commons
         assert!(matches!(recv(&mut rc).await, Frame::Heads(_)));
-        wp.send_binary(&subscribe_key(Some(b"self:p".to_vec()))).await.unwrap();
+        wp.send_binary(&subscribe_key(Some(b"self:p".to_vec())))
+            .await
+            .unwrap();
         assert!(matches!(recv(&mut rp).await, Frame::Heads(_)));
 
         // writer emits a private op then a commons op (independent chains, both seq 0)
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/server.rs:626:
-        ww.send_binary(&ops_frame(keyed_op("w", 0, b"self:p", b"secret"))).await.unwrap();
-        ww.send_binary(&ops_frame(keyed_op("w", 0, b"", b"public"))).await.unwrap();
+        ww.send_binary(&ops_frame(keyed_op("w", 0, b"self:p", b"secret")))
+            .await
+            .unwrap();
+        ww.send_binary(&ops_frame(keyed_op("w", 0, b"", b"public")))
+            .await
+            .unwrap();
 
         // the private subscriber sees the secret; the commons subscriber's only
         // delivered op is the public one — the secret never crosses the zone.
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/session.rs:26:
 /// `their` heads is missing: for each origin, everything above the peer's head
 /// (or the whole chain if the peer has never seen that origin). Scoped to the
 /// zone so a subscriber never receives another zone's (e.g. private) ops.
-pub fn missing_for(store: &Store, share: &str, glade_id: &str, key: &[u8], their: &Heads) -> Vec<Op> {
+pub fn missing_for(
+    store: &Store,
+    share: &str,
+    glade_id: &str,
+    key: &[u8],
+    their: &Heads,
+) -> Vec<Op> {
     let mut out = Vec::new();
     for (origin, _head) in store.heads(share, glade_id, key) {
         let from = their.get(&origin).copied().unwrap_or(i64::MIN);
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/session.rs:98:
 /// surfaced, never propagated or silently dropped. It is the op's status (R1).
 pub fn error_frame(err: &StoreError, op: &Op) -> Frame {
     let (code, message) = match err {
-        StoreError::Equivocation { origin, seq } => {
-            (ErrorCode::Equivocation, format!("forked chain at ({origin},{seq})"))
-        }
-        StoreError::ChainBreak { origin, seq } => {
-            (ErrorCode::Protocol, format!("chain break at ({origin},{seq})"))
-        }
-        StoreError::Gap { expected, got } => {
-            (ErrorCode::Protocol, format!("gap: expected {expected}, got {got}"))
-        }
-        StoreError::InvalidSwmrPayload { error } => {
-            (ErrorCode::Protocol, format!("invalid SWMR action envelope: {error:?}"))
-        }
-        StoreError::SwmrWriterConflict { expected, got } => {
-            (ErrorCode::Protocol, format!("SWMR writer conflict: expected {expected:?}, got {got:?}"))
-        }
-        StoreError::ShapeConflict { expected, got } => {
-            (ErrorCode::Protocol, format!("shape conflict: expected {expected:?}, got {got:?}"))
-        }
-        StoreError::Unverified { origin, seq, why } => {
-            (ErrorCode::Unauthorized, format!("({origin},{seq}) does not verify: {why}"))
-        }
+        StoreError::Equivocation { origin, seq } => (
+            ErrorCode::Equivocation,
+            format!("forked chain at ({origin},{seq})"),
+        ),
+        StoreError::ChainBreak { origin, seq } => (
+            ErrorCode::Protocol,
+            format!("chain break at ({origin},{seq})"),
+        ),
+        StoreError::Gap { expected, got } => (
+            ErrorCode::Protocol,
+            format!("gap: expected {expected}, got {got}"),
+        ),
+        StoreError::InvalidSwmrPayload { error } => (
+            ErrorCode::Protocol,
+            format!("invalid SWMR action envelope: {error:?}"),
+        ),
+        StoreError::SwmrWriterConflict { expected, got } => (
+            ErrorCode::Protocol,
+            format!("SWMR writer conflict: expected {expected:?}, got {got:?}"),
+        ),
+        StoreError::ShapeConflict { expected, got } => (
+            ErrorCode::Protocol,
+            format!("shape conflict: expected {expected:?}, got {got:?}"),
+        ),
+        StoreError::Unverified { origin, seq, why } => (
+            ErrorCode::Unauthorized,
+            format!("({origin},{seq}) does not verify: {why}"),
+        ),
         StoreError::Rewrite { origin, seq } => (
             ErrorCode::Equivocation,
             format!("rewritten chain at ({origin},{seq})"),
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/session.rs:223:
             other => panic!("expected Error frame, got {other:?}"),
         }
         // and it survives the wire
-        assert!(matches!(Frame::from_bytes(&frame.to_bytes()).unwrap(), Frame::Error(_)));
+        assert!(matches!(
+            Frame::from_bytes(&frame.to_bytes()).unwrap(),
+            Frame::Error(_)
+        ));
     }
 
     #[test]
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/session.rs:233:
         client.append(op("a", 1, b"a1")).unwrap();
         ship(&client, &mut server);
         // second sync ships nothing
-        assert!(missing_for(&server, "sh", "g", &[], &heads_map(&client, "sh", "g", &[])).is_empty());
-        assert!(missing_for(&client, "sh", "g", &[], &heads_map(&server, "sh", "g", &[])).is_empty());
+        assert!(
+            missing_for(&server, "sh", "g", &[], &heads_map(&client, "sh", "g", &[])).is_empty()
+        );
+        assert!(
+            missing_for(&client, "sh", "g", &[], &heads_map(&server, "sh", "g", &[])).is_empty()
+        );
     }
 }
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/store.rs:65:
 impl EquivProof {
     /// The forked `(share, glade_id, key, origin, seq)` slot.
     pub fn slot(&self) -> (String, String, Vec<u8>, String, i64) {
-        (self.a.share.clone(), self.a.glade_id.clone(), self.a.key.clone(), self.a.origin.clone(), self.a.seq)
+        (
+            self.a.share.clone(),
+            self.a.glade_id.clone(),
+            self.a.key.clone(),
+            self.a.origin.clone(),
+            self.a.seq,
+        )
     }
 }
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/store.rs:72:
 #[derive(Debug)]
 pub enum StoreError {
     /// Non-contiguous: an origin's log must advance by exactly one.
-    Gap { expected: i64, got: i64 },
+    Gap {
+        expected: i64,
+        got: i64,
+    },
     /// A second op at an existing `(origin, seq)` with a *different* hash — a
     /// forked per-origin chain (GQ-9). Rejected, never folded.
-    Equivocation { origin: String, seq: i64 },
+    Equivocation {
+        origin: String,
+        seq: i64,
+    },
     /// A new op's `prev` does not match its predecessor's hash.
-    ChainBreak { origin: String, seq: i64 },
+    ChainBreak {
+        origin: String,
+        seq: i64,
+    },
     /// The SWMR action envelope is not `glade.swmr.adapter/v1`.
-    InvalidSwmrPayload { error: SwmrPayloadError },
+    InvalidSwmrPayload {
+        error: SwmrPayloadError,
+    },
     /// A SWMR surface already has a different authenticated writer origin.
-    SwmrWriterConflict { expected: String, got: String },
+    SwmrWriterConflict {
+        expected: String,
+        got: String,
+    },
     /// SWMR and a multi-writer fold MUST NOT share one zone-surface.
-    ShapeConflict { expected: Shape, got: Shape },
+    ShapeConflict {
+        expected: Shape,
+        got: Shape,
+    },
     /// A `home` op that does not verify (plan Step 4.1b): unsigned, forged,
     /// or not the directory's form or kind.
-    Unverified { origin: String, seq: i64, why: Refused },
+    Unverified {
+        origin: String,
+        seq: i64,
+        why: Refused,
+    },
     /// A checkpoint whose base moves back from the one held, or that names
     /// another hash there (plan Step 4.5c): refused, the pair kept as its
     /// proof.
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/store.rs:139:
 type ChainId = (String, String, Vec<u8>, String);
 
 fn chain_of(op: &Op) -> ChainId {
-    (op.share.clone(), op.glade_id.clone(), op.key.clone(), op.origin.clone())
+    (
+        op.share.clone(),
+        op.glade_id.clone(),
+        op.key.clone(),
+        op.origin.clone(),
+    )
 }
 
 /// Each chain's ops, in order.
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/store.rs:322:
             Verdict::Duplicate => Ok(Append::Duplicate),
             Verdict::BelowRetained => Ok(Append::BelowRetained),
             Verdict::Gap { expected, got } => Err(StoreError::Gap { expected, got }),
-            Verdict::ChainBreak => Err(StoreError::ChainBreak { origin: op.origin, seq: op.seq }),
+            Verdict::ChainBreak => Err(StoreError::ChainBreak {
+                origin: op.origin,
+                seq: op.seq,
+            }),
             Verdict::Equivocation(stored) => {
                 // Two signed ops, one slot — persist the fork proof, then reject.
-                self.record_equivocation(EquivProof { a: stored, b: op.clone() })?;
-                Err(StoreError::Equivocation { origin: op.origin, seq: op.seq })
+                self.record_equivocation(EquivProof {
+                    a: stored,
+                    b: op.clone(),
+                })?;
+                Err(StoreError::Equivocation {
+                    origin: op.origin,
+                    seq: op.seq,
+                })
             }
             Verdict::Rewrite(stored) => {
                 let proof = EquivProof {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/store.rs:390:
                 || existing_shape == Shape::Crdt)
                 && existing_shape != op.shape
             {
-                return Err(StoreError::ShapeConflict { expected: existing_shape, got: op.shape });
+                return Err(StoreError::ShapeConflict {
+                    expected: existing_shape,
+                    got: op.shape,
+                });
             }
             if op.shape == Shape::Swmr && origin != &op.origin {
                 return Err(StoreError::SwmrWriterConflict {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/store.rs:463:
 
     /// Ops for a chain `(share, glade_id, key, origin)` with `seq > from_seq`, in
     /// order (the resume tail for one origin within a zone).
-    pub fn scan(&self, share: &str, glade_id: &str, key: &[u8], origin: &str, from_seq: i64) -> Vec<Op> {
+    pub fn scan(
+        &self,
+        share: &str,
+        glade_id: &str,
+        key: &[u8],
+        origin: &str,
+        from_seq: i64,
+    ) -> Vec<Op> {
         self.logs
-            .get(&(share.to_string(), glade_id.to_string(), key.to_vec(), origin.to_string()))
+            .get(&(
+                share.to_string(),
+                glade_id.to_string(),
+                key.to_vec(),
+                origin.to_string(),
+            ))
             .map(|log| log.iter().filter(|o| o.seq > from_seq).cloned().collect())
             .unwrap_or_default()
     }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/store.rs:511:
     Appended,
     Duplicate,
     BelowRetained,
-    Gap { expected: i64, got: i64 },
+    Gap {
+        expected: i64,
+        got: i64,
+    },
     ChainBreak,
     /// An op already sits at this `(origin, seq)` with a different hash — a fork.
     /// Carries the stored op so the proof can be assembled. At a chain's base
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/store.rs:636:
 }
 
 fn classify(log: Option<&Vec<Op>>, op: &Op) -> Verdict {
-    let Some(last) = log.and_then(|l| l.last()) else { return Verdict::Appended };
+    let Some(last) = log.and_then(|l| l.last()) else {
+        return Verdict::Appended;
+    };
     if op.seq <= last.seq {
         // Safe to unwrap the log: we found `last` in it.
         return match log.unwrap().iter().find(|o| o.seq == op.seq) {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/store.rs:980:
     fn append_and_scan_from_seq() {
         let mut s = Store::open(fresh("scan")).unwrap();
         for n in 1..=3 {
-            assert_eq!(s.append(op("sh", "a", n, &[n as u8])).unwrap(), Append::Appended);
+            assert_eq!(
+                s.append(op("sh", "a", n, &[n as u8])).unwrap(),
+                Append::Appended
+            );
         }
         assert_eq!(s.scan("sh", "g", &[], "a", 0).len(), 3); // all
         assert_eq!(s.scan("sh", "g", &[], "a", 1).len(), 2); // seq > 1
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/store.rs:1006:
     fn keys_are_independent_chains() {
         let mut s = Store::open(fresh("zones")).unwrap();
         let commons = |seq, p: &[u8]| op("sh", "a", seq, p); // key = []
-        let private = |seq, p: &[u8]| Op { key: b"self:a".to_vec(), ..op("sh", "a", seq, p) };
+        let private = |seq, p: &[u8]| Op {
+            key: b"self:a".to_vec(),
+            ..op("sh", "a", seq, p)
+        };
         // both chains start at seq 0 — independent, no equivocation across keys
         s.append(commons(0, b"c0")).unwrap();
         s.append(private(0, b"p0")).unwrap();
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/store.rs:1039:
     fn swmr_accepts_one_writer_snapshot_delta_and_empty_reset() {
         let mut s = Store::open(fresh("swmr-one-writer")).unwrap();
         assert_eq!(
-            s.append(swmr_op("writer-a", 0, SwmrAction::Snapshot, b"whole-0")).unwrap(),
+            s.append(swmr_op("writer-a", 0, SwmrAction::Snapshot, b"whole-0"))
+                .unwrap(),
             Append::Appended,
         );
         assert_eq!(
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/store.rs:1046:
-            s.append(swmr_op("writer-a", 1, SwmrAction::Delta, b"whole-1")).unwrap(),
+            s.append(swmr_op("writer-a", 1, SwmrAction::Delta, b"whole-1"))
+                .unwrap(),
             Append::Appended,
         );
         assert_eq!(
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/store.rs:1050:
-            s.append(swmr_op("writer-a", 2, SwmrAction::Reset, b"")).unwrap(),
+            s.append(swmr_op("writer-a", 2, SwmrAction::Reset, b""))
+                .unwrap(),
             Append::Appended,
         );
         assert_eq!(s.scan("sh", "g", &[], "writer-a", -1).len(), 3);
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/store.rs:1056:
     #[test]
     fn swmr_rejects_malformed_action_before_store_mutation() {
         let mut s = Store::open(fresh("swmr-malformed")).unwrap();
-        let malformed = Op { shape: Shape::Swmr, payload: vec![1, 99], ..op("sh", "writer-a", 0, b"") };
+        let malformed = Op {
+            shape: Shape::Swmr,
+            payload: vec![1, 99],
+            ..op("sh", "writer-a", 0, b"")
+        };
 
         assert!(matches!(
             s.append(malformed),
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/store.rs:1068:
     #[test]
     fn swmr_rejects_second_writer_and_shape_mixing_before_mutation() {
         let mut s = Store::open(fresh("swmr-conflicts")).unwrap();
-        s.append(swmr_op("writer-a", 0, SwmrAction::Snapshot, b"whole")).unwrap();
+        s.append(swmr_op("writer-a", 0, SwmrAction::Snapshot, b"whole"))
+            .unwrap();
 
         assert!(matches!(
             s.append(swmr_op("writer-b", 0, SwmrAction::Snapshot, b"other")),
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/store.rs:1077:
         ));
         assert!(matches!(
             s.append(op("sh", "writer-b", 0, b"value")),
-            Err(StoreError::ShapeConflict { expected: Shape::Swmr, got: Shape::Value })
+            Err(StoreError::ShapeConflict {
+                expected: Shape::Swmr,
+                got: Shape::Value
+            })
         ));
         assert!(s.scan("sh", "g", &[], "writer-b", -1).is_empty());
         assert_eq!(s.scan("sh", "g", &[], "writer-a", -1).len(), 1);
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/store.rs:1086:
     #[test]
     fn crdt_accepts_multiple_writers_but_rejects_shape_mixing() {
         let mut s = Store::open(fresh("crdt-multi-writer")).unwrap();
-        let alice = Op { shape: Shape::Crdt, ..op("sh", "alice", 0, b"A") };
-        let bob = Op { shape: Shape::Crdt, ..op("sh", "bob", 0, b"B") };
+        let alice = Op {
+            shape: Shape::Crdt,
+            ..op("sh", "alice", 0, b"A")
+        };
+        let bob = Op {
+            shape: Shape::Crdt,
+            ..op("sh", "bob", 0, b"B")
+        };
         assert_eq!(s.append(alice).unwrap(), Append::Appended);
         assert_eq!(s.append(bob).unwrap(), Append::Appended);
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/store.rs:1094:
         assert!(matches!(
             s.append(op("sh", "legacy", 0, b"whole-value")),
-            Err(StoreError::ShapeConflict { expected: Shape::Crdt, got: Shape::Value })
+            Err(StoreError::ShapeConflict {
+                expected: Shape::Crdt,
+                got: Shape::Value
+            })
         ));
         assert_eq!(s.scan("sh", "g", &[], "alice", -1).len(), 1);
         assert_eq!(s.scan("sh", "g", &[], "bob", -1).len(), 1);
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/store.rs:1119:
         s.append(op("sh", "a", 0, b"p0")).unwrap();
         // same (origin, seq), different payload -> forked chain, rejected
         match s.append(op("sh", "a", 0, b"p0-fork")) {
-            Err(StoreError::Equivocation { origin, seq }) => assert_eq!((origin.as_str(), seq), ("a", 0)),
+            Err(StoreError::Equivocation { origin, seq }) => {
+                assert_eq!((origin.as_str(), seq), ("a", 0))
+            }
             other => panic!("expected Equivocation, got {other:?}"),
         }
         // exact re-delivery of the real op is still idempotent
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/store.rs:1126:
-        assert_eq!(s.append(op("sh", "a", 0, b"p0")).unwrap(), Append::Duplicate);
+        assert_eq!(
+            s.append(op("sh", "a", 0, b"p0")).unwrap(),
+            Append::Duplicate
+        );
     }
 
     #[test]
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/store.rs:1133:
         let mut a1 = op("sh", "a", 1, b"p1");
         a1.prev = Some(vec![0xde, 0xad, 0xbe, 0xef]); // does not match hash(a0)
         match s.append(a1) {
-            Err(StoreError::ChainBreak { origin, seq }) => assert_eq!((origin.as_str(), seq), ("a", 1)),
+            Err(StoreError::ChainBreak { origin, seq }) => {
+                assert_eq!((origin.as_str(), seq), ("a", 1))
+            }
             other => panic!("expected ChainBreak, got {other:?}"),
         }
     }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/store.rs:1167:
     fn all_heads_are_per_zone_with_chain_hash() {
         let mut s = Store::open(fresh("all-heads")).unwrap();
         s.append(op("sh", "a", 0, b"x")).unwrap(); // commons zone
-        s.append(Op { key: b"self:a".to_vec(), ..op("sh", "a", 0, b"y") }).unwrap(); // private zone
+        s.append(Op {
+            key: b"self:a".to_vec(),
+            ..op("sh", "a", 0, b"y")
+        })
+        .unwrap(); // private zone
         let ah = s.all_heads();
         assert_eq!(ah.len(), 2); // two zones, independent
         for sh in &ah {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/sysdir.rs:339:
     let mut recovery = None;
     if !registry.has_node(&node_id) {
         registry
-            .append(Record::Node(NodeRecord { node_id: node_id.clone(), operator: operator.into() }), &node_id)
+            .append(
+                Record::Node(NodeRecord {
+                    node_id: node_id.clone(),
+                    operator: operator.into(),
+                }),
+                &node_id,
+            )
             .map_err(reg_io)?;
         registry
             .append(
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/sysdir.rs:480:
 /// expiry); never consulted inside the fold.
 pub fn now_ms() -> i64 {
     use std::time::{SystemTime, UNIX_EPOCH};
-    SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_millis() as i64).unwrap_or(0)
+    SystemTime::now()
+        .duration_since(UNIX_EPOCH)
+        .map(|d| d.as_millis() as i64)
+        .unwrap_or(0)
 }
 
 /// NodeId = hex of the node key's Ed25519 public key (plan Step 4.1a, D2): the
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/sysdir.rs:563:
 }
 
 fn reg_io(e: crate::registry::RegistryError) -> io::Error {
-    io::Error::new(io::ErrorKind::InvalidData, format!("registry append rejected: {e:?}"))
+    io::Error::new(
+        io::ErrorKind::InvalidData,
+        format!("registry append rejected: {e:?}"),
+    )
 }
 
 #[cfg(test)]
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/sysdir.rs:588:
         assert!(dir.join("records.json").exists()); // class-2 snapshot written
         assert!(dir.join("cache").is_dir());
         assert!(dir.join("instance.lock").exists()); // held while `boot` lives
-        // presence: our node is in the fold, attributed to our own id.
+                                                     // presence: our node is in the fold, attributed to our own id.
         assert!(boot.registry.has_node(&boot.node_id));
         assert_eq!(boot.registry.nodes_of("gianni"), vec![boot.node_id.clone()]);
         // the node served itself its own home before any client: whoServes(home).
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/sysdir.rs:595:
-        assert_eq!(boot.registry.who_serves(HOME, 0), Some(boot.node_id.clone()));
+        assert_eq!(
+            boot.registry.who_serves(HOME, 0),
+            Some(boot.node_id.clone())
+        );
     }
 
     #[test]
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/ws.rs:28:
     for chunk in msg.chunks(64) {
         let mut w = [0u32; 80];
         for i in 0..16 {
-            w[i] = u32::from_be_bytes([chunk[i * 4], chunk[i * 4 + 1], chunk[i * 4 + 2], chunk[i * 4 + 3]]);
+            w[i] = u32::from_be_bytes([
+                chunk[i * 4],
+                chunk[i * 4 + 1],
+                chunk[i * 4 + 2],
+                chunk[i * 4 + 3],
+            ]);
         }
         for i in 16..80 {
             w[i] = (w[i - 3] ^ w[i - 8] ^ w[i - 14] ^ w[i - 16]).rotate_left(1);
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/ws.rs:41:
                 40..=59 => ((b & c) | (b & d) | (c & d), 0x8F1BBCDC),
                 _ => (b ^ c ^ d, 0xCA62C1D6),
             };
-            let tmp = a.rotate_left(5).wrapping_add(f).wrapping_add(e).wrapping_add(k).wrapping_add(*wi);
+            let tmp = a
+                .rotate_left(5)
+                .wrapping_add(f)
+                .wrapping_add(e)
+                .wrapping_add(k)
+                .wrapping_add(*wi);
             e = d;
             d = c;
             c = b.rotate_left(30);
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/ws.rs:62:
 }
 
 pub fn accept_key(key: &str) -> String {
-    b64_encode(&sha1(format!("{}258EAFA5-E914-47DA-95CA-C5AB0DC85B11", key).as_bytes()))
+    b64_encode(&sha1(
+        format!("{}258EAFA5-E914-47DA-95CA-C5AB0DC85B11", key).as_bytes(),
+    ))
 }
 
 const B64: &[u8] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/ws.rs:70:
 pub fn b64_encode(data: &[u8]) -> String {
     let mut s = String::new();
     for chunk in data.chunks(3) {
-        let b = [chunk[0], *chunk.get(1).unwrap_or(&0), *chunk.get(2).unwrap_or(&0)];
+        let b = [
+            chunk[0],
+            *chunk.get(1).unwrap_or(&0),
+            *chunk.get(2).unwrap_or(&0),
+        ];
         let n = ((b[0] as u32) << 16) | ((b[1] as u32) << 8) | (b[2] as u32);
         s.push(B64[((n >> 18) & 63) as usize] as char);
         s.push(B64[((n >> 12) & 63) as usize] as char);
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/ws.rs:77:
-        s.push(if chunk.len() > 1 { B64[((n >> 6) & 63) as usize] as char } else { '=' });
-        s.push(if chunk.len() > 2 { B64[(n & 63) as usize] as char } else { '=' });
+        s.push(if chunk.len() > 1 {
+            B64[((n >> 6) & 63) as usize] as char
+        } else {
+            '='
+        });
+        s.push(if chunk.len() > 2 {
+            B64[(n & 63) as usize] as char
+        } else {
+            '='
+        });
     }
     s
 }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/ws.rs:177:
         .lines()
         .find_map(|l| {
             let (name, val) = l.split_once(':')?;
-            name.trim().eq_ignore_ascii_case("sec-websocket-key").then(|| val.trim().to_string())
+            name.trim()
+                .eq_ignore_ascii_case("sec-websocket-key")
+                .then(|| val.trim().to_string())
         })
         .ok_or_else(|| std::io::Error::new(std::io::ErrorKind::InvalidData, "no ws key"))?;
     let resp = format!(
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/ws.rs:185:
         accept_key(&key)
     );
     write.write_all(resp.as_bytes()).await?;
-    Ok((WsReader { inner: read }, WsWriter { inner: Arc::new(Mutex::new(write)), mask: false }))
+    Ok((
+        WsReader { inner: read },
+        WsWriter {
+            inner: Arc::new(Mutex::new(write)),
+            mask: false,
+        },
+    ))
 }
 
 /// Client side: send the upgrade request (frames will be masked).
Diff in /Volumes/projects/limbo/glade-wz/glade/node/src/ws.rs:206:
         buf.push(byte[0]);
     }
     if !String::from_utf8_lossy(&buf).contains("101") {
-        return Err(std::io::Error::new(std::io::ErrorKind::InvalidData, "no 101 upgrade"));
+        return Err(std::io::Error::new(
+            std::io::ErrorKind::InvalidData,
+            "no 101 upgrade",
+        ));
     }
-    Ok((WsReader { inner: read }, WsWriter { inner: Arc::new(Mutex::new(write)), mask: true }))
+    Ok((
+        WsReader { inner: read },
+        WsWriter {
+            inner: Arc::new(Mutex::new(write)),
+            mask: true,
+        },
+    ))
 }
 
 fn eof() -> std::io::Error {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/tests/binding_census.rs:34:
 /// every other record unchanged. The later session-desk declaration adds one
 /// fresh binding to Gyld; the pre-amendment reconstruction excludes it.
 const CENSUS: [(&str, Registered); 5] = [
-    (GRAZEL, Registered { appended: 5, unchanged: 7 }),
-    ("../apps/grazel-app.glade", Registered { appended: 5, unchanged: 7 }),
-    (GYLD, Registered { appended: 3, unchanged: 10 }),
-    ("../../glade-gyld/tests/fixtures/gyld-test-app.glade", Registered { appended: 2, unchanged: 7 }),
-    ("../../glade-gwz/tests/fixtures/gwz-test-app.glade", Registered { appended: 1, unchanged: 3 }),
+    (
+        GRAZEL,
+        Registered {
+            appended: 5,
+            unchanged: 7,
+        },
+    ),
+    (
+        "../apps/grazel-app.glade",
+        Registered {
+            appended: 5,
+            unchanged: 7,
+        },
+    ),
+    (
+        GYLD,
+        Registered {
+            appended: 3,
+            unchanged: 10,
+        },
+    ),
+    (
+        "../../glade-gyld/tests/fixtures/gyld-test-app.glade",
+        Registered {
+            appended: 2,
+            unchanged: 7,
+        },
+    ),
+    (
+        "../../glade-gwz/tests/fixtures/gwz-test-app.glade",
+        Registered {
+            appended: 1,
+            unchanged: 3,
+        },
+    ),
 ];
 
 fn path(rel: &str) -> PathBuf {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/tests/binding_census.rs:48:
 /// Read app files by their path from this crate, failing — with every
 /// missing path named — when this checkout is not inside the workspace.
 fn read_all<const N: usize>(rels: [&str; N]) -> [String; N] {
-    let missing: Vec<String> =
-        rels.iter().map(|rel| path(rel)).filter(|p| !p.is_file()).map(|p| p.display().to_string()).collect();
+    let missing: Vec<String> = rels
+        .iter()
+        .map(|rel| path(rel))
+        .filter(|p| !p.is_file())
+        .map(|p| p.display().to_string())
+        .collect();
     assert!(
         missing.is_empty(),
         "these tests read the census's app files from four repositories of the glade-wz workspace, \
Diff in /Volumes/projects/limbo/glade-wz/glade/node/tests/binding_census.rs:79:
         .filter(|line| !line.split_whitespace().take(2).eq(["binding", "gyld.desk"]))
         .map(|line| {
             let toks: Vec<&str> = line.split_whitespace().collect();
-            if toks == ["binding", "term.log", "log", "share", "commons", "from-cursor"] {
+            if toks
+                == [
+                    "binding",
+                    "term.log",
+                    "log",
+                    "share",
+                    "commons",
+                    "from-cursor",
+                ]
+            {
                 changed += 1;
                 line.replacen("from-cursor", "windowed", 1)
             } else if toks == ["glade-app", "v1"] {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/tests/binding_census.rs:105:
 /// release's flip, which refuses it in a `v1` file.
 fn pre_amendment(text: &str) -> AppDecl {
     let mut decl = parse(text).unwrap();
-    assert_eq!(decl.version, AppFileVersion::V0, "the text as it was before Step 2.4");
+    assert_eq!(
+        decl.version,
+        AppFileVersion::V0,
+        "the text as it was before Step 2.4"
+    );
     let lines: Vec<Vec<&str>> = text
         .lines()
-        .map(|line| line.split('#').next().unwrap_or("").split_whitespace().collect::<Vec<&str>>())
+        .map(|line| {
+            line.split('#')
+                .next()
+                .unwrap_or("")
+                .split_whitespace()
+                .collect::<Vec<&str>>()
+        })
         .filter(|toks| toks.first() == Some(&"binding"))
         .collect();
     assert_eq!(lines.len(), decl.bindings.len());
Diff in /Volumes/projects/limbo/glade-wz/glade/node/tests/binding_census.rs:115:
     for (b, toks) in decl.bindings.iter_mut().zip(&lines) {
-        assert_eq!(toks.len(), 6, "a pre-amendment binding line has no tail: {toks:?}");
+        assert_eq!(
+            toks.len(),
+            6,
+            "a pre-amendment binding line has no tail: {toks:?}"
+        );
         b.retention = toks[5].to_string();
-        let stored = [b.glade_id.as_str(), b.shape.as_str(), b.authority.as_str(), b.zone.as_str(), &b.retention];
+        let stored = [
+            b.glade_id.as_str(),
+            b.shape.as_str(),
+            b.authority.as_str(),
+            b.zone.as_str(),
+            &b.retention,
+        ];
         assert_eq!(stored, toks[1..6], "every field raw");
         assert_eq!(b.app, decl.app);
     }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/tests/binding_census.rs:132:
 
 /// The declarations these parses make, as `bindings_of` orders them.
 fn declared(decls: &[&AppDecl]) -> Vec<BindingDecl> {
-    let mut all: Vec<BindingDecl> = decls.iter().flat_map(|d| d.bindings.iter().cloned()).collect();
+    let mut all: Vec<BindingDecl> = decls
+        .iter()
+        .flat_map(|d| d.bindings.iter().cloned())
+        .collect();
     all.sort_by(|a, b| a.glade_id.cmp(&b.glade_id));
     all
 }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/tests/binding_census.rs:139:
 
 fn ops_of(reg: &Registry) -> Vec<Op> {
-    reg.snapshot().records.iter().map(|b| Op::decode(b).unwrap()).collect()
+    reg.snapshot()
+        .records
+        .iter()
+        .map(|b| Op::decode(b).unwrap())
+        .collect()
 }
 
 fn retracted(reg: &Registry) -> Vec<(String, String)> {
Diff in /Volumes/projects/limbo/glade-wz/glade/node/tests/binding_census.rs:163:
     let mut total = 0;
     for ((rel, want), text) in CENSUS.iter().zip(&texts) {
         let (old_text, reverted) = before_step_2_4(text);
-        assert_eq!(reverted, usize::from(rel.ends_with("grazel-app.glade")), "{rel}: Step 2.4's edit");
+        assert_eq!(
+            reverted,
+            usize::from(rel.ends_with("grazel-app.glade")),
+            "{rel}: Step 2.4's edit"
+        );
         let pre = pre_amendment(&old_text);
         let mut reg = Registry::new();
         let first = register(&pre, &mut reg, ORIGIN).unwrap();
Diff in /Volumes/projects/limbo/glade-wz/glade/node/tests/binding_census.rs:170:
-        assert_eq!(first, Registered { appended: records(&pre), unchanged: 0 }, "{rel}");
+        assert_eq!(
+            first,
+            Registered {
+                appended: records(&pre),
+                unchanged: 0
+            },
+            "{rel}"
+        );
 
         let mut reg = reboot(&reg);
         let post = parse(text).unwrap();
Diff in /Volumes/projects/limbo/glade-wz/glade/node/tests/binding_census.rs:174:
         let out = register(&post, &mut reg, ORIGIN).unwrap();
         assert_eq!(out, *want, "{rel}");
-        assert_eq!(reg.bindings_of(), declared(&[&post]), "{rel}: the post-amendment declarations are live");
+        assert_eq!(
+            reg.bindings_of(),
+            declared(&[&post]),
+            "{rel}: the post-amendment declarations are live"
+        );
         assert_eq!(retracted(&reg), vec![], "{rel}: no line was deleted");
         total += out.appended;
     }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/tests/binding_census.rs:180:
-    assert_eq!(total, 16, "binding lines appended, summed over one registry per census file");
+    assert_eq!(
+        total, 16,
+        "binding lines appended, summed over one registry per census file"
+    );
 }
 
 /// §4.7 row 9 in the owner's store: grazel's boot with its gyld leg on
Diff in /Volumes/projects/limbo/glade-wz/glade/node/tests/binding_census.rs:186:
 #[test]
 fn row9_the_owners_two_file_store_appends_8() {
     let [grazel, gyld] = read_all([GRAZEL, GYLD]);
-    let (pre_grazel, pre_gyld) =
-        (pre_amendment(&before_step_2_4(&grazel).0), pre_amendment(&before_step_2_4(&gyld).0));
+    let (pre_grazel, pre_gyld) = (
+        pre_amendment(&before_step_2_4(&grazel).0),
+        pre_amendment(&before_step_2_4(&gyld).0),
+    );
     let mut reg = Registry::new();
-    assert_eq!(register(&pre_grazel, &mut reg, ORIGIN).unwrap(), Registered { appended: 12, unchanged: 0 });
+    assert_eq!(
+        register(&pre_grazel, &mut reg, ORIGIN).unwrap(),
+        Registered {
+            appended: 12,
+            unchanged: 0
+        }
+    );
     // the `workspace ws-razel razel` entry and the `seed owner ws-razel read.*`
     // grant both files declare register once
-    assert_eq!(register(&pre_gyld, &mut reg, ORIGIN).unwrap(), Registered { appended: 10, unchanged: 2 });
+    assert_eq!(
+        register(&pre_gyld, &mut reg, ORIGIN).unwrap(),
+        Registered {
+            appended: 10,
+            unchanged: 2
+        }
+    );
 
     let mut reg = reboot(&reg);
     let (post_grazel, post_gyld) = (parse(&grazel).unwrap(), parse(&gyld).unwrap());
Diff in /Volumes/projects/limbo/glade-wz/glade/node/tests/binding_census.rs:199:
     let a = register(&post_grazel, &mut reg, ORIGIN).unwrap();
     let b = register(&post_gyld, &mut reg, ORIGIN).unwrap();
-    assert_eq!((a, b), (Registered { appended: 5, unchanged: 7 }, Registered { appended: 3, unchanged: 10 }));
+    assert_eq!(
+        (a, b),
+        (
+            Registered {
+                appended: 5,
+                unchanged: 7
+            },
+            Registered {
+                appended: 3,
+                unchanged: 10
+            }
+        )
+    );
     assert_eq!(reg.bindings_of(), declared(&[&post_grazel, &post_gyld]));
     assert_eq!(reg.bindings_of().len(), 16);
     assert_eq!(retracted(&reg), vec![]);
Diff in /Volumes/projects/limbo/glade-wz/glade/node/tests/binding_census.rs:208:
 /// with the gyld leg on does.
 fn both_registered(grazel: &AppDecl, gyld: &AppDecl) -> Registry {
     let mut reg = Registry::new();
-    assert_eq!(register(grazel, &mut reg, ORIGIN).unwrap(), Registered { appended: 12, unchanged: 0 });
-    assert_eq!(register(gyld, &mut reg, ORIGIN).unwrap(), Registered { appended: 11, unchanged: 2 });
+    assert_eq!(
+        register(grazel, &mut reg, ORIGIN).unwrap(),
+        Registered {
+            appended: 12,
+            unchanged: 0
+        }
+    );
+    assert_eq!(
+        register(gyld, &mut reg, ORIGIN).unwrap(),
+        Registered {
+            appended: 11,
+            unchanged: 2
+        }
+    );
     reg
 }
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/tests/binding_census.rs:224:
     assert_eq!(reg.bindings_of(), declared(&[&grazel, &gyld]));
     assert_eq!(reg.bindings_of().len(), 16);
     assert_eq!(retracted(&reg), vec![]);
-    assert!(ops_of(&reg).iter().all(|o| o.glade_id != G_BINDING_RETRACTIONS), "no retraction record");
+    assert!(
+        ops_of(&reg)
+            .iter()
+            .all(|o| o.glade_id != G_BINDING_RETRACTIONS),
+        "no retraction record"
+    );
 }
 
 /// §4.7 row 10, second test: the next boot loads grazel-app.glade alone
Diff in /Volumes/projects/limbo/glade-wz/glade/node/tests/binding_census.rs:236:
     let (grazel, gyld) = (parse(&grazel).unwrap(), parse(&gyld).unwrap());
     let before = both_registered(&grazel, &gyld).snapshot();
     let (mut reg, _) = Registry::from_snapshot(&before);
-    assert_eq!(register(&grazel, &mut reg, ORIGIN).unwrap(), Registered { appended: 0, unchanged: 12 });
+    assert_eq!(
+        register(&grazel, &mut reg, ORIGIN).unwrap(),
+        Registered {
+            appended: 0,
+            unchanged: 12
+        }
+    );
     assert_eq!(reg.snapshot(), before, "nothing appended");
-    let gyld_live: Vec<BindingDecl> = reg.bindings_of().into_iter().filter(|b| b.app == "gyld").collect();
+    let gyld_live: Vec<BindingDecl> = reg
+        .bindings_of()
+        .into_iter()
+        .filter(|b| b.app == "gyld")
+        .collect();
     assert_eq!(gyld_live, declared(&[&gyld]), "gyld's 9 untouched");
     assert_eq!(gyld_live.len(), 9);
     assert_eq!(retracted(&reg), vec![]);
Diff in /Volumes/projects/limbo/glade-wz/glade/node/tests/binding_census.rs:257:
         .lines()
         .filter(|line| !line.split_whitespace().take(2).eq(["binding", "gyld.file"]))
         .collect();
-    assert_eq!(edited.len(), gyld.lines().count() - 1, "exactly one line deleted");
+    assert_eq!(
+        edited.len(),
+        gyld.lines().count() - 1,
+        "exactly one line deleted"
+    );
     let edited = parse(&(edited.join("\n") + "\n")).unwrap();
 
     let mut reg = reboot(&reg);
Diff in /Volumes/projects/limbo/glade-wz/glade/node/tests/binding_census.rs:264:
-    assert_eq!(register(&grazel_decl, &mut reg, ORIGIN).unwrap(), Registered { appended: 0, unchanged: 12 });
+    assert_eq!(
+        register(&grazel_decl, &mut reg, ORIGIN).unwrap(),
+        Registered {
+            appended: 0,
+            unchanged: 12
+        }
+    );
     // the retraction is gyld's one append; its 8 bindings, service, 2 seeds
     // and workspace are unchanged
-    assert_eq!(register(&edited, &mut reg, ORIGIN).unwrap(), Registered { appended: 1, unchanged: 12 });
-    assert_eq!(retracted(&reg), vec![("gyld".to_string(), "gyld.file".to_string())]);
+    assert_eq!(
+        register(&edited, &mut reg, ORIGIN).unwrap(),
+        Registered {
+            appended: 1,
+            unchanged: 12
+        }
+    );
+    assert_eq!(
+        retracted(&reg),
+        vec![("gyld".to_string(), "gyld.file".to_string())]
+    );
     assert_eq!(reg.bindings_of(), declared(&[&grazel_decl, &edited]));
     assert_eq!(reg.bindings_of().len(), 15);
-    let retractions = ops_of(&reg).iter().filter(|o| o.glade_id == G_BINDING_RETRACTIONS).count();
+    let retractions = ops_of(&reg)
+        .iter()
+        .filter(|o| o.glade_id == G_BINDING_RETRACTIONS)
+        .count();
     assert_eq!(retractions, 1);
 }
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/tests/shipped_app_files.rs:38:
 /// The number of `text`'s header line: its first line that is not blank or
 /// a comment, as `parse` finds it.
 fn header_at(text: &str) -> usize {
-    let at = text.lines().position(|line| !line.split('#').next().unwrap_or("").trim().is_empty());
+    let at = text
+        .lines()
+        .position(|line| !line.split('#').next().unwrap_or("").trim().is_empty());
     at.expect("a header line") + 1
 }
 
Diff in /Volumes/projects/limbo/glade-wz/glade/node/tests/shipped_app_files.rs:49:
     let lines: Vec<&str> = text
         .lines()
         .enumerate()
-        .map(|(i, line)| {
-            if i + 1 == at {
-                header
-            } else {
-                line
-            }
-        })
+        .map(|(i, line)| if i + 1 == at { header } else { line })
         .collect();
     lines.join("\n") + "\n"
 }
Diff in /Volumes/projects/limbo/glade-wz/glade/node/tests/shipped_app_files.rs:62:
 
 #[test]
 fn every_shipped_file_loads_with_no_warning() {
-    let missing: Vec<String> =
-        SHIPPED.iter().map(|rel| path(rel)).filter(|p| !p.is_file()).map(|p| p.display().to_string()).collect();
+    let missing: Vec<String> = SHIPPED
+        .iter()
+        .map(|rel| path(rel))
+        .filter(|p| !p.is_file())
+        .map(|p| p.display().to_string())
+        .collect();
     assert!(
         missing.is_empty(),
         "this test reads the census's app files from four repositories of the glade-wz workspace, \
Diff in /Volumes/projects/limbo/glade-wz/glade/node/tests/shipped_app_files.rs:87:
         // the header's, on its line.
         let v0 = parse(&headed(&text, "glade-app v0")).unwrap();
         assert_eq!(v0.version, AppFileVersion::V0, "{rel}");
-        let warning = format!("line {at}: header `glade-app v0` names the old language; write `glade-app v1`");
+        let warning = format!(
+            "line {at}: header `glade-app v0` names the old language; write `glade-app v1`"
+        );
         assert_eq!(v0.warnings, [warning], "{rel}");
-        assert_eq!(v0.bindings, decl.bindings, "{rel}: the header moves no declaration");
+        assert_eq!(
+            v0.bindings, decl.bindings,
+            "{rel}: the header moves no declaration"
+        );
     }
 }
 

```

## B2 final affected node actual configured factory and retained default consumers
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--test', 'ic3_auth', '--test', 'ic3_boundary', '--test', 'ic3_disk', '--test', 'assembly']
Exit: 0; wall: 10.080s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 5.84s
     Running tests/assembly/main.rs (glade/node/target/debug/deps/assembly-3721822e7bd6d1d9)

running 30 tests
test conformance::cl_002_the_fake_clock_reads_epoch_milliseconds ... ok
test conformance::cl_001_the_fake_clock_is_one_instant_behind_every_handle ... ok
test conformance::cl_002_the_system_clock_reads_epoch_milliseconds ... ok
test conformance::gr_001_the_in_memory_fold_matches_exactly ... ok
test conformance::ca_005_the_fake_network_names_each_far_end ... ok
test conformance::ca_001_the_fake_network_carries_frames_whole_once_and_in_order ... ok
test conformance::ca_003_the_fake_networks_futures_are_lazy_and_recv_is_cancel_safe ... ok
test conformance::ca_004_a_fake_port_gives_its_endpoint_up_by_value ... ok
test conformance::ca_002_the_fake_network_holds_the_frame_limit_both_ways ... ok
test conformance::gr_002_in_the_in_memory_fold_revocation_wins_in_either_order ... ok
test conformance::gr_003_an_unreadable_in_memory_fold_is_unavailable ... ok
test conformance::si_003_the_keyed_test_signer_refuses_without_key_material ... ok
test conformance::si_002_the_keyed_test_signer_binds_bytes_purpose_and_signer ... ok
test conformance::si_001_the_keyed_test_signer_round_trips_every_purpose ... ok
test conformance::ca_006_the_fake_network_binds_each_link_to_its_session ... ok
test conformance::gr_003_the_grant_fold_the_module_builds_is_unavailable ... ok
test conformance::si_003_the_node_signer_without_a_key_refuses_both_ways ... ok
test one_grant_selection_reaches_admission ... ok
test each_carrier_role_is_its_own_occurrence_and_the_record_transport_rides_the_peer_one ... ok
test a_test_composition_constructs_no_real_provider ... ok
test one_scope_hands_out_one_occurrence_of_every_binding ... ok
test the_directory_profile_hosts_every_directory_record_kind_and_nothing_else ... ok
test a_concurrent_first_access_of_a_lazy_binding_constructs_once_per_scope ... ok
test conformance::si_002_the_node_signer_binds_bytes_purpose_and_signer ... ok
test records_refuse_an_op_outside_the_directory_profile_before_verifying_it ... ok
test one_clock_substitution_reaches_the_directory_and_admission ... ok
test conformance::si_001_the_node_signer_round_trips_every_purpose ... ok
test sibling_scopes_share_nothing_and_meet_only_through_the_network ... ok
test conformance::gr_001_to_003_the_nodes_grant_fold_keeps_the_grant_contract ... ok
test one_record_host_selection_reaches_the_directory ... ok

test result: ok. 30 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/ic3_auth.rs (glade/node/target/debug/deps/ic3_auth-e1bc2d4362c83d32)

running 16 tests
test provider_observation_is_genuine_current_signed_policy_and_owned_clock ... ok
test genuine_historical_admission_verifies_exact_scoped_signed_records ... ok
test bad_signature_wrong_domain_or_altered_namespace_are_invalid ... ok
test ic3_auth_extra::strict_ed25519_refuses_small_order_writer_and_changed_domain ... ok
test genuine_overlimit_operation_is_refused_before_payload_interpretation ... ok
test every_local_verification_requires_new_possession_not_operation_cache_reuse ... ok
test ic3_auth_extra::bare_signed_rival_does_not_convict_but_original_signed_admission_qualifies ... ok
test root_signature_does_not_authorize_an_unsupported_merge_corpus ... ok
test ic3_auth_extra::distinct_fresh_origin_qualifies_but_reused_origin_epoch_or_issuance_refuses ... ok
test released_payload_duplicate_properties_remain_supported ... ok
test local_possession_seal_and_foreign_or_replayed_session_controls ... ok
test signed_invalid_payload_is_authenticated_security_data_not_qualified_admission ... ok
test trusted_source_cannot_regress_observed_clock_or_policy_floor ... ok
test ic3_auth_extra::all_evidence_layers_reject_validly_signed_changed_bindings_or_wrong_keys ... ok
test uncertain_expired_or_revoked_current_cut_does_not_change_historical_validity ... ok
test genuine_provider_matches_shared_released_text_syntax_rows ... ok

test result: ok. 16 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.04s

     Running tests/ic3_boundary.rs (glade/node/target/debug/deps/ic3_boundary-330d971e6f6496b5)

running 6 tests
test standalone_refuser_has_no_fabricated_validated_image ... ok
test standalone_refuser_never_issues_a_consume_permit ... ok
test standalone_refuser_rejects_caller_created_permit_before_callback ... ok
test consumer_detects_recovery_selection_mutant_instead_of_discarding_host ... ok
test actual_assembled_evidence_verify_seal_and_observe_refuse ... ok
test production_composition_recovers_a_genuinely_persistent_validated_image ... ok

test result: ok. 6 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.06s

     Running tests/ic3_disk.rs (glade/node/target/debug/deps/ic3_disk-79b05533cd314114)

running 7 tests
test genuine_fresh_replica_opens_owned_validated_genesis_and_reopens_same_identity ... ok
test actual_owned_begin_precedes_factory_and_active_guard_suppresses_complete_cut ... ok
test genuine_challenge_response_custody_and_consumption_survive_owned_reopen ... ok
test finite_authenticated_empty_round_settles_exact_observation_and_never_started_abandons ... ok
test actual_storage_attempt_host_narrow_open_preserves_replica_created_namespace_and_owner ... ok
test actual_native_attempt_provider_recovers_and_returns_immutable_terminal_for_exact_request ... ok
test actual_genuine_local_commit_persists_owned_callback_history_and_exact_original_receipt ... ok

test result: ok. 7 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.23s


```

## B2 accepted data-only rollback and missing trusted floor actual full host refusal
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--test', 'ic3_disk', 'trusted_floor_refuses', '--', '--nocapture']
Exit: 0; wall: 1.906s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.81s
     Running tests/ic3_disk.rs (glade/node/target/debug/deps/ic3_disk-79b05533cd314114)

running 1 test
test trusted_floor_refuses_data_only_rollback_and_missing_floor_after_real_local_commit ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 7 filtered out; finished in 0.45s


```

## B2 final complete physical host process cuts after source module path correction
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'independent::records::tests', '--', '--nocapture']
Exit: 0; wall: 109.196s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 7.12s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 30 tests
test independent::records::tests::content::controls::genuine_ordinary_policy_observation_cannot_consume_preallocated_critical_region ... ok
test independent::records::tests::content::ingress::failed_guard_establishment_never_returns_a_consumable_owned_permit ... ok
test independent::records::tests::content::ingress::exact_selected_permanent_ingress_loss_is_validated_but_never_complete ... ok
test independent::records::tests::content::ingress::drained_partial_receive_can_retain_loss_and_close_without_false_complete_on_restart ... ok
test independent::records::tests::content::ingress::record_observation_resumes_only_exact_owned_drained_refused_continuation ... ok
test independent::records::tests::content::ingress::unknown_abandon_retains_unretired_owned_permit_until_durable_selection ... ok
test independent::records::tests::content::ingress::unknown_settlement_keeps_exact_owned_observation_and_failed_loss_write_keeps_floor_guard ... ok
test independent::records::tests::content::ingress_capacity::admitted_guard_critical_loss_can_settle_when_ordinary_image_region_is_full ... ok
test independent::records::tests::content::ingress_cuts::ingress_cut_child ... ignored, owned real guard process child
test independent::records::tests::content::controls::original_verified_continuation_rejects_mutated_facts_before_load ... ok
test independent::records::tests::content::controls::unavailable_verification_retains_provider_observed_floor_before_reply ... ok
test independent::records::tests::content::fences::close_retains_actual_reserved_plan_and_stops_new_input_until_original_callback_drains ... ok
test independent::records::tests::content::fences::actual_reserved_fence_wins_and_late_exact_or_contrary_callbacks_never_reopen_terminal ... ok
test independent::records::tests::content::native_cuts::native_cut_child ... ignored, owned child of authenticated native cut qualification
test independent::records::tests::content::controls::full_selected_state_refuses_omitted_terminal_request_and_mutated_projection ... ok
test independent::records::tests::content::observation_restart::observation_floor_child ... ignored, owned child of genuine observation floor-ahead witness
test independent::records::tests::content::controls::structurally_valid_pending_next_with_bad_authenticated_state_refuses_before_floor_selection ... ok
test independent::records::tests::content::controls::durable_current_expiry_floor_preserves_historical_original_receipt_and_projection ... ok
test independent::records::tests::content::restart::terminal_before_callback_child ... ignored, owned child of genuine native terminal restart witness
test independent::records::tests::content::fences::actual_killed_protected_started_cut_commits_original_receipt_despite_current_revocation ... ok
test independent::records::tests::content::observation_restart::actual_process_kill_keeps_new_observed_floor_and_recovers_old_valid_pending_image ... ok
test independent::records::tests::content::ingress_capacity::guard_history_and_critical_discharge_reservation_refuse_before_new_consumption ... ok
test independent::records::tests::content::restart::actual_process_kill_recovers_original_owned_seal_continuation_without_new_link_authority ... ok
test independent::records::tests::content::ingress_cancellation::owned_cancel_is_joined_before_loss_close_and_x_cannot_block_independent_y ... ok
test independent::records::tests::content::kinds::genuine_already_accepted_fork_proof_keeps_original_zero_new_receipt_batch_shape ... ok
test independent::records::tests::content::restart::actual_process_kill_recovers_selected_terminal_through_original_core_callback_before_load ... ok
test independent::records::tests::content::kinds::all_four_genuine_native_kinds_couple_original_custody_and_reopen_projection ... ok
test independent::records::tests::content::ingress_cuts::actual_process_kill_guard_begin_settle_abandon_loss_and_consumed_prefix_reopen_honestly ... ok
test independent::records::tests::content::native_cuts::actual_signed_host_process_kill_reopens_prepare_started_and_terminal_cuts ... ok
test independent::records::tests::content::native_cuts::actual_signed_candidate_security_and_fork_native_kinds_171_os_cuts has been running for over 60 seconds
test independent::records::tests::content::native_cuts::actual_signed_candidate_security_and_fork_native_kinds_171_os_cuts ... ok

test result: ok. 26 passed; 0 failed; 4 ignored; 0 measured; 382 filtered out; finished in 101.07s


```

## B2 syntax-owned public consumer cohesion move preserves all8 assertions
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--test', 'ic3_disk', '--', '--nocapture']
Exit: 0; wall: 2.711s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.80s
     Running tests/ic3_disk.rs (glade/node/target/debug/deps/ic3_disk-79b05533cd314114)

running 8 tests
test actual_owned_begin_precedes_factory_and_active_guard_suppresses_complete_cut ... ok
test genuine_fresh_replica_opens_owned_validated_genesis_and_reopens_same_identity ... ok
test genuine_challenge_response_custody_and_consumption_survive_owned_reopen ... ok
test finite_authenticated_empty_round_settles_exact_observation_and_never_started_abandons ... ok
test ic3_disk_native::actual_storage_attempt_host_narrow_open_preserves_replica_created_namespace_and_owner ... ok
test ic3_disk_native::actual_native_attempt_provider_recovers_and_returns_immutable_terminal_for_exact_request ... ok
test ic3_disk_native::trusted_floor_refuses_data_only_rollback_and_missing_floor_after_real_local_commit ... ok
test ic3_disk_native::actual_genuine_local_commit_persists_owned_callback_history_and_exact_original_receipt ... ok

test result: ok. 8 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.26s


```

## B2 final source all disabled scopes and recovery utility consumer gates
Command: ['cargo', 'test', '--manifest-path', 'glade/contracts/Cargo.toml', '--locked', '--offline', '-p', 'glade-crdt-recovery-api', '--test', 'source_boundaries']
Exit: 0; wall: 0.225s
```text
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.08s
     Running tests/source_boundaries.rs (glade/contracts/target/debug/deps/source_boundaries-d87c63d050de1dbe)

running 4 tests
test checks_disabled_branch_instead_of_skipping_cfg ... ok
test disabled_associated_foreign_and_field_declarations_are_checked ... ok
test tranche_sources_have_explicit_conditional_boundaries ... ok
test actual_node_independent_subtree_and_disabled_branches_are_checked ... ok

test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.11s


```

## B2 final source adoption and process globals no allowlist relaxation
Command: ['python3', 'glade/scripts/checks/check_process_globals.py', '--repo', 'glade']
Exit: 0; wall: 0.655s
```text
process-global state guard: 148 files, 3 allowlisted items (0 debt, 3 permanent); nothing new

```

## B2 final adopted architecture normal pure core edge
Command: ['cargo', 'run', '--quiet', '--locked', '--offline', '--manifest-path', 'glade-discover/tools/architecture-check/Cargo.toml', '--', 'glade/node']
Exit: 0; wall: 0.961s
```text
Architecture boundaries: PASS (workspace libraries, declared dependencies, traits and conformance targets)

```

## B2 exact legacy executable refuses fresh compatibility marker final
Command: ['cargo', 'test', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '--lib', 'independent::disk::tests::actual_committed_legacy_executable_refuses_the_disposable_ic3_root', '--', '--exact', '--ignored', '--nocapture']
Exit: 0; wall: 8.614s
```text
   Compiling glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 7.53s
     Running unittests src/lib.rs (glade/node/target/debug/deps/glade_node-034b6043dd3c1c5f)

running 1 test
test independent::disk::tests::actual_committed_legacy_executable_refuses_the_disposable_ic3_root ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 411 filtered out; finished in 0.05s


```

## B2 final node all-target clippy retained9 old warnings
Command: ['cargo', 'clippy', '--manifest-path', 'glade/node/Cargo.toml', '--locked', '--offline', '-p', 'glade-node', '--all-targets', '--all-features']
Exit: 0; wall: 9.570s
```text
    Blocking waiting for file lock on build directory
    Checking glade-node v0.0.0 (/Volumes/projects/limbo/glade-wz/glade/node)
warning: this can be `std::io::Error::other(_)`
   --> src/claims.rs:138:5
    |
138 |     io::Error::new(io::ErrorKind::Other, e)
    |     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    |
    = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
    = note: `#[warn(clippy::io_other_error)]` on by default
help: use `std::io::Error::other`
    |
138 -     io::Error::new(io::ErrorKind::Other, e)
138 +     io::Error::other(e)
    |

warning: this can be `std::io::Error::other(_)`
  --> src/exchange.rs:53:5
   |
53 |     io::Error::new(io::ErrorKind::Other, e)
   |     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
   |
   = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
help: use `std::io::Error::other`
   |
53 -     io::Error::new(io::ErrorKind::Other, e)
53 +     io::Error::other(e)
   |

warning: this can be `std::io::Error::other(_)`
  --> src/iroh_carrier.rs:68:5
   |
68 |     io::Error::new(io::ErrorKind::Other, e)
   |     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
   |
   = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
help: use `std::io::Error::other`
   |
68 -     io::Error::new(io::ErrorKind::Other, e)
68 +     io::Error::other(e)
   |

warning: this can be `std::io::Error::other(_)`
  --> src/mesh.rs:63:5
   |
63 |     io::Error::new(io::ErrorKind::Other, e)
   |     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
   |
   = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
help: use `std::io::Error::other`
   |
63 -     io::Error::new(io::ErrorKind::Other, e)
63 +     io::Error::other(e)
   |

warning: this can be `std::io::Error::other(_)`
   --> src/server.rs:458:18
    |
458 |         other => std::io::Error::new(std::io::ErrorKind::Other, format!("{other:?}")),
    |                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    |
    = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#io_other_error
help: use `std::io::Error::other`
    |
458 -         other => std::io::Error::new(std::io::ErrorKind::Other, format!("{other:?}")),
458 +         other => std::io::Error::other(format!("{other:?}")),
    |

warning: doc list item without indentation
 --> src/ws.rs:3:5
  |
3 | //! (which is text-only) for **binary** frames: glade carries CBOR, not text.
  |     ^
  |
  = help: if this is supposed to be its own paragraph, add a blank line
  = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#doc_lazy_continuation
  = note: `#[warn(clippy::doc_lazy_continuation)]` on by default
help: indent this line
  |
3 | //!   (which is text-only) for **binary** frames: glade carries CBOR, not text.
  |     ++

warning: doc list item without indentation
 --> src/ws.rs:4:5
  |
4 | //! Enough to talk to a browser/Node WebSocket: the upgrade handshake, masked
  |     ^
  |
  = help: if this is supposed to be its own paragraph, add a blank line
  = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#doc_lazy_continuation
help: indent this line
  |
4 | //!   Enough to talk to a browser/Node WebSocket: the upgrade handshake, masked
  |     ++

warning: doc list item without indentation
 --> src/ws.rs:5:5
  |
5 | //! client->server and unmasked server->client binary frames; close surfaced;
  |     ^
  |
  = help: if this is supposed to be its own paragraph, add a blank line
  = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#doc_lazy_continuation
help: indent this line
  |
5 | //!   client->server and unmasked server->client binary frames; close surfaced;
  |     ++

warning: doc list item without indentation
 --> src/ws.rs:6:5
  |
6 | //! ping/pong skipped (trusted localhost).
  |     ^
  |
  = help: if this is supposed to be its own paragraph, add a blank line
  = help: for further information visit https://rust-lang.github.io/rust-clippy/rust-1.96.0/index.html#doc_lazy_continuation
help: indent this line
  |
6 | //!   ping/pong skipped (trusted localhost).
  |     ++

warning: `glade-node` (lib) generated 9 warnings (run `cargo clippy --fix --lib -p glade-node -- ` to apply 5 suggestions)
warning: `glade-node` (lib test) generated 9 warnings (9 duplicates)
    Finished `dev` profile [unoptimized + debuginfo] target(s) in 9.51s

```

## B2 preserved adopting ARCH002 node negative normal and disabled target edge
Command: ['sh', 'glade/node/arch002-fixture.sh']
Exit: 0; wall: 2.363s
```text
  refused an ordinary dependency: ARCH-002 glade-node: undeclared dependency normal:dill
  refused a cfg(windows) dependency: ARCH-002 glade-node: undeclared dependency normal:dill
ARCH-002 fixture: the gate refused dill injected into glade-node, in both cases

```

## B2 preserved adopting ARCH002 contract framework refusal
Command: ['sh', 'glade/contracts/arch002-fixture.sh']
Exit: 0; wall: 7.190s
```text
  refused: ARCH-002 glade-persistence-api: undeclared dependency normal:shaku
  refused: ARCH-002 glade-binding-api: undeclared dependency normal:shaku
  refused: ARCH-002 glade-invocation-api: undeclared dependency normal:shaku
  refused: ARCH-002 glade-subscription-api: undeclared dependency normal:shaku
  refused: ARCH-002 glade-sync-api: undeclared dependency normal:shaku
  refused: ARCH-002 glade-lifecycle-api: undeclared dependency normal:shaku
  refused: ARCH-002 glade-carrier-api: undeclared dependency normal:shaku
  refused: ARCH-002 glade-clock-api: undeclared dependency normal:shaku
  refused: ARCH-002 glade-grant-api: undeclared dependency normal:shaku
  refused: ARCH-002 glade-signer-api: undeclared dependency normal:shaku
  refused: ARCH-002 glade-crdt-admission-core: undeclared dependency normal:shaku
  refused: ARCH-002 glade-crdt-storage-attempt-api: undeclared dependency normal:shaku
  refused: ARCH-002 glade-crdt-admission-data: undeclared dependency normal:shaku
  refused: ARCH-002 glade-crdt-evidence-api: undeclared dependency normal:shaku
  refused: ARCH-002 glade-crdt-recovery-api: undeclared dependency normal:shaku
  refused: ARCH-002 glade-crdt-recovery-codec: undeclared dependency normal:shaku
ARCH-002 fixture: the gate refused the injected framework dependency in all 16 classified libraries

```

## B2 exact affected-file formatting node/
Command: ['rustfmt', '--check', '--edition', '2021', '--config', 'skip_children=true', 'glade/node/src/assembly.rs', 'glade/node/src/independent/auth.rs', 'glade/node/src/independent/auth/custody.rs', 'glade/node/src/independent/disk.rs', 'glade/node/src/independent/disk/floors.rs', 'glade/node/src/independent/disk/metadata.rs', 'glade/node/src/independent/disk/paired.rs', 'glade/node/src/independent/disk/paired/tests.rs', 'glade/node/src/independent/disk/paired/tests/process.rs', 'glade/node/src/independent/disk/paired/validation.rs', 'glade/node/src/independent/disk/slots.rs', 'glade/node/src/independent/mod.rs', 'glade/node/src/independent/records.rs', 'glade/node/src/independent/records/authentication.rs', 'glade/node/src/independent/records/bindings.rs', 'glade/node/src/independent/records/evidence_recovery.rs', 'glade/node/src/independent/records/genesis.rs', 'glade/node/src/independent/records/guards.rs', 'glade/node/src/independent/records/host.rs', 'glade/node/src/independent/records/loss.rs', 'glade/node/src/independent/records/observations.rs', 'glade/node/src/independent/records/persist.rs', 'glade/node/src/independent/records/reserves.rs', 'glade/node/src/independent/records/runtime.rs', 'glade/node/src/independent/records/storage.rs', 'glade/node/src/independent/records/tests.rs', 'glade/node/src/independent/records/tests/controls.rs', 'glade/node/src/independent/records/tests/fences.rs', 'glade/node/src/independent/records/tests/ingress.rs', 'glade/node/src/independent/records/tests/ingress_cancellation.rs', 'glade/node/src/independent/records/tests/ingress_capacity.rs', 'glade/node/src/independent/records/tests/ingress_cuts.rs', 'glade/node/src/independent/records/tests/kinds.rs', 'glade/node/src/independent/records/tests/native_cuts.rs', 'glade/node/src/independent/records/tests/observation_restart.rs', 'glade/node/src/independent/records/tests/restart.rs', 'glade/node/src/independent/records/validation.rs', 'glade/node/src/lib.rs', 'glade/node/tests/ic3_boundary.rs', 'glade/node/tests/ic3_disk.rs', 'glade/node/tests/ic3_disk_fixture/mod.rs', 'glade/node/tests/ic3_disk_native/mod.rs']
Exit: 0; wall: 0.083s; files:42
```text

```

## B2 exact affected-file formatting contracts/
Command: ['rustfmt', '--check', '--edition', '2024', '--config', 'skip_children=true', 'glade/contracts/crdt-recovery-api/src/ingress.rs', 'glade/contracts/crdt-recovery-api/tests/public_contract.rs']
Exit: 0; wall: 0.025s; files:2
```text

```
